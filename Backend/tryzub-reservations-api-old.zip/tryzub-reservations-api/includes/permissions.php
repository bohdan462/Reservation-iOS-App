<?php

// Restricts protected endpoints to authenticated users allowed to manage Tryzub reservations.
// Administrators stay allowed during development; the staff app should use a limited user with manage_tryzub_reservations.
function tryzub_can_read_reservations(WP_REST_Request $request) {
    return current_user_can('manage_tryzub_reservations') || current_user_can('manage_options');
}

// Permanent deletion is reserved for administrators/developers. Staff should use soft hide.
function tryzub_can_hard_delete_reservations(WP_REST_Request $request) {
    return current_user_can('manage_options');
}
