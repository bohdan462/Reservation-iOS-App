<?php

// Lightweight health endpoint.
// Useful during development to confirm the plugin loads, REST routing works, and the managed table exists.
// Do not expose unnecessary database details here in a final production version.
// Returns a simple JSON response to verify the API is reachable.
function tryzub_api_ping(WP_REST_Request $request) {
    $response = [
        'success' => true,
        'message' => 'Tryzub Reservations API is working',
        'time' => current_time('mysql')
    ];

    if (current_user_can('manage_tryzub_reservations') || current_user_can('manage_options')) {
        $response['table_exists'] = tryzub_reservations_table_exists();
    }

    return rest_ensure_response($response);
}
