<?php

// Plugin activation callback.
// Creates or updates the custom managed reservations table.
// This does not run on every page load; it runs when the plugin is activated.
//MARK: - Activation Functions
function tryzub_reservations_activate() {
    tryzub_create_reservations_table();
    tryzub_create_intelligence_cache_table();
    tryzub_create_reservation_import_failures_table();
    tryzub_create_reservation_duplicate_imports_table();
    tryzub_create_reservation_deletion_audit_table();
    tryzub_create_reservation_guest_tokens_table();
    tryzub_create_reservation_guest_requests_table();
    tryzub_create_reservation_emails_table();
    tryzub_create_reservation_messages_table();
    tryzub_create_restaurant_settings_table();
    tryzub_create_restaurant_weekly_hours_table();
    tryzub_create_restaurant_special_hours_table();
    tryzub_create_restaurant_blocked_slots_table();
    tryzub_create_restaurant_tables_table();
    tryzub_create_reservation_table_assignments_table();
    tryzub_create_reservation_activity_table();
    tryzub_create_guest_profiles_table();
    tryzub_register_reservations_capabilities();
    tryzub_schedule_reservation_reminders();
    tryzub_schedule_bi_daily_precompute();
    tryzub_schedule_guest_profiles_rebuild();

    if (tryzub_reservations_table_exists()) {
        update_option('tryzub_reservations_db_version', tryzub_get_reservations_db_version());
    }
}

// Runs lightweight schema upgrades for already-active installs after a plugin update.
function tryzub_maybe_upgrade_reservations_table() {
    $current_version = get_option('tryzub_reservations_db_version');

    if ($current_version === tryzub_get_reservations_db_version() && tryzub_reservations_table_exists()) {
        return;
    }

    tryzub_create_reservations_table();
    tryzub_create_intelligence_cache_table();
    tryzub_create_reservation_import_failures_table();
    tryzub_create_reservation_duplicate_imports_table();
    tryzub_create_reservation_deletion_audit_table();
    tryzub_create_reservation_guest_tokens_table();
    tryzub_create_reservation_guest_requests_table();
    tryzub_create_reservation_emails_table();
    tryzub_create_reservation_messages_table();
    tryzub_create_restaurant_settings_table();
    tryzub_create_restaurant_weekly_hours_table();
    tryzub_create_restaurant_special_hours_table();
    tryzub_create_restaurant_blocked_slots_table();
    tryzub_create_restaurant_tables_table();
    tryzub_create_reservation_table_assignments_table();
    tryzub_create_reservation_activity_table();
    tryzub_create_guest_profiles_table();
    tryzub_register_reservations_capabilities();
    tryzub_schedule_reservation_reminders();
    tryzub_schedule_bi_daily_precompute();
    tryzub_schedule_guest_profiles_rebuild();

    if (tryzub_reservations_table_exists()) {
        update_option('tryzub_reservations_db_version', tryzub_get_reservations_db_version());
    }
}

function tryzub_get_reservations_db_version() {
    return '1.11.0';
}

// Creates the managed reservations table.
// dbDelta is used because WordPress can compare the CREATE TABLE statement against the existing table.
// This table is the restaurant-facing source of truth for reservation status, staff notes, table assignment, and email timestamps.
//MARK: - DB Creation
function tryzub_create_reservations_table() {
    global $wpdb;

    $table_name = tryzub_get_reservations_table_name();
    $charset_collate = $wpdb->get_charset_collate();
    // source_submission_id links imported reservations back to the original Flamingo post.
    // Manual reservations can keep this NULL unless staff is correcting a specific failed Flamingo submission.
    // MySQL allows multiple NULL values in a UNIQUE key, while still preventing duplicate real Flamingo IDs.
    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        source_submission_id BIGINT(20) UNSIGNED NULL,
        source_type VARCHAR(40) NOT NULL DEFAULT 'form',
        created_by_user_id BIGINT(20) UNSIGNED NULL,
        created_by_device VARCHAR(120) NULL,
        guest_name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(50) NOT NULL,
        reservation_date DATE NOT NULL,
        reservation_time TIME NOT NULL,
        party_size INT UNSIGNED NOT NULL DEFAULT 1,
        guest_notes TEXT NULL,
        staff_notes TEXT NULL,
        status VARCHAR(50) NOT NULL DEFAULT 'new',
        table_name VARCHAR(100) NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NULL,
        confirmed_at DATETIME NULL,
        seated_at DATETIME NULL,
        completed_at DATETIME NULL,
        confirmation_email_sent_at DATETIME NULL,
        reminder_email_sent_at DATETIME NULL,
        superseded_by_id BIGINT(20) UNSIGNED NULL,
        is_hidden TINYINT(1) NOT NULL DEFAULT 0,
        hidden_at DATETIME NULL,
        hidden_reason TEXT NULL,
        hidden_by_user_id BIGINT(20) UNSIGNED NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY source_submission_id (source_submission_id),
        KEY source_type (source_type),
        KEY created_by_user_id (created_by_user_id),
        KEY is_hidden (is_hidden),
        KEY reservation_date (reservation_date),
        KEY reservation_time (reservation_time),
        KEY status (status),
        KEY created_at (created_at),
        KEY updated_at (updated_at),
        KEY superseded_by_id (superseded_by_id),
        KEY email (email),
        KEY phone (phone),
        KEY reservation_date_status (reservation_date, status),
        KEY reservation_date_hidden (reservation_date, is_hidden),
        KEY reservation_date_status_hidden (reservation_date, status, is_hidden),
        KEY reservation_date_time (reservation_date, reservation_time)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
    tryzub_allow_nullable_source_submission_id();
    tryzub_ensure_reservation_idempotency_columns();
    tryzub_ensure_reservation_lifecycle_columns();
    tryzub_ensure_intelligence_performance_indexes();
    tryzub_backfill_reservation_schema_defaults();
}

function tryzub_create_intelligence_cache_table() {
    global $wpdb;

    $table_name = tryzub_get_intelligence_cache_table_name();
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        cache_group VARCHAR(64) NOT NULL DEFAULT 'business_intelligence',
        cache_key VARCHAR(191) NOT NULL,
        range_key VARCHAR(64) NOT NULL,
        range_from DATE NOT NULL,
        range_to DATE NOT NULL,
        generated_date DATE NOT NULL,
        cache_version INT UNSIGNED NOT NULL DEFAULT 1,
        payload_json LONGTEXT NOT NULL,
        compute_duration_ms INT UNSIGNED NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY cache_key (cache_key),
        KEY group_generated_date (cache_group, generated_date),
        KEY range_preset_date (range_key, generated_date)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

// Adds the lifecycle timestamp columns used for seated/completed transitions on already-active installs.
function tryzub_ensure_reservation_lifecycle_columns() {
    $table_name = tryzub_get_reservations_table_name();

    tryzub_add_table_column_if_missing($table_name, 'seated_at', 'seated_at DATETIME NULL AFTER confirmed_at');
    tryzub_add_table_column_if_missing($table_name, 'completed_at', 'completed_at DATETIME NULL AFTER seated_at');
}

function tryzub_ensure_intelligence_performance_indexes() {
    $table_name = tryzub_get_reservations_table_name();

    tryzub_add_table_index_if_missing(
        $table_name,
        'reservation_date_hidden_superseded',
        'KEY reservation_date_hidden_superseded (reservation_date, is_hidden, superseded_by_id)'
    );
    tryzub_add_table_index_if_missing(
        $table_name,
        'email_reservation_date',
        'KEY email_reservation_date (email, reservation_date)'
    );
    tryzub_add_table_index_if_missing(
        $table_name,
        'phone_reservation_date',
        'KEY phone_reservation_date (phone, reservation_date)'
    );
    tryzub_add_table_index_if_missing(
        $table_name,
        'source_type_reservation_date',
        'KEY source_type_reservation_date (source_type, reservation_date)'
    );
    tryzub_add_table_index_if_missing(
        $table_name,
        'status_reservation_date',
        'KEY status_reservation_date (status, reservation_date)'
    );
}

function tryzub_ensure_reservation_idempotency_columns() {
    $table_name = tryzub_get_reservations_table_name();

    $columns = [
        'client_request_id' => 'client_request_id VARCHAR(191) NULL',
        'submission_fingerprint' => 'submission_fingerprint CHAR(64) NULL',
        'duplicate_of_reservation_id' => 'duplicate_of_reservation_id BIGINT(20) UNSIGNED NULL',
        'duplicate_reason' => 'duplicate_reason VARCHAR(100) NULL',
    ];

    foreach ($columns as $column_name => $column_sql) {
        tryzub_add_table_column_if_missing($table_name, $column_name, $column_sql);
    }

    tryzub_add_table_index_if_missing($table_name, 'client_request_id', 'KEY client_request_id (client_request_id)');
    tryzub_add_table_index_if_missing($table_name, 'submission_fingerprint', 'KEY submission_fingerprint (submission_fingerprint)');
    tryzub_add_table_index_if_missing($table_name, 'duplicate_of_reservation_id', 'KEY duplicate_of_reservation_id (duplicate_of_reservation_id)');
}

function tryzub_create_reservation_import_failures_table() {
    global $wpdb;

    $table_name = tryzub_get_import_failures_table_name();
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        source_submission_id BIGINT(20) UNSIGNED NULL,
        error_code VARCHAR(100) NULL,
        error_message TEXT NOT NULL,
        reservation_snapshot_json LONGTEXT NULL,
        raw_fields_json LONGTEXT NULL,
        raw_payload_json LONGTEXT NULL,
        submission_status VARCHAR(50) NULL,
        status VARCHAR(30) NOT NULL DEFAULT 'open',
        staff_notes TEXT NULL,
        submitted_at DATETIME NULL,
        submitted_at_gmt DATETIME NULL,
        resolved_at DATETIME NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY source_submission_id (source_submission_id),
        KEY status (status),
        KEY created_at (created_at),
        KEY submitted_at (submitted_at)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

function tryzub_create_reservation_duplicate_imports_table() {
    global $wpdb;

    $table_name = tryzub_get_reservation_duplicate_imports_table_name();
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        source_submission_id BIGINT(20) UNSIGNED NULL,
        existing_reservation_id BIGINT(20) UNSIGNED NOT NULL,
        duplicate_reason VARCHAR(100) NOT NULL,
        client_request_id VARCHAR(191) NULL,
        submission_fingerprint CHAR(64) NULL,
        reservation_snapshot_json LONGTEXT NULL,
        raw_fields_json LONGTEXT NULL,
        raw_payload_json LONGTEXT NULL,
        created_at DATETIME NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY source_submission_id (source_submission_id),
        KEY existing_reservation_id (existing_reservation_id),
        KEY duplicate_reason (duplicate_reason),
        KEY client_request_id (client_request_id),
        KEY submission_fingerprint (submission_fingerprint),
        KEY created_at (created_at)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

function tryzub_create_reservation_deletion_audit_table() {
    global $wpdb;

    $table_name = tryzub_get_reservation_deletion_audit_table_name();
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        reservation_id BIGINT(20) UNSIGNED NOT NULL,
        source_submission_id BIGINT(20) UNSIGNED NULL,
        deleted_by_user_id BIGINT(20) UNSIGNED NULL,
        deleted_at DATETIME NOT NULL,
        reason TEXT NULL,
        reservation_snapshot_json LONGTEXT NOT NULL,
        PRIMARY KEY  (id),
        KEY reservation_id (reservation_id),
        KEY source_submission_id (source_submission_id),
        KEY deleted_by_user_id (deleted_by_user_id),
        KEY deleted_at (deleted_at)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

function tryzub_create_reservation_guest_tokens_table() {
    global $wpdb;

    $table_name = tryzub_get_reservation_guest_tokens_table_name();
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        reservation_id BIGINT(20) UNSIGNED NOT NULL,
        token_hash CHAR(64) NOT NULL,
        purpose VARCHAR(50) NOT NULL DEFAULT 'manage',
        expires_at DATETIME NOT NULL,
        created_at DATETIME NOT NULL,
        revoked_at DATETIME NULL,
        used_at DATETIME NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY token_hash (token_hash),
        KEY reservation_id (reservation_id),
        KEY purpose (purpose),
        KEY expires_at (expires_at),
        KEY revoked_at (revoked_at)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

function tryzub_create_reservation_guest_requests_table() {
    global $wpdb;

    $table_name = tryzub_get_reservation_guest_requests_table_name();
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        reservation_id BIGINT(20) UNSIGNED NOT NULL,
        request_type VARCHAR(20) NOT NULL,
        requested_payload_json LONGTEXT NULL,
        status VARCHAR(30) NOT NULL DEFAULT 'open',
        created_at DATETIME NOT NULL,
        resolved_at DATETIME NULL,
        resolved_by_user_id BIGINT(20) UNSIGNED NULL,
        PRIMARY KEY  (id),
        KEY reservation_id (reservation_id),
        KEY request_type (request_type),
        KEY status (status),
        KEY created_at (created_at)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

function tryzub_create_reservation_emails_table() {
    global $wpdb;

    $table_name = tryzub_get_reservation_emails_table_name();
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        reservation_id BIGINT(20) UNSIGNED NULL,
        email_type VARCHAR(50) NOT NULL,
        to_email VARCHAR(190) NOT NULL,
        from_email VARCHAR(190) NULL,
        reply_to_email VARCHAR(190) NULL,
        subject TEXT NULL,
        body_snapshot LONGTEXT NULL,
        provider VARCHAR(50) NULL,
        provider_message_id VARCHAR(190) NULL,
        status VARCHAR(30) NOT NULL DEFAULT 'pending',
        error_message TEXT NULL,
        sent_at DATETIME NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NULL,
        PRIMARY KEY  (id),
        KEY reservation_id (reservation_id),
        KEY email_type (email_type),
        KEY provider (provider),
        KEY status (status),
        KEY sent_at (sent_at)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

function tryzub_create_restaurant_settings_table() {
    global $wpdb;

    $table_name = tryzub_get_restaurant_settings_table_name();
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        restaurant_key VARCHAR(80) NOT NULL,
        business_name VARCHAR(190) NOT NULL,
        timezone VARCHAR(80) NOT NULL DEFAULT 'America/Chicago',
        default_party_size INT NOT NULL DEFAULT 2,
        booking_window_days INT NOT NULL DEFAULT 60,
        slot_interval_minutes INT NOT NULL DEFAULT 15,
        max_online_party_size INT NOT NULL DEFAULT 8,
        large_party_review_threshold INT NOT NULL DEFAULT 7,
        same_day_booking_enabled TINYINT(1) NOT NULL DEFAULT 1,
        minimum_lead_time_minutes INT NOT NULL DEFAULT 60,
        automatic_reminders_enabled TINYINT(1) NOT NULL DEFAULT 1,
        reminder_lead_hours INT NOT NULL DEFAULT 3,
        manual_batch_reminders_enabled TINYINT(1) NOT NULL DEFAULT 0,
        morning_reminder_time TIME NOT NULL DEFAULT '09:00:00',
        auto_confirm_enabled TINYINT(1) NOT NULL DEFAULT 0,
        auto_confirm_require_email TINYINT(1) NOT NULL DEFAULT 1,
        auto_confirm_block_guest_notes TINYINT(1) NOT NULL DEFAULT 1,
        auto_confirm_block_duplicates TINYINT(1) NOT NULL DEFAULT 1,
        auto_confirm_block_suspicious TINYINT(1) NOT NULL DEFAULT 1,
        auto_confirm_policy_json LONGTEXT NULL,
        email_daily_limit INT NOT NULL DEFAULT 100,
        email_monthly_limit INT NOT NULL DEFAULT 3000,
        call_in_placeholder_email VARCHAR(190) NOT NULL DEFAULT 'callinreservation@tryzubchicago.com',
        from_email VARCHAR(190) NOT NULL DEFAULT 'reservations@send.tryzubchicago.com',
        reply_to_email VARCHAR(190) NOT NULL DEFAULT 'info@tryzubchicago.com',
        created_at DATETIME NOT NULL,
        updated_at DATETIME NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY restaurant_key (restaurant_key)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
    tryzub_ensure_restaurant_settings_policy_columns();
    tryzub_seed_default_restaurant_settings();
    tryzub_backfill_restaurant_settings_policy_defaults();
}

function tryzub_get_default_restaurant_settings_values() {
    return [
        'restaurant_key' => 'tryzub',
        'business_name' => 'Tryzub Ukrainian Kitchen',
        'timezone' => 'America/Chicago',
        'default_party_size' => 2,
        'booking_window_days' => 60,
        'slot_interval_minutes' => 15,
        'max_online_party_size' => 8,
        'large_party_review_threshold' => 7,
        'same_day_booking_enabled' => 1,
        'minimum_lead_time_minutes' => 60,
        'automatic_reminders_enabled' => 1,
        'reminder_lead_hours' => 3,
        'manual_batch_reminders_enabled' => 0,
        'morning_reminder_time' => '09:00:00',
        'auto_confirm_enabled' => 0,
        'auto_confirm_require_email' => 1,
        'auto_confirm_block_guest_notes' => 1,
        'auto_confirm_block_duplicates' => 1,
        'auto_confirm_block_suspicious' => 1,
        'auto_confirm_policy_json' => wp_json_encode([
            'rules' => [],
            'excluded_dates' => [],
        ]),
        'email_daily_limit' => 100,
        'email_monthly_limit' => 3000,
        'call_in_placeholder_email' => 'callinreservation@tryzubchicago.com',
        'from_email' => 'reservations@send.tryzubchicago.com',
        'reply_to_email' => 'info@tryzubchicago.com',
    ];
}

function tryzub_seed_default_restaurant_settings() {
    global $wpdb;

    $table_name = tryzub_get_restaurant_settings_table_name();
    $exists = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT id FROM $table_name WHERE restaurant_key = %s LIMIT 1",
            'tryzub'
        )
    );

    if ($exists) {
        return;
    }

    $defaults = tryzub_get_default_restaurant_settings_values();
    $now = current_time('mysql');

    $wpdb->insert(
        $table_name,
        [
            'restaurant_key' => $defaults['restaurant_key'],
            'business_name' => $defaults['business_name'],
            'timezone' => $defaults['timezone'],
            'default_party_size' => $defaults['default_party_size'],
            'booking_window_days' => $defaults['booking_window_days'],
            'slot_interval_minutes' => $defaults['slot_interval_minutes'],
            'max_online_party_size' => $defaults['max_online_party_size'],
            'large_party_review_threshold' => $defaults['large_party_review_threshold'],
            'same_day_booking_enabled' => $defaults['same_day_booking_enabled'],
            'minimum_lead_time_minutes' => $defaults['minimum_lead_time_minutes'],
            'automatic_reminders_enabled' => $defaults['automatic_reminders_enabled'],
            'reminder_lead_hours' => $defaults['reminder_lead_hours'],
            'manual_batch_reminders_enabled' => $defaults['manual_batch_reminders_enabled'],
            'morning_reminder_time' => $defaults['morning_reminder_time'],
            'auto_confirm_enabled' => $defaults['auto_confirm_enabled'],
            'auto_confirm_require_email' => $defaults['auto_confirm_require_email'],
            'auto_confirm_block_guest_notes' => $defaults['auto_confirm_block_guest_notes'],
            'auto_confirm_block_duplicates' => $defaults['auto_confirm_block_duplicates'],
            'auto_confirm_block_suspicious' => $defaults['auto_confirm_block_suspicious'],
            'auto_confirm_policy_json' => $defaults['auto_confirm_policy_json'],
            'email_daily_limit' => $defaults['email_daily_limit'],
            'email_monthly_limit' => $defaults['email_monthly_limit'],
            'call_in_placeholder_email' => $defaults['call_in_placeholder_email'],
            'from_email' => $defaults['from_email'],
            'reply_to_email' => $defaults['reply_to_email'],
            'created_at' => $now,
            'updated_at' => $now,
        ],
        ['%s', '%s', '%s', '%d', '%d', '%d', '%d', '%d', '%d', '%d', '%d', '%d', '%d', '%s', '%d', '%d', '%d', '%d', '%d', '%s', '%d', '%d', '%s', '%s', '%s', '%s', '%s']
    );
}

function tryzub_ensure_restaurant_settings_policy_columns() {
    $table_name = tryzub_get_restaurant_settings_table_name();

    $columns = [
        'booking_window_days' => 'booking_window_days INT NOT NULL DEFAULT 60',
        'slot_interval_minutes' => 'slot_interval_minutes INT NOT NULL DEFAULT 15',
        'max_online_party_size' => 'max_online_party_size INT NOT NULL DEFAULT 8',
        'large_party_review_threshold' => 'large_party_review_threshold INT NOT NULL DEFAULT 7',
        'same_day_booking_enabled' => 'same_day_booking_enabled TINYINT(1) NOT NULL DEFAULT 1',
        'minimum_lead_time_minutes' => 'minimum_lead_time_minutes INT NOT NULL DEFAULT 60',
        'automatic_reminders_enabled' => 'automatic_reminders_enabled TINYINT(1) NOT NULL DEFAULT 1',
        'reminder_lead_hours' => 'reminder_lead_hours INT NOT NULL DEFAULT 3',
        'manual_batch_reminders_enabled' => 'manual_batch_reminders_enabled TINYINT(1) NOT NULL DEFAULT 0',
        'morning_reminder_time' => "morning_reminder_time TIME NOT NULL DEFAULT '09:00:00'",
        'auto_confirm_enabled' => 'auto_confirm_enabled TINYINT(1) NOT NULL DEFAULT 0',
        'auto_confirm_require_email' => 'auto_confirm_require_email TINYINT(1) NOT NULL DEFAULT 1',
        'auto_confirm_block_guest_notes' => 'auto_confirm_block_guest_notes TINYINT(1) NOT NULL DEFAULT 1',
        'auto_confirm_block_duplicates' => 'auto_confirm_block_duplicates TINYINT(1) NOT NULL DEFAULT 1',
        'auto_confirm_block_suspicious' => 'auto_confirm_block_suspicious TINYINT(1) NOT NULL DEFAULT 1',
        'auto_confirm_policy_json' => 'auto_confirm_policy_json LONGTEXT NULL',
        'email_daily_limit' => 'email_daily_limit INT NOT NULL DEFAULT 100',
        'email_monthly_limit' => 'email_monthly_limit INT NOT NULL DEFAULT 3000',
    ];

    foreach ($columns as $column_name => $column_sql) {
        tryzub_add_table_column_if_missing($table_name, $column_name, $column_sql);
    }
}

function tryzub_backfill_restaurant_settings_policy_defaults() {
    global $wpdb;

    $table_name = tryzub_get_restaurant_settings_table_name();

    if (tryzub_table_column_exists($table_name, 'booking_window_days')) {
        $wpdb->query("UPDATE $table_name SET booking_window_days = 60 WHERE booking_window_days IS NULL OR booking_window_days < 1");
    }

    if (tryzub_table_column_exists($table_name, 'slot_interval_minutes')) {
        $wpdb->query("UPDATE $table_name SET slot_interval_minutes = 15 WHERE slot_interval_minutes IS NULL OR slot_interval_minutes NOT IN (15, 30, 45, 60)");
    }

    if (tryzub_table_column_exists($table_name, 'max_online_party_size')) {
        $wpdb->query("UPDATE $table_name SET max_online_party_size = 8 WHERE max_online_party_size IS NULL OR max_online_party_size < 1");
    }

    if (tryzub_table_column_exists($table_name, 'large_party_review_threshold')) {
        $wpdb->query("UPDATE $table_name SET large_party_review_threshold = 7 WHERE large_party_review_threshold IS NULL OR large_party_review_threshold < 1");
    }

    if (tryzub_table_column_exists($table_name, 'same_day_booking_enabled')) {
        $wpdb->query("UPDATE $table_name SET same_day_booking_enabled = 1 WHERE same_day_booking_enabled IS NULL OR same_day_booking_enabled NOT IN (0, 1)");
    }

    if (tryzub_table_column_exists($table_name, 'minimum_lead_time_minutes')) {
        $wpdb->query("UPDATE $table_name SET minimum_lead_time_minutes = 60 WHERE minimum_lead_time_minutes IS NULL OR minimum_lead_time_minutes < 0");
    }

    if (tryzub_table_column_exists($table_name, 'automatic_reminders_enabled')) {
        $wpdb->query("UPDATE $table_name SET automatic_reminders_enabled = 1 WHERE automatic_reminders_enabled IS NULL OR automatic_reminders_enabled NOT IN (0, 1)");
    }

    if (tryzub_table_column_exists($table_name, 'manual_batch_reminders_enabled')) {
        $wpdb->query("UPDATE $table_name SET manual_batch_reminders_enabled = 0 WHERE manual_batch_reminders_enabled IS NULL OR manual_batch_reminders_enabled NOT IN (0, 1)");
    }

    if (tryzub_table_column_exists($table_name, 'reminder_lead_hours')) {
        $wpdb->query("UPDATE $table_name SET reminder_lead_hours = 3 WHERE reminder_lead_hours IS NULL OR reminder_lead_hours < 1 OR reminder_lead_hours > 24");
    }

    if (tryzub_table_column_exists($table_name, 'morning_reminder_time')) {
        $wpdb->query("UPDATE $table_name SET morning_reminder_time = '09:00:00' WHERE morning_reminder_time IS NULL OR morning_reminder_time = ''");
    }

    foreach (['auto_confirm_enabled' => 0, 'auto_confirm_require_email' => 1, 'auto_confirm_block_guest_notes' => 1, 'auto_confirm_block_duplicates' => 1, 'auto_confirm_block_suspicious' => 1] as $column_name => $default_value) {
        if (tryzub_table_column_exists($table_name, $column_name)) {
            $wpdb->query("UPDATE $table_name SET $column_name = " . absint($default_value) . " WHERE $column_name IS NULL OR $column_name NOT IN (0, 1)");
        }
    }

    if (tryzub_table_column_exists($table_name, 'auto_confirm_policy_json')) {
        $default_policy = wp_json_encode(['rules' => [], 'excluded_dates' => []]);
        $wpdb->query($wpdb->prepare("UPDATE $table_name SET auto_confirm_policy_json = %s WHERE auto_confirm_policy_json IS NULL OR auto_confirm_policy_json = ''", $default_policy));
    }

    if (tryzub_table_column_exists($table_name, 'email_daily_limit')) {
        $wpdb->query("UPDATE $table_name SET email_daily_limit = 100 WHERE email_daily_limit IS NULL OR email_daily_limit < 1");
    }

    if (tryzub_table_column_exists($table_name, 'email_monthly_limit')) {
        $wpdb->query("UPDATE $table_name SET email_monthly_limit = 3000 WHERE email_monthly_limit IS NULL OR email_monthly_limit < 1");
    }
}

function tryzub_create_reservation_messages_table() {
    global $wpdb;

    $table_name = tryzub_get_reservation_messages_table_name();
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        reservation_id BIGINT(20) UNSIGNED NULL,
        direction VARCHAR(20) NOT NULL,
        channel VARCHAR(20) NOT NULL,
        from_email VARCHAR(190) NULL,
        to_email VARCHAR(190) NULL,
        subject TEXT NULL,
        body_text LONGTEXT NULL,
        body_html LONGTEXT NULL,
        raw_payload_json LONGTEXT NULL,
        provider_message_id VARCHAR(190) NULL,
        in_reply_to VARCHAR(190) NULL,
        reply_token VARCHAR(190) NULL,
        status VARCHAR(30) NULL,
        created_at DATETIME NOT NULL,
        read_at DATETIME NULL,
        handled_at DATETIME NULL,
        PRIMARY KEY  (id),
        KEY reservation_id (reservation_id),
        KEY direction (direction),
        KEY channel (channel),
        KEY status (status),
        KEY reply_token (reply_token),
        KEY created_at (created_at)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

function tryzub_create_restaurant_weekly_hours_table() {
    global $wpdb;

    $table_name = tryzub_get_restaurant_weekly_hours_table_name();
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        restaurant_key VARCHAR(80) NOT NULL DEFAULT 'tryzub',
        weekday TINYINT UNSIGNED NOT NULL,
        is_open TINYINT(1) NOT NULL DEFAULT 1,
        open_time TIME NULL,
        close_time TIME NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY restaurant_weekday (restaurant_key, weekday),
        KEY weekday (weekday),
        KEY is_open (is_open)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
    tryzub_repair_known_restaurant_weekly_hours_seed_rows();
    tryzub_seed_default_restaurant_weekly_hours();
}

function tryzub_get_default_restaurant_weekly_hours_values() {
    return [
        0 => ['is_open' => 0, 'open_time' => null, 'close_time' => null],
        1 => ['is_open' => 1, 'open_time' => '17:00:00', 'close_time' => '21:00:00'],
        2 => ['is_open' => 1, 'open_time' => '17:00:00', 'close_time' => '21:00:00'],
        3 => ['is_open' => 1, 'open_time' => '17:00:00', 'close_time' => '21:00:00'],
        4 => ['is_open' => 1, 'open_time' => '17:00:00', 'close_time' => '22:00:00'],
        5 => ['is_open' => 1, 'open_time' => '11:00:00', 'close_time' => '22:00:00'],
        6 => ['is_open' => 1, 'open_time' => '11:00:00', 'close_time' => '21:00:00'],
    ];
}

function tryzub_seed_default_restaurant_weekly_hours() {
    global $wpdb;

    $table_name = tryzub_get_restaurant_weekly_hours_table_name();
    $now = current_time('mysql');

    foreach (tryzub_get_default_restaurant_weekly_hours_values() as $weekday => $hours) {
        $exists = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM $table_name WHERE restaurant_key = %s AND weekday = %d LIMIT 1",
                'tryzub',
                $weekday
            )
        );

        if ($exists) {
            continue;
        }

        $wpdb->insert(
            $table_name,
            [
                'restaurant_key' => 'tryzub',
                'weekday' => $weekday,
                'is_open' => $hours['is_open'],
                'open_time' => $hours['open_time'],
                'close_time' => $hours['close_time'],
                'created_at' => $now,
                'updated_at' => null,
            ],
            ['%s', '%d', '%d', '%s', '%s', '%s', '%s']
        );
    }
}

function tryzub_get_known_restaurant_weekly_hours_seed_snapshots() {
    return [
        'pre_1_4_1_public_close_times' => [
            0 => ['is_open' => 0, 'open_time' => null, 'close_time' => null],
            1 => ['is_open' => 1, 'open_time' => '17:00:00', 'close_time' => '20:30:00'],
            2 => ['is_open' => 1, 'open_time' => '17:00:00', 'close_time' => '20:30:00'],
            3 => ['is_open' => 1, 'open_time' => '17:00:00', 'close_time' => '20:30:00'],
            4 => ['is_open' => 1, 'open_time' => '17:00:00', 'close_time' => '21:30:00'],
            5 => ['is_open' => 1, 'open_time' => '11:00:00', 'close_time' => '21:30:00'],
            6 => ['is_open' => 1, 'open_time' => '11:00:00', 'close_time' => '20:30:00'],
        ],
        'pre_1_4_0_extended_hours' => [
            0 => ['is_open' => 0, 'open_time' => null, 'close_time' => null],
            1 => ['is_open' => 1, 'open_time' => '16:30:00', 'close_time' => '21:30:00'],
            2 => ['is_open' => 1, 'open_time' => '16:30:00', 'close_time' => '21:30:00'],
            3 => ['is_open' => 1, 'open_time' => '16:30:00', 'close_time' => '21:30:00'],
            4 => ['is_open' => 1, 'open_time' => '16:30:00', 'close_time' => '22:30:00'],
            5 => ['is_open' => 1, 'open_time' => '11:00:00', 'close_time' => '22:30:00'],
            6 => ['is_open' => 1, 'open_time' => '11:00:00', 'close_time' => '21:00:00'],
        ],
        'legacy_sunday_first_defaults' => [
            0 => ['is_open' => 1, 'open_time' => '11:00:00', 'close_time' => '21:00:00'],
            1 => ['is_open' => 0, 'open_time' => null, 'close_time' => null],
            2 => ['is_open' => 1, 'open_time' => '17:00:00', 'close_time' => '21:00:00'],
            3 => ['is_open' => 1, 'open_time' => '17:00:00', 'close_time' => '21:00:00'],
            4 => ['is_open' => 1, 'open_time' => '17:00:00', 'close_time' => '21:00:00'],
            5 => ['is_open' => 1, 'open_time' => '17:00:00', 'close_time' => '22:00:00'],
            6 => ['is_open' => 1, 'open_time' => '11:00:00', 'close_time' => '22:00:00'],
        ],
    ];
}

function tryzub_repair_known_restaurant_weekly_hours_seed_rows() {
    global $wpdb;

    $table_name = tryzub_get_restaurant_weekly_hours_table_name();
    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT weekday, is_open, open_time, close_time, updated_at
            FROM $table_name
            WHERE restaurant_key = %s
            ORDER BY weekday ASC",
            'tryzub'
        ),
        ARRAY_A
    );

    if (count($rows) !== 7) {
        return;
    }

    foreach (tryzub_get_known_restaurant_weekly_hours_seed_snapshots() as $snapshot) {
        if (!tryzub_restaurant_weekly_hours_rows_match_seed_snapshot($rows, $snapshot)) {
            continue;
        }

        tryzub_replace_restaurant_weekly_hours_seed_rows(tryzub_get_default_restaurant_weekly_hours_values());
        return;
    }
}

function tryzub_restaurant_weekly_hours_rows_match_seed_snapshot(array $rows, array $snapshot) {
    foreach ($rows as $row) {
        $weekday = (int) ($row['weekday'] ?? -1);

        if (!empty($row['updated_at'])) {
            return false;
        }

        if (!array_key_exists($weekday, $snapshot)) {
            return false;
        }

        $expected = $snapshot[$weekday];

        if ((int) $row['is_open'] !== (int) $expected['is_open']) {
            return false;
        }

        if (tryzub_normalize_seed_time_value($row['open_time'] ?? null) !== tryzub_normalize_seed_time_value($expected['open_time'])) {
            return false;
        }

        if (tryzub_normalize_seed_time_value($row['close_time'] ?? null) !== tryzub_normalize_seed_time_value($expected['close_time'])) {
            return false;
        }
    }

    return true;
}

function tryzub_replace_restaurant_weekly_hours_seed_rows(array $defaults) {
    global $wpdb;

    $table_name = tryzub_get_restaurant_weekly_hours_table_name();
    $now = current_time('mysql');

    foreach ($defaults as $weekday => $hours) {
        $updated = $wpdb->update(
            $table_name,
            [
                'is_open' => $hours['is_open'],
                'open_time' => $hours['open_time'],
                'close_time' => $hours['close_time'],
                'updated_at' => $now,
            ],
            [
                'restaurant_key' => 'tryzub',
                'weekday' => $weekday,
            ],
            ['%d', '%s', '%s', '%s'],
            ['%s', '%d']
        );

        if ($updated === false) {
            error_log('Tryzub weekly hours seed repair failed: ' . $wpdb->last_error);
            return;
        }
    }
}

function tryzub_normalize_seed_time_value($value) {
    return $value === null || $value === '' ? null : (string) $value;
}

function tryzub_create_restaurant_special_hours_table() {
    global $wpdb;

    $table_name = tryzub_get_restaurant_special_hours_table_name();
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        restaurant_key VARCHAR(80) NOT NULL DEFAULT 'tryzub',
        reservation_date DATE NOT NULL,
        is_open TINYINT(1) NOT NULL DEFAULT 1,
        open_time TIME NULL,
        close_time TIME NULL,
        reason TEXT NULL,
        created_by_user_id BIGINT(20) UNSIGNED NULL,
        updated_by_user_id BIGINT(20) UNSIGNED NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY restaurant_date (restaurant_key, reservation_date),
        KEY reservation_date (reservation_date),
        KEY is_open (is_open)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

function tryzub_create_restaurant_blocked_slots_table() {
    global $wpdb;

    $table_name = tryzub_get_restaurant_blocked_slots_table_name();
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        restaurant_key VARCHAR(80) NOT NULL DEFAULT 'tryzub',
        reservation_date DATE NOT NULL,
        slot_time TIME NOT NULL,
        reason TEXT NULL,
        created_by_user_id BIGINT(20) UNSIGNED NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY restaurant_date_slot (restaurant_key, reservation_date, slot_time),
        KEY reservation_date (reservation_date),
        KEY slot_time (slot_time)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

function tryzub_create_restaurant_tables_table() {
    global $wpdb;

    $table_name = tryzub_get_restaurant_tables_table_name();
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        restaurant_key VARCHAR(64) NOT NULL DEFAULT 'tryzub',
        table_key VARCHAR(32) NOT NULL,
        label VARCHAR(64) NOT NULL,
        x INT NOT NULL,
        y INT NOT NULL,
        width_units INT NOT NULL DEFAULT 1,
        height_units INT NOT NULL DEFAULT 1,
        min_capacity INT NOT NULL DEFAULT 1,
        max_capacity INT NOT NULL DEFAULT 4,
        section VARCHAR(64) NULL,
        sort_order INT NOT NULL DEFAULT 0,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY restaurant_table_key (restaurant_key, table_key),
        KEY restaurant_key (restaurant_key),
        KEY is_active (is_active),
        KEY grid_position (x, y)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

function tryzub_create_reservation_table_assignments_table() {
    global $wpdb;

    $table_name = tryzub_get_reservation_table_assignments_table_name();
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        reservation_id BIGINT(20) UNSIGNED NOT NULL,
        reservation_date DATE NOT NULL,
        table_key VARCHAR(32) NOT NULL,
        assigned_by_user_id BIGINT(20) UNSIGNED NULL,
        assigned_at DATETIME NOT NULL,
        updated_at DATETIME NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY reservation_table (reservation_id, table_key),
        KEY reservation_id (reservation_id),
        KEY reservation_date (reservation_date),
        KEY table_key (table_key),
        KEY reservation_date_table_key (reservation_date, table_key)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

function tryzub_create_reservation_activity_table() {
    global $wpdb;

    $table_name = tryzub_get_reservation_activity_table_name();
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        reservation_id BIGINT(20) UNSIGNED NOT NULL,
        event_type VARCHAR(64) NOT NULL,
        actor_user_id BIGINT(20) UNSIGNED NULL,
        actor_name VARCHAR(191) NULL,
        actor_role VARCHAR(64) NULL,
        source VARCHAR(64) NOT NULL DEFAULT 'backend',
        summary TEXT NOT NULL,
        old_value LONGTEXT NULL,
        new_value LONGTEXT NULL,
        metadata_json LONGTEXT NULL,
        created_at DATETIME NOT NULL,
        created_at_gmt DATETIME NOT NULL,
        PRIMARY KEY  (id),
        KEY reservation_id (reservation_id),
        KEY event_type (event_type),
        KEY actor_user_id (actor_user_id),
        KEY created_at (created_at),
        KEY created_at_gmt (created_at_gmt),
        KEY reservation_created_at (reservation_id, created_at),
        KEY event_type_created_at (event_type, created_at)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

function tryzub_create_guest_profiles_table() {
    global $wpdb;

    $table_name = tryzub_get_guest_profiles_table_name();
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        guest_key VARCHAR(190) NOT NULL,
        primary_name VARCHAR(190) NULL,
        primary_email VARCHAR(190) NULL,
        primary_phone VARCHAR(64) NULL,
        normalized_phone VARCHAR(32) NULL,
        identity_confidence VARCHAR(32) NOT NULL DEFAULT 'derived',
        identity_source VARCHAR(32) NOT NULL DEFAULT 'reservation_history',
        first_seen_date DATE NULL,
        last_seen_date DATE NULL,
        last_booked_at DATETIME NULL,
        total_reservations INT NOT NULL DEFAULT 0,
        clean_visit_count INT NOT NULL DEFAULT 0,
        completed_count INT NOT NULL DEFAULT 0,
        confirmed_count INT NOT NULL DEFAULT 0,
        cancelled_count INT NOT NULL DEFAULT 0,
        no_show_count INT NOT NULL DEFAULT 0,
        needs_review_count INT NOT NULL DEFAULT 0,
        upcoming_count INT NOT NULL DEFAULT 0,
        next_reservation_id BIGINT(20) UNSIGNED NULL,
        next_reservation_date DATE NULL,
        next_reservation_time TIME NULL,
        next_reservation_status VARCHAR(32) NULL,
        next_party_size INT NULL,
        next_table_name VARCHAR(190) NULL,
        usual_party_size INT NULL,
        average_party_size DECIMAL(6,2) NULL,
        largest_party_size INT NULL,
        usual_hour TINYINT NULL,
        usual_weekday TINYINT NULL,
        website_count INT NOT NULL DEFAULT 0,
        call_in_count INT NOT NULL DEFAULT 0,
        manual_count INT NOT NULL DEFAULT 0,
        unknown_source_count INT NOT NULL DEFAULT 0,
        guest_notes_count INT NOT NULL DEFAULT 0,
        staff_notes_count INT NOT NULL DEFAULT 0,
        notes_count INT NOT NULL DEFAULT 0,
        has_birthday_note TINYINT(1) NOT NULL DEFAULT 0,
        has_occasion_note TINYINT(1) NOT NULL DEFAULT 0,
        has_reply_needed_note TINYINT(1) NOT NULL DEFAULT 0,
        has_group_note TINYINT(1) NOT NULL DEFAULT 0,
        has_dietary_note TINYINT(1) NOT NULL DEFAULT 0,
        has_large_party_history TINYINT(1) NOT NULL DEFAULT 0,
        labels_json LONGTEXT NULL,
        evidence_json LONGTEXT NULL,
        summary_json LONGTEXT NULL,
        source_coverage_json LONGTEXT NULL,
        profile_pack_json LONGTEXT NULL,
        last_calculated_at DATETIME NULL,
        last_calculated_at_gmt DATETIME NULL,
        dirty_at DATETIME NULL,
        dirty_reason VARCHAR(190) NULL,
        created_at DATETIME NOT NULL,
        created_at_gmt DATETIME NOT NULL,
        updated_at DATETIME NOT NULL,
        updated_at_gmt DATETIME NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY guest_key_unique (guest_key),
        KEY normalized_phone_idx (normalized_phone),
        KEY primary_email_idx (primary_email),
        KEY last_seen_idx (last_seen_date),
        KEY next_reservation_idx (next_reservation_date),
        KEY dirty_idx (dirty_at)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

function tryzub_register_reservations_capabilities() {
    $capability = 'manage_tryzub_reservations';

    add_role(
        'tryzub_reservations_staff',
        'Tryzub Reservations Staff',
        [
            'read' => true,
            $capability => true,
        ]
    );

    $staff = get_role('tryzub_reservations_staff');

    if ($staff && !$staff->has_cap($capability)) {
        $staff->add_cap($capability);
    }

    $administrator = get_role('administrator');

    if ($administrator && !$administrator->has_cap($capability)) {
        $administrator->add_cap($capability);
    }
}

function tryzub_schedule_reservation_reminders() {
    if (!wp_next_scheduled('tryzub_reservation_reminders_cron')) {
        wp_schedule_event(time() + HOUR_IN_SECONDS, 'hourly', 'tryzub_reservation_reminders_cron');
    }
}

function tryzub_schedule_guest_profiles_rebuild() {
    if (!wp_next_scheduled('tryzub_guest_profiles_rebuild_dirty_cron')) {
        wp_schedule_event(time() + 10 * MINUTE_IN_SECONDS, 'hourly', 'tryzub_guest_profiles_rebuild_dirty_cron');
    }
}

function tryzub_reservations_deactivate() {
    wp_clear_scheduled_hook('tryzub_reservation_reminders_cron');
    wp_clear_scheduled_hook('tryzub_bi_daily_precompute_cron');
    wp_clear_scheduled_hook('tryzub_guest_profiles_rebuild_dirty_cron');
}

function tryzub_allow_nullable_source_submission_id() {
    global $wpdb;

    $table_name = tryzub_get_reservations_table_name();
    $column = $wpdb->get_row("SHOW COLUMNS FROM $table_name LIKE 'source_submission_id'", ARRAY_A);

    if (!$column || strtoupper((string) ($column['Null'] ?? '')) === 'YES') {
        return;
    }

    $wpdb->query("ALTER TABLE $table_name MODIFY source_submission_id BIGINT(20) UNSIGNED NULL");
}

function tryzub_backfill_reservation_schema_defaults() {
    global $wpdb;

    $table_name = tryzub_get_reservations_table_name();

    if (!tryzub_table_column_exists($table_name, 'source_type')) {
        return;
    }

    $wpdb->query("UPDATE $table_name SET source_type = 'form' WHERE source_type IS NULL OR source_type = ''");

    if (tryzub_table_column_exists($table_name, 'is_hidden')) {
        $wpdb->query("UPDATE $table_name SET is_hidden = 0 WHERE is_hidden IS NULL");
    }
}

function tryzub_table_column_exists($table_name, $column_name) {
    global $wpdb;

    return (bool) $wpdb->get_var(
        $wpdb->prepare(
            "SHOW COLUMNS FROM $table_name LIKE %s",
            $column_name
        )
    );
}

function tryzub_add_table_column_if_missing($table_name, $column_name, $column_sql) {
    global $wpdb;

    if (tryzub_table_column_exists($table_name, $column_name)) {
        return;
    }

    $wpdb->query("ALTER TABLE $table_name ADD $column_sql");
}

function tryzub_table_index_exists($table_name, $index_name) {
    global $wpdb;

    return (bool) $wpdb->get_var(
        $wpdb->prepare(
            "SHOW INDEX FROM $table_name WHERE Key_name = %s",
            $index_name
        )
    );
}

function tryzub_add_table_index_if_missing($table_name, $index_name, $index_sql) {
    global $wpdb;

    if (tryzub_table_index_exists($table_name, $index_name)) {
        return;
    }

    $wpdb->query("ALTER TABLE $table_name ADD $index_sql");
}

// Used by /ping to confirm the custom table exists after activation.
// Later, table_exists should be removed from the public ping response or moved behind authentication.
//MARK: - DB Helper Health Check
function tryzub_reservations_table_exists() {
    global $wpdb;

    $table_name = tryzub_get_reservations_table_name();

    return $wpdb->get_var(
        $wpdb->prepare("SHOW TABLES LIKE %s", $table_name)
    ) === $table_name;
}

// Central table-name helper.
// Always use this instead of hardcoding wp_tryzub_reservations because WordPress table prefixes differ by install.
function tryzub_get_reservations_table_name() {
    global $wpdb;
    return $wpdb->prefix . 'tryzub_reservations';
}

function tryzub_get_import_failures_table_name() {
    global $wpdb;
    return $wpdb->prefix . 'tryzub_reservation_import_failures';
}

function tryzub_get_reservation_duplicate_imports_table_name() {
    global $wpdb;
    return $wpdb->prefix . 'tryzub_reservation_duplicate_imports';
}

function tryzub_get_reservation_deletion_audit_table_name() {
    global $wpdb;
    return $wpdb->prefix . 'tryzub_reservation_deletion_audit';
}

function tryzub_get_reservation_guest_tokens_table_name() {
    global $wpdb;
    return $wpdb->prefix . 'tryzub_reservation_guest_tokens';
}

function tryzub_get_reservation_guest_requests_table_name() {
    global $wpdb;
    return $wpdb->prefix . 'tryzub_reservation_guest_requests';
}

function tryzub_get_reservation_emails_table_name() {
    global $wpdb;
    return $wpdb->prefix . 'tryzub_reservation_emails';
}

function tryzub_get_reservation_messages_table_name() {
    global $wpdb;
    return $wpdb->prefix . 'tryzub_reservation_messages';
}

function tryzub_get_restaurant_settings_table_name() {
    global $wpdb;
    return $wpdb->prefix . 'tryzub_restaurant_settings';
}

function tryzub_get_restaurant_weekly_hours_table_name() {
    global $wpdb;
    return $wpdb->prefix . 'tryzub_restaurant_weekly_hours';
}

function tryzub_get_restaurant_special_hours_table_name() {
    global $wpdb;
    return $wpdb->prefix . 'tryzub_restaurant_special_hours';
}

function tryzub_get_restaurant_blocked_slots_table_name() {
    global $wpdb;
    return $wpdb->prefix . 'tryzub_restaurant_blocked_slots';
}

function tryzub_get_restaurant_tables_table_name() {
    global $wpdb;
    return $wpdb->prefix . 'tryzub_restaurant_tables';
}

function tryzub_get_reservation_table_assignments_table_name() {
    global $wpdb;
    return $wpdb->prefix . 'tryzub_reservation_table_assignments';
}

function tryzub_get_reservation_activity_table_name() {
    global $wpdb;
    return $wpdb->prefix . 'tryzub_reservation_activity';
}

function tryzub_get_guest_profiles_table_name() {
    global $wpdb;
    return $wpdb->prefix . 'tryzub_guest_profiles';
}
