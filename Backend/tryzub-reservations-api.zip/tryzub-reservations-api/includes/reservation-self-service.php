<?php

function tryzub_create_guest_manage_link(WP_REST_Request $request) {
    $reservation_id = absint($request->get_param('id'));
    $reservation = tryzub_get_managed_reservation_row_by_id($reservation_id);

    if (!$reservation) {
        return new WP_Error(
            'tryzub_reservation_not_found',
            'Managed reservation not found.',
            ['status' => 404]
        );
    }

    $token = tryzub_create_guest_manage_token($reservation_id);

    if (is_wp_error($token)) {
        return $token;
    }

    tryzub_reservation_activity_log(
        $reservation_id,
        'guest_manage_link_created',
        'Guest manage link created.',
        [
            'source' => tryzub_reservation_activity_request_context([])['source'],
            'metadata' => [
                'expires_at' => $token['expires_at'],
            ],
        ]
    );

    return rest_ensure_response([
        'success' => true,
        'data' => [
            'url' => tryzub_build_guest_manage_url($token['raw_token']),
            'expires_at' => $token['expires_at'],
        ],
    ]);
}

function tryzub_create_guest_manage_token($reservation_id) {
    global $wpdb;

    $reservation_id = absint($reservation_id);
    $now = current_time('mysql');
    $expires_at = date('Y-m-d H:i:s', current_time('timestamp') + (30 * DAY_IN_SECONDS));
    $raw_token = tryzub_generate_guest_token_raw();
    $token_hash = tryzub_hash_guest_token($raw_token);

    $inserted = $wpdb->insert(
        tryzub_get_reservation_guest_tokens_table_name(),
        [
            'reservation_id' => $reservation_id,
            'token_hash' => $token_hash,
            'purpose' => 'manage',
            'expires_at' => $expires_at,
            'created_at' => $now,
            'revoked_at' => null,
            'used_at' => null,
        ],
        ['%d', '%s', '%s', '%s', '%s', '%s', '%s']
    );

    if ($inserted === false) {
        error_log('Tryzub guest token insert failed: ' . $wpdb->last_error);

        return new WP_Error(
            'tryzub_database_error',
            'Failed to create guest manage link.',
            ['status' => 500]
        );
    }

    tryzub_revoke_other_active_guest_manage_tokens($reservation_id, $token_hash);

    return [
        'raw_token' => $raw_token,
        'expires_at' => $expires_at,
    ];
}

function tryzub_revoke_other_active_guest_manage_tokens($reservation_id, $active_token_hash) {
    global $wpdb;

    $wpdb->query(
        $wpdb->prepare(
            "UPDATE " . tryzub_get_reservation_guest_tokens_table_name() . "
            SET revoked_at = %s
            WHERE reservation_id = %d
            AND purpose = %s
            AND revoked_at IS NULL
            AND token_hash <> %s",
            current_time('mysql'),
            absint($reservation_id),
            'manage',
            sanitize_text_field((string) $active_token_hash)
        )
    );
}

function tryzub_generate_guest_token_raw() {
    try {
        return bin2hex(random_bytes(32));
    } catch (Exception $exception) {
        return wp_generate_password(64, false, false);
    }
}

function tryzub_hash_guest_token($token) {
    return hash('sha256', (string) $token);
}

function tryzub_build_guest_manage_url($raw_token) {
    return 'https://tryzubchicago.com/manage-reservation/?token=' . rawurlencode($raw_token);
}

function tryzub_get_reservation_self(WP_REST_Request $request) {
    $validated = tryzub_validate_guest_manage_token($request->get_param('token'));

    if (is_wp_error($validated)) {
        return $validated;
    }

    return rest_ensure_response([
        'success' => true,
        'data' => tryzub_format_guest_safe_reservation($validated['reservation']),
    ]);
}

function tryzub_validate_guest_manage_token($token) {
    global $wpdb;

    $token = trim(sanitize_text_field((string) $token));

    if ($token === '') {
        return tryzub_invalid_guest_manage_token_error();
    }

    $token_row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT *
            FROM " . tryzub_get_reservation_guest_tokens_table_name() . "
            WHERE token_hash = %s
            AND purpose = %s
            AND revoked_at IS NULL
            AND expires_at >= %s
            LIMIT 1",
            tryzub_hash_guest_token($token),
            'manage',
            current_time('mysql')
        ),
        ARRAY_A
    );

    if (!$token_row) {
        return tryzub_invalid_guest_manage_token_error();
    }

    $reservation = tryzub_get_managed_reservation_row_by_id((int) $token_row['reservation_id']);

    if (!$reservation || (int) ($reservation['is_hidden'] ?? 0) === 1) {
        return tryzub_invalid_guest_manage_token_error();
    }

    return [
        'token' => $token_row,
        'reservation' => $reservation,
    ];
}

function tryzub_invalid_guest_manage_token_error() {
    return new WP_Error(
        'tryzub_invalid_guest_token',
        'This reservation link is invalid or has expired. Please contact Tryzub Ukrainian Kitchen for help.',
        ['status' => 404]
    );
}

function tryzub_format_guest_safe_reservation(array $reservation) {
    $settings = tryzub_get_restaurant_settings();
    $status = sanitize_text_field((string) ($reservation['status'] ?? ''));
    $can_request_change = in_array($status, ['new', 'needs_review', 'confirmed'], true);

    return [
        'restaurant_name' => $settings['business_name'] ?? 'Tryzub Ukrainian Kitchen',
        'guest_name' => $reservation['guest_name'],
        'reservation_date' => $reservation['reservation_date'],
        'reservation_time' => substr((string) $reservation['reservation_time'], 0, 5),
        'party_size' => (int) $reservation['party_size'],
        'guest_notes' => $reservation['guest_notes'],
        'status' => $status,
        'can_request_change' => $can_request_change,
        'can_request_cancel' => tryzub_guest_can_cancel_reservation_online($reservation),
    ];
}

function tryzub_create_reservation_self_change_request(WP_REST_Request $request) {
    $body = tryzub_get_rest_request_body($request);
    $validated = tryzub_validate_guest_manage_token($body['token'] ?? '');

    if (is_wp_error($validated)) {
        return $validated;
    }

    $payload = tryzub_prepare_guest_change_payload($body);

    if (is_wp_error($payload)) {
        return $payload;
    }

    $reservation = $validated['reservation'];
    $status = sanitize_text_field((string) ($reservation['status'] ?? ''));

    if (in_array($status, ['cancelled', 'seated', 'completed', 'no_show'], true)) {
        return new WP_Error(
            'tryzub_guest_request_not_allowed',
            'This reservation cannot be changed from this link.',
            ['status' => 409]
        );
    }

    $request_id = tryzub_insert_guest_request((int) $reservation['id'], 'change', $payload, 'open');

    if (is_wp_error($request_id)) {
        return $request_id;
    }

    $updated = tryzub_update_reservation_for_guest_request(
        (int) $reservation['id'],
        'needs_review',
        'Guest requested a reservation change from self-service link.'
    );

    if (is_wp_error($updated)) {
        return $updated;
    }

    tryzub_reservation_activity_log(
        (int) $reservation['id'],
        'guest_change_requested',
        'Guest requested a reservation change.',
        [
            'source' => 'guest_self_service',
            'actor_name' => 'Guest',
            'actor_role' => 'guest',
            'metadata' => [
                'request_id' => (int) $request_id,
            ],
        ]
    );

    return rest_ensure_response([
        'success' => true,
        'message' => 'Your change request was sent to the restaurant.',
    ]);
}

function tryzub_prepare_guest_change_payload(array $body) {
    $allowed_fields = ['token', 'reservation_date', 'reservation_time', 'party_size', 'guest_notes'];
    $unknown_fields = array_diff(array_keys($body), $allowed_fields);

    if (!empty($unknown_fields)) {
        return new WP_Error(
            'tryzub_unknown_guest_request_field',
            'Unknown request field: ' . implode(', ', array_values($unknown_fields)),
            ['status' => 400]
        );
    }

    $reservation_date = tryzub_normalize_reservation_date($body['reservation_date'] ?? '');

    if (!$reservation_date) {
        return new WP_Error(
            'tryzub_invalid_date',
            'Reservation date must be valid.',
            ['status' => 400]
        );
    }

    $reservation_time = tryzub_normalize_reservation_time($body['reservation_time'] ?? '');

    if (!$reservation_time) {
        return new WP_Error(
            'tryzub_invalid_time',
            'Reservation time must be valid.',
            ['status' => 400]
        );
    }

    $party_size = absint($body['party_size'] ?? 0);

    if ($party_size < 1 || $party_size > tryzub_get_max_party_size()) {
        return new WP_Error(
            'tryzub_invalid_party_size',
            'Party size must be a positive number within the allowed limit.',
            ['status' => 400]
        );
    }

    return [
        'reservation_date' => $reservation_date,
        'reservation_time' => $reservation_time,
        'party_size' => $party_size,
        'guest_notes' => sanitize_textarea_field((string) ($body['guest_notes'] ?? '')),
    ];
}

function tryzub_cancel_reservation_self(WP_REST_Request $request) {
    $body = tryzub_get_rest_request_body($request);
    $validated = tryzub_validate_guest_manage_token($body['token'] ?? '');

    if (is_wp_error($validated)) {
        return $validated;
    }

    $allowed_fields = ['token', 'reason'];
    $unknown_fields = array_diff(array_keys($body), $allowed_fields);

    if (!empty($unknown_fields)) {
        return new WP_Error(
            'tryzub_unknown_guest_request_field',
            'Unknown request field: ' . implode(', ', array_values($unknown_fields)),
            ['status' => 400]
        );
    }

    $reservation = $validated['reservation'];
    $status = sanitize_text_field((string) ($reservation['status'] ?? ''));
    $reason = sanitize_textarea_field((string) ($body['reason'] ?? ''));

    if ($status === 'cancelled') {
        $request_id = tryzub_insert_guest_request(
            (int) $reservation['id'],
            'cancel',
            ['reason' => $reason, 'outcome' => 'already_cancelled'],
            'rejected'
        );

        if (is_wp_error($request_id)) {
            return $request_id;
        }

        return new WP_Error(
            'tryzub_guest_cancel_already_cancelled',
            'This reservation has already been cancelled.',
            ['status' => 409]
        );
    }

    if (!in_array($status, ['new', 'needs_review', 'confirmed'], true)) {
        $request_id = tryzub_insert_guest_request(
            (int) $reservation['id'],
            'cancel',
            ['reason' => $reason, 'outcome' => 'status_not_cancellable'],
            'rejected'
        );

        if (is_wp_error($request_id)) {
            return $request_id;
        }

        return new WP_Error(
            'tryzub_guest_cancel_not_allowed',
            'This reservation cannot be cancelled from this link.',
            ['status' => 409]
        );
    }

    if (!tryzub_reservation_is_at_least_hours_away($reservation, 2)) {
        $request_id = tryzub_insert_guest_request(
            (int) $reservation['id'],
            'cancel',
            ['reason' => $reason, 'outcome' => 'too_late_online'],
            'rejected'
        );

        if (is_wp_error($request_id)) {
            return $request_id;
        }

        return new WP_Error(
            'tryzub_guest_cancel_too_late',
            'Online cancellation is no longer available for this reservation. Please call Tryzub Ukrainian Kitchen so our team can help you.',
            ['status' => 409]
        );
    }

    $request_id = tryzub_insert_guest_request(
        (int) $reservation['id'],
        'cancel',
        ['reason' => $reason],
        'applied'
    );

    if (is_wp_error($request_id)) {
        return $request_id;
    }

    $updated = tryzub_update_reservation_for_guest_request(
        (int) $reservation['id'],
        'cancelled',
        'Guest cancelled reservation from self-service link.'
    );

    if (is_wp_error($updated)) {
        return $updated;
    }

    tryzub_reservation_activity_log(
        (int) $reservation['id'],
        'guest_cancelled',
        'Guest cancelled from self-service link.',
        [
            'source' => 'guest_self_service',
            'actor_name' => 'Guest',
            'actor_role' => 'guest',
            'metadata' => [
                'request_id' => (int) $request_id,
                'reason_present' => trim($reason) !== '',
            ],
        ]
    );

    return rest_ensure_response([
        'success' => true,
        'message' => 'Your reservation has been cancelled.',
    ]);
}

function tryzub_insert_guest_request($reservation_id, $request_type, array $payload, $status = 'open') {
    global $wpdb;

    $request_type = sanitize_text_field((string) $request_type);
    $status = sanitize_text_field((string) $status);

    if (!in_array($request_type, ['change', 'cancel'], true) || !in_array($status, ['open', 'applied', 'rejected'], true)) {
        return new WP_Error(
            'tryzub_invalid_guest_request',
            'Guest request is invalid.',
            ['status' => 400]
        );
    }

    $inserted = $wpdb->insert(
        tryzub_get_reservation_guest_requests_table_name(),
        [
            'reservation_id' => absint($reservation_id),
            'request_type' => $request_type,
            'requested_payload_json' => wp_json_encode($payload),
            'status' => $status,
            'created_at' => current_time('mysql'),
            'resolved_at' => null,
            'resolved_by_user_id' => null,
        ],
        ['%d', '%s', '%s', '%s', '%s', '%s', '%d']
    );

    if ($inserted === false) {
        error_log('Tryzub guest request insert failed: ' . $wpdb->last_error);

        return new WP_Error(
            'tryzub_database_error',
            'Failed to record guest request.',
            ['status' => 500]
        );
    }

    return (int) $wpdb->insert_id;
}

function tryzub_update_reservation_for_guest_request($reservation_id, $status, $note) {
    global $wpdb;

    $reservation = tryzub_get_managed_reservation_row_by_id($reservation_id);

    if (!$reservation) {
        return new WP_Error(
            'tryzub_reservation_not_found',
            'Managed reservation not found.',
            ['status' => 404]
        );
    }

    $updated = $wpdb->update(
        tryzub_get_reservations_table_name(),
        [
            'status' => sanitize_text_field((string) $status),
            'staff_notes' => tryzub_append_staff_note($reservation['staff_notes'] ?? '', $note),
            'updated_at' => current_time('mysql'),
        ],
        ['id' => absint($reservation_id)],
        ['%s', '%s', '%s'],
        ['%d']
    );

    if ($updated === false) {
        error_log('Tryzub guest request reservation update failed: ' . $wpdb->last_error);

        return new WP_Error(
            'tryzub_database_error',
            'Failed to update reservation request status.',
            ['status' => 500]
        );
    }

    tryzub_bump_intelligence_cache_version();
    tryzub_guest_profiles_mark_dirty_for_reservation($reservation_id, 'guest_self_service_update');

    return true;
}

function tryzub_append_staff_note($existing_notes, $note) {
    $existing_notes = trim((string) $existing_notes);
    $note = sanitize_textarea_field((string) $note);

    if ($note === '') {
        return $existing_notes;
    }

    if (strpos($existing_notes, $note) !== false) {
        return $existing_notes;
    }

    return $existing_notes !== '' ? $existing_notes . "\n" . $note : $note;
}

function tryzub_reservation_starts_within_hours(array $reservation, $hours) {
    $reservation_start = tryzub_get_reservation_start_timestamp($reservation);

    if (!$reservation_start) {
        return false;
    }

    $seconds_until_start = $reservation_start - tryzub_get_current_restaurant_timestamp();

    return $seconds_until_start <= (absint($hours) * HOUR_IN_SECONDS);
}

function tryzub_guest_can_cancel_reservation_online(array $reservation) {
    $status = sanitize_text_field((string) ($reservation['status'] ?? ''));

    if (!in_array($status, ['new', 'needs_review', 'confirmed'], true)) {
        return false;
    }

    return tryzub_reservation_is_at_least_hours_away($reservation, 2);
}

function tryzub_reservation_is_at_least_hours_away(array $reservation, $hours) {
    $reservation_start = tryzub_get_reservation_start_timestamp($reservation);

    if (!$reservation_start) {
        return false;
    }

    $seconds_until_start = $reservation_start - tryzub_get_current_restaurant_timestamp();

    return $seconds_until_start >= (absint($hours) * HOUR_IN_SECONDS);
}

function tryzub_get_reservation_start_timestamp(array $reservation) {
    $date = tryzub_normalize_reservation_date($reservation['reservation_date'] ?? '');
    $time = tryzub_normalize_reservation_time($reservation['reservation_time'] ?? '');

    if (!$date || !$time) {
        return null;
    }

    $timezone = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('America/Chicago');
    $date_time = DateTimeImmutable::createFromFormat('!Y-m-d H:i:s', $date . ' ' . $time, $timezone);
    $errors = DateTimeImmutable::getLastErrors();

    if (
        !$date_time instanceof DateTimeImmutable ||
        (
            $errors !== false &&
            ((int) $errors['warning_count'] > 0 || (int) $errors['error_count'] > 0)
        )
    ) {
        return null;
    }

    return $date_time->getTimestamp();
}

function tryzub_get_current_restaurant_timestamp() {
    if (function_exists('current_datetime')) {
        return current_datetime()->getTimestamp();
    }

    return time();
}

function tryzub_render_manage_reservation_shortcode() {
    $element_id = 'tryzub-manage-reservation-' . wp_rand(1000, 999999);
    $rest_root = rest_url('tryzub/v1/');

    ob_start();
    ?>
    <div id="<?php echo esc_attr($element_id); ?>" class="tryzub-manage-reservation" data-rest-root="<?php echo esc_url($rest_root); ?>">
        <div class="tryzub-manage-card tryzub-loading-card" role="status" aria-live="polite">
            <p>Loading reservation...</p>
        </div>
    </div>
    <style>
        .tryzub-manage-reservation { --tryzub-self-bg: #f5f1e8; --tryzub-self-card: #fffdf8; --tryzub-self-ink: #26231d; --tryzub-self-muted: #676154; --tryzub-self-line: rgba(47, 74, 58, 0.15); --tryzub-self-green: #557867; --tryzub-self-green-dark: #2f4a3a; --tryzub-self-gold: #ad7f3a; --tryzub-self-red: #9d332a; align-items: flex-start; background: var(--tryzub-self-bg); box-sizing: border-box; color: var(--tryzub-self-ink); display: flex; font-family: inherit; justify-content: center; margin: 0 calc(50% - 50vw); max-width: 100vw; min-height: 320px; overflow-x: hidden; padding: 28px 16px; width: 100vw; }
        .tryzub-manage-reservation *, .tryzub-manage-reservation *::before, .tryzub-manage-reservation *::after { box-sizing: border-box; }
        .tryzub-manage-card { background: var(--tryzub-self-card); border: 1px solid var(--tryzub-self-line); border-radius: 8px; box-shadow: 0 18px 42px -28px rgba(38, 35, 29, 0.42); max-width: 600px; padding: 24px; width: 100%; }
        .tryzub-loading-card p { color: var(--tryzub-self-muted); font-size: 16px; line-height: 1.5; margin: 0; text-align: center; }
        .tryzub-manage-reservation header { margin: 0 0 18px; }
        .tryzub-manage-reservation .tryzub-restaurant-name { color: var(--tryzub-self-gold); display: block; font-size: 0.88rem; font-weight: 700; line-height: 1.3; margin: 0 0 6px; }
        .tryzub-manage-reservation h2 { color: var(--tryzub-self-green-dark); font-size: 1.65rem; line-height: 1.15; margin: 0; }
        .tryzub-manage-reservation .tryzub-subtitle { color: var(--tryzub-self-muted); font-size: 16px; line-height: 1.45; margin: 8px 0 0; }
        .tryzub-manage-reservation .tryzub-banner { border: 1px solid transparent; border-radius: 8px; margin: 0 0 16px; padding: 14px 15px; }
        .tryzub-manage-reservation .tryzub-banner[hidden] { display: none !important; }
        .tryzub-manage-reservation .tryzub-banner h3 { font-size: 1rem; line-height: 1.25; margin: 0 0 4px; }
        .tryzub-manage-reservation .tryzub-banner p { font-size: 16px; line-height: 1.45; margin: 0; }
        .tryzub-manage-reservation .tryzub-banner-success { background: #edf7f0; border-color: rgba(36, 122, 59, 0.36); color: #155c28; }
        .tryzub-manage-reservation .tryzub-banner-error { background: #fff1ef; border-color: rgba(157, 51, 42, 0.3); color: var(--tryzub-self-red); }
        .tryzub-detail-list { border-top: 1px solid var(--tryzub-self-line); display: grid; gap: 0; margin: 18px 0 0; }
        .tryzub-detail-row { align-items: start; border-bottom: 1px solid var(--tryzub-self-line); display: grid; gap: 10px; grid-template-columns: minmax(108px, 0.42fr) 1fr; padding: 12px 0; }
        .tryzub-detail-label { color: var(--tryzub-self-muted); font-size: 0.95rem; font-weight: 700; line-height: 1.35; }
        .tryzub-detail-value { color: var(--tryzub-self-ink); font-size: 16px; line-height: 1.45; min-width: 0; overflow-wrap: anywhere; }
        .tryzub-detail-row[hidden] { display: none !important; }
        .tryzub-status-pill { align-items: center; background: rgba(85, 120, 103, 0.12); border: 1px solid rgba(85, 120, 103, 0.24); border-radius: 999px; color: var(--tryzub-self-green-dark); display: inline-flex; font-size: 0.95rem; font-weight: 800; line-height: 1; min-height: 30px; padding: 7px 11px; width: fit-content; }
        .tryzub-status-pill.tryzub-status-cancelled { background: rgba(157, 51, 42, 0.1); border-color: rgba(157, 51, 42, 0.24); color: var(--tryzub-self-red); }
        .tryzub-cancel-section { border-top: 1px solid var(--tryzub-self-line); margin: 18px 0 0; padding-top: 18px; }
        .tryzub-cancel-section p { color: var(--tryzub-self-muted); font-size: 16px; line-height: 1.45; margin: 0; }
        .tryzub-cancel-section[hidden] { display: none !important; }
        .tryzub-action-area { display: grid; gap: 10px; margin-top: 10px; }
        .tryzub-cancel-button { align-items: center; background: var(--tryzub-self-green); border: 1px solid var(--tryzub-self-green); border-radius: 8px; color: #ffffff; cursor: pointer; display: inline-flex; font: inherit; font-size: 16px; font-weight: 800; justify-content: center; line-height: 1.2; min-height: 48px; padding: 12px 18px; transition: background-color 150ms ease, border-color 150ms ease, box-shadow 150ms ease; }
        .tryzub-cancel-button:hover, .tryzub-cancel-button:focus { background: var(--tryzub-self-green-dark); border-color: var(--tryzub-self-green-dark); }
        .tryzub-cancel-button:focus-visible { box-shadow: 0 0 0 3px rgba(173, 127, 58, 0.35); outline: 0; }
        .tryzub-cancel-button:disabled { cursor: wait; opacity: 0.68; }
        .tryzub-online-unavailable { color: var(--tryzub-self-muted); font-size: 16px; line-height: 1.45; margin: 0; }
        @media (max-width: 520px) {
            .tryzub-manage-reservation { padding: 12px; }
            .tryzub-manage-card { padding: 20px 16px; }
            .tryzub-manage-reservation h2 { font-size: 1.45rem; }
            .tryzub-detail-row { gap: 4px; grid-template-columns: 1fr; padding: 11px 0; }
            .tryzub-cancel-button { width: 100%; }
        }
    </style>
    <script>
    (function () {
        var root = document.getElementById(<?php echo wp_json_encode($element_id); ?>);
        if (!root) {
            return;
        }

        var restRoot = root.getAttribute('data-rest-root').replace(/\/?$/, '/');
        var token = new URLSearchParams(window.location.search).get('token') || '';
        var reservation = null;
        var isCanceling = false;
        var statusLabels = {
            new: 'Received',
            needs_review: 'Under Review',
            confirmed: 'Confirmed',
            cancelled: 'Cancelled',
            seated: 'Checked In',
            completed: 'Completed',
            no_show: 'No Show'
        };
        var invalidLinkMessage = 'This reservation link is invalid or has expired. Please contact Tryzub Ukrainian Kitchen for help.';
        var lateCancelMessage = 'Online cancellation is no longer available for this reservation. Please call Tryzub Ukrainian Kitchen so our team can help you.';

        function setText(element, text) {
            if (!element) {
                return;
            }

            element.textContent = text == null ? '' : String(text);
        }

        function request(path, options) {
            options = options || {};
            options.headers = Object.assign({ Accept: 'application/json' }, options.headers || {});

            if (options.body && !options.headers['Content-Type']) {
                options.headers['Content-Type'] = 'application/json';
            }

            return window.fetch(restRoot + path, options).then(function (response) {
                return response.json().then(function (payload) {
                    if (!response.ok || payload.success === false) {
                        throw new Error(payload.message || 'Request failed.');
                    }

                    return payload;
                });
            });
        }

        function renderError(message) {
            root.innerHTML = [
                '<div class="tryzub-manage-card">',
                '<div class="tryzub-banner tryzub-banner-error" role="alert">',
                '<h3>Reservation Link Unavailable</h3>',
                '<p></p>',
                '</div>',
                '</div>'
            ].join('');
            setText(root.querySelector('p'), message || invalidLinkMessage);
        }

        function renderBanner(type, title, message) {
            var banner = root.querySelector('[data-banner]');

            if (!banner) {
                return;
            }

            banner.className = 'tryzub-banner tryzub-banner-' + type;
            banner.removeAttribute('hidden');
            banner.setAttribute('role', type === 'error' ? 'alert' : 'status');
            setText(banner.querySelector('h3'), title);
            setText(banner.querySelector('p'), message);
            banner.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }

        function displayStatusLabel(status) {
            return statusLabels[status] || 'Under Review';
        }

        function updateStatusDisplay(status) {
            var statusRow = root.querySelector('[data-row="status"]');
            var statusField = root.querySelector('[data-field="status"]');

            if (!statusField) {
                return;
            }

            statusField.innerHTML = '<span class="tryzub-status-pill"></span>';
            var pill = statusField.querySelector('.tryzub-status-pill');

            if (status === 'cancelled') {
                pill.classList.add('tryzub-status-cancelled');
            }

            setText(pill, displayStatusLabel(status));

            if (statusRow) {
                statusRow.hidden = false;
            }
        }

        function updateSubtitle(data) {
            var subtitle = root.querySelector('.tryzub-subtitle');

            if (!subtitle) {
                return;
            }

            if (data && data.status === 'cancelled') {
                subtitle.hidden = true;
                return;
            }

            subtitle.hidden = false;
            setText(subtitle, 'To change your reservation, reply to your confirmation email. To cancel, use the button below.');
        }

        function loadReservation() {
            return request('reservation-self?token=' + encodeURIComponent(token)).then(function (payload) {
                reservation = payload.data;
                return reservation;
            });
        }

        function formatDateForDisplay(value) {
            var parts = String(value || '').split('-').map(Number);

            if (parts.length !== 3 || !parts[0] || !parts[1] || !parts[2]) {
                return value || '';
            }

            var date = new Date(parts[0], parts[1] - 1, parts[2]);

            if (isNaN(date.getTime())) {
                return value || '';
            }

            return date.toLocaleDateString(undefined, {
                weekday: 'short',
                month: 'long',
                day: 'numeric',
                year: 'numeric'
            });
        }

        function formatTimeForDisplay(value) {
            var match = String(value || '').match(/^(\d{1,2}):(\d{2})/);

            if (!match) {
                return value || '';
            }

            var hour = Number(match[1]);
            var minute = match[2];
            var suffix = hour >= 12 ? 'PM' : 'AM';
            var hour12 = hour % 12 || 12;

            return hour12 + ':' + minute + ' ' + suffix;
        }

        function isActiveCancelableStatus(status) {
            return status === 'new' || status === 'needs_review' || status === 'confirmed';
        }

        function isOnlineCancellationAllowed(data) {
            return Boolean(data && data.can_request_cancel);
        }

        function buildDetailRow(label, field, extraClass) {
            return [
                '<div class="tryzub-detail-row ', extraClass || '', '" data-row="', field, '">',
                '<span class="tryzub-detail-label">', label, '</span>',
                '<span class="tryzub-detail-value" data-field="', field, '"></span>',
                '</div>'
            ].join('');
        }

        function buildCardMarkup() {
            return [
                '<div class="tryzub-manage-card">',
                '<div class="tryzub-banner" data-banner hidden><h3></h3><p></p></div>',
                '<header>',
                '<span class="tryzub-restaurant-name" data-field="restaurant"></span>',
                '<h2>Your Booking Details</h2>',
                '<p class="tryzub-subtitle"></p>',
                '</header>',
                '<div class="tryzub-detail-list">',
                buildDetailRow('Guest', 'name'),
                buildDetailRow('Date', 'date'),
                buildDetailRow('Time', 'time'),
                buildDetailRow('Party size', 'party'),
                buildDetailRow('Status', 'status'),
                buildDetailRow('Notes', 'notes'),
                '</div>',
                '<section class="tryzub-cancel-section" data-cancel-section>',
                '<div class="tryzub-action-area" data-action-area></div>',
                '</section>',
                '</div>'
            ].join('');
        }

        function setNotesVisibility(data) {
            var row = root.querySelector('[data-row="notes"]');
            var notes = data.guest_notes ? String(data.guest_notes).trim() : '';

            if (!row) {
                return;
            }

            if (!notes) {
                row.hidden = true;
                return;
            }

            row.hidden = false;
            setText(root.querySelector('[data-field="notes"]'), notes);
        }

        function renderCard(data) {
            reservation = data;
            root.innerHTML = buildCardMarkup();

            setText(root.querySelector('[data-field="restaurant"]'), data.restaurant_name);
            setText(root.querySelector('[data-field="name"]'), data.guest_name);
            setText(root.querySelector('[data-field="date"]'), formatDateForDisplay(data.reservation_date));
            setText(root.querySelector('[data-field="time"]'), formatTimeForDisplay(data.reservation_time));
            setText(root.querySelector('[data-field="party"]'), String(data.party_size) + (Number(data.party_size) === 1 ? ' guest' : ' guests'));

            updateStatusDisplay(data.status);
            updateSubtitle(data);
            setNotesVisibility(data);

            renderCancelAction(data);
        }

        function renderCancelAction(data) {
            var actionArea = root.querySelector('[data-action-area]');
            var cancelSection = root.querySelector('[data-cancel-section]');

            if (!actionArea || !cancelSection) {
                return;
            }

            if (data && data.status === 'cancelled') {
                cancelSection.hidden = true;
                actionArea.innerHTML = '';
                return;
            }

            cancelSection.hidden = false;

            if (!isOnlineCancellationAllowed(data)) {
                actionArea.innerHTML = '<p class="tryzub-online-unavailable"></p>';
                if (data && isActiveCancelableStatus(data.status)) {
                    setText(actionArea.querySelector('p'), lateCancelMessage);
                } else {
                    setText(actionArea.querySelector('p'), 'Online cancellation is not available. Please contact the restaurant.');
                }
                return;
            }

            actionArea.innerHTML = '<button type="button" class="tryzub-cancel-button" data-action="cancel">Cancel Reservation</button>';
            actionArea.querySelector('[data-action="cancel"]').addEventListener('click', sendCancelRequest);
        }

        function sendCancelRequest() {
            var cancelButton = root.querySelector('[data-action="cancel"]');

            if (isCanceling || !cancelButton) {
                return;
            }

            if (!window.confirm('Cancel this reservation?')) {
                return;
            }

            isCanceling = true;
            cancelButton.disabled = true;
            cancelButton.textContent = 'Cancelling...';

            request('reservation-self/cancel', {
                method: 'POST',
                body: JSON.stringify({
                    token: token
                })
            }).then(function () {
                return loadReservation();
            }).then(function (data) {
                updateStatusDisplay(data.status);
                updateSubtitle(data);
                renderCancelAction(data);
                renderBanner('success', 'Reservation Cancelled', 'Your reservation has been cancelled.');
            }).catch(function (error) {
                isCanceling = false;
                cancelButton.disabled = false;
                cancelButton.textContent = 'Cancel Reservation';
                renderBanner('error', 'Cancellation Unavailable', error.message || lateCancelMessage);
            });
        }

        if (!token) {
            renderError(invalidLinkMessage);
            return;
        }

        loadReservation()
            .then(function (data) {
                renderCard(data);
            })
            .catch(function (error) {
                renderError(error.message);
            });
    })();
    </script>
    <?php
    return ob_get_clean();
}

add_shortcode('tryzub_manage_reservation', 'tryzub_render_manage_reservation_shortcode');
