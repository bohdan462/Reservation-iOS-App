<?php

function tryzub_get_guest_intelligence(WP_REST_Request $request) {
    $date = tryzub_intelligence_validate_date($request->get_param('date'));

    if (is_wp_error($date)) {
        return $date;
    }

    $service_rows = tryzub_guest_intelligence_fetch_service_date_rows($date);
    $payload = tryzub_guest_intelligence_empty_payload($date);

    if (!empty($service_rows)) {
        $history_rows = tryzub_guest_intelligence_fetch_history_rows($service_rows, $date);
        $items = [];

        foreach ($service_rows as $row) {
            $items[] = tryzub_guest_intelligence_build_item($row, $history_rows, $service_rows, false);
        }

        $payload['items'] = $items;
    }

    $payload['data_quality']['warnings'] = tryzub_guest_intelligence_build_warnings($service_rows);

    return tryzub_intelligence_response($payload);
}

function tryzub_get_guest_intelligence_for_reservation(WP_REST_Request $request) {
    $reservation_id = absint($request->get_param('id'));
    $row = tryzub_guest_intelligence_fetch_reservation_row_by_id($reservation_id);

    if (is_wp_error($row)) {
        return $row;
    }

    if (function_exists('tryzub_guest_profiles_fetch_profile_for_reservation')) {
        $profile = tryzub_guest_profiles_fetch_profile_for_reservation($reservation_id);

        if (is_array($profile) && !empty($profile['profile_pack_json'])) {
            if (!empty($profile['dirty_at']) && function_exists('tryzub_guest_profiles_schedule_dirty_rebuild')) {
                tryzub_guest_profiles_schedule_dirty_rebuild();
            }

            return tryzub_intelligence_response(
                tryzub_guest_profiles_build_compatible_reservation_payload($row, $profile)
            );
        }

        if (function_exists('tryzub_guest_profiles_mark_dirty_for_reservation_row')) {
            tryzub_guest_profiles_mark_dirty_for_reservation_row($row, 'legacy_guest_intelligence_pending');
        }
    }

    if (function_exists('tryzub_guest_profiles_schedule_dirty_rebuild')) {
        tryzub_guest_profiles_schedule_dirty_rebuild();
    }

    return tryzub_intelligence_response(
        tryzub_guest_intelligence_build_stale_reservation_profile_payload($row)
    );
}

function tryzub_guest_intelligence_reservation_contract_metadata() {
    return [
        'contract_version' => '1.0',
        'profile_pack_version' => '1.0',
        'scope' => 'reservation_guest_intelligence',
        'source' => 'server_guest_intelligence',
        'data_quality' => [
            'history_matching' => 'email_phone_only_v1',
            'name_only_history_matching' => false,
            'notes_mode' => 'multilingual_boolean_flags_v1',
            'identity_matching' => 'email_phone_hmac_v1',
            'history_scope' => 'full_managed_reservations',
            'warnings' => [
                'note_flags_are_heuristic',
                'history_matching_limited_to_email_phone',
                'name_only_identity_not_used_for_history',
            ],
        ],
    ];
}

function tryzub_guest_intelligence_fetch_reservation_row_by_id($reservation_id) {
    $reservation_id = absint($reservation_id);

    if ($reservation_id < 1) {
        return new WP_Error(
            'tryzub_invalid_reservation_id',
            'Reservation ID must be valid.',
            ['status' => 400]
        );
    }

    if (!function_exists('tryzub_get_managed_reservation_row_by_id')) {
        return new WP_Error(
            'tryzub_guest_intelligence_unavailable',
            'Managed reservation lookup is unavailable.',
            ['status' => 500]
        );
    }

    $row = tryzub_get_managed_reservation_row_by_id($reservation_id);

    if (!$row) {
        return new WP_Error(
            'tryzub_reservation_not_found',
            'Managed reservation not found.',
            ['status' => 404]
        );
    }

    return $row;
}

function tryzub_guest_intelligence_build_reservation_payload(array $row, array $item, array $profile_pack = []) {
    $history = $item['history'];

    if (!empty($profile_pack['history'])) {
        $history = array_merge($history, $profile_pack['history']);
    }

    $payload = array_merge(
        tryzub_guest_intelligence_reservation_contract_metadata(),
        [
            'generated_at' => tryzub_intelligence_generated_at_iso(),
            'reservation_id' => (int) ($row['id'] ?? 0),
            'guest_name' => (string) ($item['guest_name'] ?? ''),
            'identity' => $item['identity'],
            'history' => $history,
            'signals' => $item['signals'],
            'debug' => $item['debug'],
            'item' => $item,
        ]
    );

    foreach (['profile_summary', 'preferences', 'note_intelligence', 'visit_analytics', 'host_profile_packet'] as $section) {
        if (isset($profile_pack[$section])) {
            $payload[$section] = $profile_pack[$section];
        }
    }

    return $payload;
}

function tryzub_guest_intelligence_build_stale_reservation_profile_payload(array $row) {
    $item = tryzub_guest_intelligence_build_item($row, [], [$row], false);
    unset($item['debug']);

    $history = $item['history'] ?? [];
    $history['matched_visit_preview'] = [];

    return array_merge(
        tryzub_guest_intelligence_reservation_contract_metadata(),
        [
            'generated_at' => tryzub_intelligence_generated_at_iso(),
            'reservation_id' => (int) ($row['id'] ?? 0),
            'guest_name' => (string) ($row['guest_name'] ?? ''),
            'identity' => $item['identity'] ?? [
                'match_type' => 'unknown',
                'confidence' => 'low',
                'normalized_phone_present' => false,
                'email_present' => false,
            ],
            'history' => $history,
            'signals' => $item['signals'] ?? [],
            'item' => $item,
            'stale' => true,
            'source_coverage' => [
                'backend_profile' => true,
                'backend_precomputed' => false,
                'local_cache_supplement' => false,
                'pos_connected' => false,
                'stale' => true,
            ],
            'profile_summary' => [
                'summary_text' => 'Guest profile is updating.',
                'classification' => 'unknown',
                'management_notes' => [],
                'confidence' => 'low',
                'history_scope' => 'backend_precomputed_pending',
            ],
            'preferences' => tryzub_guest_intelligence_empty_preferences(),
            'note_intelligence' => tryzub_guest_intelligence_empty_note_intelligence(),
            'visit_analytics' => [],
            'host_profile_packet' => [
                'service_lines' => [],
                'risk_lines' => [],
                'preference_lines' => [],
                'evidence_lines' => [],
            ],
        ]
    );
}

function tryzub_guest_intelligence_contract_metadata() {
    return [
        'contract_version' => '1.0',
        'scope' => 'service_date_guest_intelligence',
        'source' => 'managed_reservations',
        'data_quality' => [
            'history_matching' => 'email_phone_only_v1',
            'name_only_history_matching' => false,
            'notes_mode' => 'multilingual_boolean_flags_v1',
            'identity_matching' => 'email_phone_hmac_v1',
            'warnings' => [],
        ],
    ];
}

function tryzub_guest_intelligence_build_warnings(array $service_rows) {
    $warnings = [
        'note_flags_are_heuristic',
        'history_matching_limited_to_email_phone',
        'name_only_identity_not_used_for_history',
    ];

    if (empty($service_rows)) {
        return $warnings;
    }

    $identity_keys = 0;
    $name_only_rows = 0;

    foreach ($service_rows as $row) {
        $identity = tryzub_intelligence_identity_from_row($row);

        if (!empty($identity['guest_key'])) {
            $identity_keys++;
        }

        if (strpos((string) ($identity['basis'] ?? ''), 'name:') === 0) {
            $name_only_rows++;
        }
    }

    if ($identity_keys === 0) {
        $warnings[] = 'no_identity_keys_available';
    }

    if ($name_only_rows > 0) {
        $warnings[] = 'name_only_identity_not_used_for_history';
    }

    return array_values(array_unique($warnings));
}

function tryzub_guest_intelligence_empty_payload($date) {
    return array_merge(tryzub_guest_intelligence_contract_metadata(), [
        'date' => $date,
        'generated_at' => tryzub_intelligence_generated_at_iso(),
        'items' => [],
    ]);
}

function tryzub_guest_intelligence_fetch_service_date_rows($date) {
    global $wpdb;

    $table_name = tryzub_get_reservations_table_name();

    return $wpdb->get_results(
        $wpdb->prepare(
            "SELECT
                id,
                email,
                phone,
                guest_name,
                reservation_date,
                reservation_time,
                party_size,
                status,
                source_type,
                table_name,
                guest_notes,
                staff_notes,
                duplicate_of_reservation_id,
                duplicate_reason,
                superseded_by_id,
                is_hidden
            FROM $table_name
            WHERE reservation_date = %s
            AND is_hidden = 0
            AND superseded_by_id IS NULL
            ORDER BY reservation_time ASC, id ASC",
            $date
        ),
        ARRAY_A
    );
}

function tryzub_guest_intelligence_fetch_history_rows(array $service_rows, $date) {
    global $wpdb;

    $emails = [];
    $phones = [];

    foreach ($service_rows as $row) {
        $identity = tryzub_intelligence_identity_from_row($row);

        if ($identity['normalized_email'] !== '') {
            $emails[$identity['normalized_email']] = true;
        }

        if ($identity['normalized_phone'] !== '') {
            $phones[$identity['normalized_phone']] = true;
        }
    }

    $emails = array_keys($emails);
    $phones = array_keys($phones);

    if (empty($emails) && empty($phones)) {
        return [];
    }

    $table_name = tryzub_get_reservations_table_name();
    $conditions = [];
    $values = [$date];

    if (!empty($emails)) {
        $email_placeholders = implode(', ', array_fill(0, count($emails), '%s'));
        $conditions[] = "LOWER(email) IN ($email_placeholders)";
        $values = array_merge($values, $emails);
    }

    if (!empty($phones)) {
        $phone_placeholders = implode(', ', array_fill(0, count($phones), '%s'));
        $conditions[] = "phone IN ($phone_placeholders)";
        $values = array_merge($values, $phones);
    }

    $sql = "
        SELECT
            id,
            email,
            phone,
            guest_name,
            reservation_date,
            reservation_time,
            party_size,
            status,
            source_type,
            table_name,
            guest_notes,
            staff_notes,
            duplicate_of_reservation_id,
            duplicate_reason,
            superseded_by_id,
            is_hidden
        FROM $table_name
        WHERE reservation_date <= %s
        AND (" . implode(' OR ', $conditions) . ")
        ORDER BY reservation_date ASC, reservation_time ASC, id ASC
    ";

    return $wpdb->get_results($wpdb->prepare($sql, $values), ARRAY_A);
}

function tryzub_guest_intelligence_build_item(array $row, array $history_rows, array $service_rows, $include_debug = false) {
    $identity = tryzub_intelligence_identity_from_row($row);
    $related_reservation_ids = tryzub_guest_intelligence_same_day_related_ids($row, $identity, $service_rows);
    $possible_duplicate = tryzub_guest_intelligence_detect_possible_duplicate($row, $related_reservation_ids);
    $needs_review = sanitize_text_field((string) ($row['status'] ?? '')) === 'needs_review';
    $prior_matches = tryzub_guest_intelligence_prior_matches($row, $identity, $history_rows);
    $clean_matches = array_values(
        array_filter(
            $prior_matches,
            'tryzub_intelligence_is_clean_history_row'
        )
    );
    $clean_visit_count = count($clean_matches);
    $matched_visit_count = count($prior_matches);
    $cancelled_count = 0;
    $no_show_count = 0;

    foreach ($prior_matches as $match) {
        $status = sanitize_text_field((string) ($match['status'] ?? ''));

        if ($status === 'cancelled') {
            $cancelled_count++;
        } elseif ($status === 'no_show') {
            $no_show_count++;
        }
    }

    $clean_dates = array_map(
        function ($match) {
            return (string) ($match['reservation_date'] ?? '');
        },
        $clean_matches
    );
    $clean_dates = array_values(array_filter($clean_dates));

    $last_visit_date = !empty($clean_dates) ? max($clean_dates) : null;
    $first_visit_date = !empty($clean_dates) ? min($clean_dates) : null;
    $source_counts = tryzub_guest_intelligence_source_counts($clean_matches);
    $note_flags = tryzub_guest_intelligence_collect_note_flags($row, array_merge($prior_matches, [$row]));
    $classification = tryzub_intelligence_classify_guest(
        $clean_visit_count,
        $identity['confidence'],
        $needs_review,
        $possible_duplicate
    );

    $identity_confidence = tryzub_intelligence_safe_enum(
        $identity['confidence'],
        ['exact', 'strong', 'possible', 'weak', 'unknown'],
        'unknown'
    );
    $ios = tryzub_guest_intelligence_build_ios_summary(
        $row,
        $identity,
        $identity_confidence,
        $clean_visit_count,
        $last_visit_date,
        $first_visit_date,
        $note_flags,
        $no_show_count,
        $include_debug
    );

    return array_merge([
        'reservation_id' => (int) ($row['id'] ?? 0),
        'guest_key' => $identity['guest_key'],
        'guest_name' => (string) ($row['guest_name'] ?? ''),
        'identity_confidence' => $identity_confidence,
        'classification' => tryzub_intelligence_safe_enum(
            $classification,
            ['unknown', 'new', 'returning', 'regular', 'frequent_regular', 'needs_review'],
            'unknown'
        ),
        'matched_visit_count' => $matched_visit_count,
        'clean_visit_count' => $clean_visit_count,
        'last_visit_date' => $last_visit_date,
        'first_visit_date' => $first_visit_date,
        'usual_time' => tryzub_guest_intelligence_usual_time($clean_matches),
        'usual_weekday' => tryzub_guest_intelligence_usual_weekday($clean_matches),
        'average_party_size' => tryzub_guest_intelligence_average_party_size($clean_matches),
        'max_party_size' => tryzub_guest_intelligence_max_party_size($clean_matches),
        'online_count' => $source_counts['online_count'],
        'call_in_count' => $source_counts['call_in_count'],
        'manual_count' => $source_counts['manual_count'],
        'cancelled_count' => $cancelled_count,
        'no_show_count' => $no_show_count,
        'has_seating_preference' => (bool) $note_flags['has_seating_preference'],
        'has_allergy_note' => (bool) $note_flags['has_allergy_note'],
        'has_accessibility_note' => (bool) $note_flags['has_accessibility_note'],
        'has_special_occasion_note' => (bool) $note_flags['has_special_occasion_note'],
        'has_prior_service_issue' => (bool) $note_flags['has_prior_service_issue'],
        'possible_duplicate' => $possible_duplicate,
        'related_reservation_ids' => array_values(array_map('intval', $related_reservation_ids)),
        'seen_before' => $ios['seen_before'],
        'prior_visit_count' => $ios['prior_visit_count'],
        'last_seen_date' => $ios['last_seen_date'],
        'safe_copy' => $ios['safe_copy'],
        'identity' => $ios['identity'],
        'history' => $ios['history'],
        'signals' => $ios['signals'],
        'has_history_preview' => tryzub_guest_intelligence_identity_supports_history_matching($identity) && $clean_visit_count > 0,
        'has_prior_notes' => tryzub_guest_intelligence_identity_supports_history_matching($identity)
            && tryzub_guest_intelligence_prior_rows_have_notes($prior_matches),
        'profile_endpoint' => '/tryzub/v1/guest-intelligence/reservation/' . (int) ($row['id'] ?? 0),
    ], $include_debug ? ['debug' => $ios['debug']] : []);
}

function tryzub_guest_intelligence_prior_matches(array $row, array $identity, array $history_rows) {
    if (in_array($identity['confidence'], ['weak', 'unknown'], true)) {
        return [];
    }

    if (strpos((string) ($identity['basis'] ?? ''), 'name:') === 0) {
        return [];
    }

    $row_id = (int) ($row['id'] ?? 0);
    $service_date = (string) ($row['reservation_date'] ?? '');
    $matches = [];

    foreach ($history_rows as $history_row) {
        if ((int) ($history_row['id'] ?? 0) === $row_id) {
            continue;
        }

        if ((string) ($history_row['reservation_date'] ?? '') >= $service_date) {
            continue;
        }

        if (!tryzub_intelligence_is_operational_row($history_row)) {
            continue;
        }

        if (!tryzub_guest_intelligence_row_matches_identity($history_row, $identity)) {
            continue;
        }

        $matches[] = $history_row;
    }

    return $matches;
}

function tryzub_guest_intelligence_row_matches_identity(array $history_row, array $identity) {
    if ($identity['normalized_email'] !== '') {
        $history_email = tryzub_intelligence_normalize_email($history_row['email'] ?? '');

        if ($history_email !== '' && $history_email === $identity['normalized_email']) {
            return true;
        }
    }

    if ($identity['normalized_phone'] !== '') {
        $history_phone = tryzub_intelligence_normalize_phone($history_row['phone'] ?? '');

        if ($history_phone !== '' && $history_phone === $identity['normalized_phone']) {
            return true;
        }
    }

    return false;
}

function tryzub_guest_intelligence_same_day_related_ids(array $row, array $identity, array $service_rows) {
    if (in_array($identity['confidence'], ['weak', 'unknown'], true)) {
        return [];
    }

    if (strpos((string) ($identity['basis'] ?? ''), 'name:') === 0) {
        return [];
    }

    $row_id = (int) ($row['id'] ?? 0);
    $active_statuses = tryzub_intelligence_active_statuses();
    $related = [];

    foreach ($service_rows as $other_row) {
        $other_id = (int) ($other_row['id'] ?? 0);

        if ($other_id === $row_id) {
            continue;
        }

        if (!tryzub_intelligence_is_operational_row($other_row)) {
            continue;
        }

        if (!in_array(sanitize_text_field((string) ($other_row['status'] ?? '')), $active_statuses, true)) {
            continue;
        }

        if (!tryzub_guest_intelligence_row_matches_identity($other_row, $identity)) {
            continue;
        }

        $related[] = $other_id;
    }

    sort($related, SORT_NUMERIC);

    return $related;
}

function tryzub_guest_intelligence_detect_possible_duplicate(array $row, array $related_ids) {
    if (!empty($row['duplicate_of_reservation_id'])) {
        return true;
    }

    if (trim((string) ($row['duplicate_reason'] ?? '')) !== '') {
        return true;
    }

    if (stripos((string) ($row['staff_notes'] ?? ''), 'Possible duplicate') !== false) {
        return true;
    }

    return !empty($related_ids);
}

function tryzub_guest_intelligence_usual_time(array $clean_matches) {
    if (empty($clean_matches)) {
        return null;
    }

    $bucket_counts = [];
    $bucket_latest_date = [];

    foreach ($clean_matches as $match) {
        $bucket = tryzub_intelligence_time_15min_bucket($match['reservation_time'] ?? '');

        if ($bucket === null) {
            continue;
        }

        if (!isset($bucket_counts[$bucket])) {
            $bucket_counts[$bucket] = 0;
            $bucket_latest_date[$bucket] = '';
        }

        $bucket_counts[$bucket]++;
        $match_date = (string) ($match['reservation_date'] ?? '');

        if ($match_date >= $bucket_latest_date[$bucket]) {
            $bucket_latest_date[$bucket] = $match_date;
        }
    }

    if (empty($bucket_counts)) {
        return null;
    }

    arsort($bucket_counts, SORT_NUMERIC);
    $top_count = reset($bucket_counts);
    $candidates = array_keys(
        array_filter(
            $bucket_counts,
            function ($count) use ($top_count) {
                return $count === $top_count;
            }
        )
    );

    if (count($candidates) === 1) {
        return $candidates[0];
    }

    // Tie-break: prefer the bucket from the most recent prior clean visit; if still tied, earliest HH:mm.
    usort(
        $candidates,
        function ($left, $right) use ($bucket_latest_date) {
            $left_date = $bucket_latest_date[$left] ?? '';
            $right_date = $bucket_latest_date[$right] ?? '';

            if ($left_date !== $right_date) {
                return strcmp($right_date, $left_date);
            }

            return strcmp($left, $right);
        }
    );

    return $candidates[0];
}

function tryzub_guest_intelligence_usual_weekday(array $clean_matches) {
    if (empty($clean_matches)) {
        return null;
    }

    $weekday_counts = [];

    foreach ($clean_matches as $match) {
        $weekday = tryzub_guest_intelligence_mysql_weekday((string) ($match['reservation_date'] ?? ''));

        if (!isset($weekday_counts[$weekday])) {
            $weekday_counts[$weekday] = 0;
        }

        $weekday_counts[$weekday]++;
    }

    if (empty($weekday_counts)) {
        return null;
    }

    arsort($weekday_counts, SORT_NUMERIC);
    $top_count = reset($weekday_counts);
    $candidates = array_keys(
        array_filter(
            $weekday_counts,
            function ($count) use ($top_count) {
                return $count === $top_count;
            }
        )
    );

    sort($candidates, SORT_NUMERIC);

    return tryzub_intelligence_weekday_label((int) $candidates[0]);
}

function tryzub_guest_intelligence_source_counts(array $clean_matches) {
    $counts = [
        'online_count' => 0,
        'call_in_count' => 0,
        'manual_count' => 0,
    ];

    foreach ($clean_matches as $match) {
        $bucket = tryzub_intelligence_source_bucket($match['source_type'] ?? '');

        if ($bucket === 'online') {
            $counts['online_count']++;
        } elseif ($bucket === 'call_in') {
            $counts['call_in_count']++;
        } elseif ($bucket === 'manual') {
            $counts['manual_count']++;
        }
    }

    return $counts;
}

function tryzub_guest_intelligence_collect_note_flags(array $row, array $matches) {
    $flags = [
        'has_seating_preference' => false,
        'has_allergy_note' => false,
        'has_accessibility_note' => false,
        'has_special_occasion_note' => false,
        'has_prior_service_issue' => false,
    ];

    foreach ($matches as $match) {
        $match_flags = tryzub_intelligence_detect_note_flags(
            $match['guest_notes'] ?? '',
            $match['staff_notes'] ?? ''
        );

        foreach ($flags as $key => $value) {
            if ($match_flags[$key]) {
                $flags[$key] = true;
            }
        }
    }

    return $flags;
}

function tryzub_guest_intelligence_average_party_size(array $clean_matches) {
    if (empty($clean_matches)) {
        return null;
    }

    $total = 0;

    foreach ($clean_matches as $match) {
        $total += (int) ($match['party_size'] ?? 0);
    }

    return round($total / count($clean_matches), 2);
}

function tryzub_guest_intelligence_max_party_size(array $clean_matches) {
    if (empty($clean_matches)) {
        return null;
    }

    $max = 0;

    foreach ($clean_matches as $match) {
        $max = max($max, (int) ($match['party_size'] ?? 0));
    }

    return $max > 0 ? $max : null;
}

function tryzub_guest_intelligence_usual_party_size(array $clean_matches) {
    if (empty($clean_matches)) {
        return null;
    }

    $size_counts = [];

    foreach ($clean_matches as $match) {
        $party_size = (int) ($match['party_size'] ?? 0);

        if ($party_size < 1) {
            continue;
        }

        if (!isset($size_counts[$party_size])) {
            $size_counts[$party_size] = 0;
        }

        $size_counts[$party_size]++;
    }

    if (empty($size_counts)) {
        return null;
    }

    arsort($size_counts, SORT_NUMERIC);

    return (int) key($size_counts);
}

function tryzub_guest_intelligence_mysql_weekday($date) {
    $date_time = DateTimeImmutable::createFromFormat('!Y-m-d', (string) $date);

    if (!$date_time instanceof DateTimeImmutable) {
        return 0;
    }

    return ((int) $date_time->format('N')) - 1;
}

function tryzub_guest_intelligence_identity_supports_history_matching(array $identity) {
    if (in_array($identity['confidence'] ?? '', ['weak', 'unknown'], true)) {
        return false;
    }

    if (strpos((string) ($identity['basis'] ?? ''), 'name:') === 0) {
        return false;
    }

    return ($identity['normalized_email'] ?? '') !== '' || ($identity['normalized_phone'] ?? '') !== '';
}

function tryzub_guest_intelligence_prior_count_is_reliable($identity_confidence) {
    return in_array($identity_confidence, ['exact', 'strong'], true);
}

function tryzub_guest_intelligence_map_match_type(array $identity) {
    $email_present = ($identity['normalized_email'] ?? '') !== '';
    $phone_present = ($identity['normalized_phone'] ?? '') !== '';

    if ($email_present && $phone_present) {
        return 'phone_email';
    }

    if ($phone_present) {
        return 'phone';
    }

    if ($email_present) {
        return 'email';
    }

    if (strpos((string) ($identity['basis'] ?? ''), 'name:') === 0) {
        return 'name_only';
    }

    return 'unknown';
}

function tryzub_guest_intelligence_map_confidence_level($identity_confidence) {
    if (in_array($identity_confidence, ['exact', 'strong'], true)) {
        return 'high';
    }

    if ($identity_confidence === 'possible') {
        return 'medium';
    }

    return 'low';
}

function tryzub_guest_intelligence_resolve_seen_before($clean_visit_count, array $identity, $identity_confidence) {
    if (!tryzub_guest_intelligence_identity_supports_history_matching($identity)) {
        return null;
    }

    return $clean_visit_count > 0;
}

function tryzub_guest_intelligence_resolve_prior_visit_count($clean_visit_count, $identity_confidence) {
    if (!tryzub_guest_intelligence_prior_count_is_reliable($identity_confidence)) {
        return null;
    }

    return $clean_visit_count;
}

function tryzub_guest_intelligence_build_safe_copy($guest_name, $seen_before, $prior_visit_count, $identity_confidence) {
    $guest_name = trim((string) $guest_name);
    $label = $guest_name !== '' ? $guest_name : 'This guest';

    if ($seen_before === null) {
        return null;
    }

    if ($seen_before === false) {
        return $label . ' has no prior visits found in managed reservations.';
    }

    if (
        tryzub_guest_intelligence_prior_count_is_reliable($identity_confidence) &&
        is_int($prior_visit_count) &&
        $prior_visit_count > 1
    ) {
        return $label . ' visited ' . $prior_visit_count . ' times before.';
    }

    return $label . ' appears to have visited before.';
}

function tryzub_guest_intelligence_has_birthday_note($guest_notes, $staff_notes = '') {
    return tryzub_intelligence_text_contains_keyword(
        tryzub_intelligence_normalize_note_text($guest_notes, $staff_notes),
        [
            'birthday',
            'день народження',
            'день рождения',
            'den narodzhennya',
        ]
    );
}

function tryzub_guest_intelligence_has_dietary_note($guest_notes, $staff_notes = '') {
    return tryzub_intelligence_text_contains_keyword(
        tryzub_intelligence_normalize_note_text($guest_notes, $staff_notes),
        [
            'vegetarian',
            'vegan',
            'веган',
            'вегетаріанець',
            'вегетаріанський',
        ]
    );
}

function tryzub_guest_intelligence_build_signals(array $row, array $note_flags, $no_show_count) {
    $guest_notes = $row['guest_notes'] ?? '';
    $staff_notes = $row['staff_notes'] ?? '';
    $has_dietary = tryzub_guest_intelligence_has_dietary_note($guest_notes, $staff_notes);
    $has_allergy = (bool) ($note_flags['has_allergy_note'] ?? false) && !$has_dietary;

    return [
        'occasion' => !empty($note_flags['has_special_occasion_note']) ? true : null,
        'birthday' => tryzub_guest_intelligence_has_birthday_note($guest_notes, $staff_notes),
        'dietary' => $has_dietary ? true : null,
        'allergy' => $has_allergy ? true : null,
        'accessibility' => !empty($note_flags['has_accessibility_note']) ? true : null,
        'service_issue' => !empty($note_flags['has_prior_service_issue']) ? true : null,
        'no_show_risk' => $no_show_count > 0 ? true : null,
    ];
}

function tryzub_guest_intelligence_build_ios_summary(
    array $row,
    array $identity,
    $identity_confidence,
    $clean_visit_count,
    $last_visit_date,
    $first_visit_date,
    array $note_flags,
    $no_show_count,
    $include_debug = false
) {
    $seen_before = tryzub_guest_intelligence_resolve_seen_before($clean_visit_count, $identity, $identity_confidence);
    $prior_visit_count = tryzub_guest_intelligence_resolve_prior_visit_count($clean_visit_count, $identity_confidence);
    $match_type = tryzub_guest_intelligence_map_match_type($identity);
    $confidence_level = tryzub_guest_intelligence_map_confidence_level($identity_confidence);
    $identity_summary = [
        'match_type' => tryzub_intelligence_safe_enum(
            $match_type,
            ['phone_email', 'phone', 'email', 'name_only', 'unknown'],
            'unknown'
        ),
        'confidence' => tryzub_intelligence_safe_enum(
            $confidence_level,
            ['high', 'medium', 'low'],
            'low'
        ),
        'normalized_phone_present' => ($identity['normalized_phone'] ?? '') !== '',
        'email_present' => ($identity['normalized_email'] ?? '') !== '',
    ];
    $history = [
        'seen_before' => $seen_before,
        'prior_visit_count' => $prior_visit_count,
        'last_seen_date' => $seen_before ? $last_visit_date : null,
        'first_seen_date' => $seen_before ? $first_visit_date : null,
        'safe_copy' => tryzub_guest_intelligence_build_safe_copy(
            $row['guest_name'] ?? '',
            $seen_before,
            $prior_visit_count,
            $identity_confidence
        ),
    ];
    $signals = tryzub_guest_intelligence_build_signals($row, $note_flags, $no_show_count);
    $debug = null;

    if ($include_debug) {
        $matched_by = 'none';

        if ($match_type === 'phone_email') {
            $matched_by = 'phone_email';
        } elseif ($match_type === 'phone') {
            $matched_by = 'phone';
        } elseif ($match_type === 'email') {
            $matched_by = 'email';
        }

        $debug = [
            'matched_by' => $matched_by,
            'prior_count_source' => tryzub_guest_intelligence_prior_count_is_reliable($identity_confidence)
                ? 'high_confidence'
                : 'unavailable',
            'history_scope' => 'full_managed_reservations',
        ];
    }

    return [
        'seen_before' => $seen_before,
        'prior_visit_count' => $prior_visit_count,
        'last_seen_date' => $history['last_seen_date'],
        'safe_copy' => $history['safe_copy'],
        'identity' => $identity_summary,
        'history' => $history,
        'signals' => $signals,
        'debug' => $debug,
    ];
}

function tryzub_guest_intelligence_build_profile_pack(
    array $row,
    array $identity,
    array $prior_matches,
    array $clean_matches,
    array $item
) {
    $identity_confidence = (string) ($item['identity_confidence'] ?? 'unknown');
    $supports_history = tryzub_guest_intelligence_identity_supports_history_matching($identity);

    if (!$supports_history) {
        return [
            'history' => [
                'matched_visit_preview' => [],
            ],
            'profile_summary' => [
                'summary_text' => null,
                'management_notes' => [],
                'confidence' => tryzub_guest_intelligence_map_confidence_level($identity_confidence),
                'history_scope' => 'full_managed_reservations',
            ],
            'preferences' => tryzub_guest_intelligence_empty_preferences(),
            'note_intelligence' => tryzub_guest_intelligence_empty_note_intelligence(),
            'visit_analytics' => tryzub_guest_intelligence_build_visit_analytics(
                $row,
                $prior_matches,
                $clean_matches,
                $identity_confidence,
                $item
            ),
            'host_profile_packet' => tryzub_guest_intelligence_build_host_profile_packet(
                $row,
                $item,
                tryzub_guest_intelligence_empty_preferences(),
                tryzub_guest_intelligence_empty_note_intelligence(),
                []
            ),
        ];
    }

    $matched_visit_preview = tryzub_guest_intelligence_build_matched_visit_preview($prior_matches, $identity);
    $preferences = tryzub_guest_intelligence_build_preferences($clean_matches, $identity_confidence, count($clean_matches));
    $note_intelligence = tryzub_guest_intelligence_build_note_intelligence($prior_matches, $identity);
    $visit_analytics = tryzub_guest_intelligence_build_visit_analytics(
        $row,
        $prior_matches,
        $clean_matches,
        $identity_confidence,
        $item
    );
    $profile_summary = tryzub_guest_intelligence_build_profile_summary(
        $row,
        $item,
        $preferences,
        $note_intelligence,
        count($clean_matches),
        $identity_confidence
    );
    $host_profile_packet = tryzub_guest_intelligence_build_host_profile_packet(
        $row,
        $item,
        $preferences,
        $note_intelligence,
        $matched_visit_preview
    );

    return [
        'history' => [
            'matched_visit_preview' => $matched_visit_preview,
        ],
        'profile_summary' => $profile_summary,
        'preferences' => $preferences,
        'note_intelligence' => $note_intelligence,
        'visit_analytics' => $visit_analytics,
        'host_profile_packet' => $host_profile_packet,
    ];
}

function tryzub_guest_intelligence_empty_preferences() {
    return [
        'usual_time' => null,
        'usual_weekday' => null,
        'usual_party_size' => null,
        'largest_party_size' => null,
        'preferred_tables' => [],
        'preferred_table_area' => null,
        'source_pattern' => null,
        'common_occasion' => null,
    ];
}

function tryzub_guest_intelligence_empty_note_intelligence() {
    return [
        'has_prior_guest_notes' => false,
        'has_prior_staff_notes' => false,
        'guest_note_count' => 0,
        'staff_note_count' => 0,
        'latest_guest_note_preview' => null,
        'latest_staff_note_preview' => null,
        'all_note_signals' => [
            'occasion' => [],
            'dietary' => [],
            'allergy' => [],
            'table_preference' => [],
            'accessibility' => [],
            'service_issue' => [],
        ],
    ];
}

function tryzub_guest_intelligence_prior_rows_have_notes(array $prior_matches) {
    foreach ($prior_matches as $match) {
        if (trim((string) ($match['guest_notes'] ?? '')) !== '') {
            return true;
        }

        if (trim((string) ($match['staff_notes'] ?? '')) !== '') {
            return true;
        }
    }

    return false;
}

function tryzub_guest_intelligence_trim_note_preview($text, $max_length = 160) {
    $text = trim(preg_replace('/\s+/u', ' ', (string) $text));

    if ($text === '') {
        return null;
    }

    if (function_exists('mb_strlen') && function_exists('mb_substr')) {
        if (mb_strlen($text, 'UTF-8') <= $max_length) {
            return $text;
        }

        return rtrim(mb_substr($text, 0, $max_length - 1, 'UTF-8')) . '…';
    }

    if (strlen($text) <= $max_length) {
        return $text;
    }

    return rtrim(substr($text, 0, $max_length - 1)) . '…';
}

function tryzub_guest_intelligence_format_display_date($date) {
    $date_time = DateTimeImmutable::createFromFormat('!Y-m-d', (string) $date);

    if (!$date_time instanceof DateTimeImmutable) {
        return null;
    }

    return $date_time->format('M j, Y');
}

function tryzub_guest_intelligence_format_time_friendly($time) {
    $bucket = tryzub_intelligence_time_15min_bucket($time);

    if ($bucket === null) {
        return null;
    }

    [$hour, $minute] = array_map('intval', explode(':', $bucket));
    $ampm = $hour >= 12 ? 'PM' : 'AM';
    $display_hour = $hour % 12;

    if ($display_hour === 0) {
        $display_hour = 12;
    }

    if ($minute === 0) {
        return $display_hour . ' ' . $ampm;
    }

    return sprintf('%d:%02d %s', $display_hour, $minute, $ampm);
}

function tryzub_guest_intelligence_row_match_metadata(array $history_row, array $identity) {
    $matched_by = [];
    $history_email = tryzub_intelligence_normalize_email($history_row['email'] ?? '');
    $history_phone = tryzub_intelligence_normalize_phone($history_row['phone'] ?? '');

    if ($identity['normalized_email'] !== '' && $history_email !== '' && $history_email === $identity['normalized_email']) {
        $matched_by[] = 'email';
    }

    if ($identity['normalized_phone'] !== '' && $history_phone !== '' && $history_phone === $identity['normalized_phone']) {
        $matched_by[] = 'phone';
    }

    if (empty($matched_by)) {
        return [
            'match_confidence' => 'low',
            'matched_by' => [],
        ];
    }

    $confidence = 'high';

    if (!in_array('email', $matched_by, true) && ($identity['confidence'] ?? '') === 'possible') {
        $confidence = 'medium';
    }

    return [
        'match_confidence' => $confidence,
        'matched_by' => $matched_by,
    ];
}

function tryzub_guest_intelligence_get_signal_keyword_maps() {
    return [
        'occasion' => [
            'birthday' => ['birthday', 'день народження', 'день рождения', 'den narodzhennya'],
            'anniversary' => ['anniversary', 'річниця', 'годовщина', 'richnytsya'],
            'graduation' => ['graduation', 'випускний'],
            'wedding' => ['wedding', 'весілля', 'свадьба', 'vesillia'],
            'baby shower' => ['baby shower', 'бейбі шауер', 'бебі шауер'],
            'baptism' => ['baptism', 'christening', 'хрестини', 'хрещення', 'крестины', 'khrestyny'],
            'celebration' => ['celebration', 'святкування', 'свято'],
        ],
        'dietary' => [
            'vegetarian' => ['vegetarian', 'вегетаріанець', 'вегетаріанський'],
            'vegan' => ['vegan', 'веган', 'веганський'],
            'gluten-free' => ['gluten free', 'gluten-free', 'без глютену', 'без глютена'],
            'dairy-free' => ['dairy free', 'dairy-free', 'без молочного', 'лактоза'],
        ],
        'allergy' => [
            'allergy' => ['allergy', 'allergic', 'nut allergy', 'peanut', 'shellfish', 'алергія', 'алергик', 'аллергия', 'alergiya'],
        ],
        'table_preference' => [
            'quiet table' => ['quiet table', 'quiet', 'тихо', 'тихий', 'тихе місце'],
            'window seat' => ['window seat', 'by the window', 'near window', 'window', 'біля вікна', 'вікно'],
            'booth' => ['booth', 'будка', 'кабінка'],
            'patio' => ['patio', 'outside', 'outdoor', 'патіо', 'надворі', 'на вулиці'],
            'corner' => ['corner', 'кут', 'в кутку'],
            'bar area' => ['at the bar', 'near bar', 'bar area', 'біля бару'],
        ],
        'accessibility' => [
            'wheelchair' => ['wheelchair', 'інвалідний візок', 'візок'],
            'stroller' => ['stroller', 'коляска', 'дитяча коляска'],
            'high chair' => ['high chair', 'highchair', 'дитячий стілець', 'стільчик'],
        ],
        'service_issue' => [
            'complaint' => ['complaint', 'complained', 'скарга', 'жалоба'],
            'bad experience' => ['bad experience', 'upset', 'поганий досвід', 'незадоволений', 'незадоволена'],
            'wait issue' => ['waited too long', 'long wait', 'довго чекали'],
        ],
    ];
}

function tryzub_guest_intelligence_extract_signal_label($text, array $label_keywords) {
    $text = tryzub_intelligence_normalize_note_text($text);

    if ($text === '') {
        return null;
    }

    foreach ($label_keywords as $label => $keywords) {
        if (tryzub_intelligence_text_contains_keyword($text, $keywords)) {
            return $label;
        }
    }

    return null;
}

function tryzub_guest_intelligence_extract_row_signals($guest_notes, $staff_notes = '') {
    $combined = tryzub_intelligence_normalize_note_text($guest_notes, $staff_notes);
    $maps = tryzub_guest_intelligence_get_signal_keyword_maps();
    $dietary = tryzub_guest_intelligence_extract_signal_label($combined, $maps['dietary']);
    $allergy = null;

    if (tryzub_intelligence_text_contains_keyword($combined, $maps['allergy']['allergy'])) {
        if ($dietary === null || tryzub_intelligence_text_contains_keyword($combined, ['allergy', 'allergic', 'алергія', 'аллергия'])) {
            $allergy = 'allergy';
        }
    }

    return [
        'occasion' => tryzub_guest_intelligence_extract_signal_label($combined, $maps['occasion']),
        'dietary' => $dietary,
        'allergy' => $allergy,
        'table_preference' => tryzub_guest_intelligence_extract_signal_label($combined, $maps['table_preference']),
        'accessibility' => tryzub_guest_intelligence_extract_signal_label($combined, $maps['accessibility']),
        'service_issue' => tryzub_guest_intelligence_extract_signal_label($combined, $maps['service_issue']),
    ];
}

function tryzub_guest_intelligence_map_source_label($source_type) {
    $bucket = tryzub_intelligence_source_bucket($source_type);

    if ($bucket === 'unknown') {
        return sanitize_text_field((string) $source_type) !== '' ? sanitize_text_field((string) $source_type) : 'unknown';
    }

    return $bucket;
}

function tryzub_guest_intelligence_build_preview_row(array $history_row, array $identity) {
    $guest_notes = (string) ($history_row['guest_notes'] ?? '');
    $staff_notes = (string) ($history_row['staff_notes'] ?? '');
    $guest_preview = tryzub_guest_intelligence_trim_note_preview($guest_notes);
    $staff_preview = tryzub_guest_intelligence_trim_note_preview($staff_notes);
    $match_meta = tryzub_guest_intelligence_row_match_metadata($history_row, $identity);
    $time = tryzub_intelligence_time_15min_bucket($history_row['reservation_time'] ?? '');

    if ($time === null) {
        $time = sanitize_text_field((string) ($history_row['reservation_time'] ?? ''));
        $time = $time !== '' ? $time : null;
    }

    $table_name = trim(sanitize_text_field((string) ($history_row['table_name'] ?? '')));

    return [
        'reservation_id' => (int) ($history_row['id'] ?? 0),
        'date' => (string) ($history_row['reservation_date'] ?? ''),
        'time' => $time,
        'party_size' => max(0, (int) ($history_row['party_size'] ?? 0)),
        'status' => sanitize_text_field((string) ($history_row['status'] ?? '')),
        'table_name' => $table_name !== '' ? $table_name : null,
        'source' => tryzub_guest_intelligence_map_source_label($history_row['source_type'] ?? ''),
        'guest_notes_preview' => $guest_preview,
        'staff_notes_preview' => $staff_preview,
        'has_guest_notes' => $guest_preview !== null,
        'has_staff_notes' => $staff_preview !== null,
        'signals' => tryzub_guest_intelligence_extract_row_signals($guest_notes, $staff_notes),
        'match_confidence' => $match_meta['match_confidence'],
        'matched_by' => $match_meta['matched_by'],
    ];
}

function tryzub_guest_intelligence_sort_matches_newest_first(array $matches) {
    usort(
        $matches,
        function ($left, $right) {
            $left_date = (string) ($left['reservation_date'] ?? '');
            $right_date = (string) ($right['reservation_date'] ?? '');

            if ($left_date !== $right_date) {
                return strcmp($right_date, $left_date);
            }

            $left_time = (string) ($left['reservation_time'] ?? '');
            $right_time = (string) ($right['reservation_time'] ?? '');

            if ($left_time !== $right_time) {
                return strcmp($right_time, $left_time);
            }

            return ((int) ($right['id'] ?? 0)) <=> ((int) ($left['id'] ?? 0));
        }
    );

    return $matches;
}

function tryzub_guest_intelligence_build_matched_visit_preview(array $prior_matches, array $identity, $limit = 5) {
    if (!tryzub_guest_intelligence_identity_supports_history_matching($identity) || empty($prior_matches)) {
        return [];
    }

    $clean_matches = array_values(
        array_filter(
            $prior_matches,
            'tryzub_intelligence_is_clean_history_row'
        )
    );
    $risk_matches = array_values(
        array_filter(
            $prior_matches,
            function ($row) {
                if (!tryzub_intelligence_is_operational_row($row)) {
                    return false;
                }

                $status = sanitize_text_field((string) ($row['status'] ?? ''));

                return in_array($status, ['cancelled', 'no_show'], true);
            }
        )
    );

    $clean_matches = tryzub_guest_intelligence_sort_matches_newest_first($clean_matches);
    $risk_matches = tryzub_guest_intelligence_sort_matches_newest_first($risk_matches);
    $preview = [];
    $limit = min(5, max(1, absint($limit)));

    foreach (array_slice($clean_matches, 0, $limit) as $match) {
        $preview[] = tryzub_guest_intelligence_build_preview_row($match, $identity);
    }

    if (count($preview) < $limit && !empty($risk_matches)) {
        $preview[] = tryzub_guest_intelligence_build_preview_row($risk_matches[0], $identity);
    }

    return array_slice($preview, 0, $limit);
}

function tryzub_guest_intelligence_collect_note_signal_values(array $prior_matches, $signal_key) {
    $values = [];

    foreach ($prior_matches as $match) {
        $signals = tryzub_guest_intelligence_extract_row_signals(
            $match['guest_notes'] ?? '',
            $match['staff_notes'] ?? ''
        );
        $value = $signals[$signal_key] ?? null;

        if ($value !== null && $value !== '') {
            $values[] = $value;
        }
    }

    return array_values(array_unique($values));
}

function tryzub_guest_intelligence_build_note_intelligence(array $prior_matches, array $identity) {
    if (!tryzub_guest_intelligence_identity_supports_history_matching($identity)) {
        return tryzub_guest_intelligence_empty_note_intelligence();
    }

    $guest_note_count = 0;
    $staff_note_count = 0;
    $latest_guest_note_preview = null;
    $latest_staff_note_preview = null;
    $latest_guest_date = '';
    $latest_staff_date = '';

    foreach ($prior_matches as $match) {
        $guest_notes = trim((string) ($match['guest_notes'] ?? ''));
        $staff_notes = trim((string) ($match['staff_notes'] ?? ''));
        $match_date = (string) ($match['reservation_date'] ?? '');

        if ($guest_notes !== '') {
            $guest_note_count++;

            if ($match_date >= $latest_guest_date) {
                $latest_guest_date = $match_date;
                $latest_guest_note_preview = tryzub_guest_intelligence_trim_note_preview($guest_notes);
            }
        }

        if ($staff_notes !== '') {
            $staff_note_count++;

            if ($match_date >= $latest_staff_date) {
                $latest_staff_date = $match_date;
                $latest_staff_note_preview = tryzub_guest_intelligence_trim_note_preview($staff_notes);
            }
        }
    }

    return [
        'has_prior_guest_notes' => $guest_note_count > 0,
        'has_prior_staff_notes' => $staff_note_count > 0,
        'guest_note_count' => $guest_note_count,
        'staff_note_count' => $staff_note_count,
        'latest_guest_note_preview' => $latest_guest_note_preview,
        'latest_staff_note_preview' => $latest_staff_note_preview,
        'all_note_signals' => [
            'occasion' => tryzub_guest_intelligence_collect_note_signal_values($prior_matches, 'occasion'),
            'dietary' => tryzub_guest_intelligence_collect_note_signal_values($prior_matches, 'dietary'),
            'allergy' => tryzub_guest_intelligence_collect_note_signal_values($prior_matches, 'allergy'),
            'table_preference' => tryzub_guest_intelligence_collect_note_signal_values($prior_matches, 'table_preference'),
            'accessibility' => tryzub_guest_intelligence_collect_note_signal_values($prior_matches, 'accessibility'),
            'service_issue' => tryzub_guest_intelligence_collect_note_signal_values($prior_matches, 'service_issue'),
        ],
    ];
}

function tryzub_guest_intelligence_build_preferences(array $clean_matches, $identity_confidence, $clean_visit_count) {
    $preferences = tryzub_guest_intelligence_empty_preferences();

    if (!tryzub_guest_intelligence_prior_count_is_reliable($identity_confidence) || $clean_visit_count < 1) {
        return $preferences;
    }

    $preferences['usual_time'] = tryzub_guest_intelligence_usual_time($clean_matches);
    $preferences['usual_weekday'] = tryzub_guest_intelligence_usual_weekday($clean_matches);
    $preferences['usual_party_size'] = tryzub_guest_intelligence_usual_party_size($clean_matches);
    $preferences['largest_party_size'] = tryzub_guest_intelligence_max_party_size($clean_matches);

    $table_counts = [];

    foreach ($clean_matches as $match) {
        $table_name = trim(sanitize_text_field((string) ($match['table_name'] ?? '')));

        if ($table_name === '') {
            continue;
        }

        if (!isset($table_counts[$table_name])) {
            $table_counts[$table_name] = 0;
        }

        $table_counts[$table_name]++;
    }

    if (!empty($table_counts)) {
        arsort($table_counts, SORT_NUMERIC);
        $preferences['preferred_tables'] = array_keys($table_counts);
    }

    $source_counts = tryzub_guest_intelligence_source_counts($clean_matches);
    $source_leader = null;
    $source_leader_count = 0;

    foreach ($source_counts as $key => $count) {
        if ($count > $source_leader_count) {
            $source_leader_count = $count;
            $source_leader = str_replace('_count', '', $key);
        }
    }

    if ($source_leader_count > 0 && ($clean_visit_count >= 2 ? $source_leader_count >= 2 : $source_leader_count >= 1)) {
        $preferences['source_pattern'] = $source_leader;
    }

    $occasions = tryzub_guest_intelligence_collect_note_signal_values($clean_matches, 'occasion');

    if (!empty($occasions)) {
        $preferences['common_occasion'] = $occasions[0];
    }

    $table_preferences = tryzub_guest_intelligence_collect_note_signal_values($clean_matches, 'table_preference');

    if (!empty($table_preferences)) {
        $preferences['preferred_table_area'] = $table_preferences[0];
    }

    return $preferences;
}

function tryzub_guest_intelligence_build_status_breakdown(array $rows) {
    $breakdown = [
        'completed' => 0,
        'confirmed' => 0,
        'seated' => 0,
        'cancelled' => 0,
        'no_show' => 0,
        'new' => 0,
        'needs_review' => 0,
    ];

    foreach ($rows as $row) {
        $status = sanitize_text_field((string) ($row['status'] ?? ''));

        if (isset($breakdown[$status])) {
            $breakdown[$status]++;
        }
    }

    return $breakdown;
}

function tryzub_guest_intelligence_build_source_breakdown(array $rows) {
    $breakdown = [
        'online' => 0,
        'call_in' => 0,
        'manual' => 0,
        'unknown' => 0,
    ];

    foreach ($rows as $row) {
        $bucket = tryzub_intelligence_source_bucket($row['source_type'] ?? '');

        if (!isset($breakdown[$bucket])) {
            $bucket = 'unknown';
        }

        $breakdown[$bucket]++;
    }

    return $breakdown;
}

function tryzub_guest_intelligence_build_visit_analytics(
    array $row,
    array $prior_matches,
    array $clean_matches,
    $identity_confidence,
    array $item
) {
    $supports_history = tryzub_guest_intelligence_identity_supports_history_matching(
        tryzub_intelligence_identity_from_row($row)
    );
    $all_rows = array_merge($prior_matches, [$row]);
    $party_sizes = [];

    foreach (array_merge($clean_matches, tryzub_intelligence_is_clean_history_row($row) ? [$row] : []) as $match) {
        $party_size = (int) ($match['party_size'] ?? 0);

        if ($party_size > 0) {
            $party_sizes[] = $party_size;
        }
    }

    $average_party_size = null;
    $max_party_size = null;

    if (!empty($party_sizes)) {
        $average_party_size = round(array_sum($party_sizes) / count($party_sizes), 1);
        $max_party_size = max($party_sizes);
    }

    $completed_count = 0;

    foreach ($clean_matches as $match) {
        if (sanitize_text_field((string) ($match['status'] ?? '')) === 'completed') {
            $completed_count++;
        }
    }

    if (sanitize_text_field((string) ($row['status'] ?? '')) === 'completed') {
        $completed_count++;
    }

    return [
        'known_visit_count' => $supports_history ? 1 + count($prior_matches) : null,
        'prior_visit_count' => $item['prior_visit_count'] ?? null,
        'completed_count' => $supports_history ? $completed_count : null,
        'cancelled_count' => $supports_history ? (int) ($item['cancelled_count'] ?? 0) : null,
        'no_show_count' => $supports_history ? (int) ($item['no_show_count'] ?? 0) : null,
        'average_party_size' => $supports_history ? $average_party_size : null,
        'max_party_size' => $supports_history ? $max_party_size : null,
        'last_seen_date' => $item['last_seen_date'] ?? null,
        'first_seen_date' => $item['first_seen_date'] ?? null,
        'source_breakdown' => $supports_history ? tryzub_guest_intelligence_build_source_breakdown($all_rows) : null,
        'status_breakdown' => $supports_history ? tryzub_guest_intelligence_build_status_breakdown($all_rows) : null,
    ];
}

function tryzub_guest_intelligence_build_profile_summary(
    array $row,
    array $item,
    array $preferences,
    array $note_intelligence,
    $clean_visit_count,
    $identity_confidence
) {
    $guest_name = trim((string) ($row['guest_name'] ?? ''));
    $label = $guest_name !== '' ? $guest_name : 'This guest';
    $seen_before = $item['seen_before'] ?? null;
    $confidence = tryzub_guest_intelligence_map_confidence_level($identity_confidence);
    $management_notes = [];

    if ($seen_before === true) {
        $management_notes[] = 'Returning guest';
    }

    if ($seen_before !== true) {
        return [
            'summary_text' => $seen_before === false
                ? $label . ' has no prior visits found in managed reservations.'
                : null,
            'management_notes' => $management_notes,
            'confidence' => $confidence,
            'history_scope' => 'full_managed_reservations',
        ];
    }

    $is_pattern = $clean_visit_count >= 2;
    $summary_parts = [$label . ' has visited before'];
    $usual_time = $preferences['usual_time'] ?? null;
    $usual_party_size = $preferences['usual_party_size'] ?? null;
    $common_occasion = $preferences['common_occasion'] ?? null;

    if ($usual_time) {
        $time_label = tryzub_guest_intelligence_format_time_friendly($usual_time);
        $line = ($is_pattern ? 'Usually books around ' : 'Previously booked around ') . $time_label;

        if ($usual_party_size) {
            $line .= ' for ' . $usual_party_size . ' guests';
        }

        $summary_parts[] = lcfirst($line);
        $management_notes[] = $is_pattern ? 'Usually books around ' . $time_label : 'Previously booked around ' . $time_label;
    } elseif ($usual_party_size) {
        $summary_parts[] = ($is_pattern ? 'typical party size is ' : 'prior party size was ') . $usual_party_size;
        $management_notes[] = ($is_pattern ? 'Typical party size: ' : 'Prior party size: ') . $usual_party_size;
    }

    if ($common_occasion) {
        $summary_parts[] = ($is_pattern ? 'often mentions ' : 'previously mentioned ') . 'a ' . $common_occasion;
        $management_notes[] = ($is_pattern ? 'Often mentions ' : 'Prior occasion: ') . $common_occasion;
    }

    if (!empty($note_intelligence['all_note_signals']['dietary'])) {
        $management_notes[] = 'Prior dietary note: ' . $note_intelligence['all_note_signals']['dietary'][0];
    }

    if (!empty($note_intelligence['all_note_signals']['allergy'])) {
        $management_notes[] = 'Prior allergy note recorded';
    }

    if (!empty($note_intelligence['all_note_signals']['table_preference'])) {
        $management_notes[] = 'Prior table preference: ' . $note_intelligence['all_note_signals']['table_preference'][0];
    }

    $summary_text = $summary_parts[0];

    if (count($summary_parts) > 1) {
        $summary_text .= ', ' . implode(', and ', array_slice($summary_parts, 1));
    }

    $summary_text .= '.';

    return [
        'summary_text' => $summary_text,
        'management_notes' => array_values(array_unique($management_notes)),
        'confidence' => $confidence,
        'history_scope' => 'full_managed_reservations',
    ];
}

function tryzub_guest_intelligence_build_host_profile_packet(
    array $row,
    array $item,
    array $preferences,
    array $note_intelligence,
    array $matched_visit_preview
) {
    $guest_name = trim((string) ($row['guest_name'] ?? ''));
    $identity_confidence = tryzub_guest_intelligence_map_confidence_level((string) ($item['identity_confidence'] ?? 'unknown'));
    $seen_before = $item['seen_before'] ?? null;
    $preference_lines = [];
    $risk_lines = [];
    $service_lines = [];
    $clean_visit_count = (int) ($item['clean_visit_count'] ?? 0);
    $is_pattern = $clean_visit_count >= 2;

    if ($preferences['usual_time']) {
        $time_label = tryzub_guest_intelligence_format_time_friendly($preferences['usual_time']);
        $line = ($is_pattern ? 'Usually books around ' : 'Previously booked around ') . $time_label;

        if ($preferences['usual_party_size']) {
            $line .= ' for ' . $preferences['usual_party_size'] . ' guests';
        }

        $preference_lines[] = $line . '.';
    } elseif ($preferences['usual_party_size']) {
        $preference_lines[] = ($is_pattern ? 'Typical party size: ' : 'Prior party size: ')
            . $preferences['usual_party_size'] . '.';
    }

    if ($preferences['common_occasion']) {
        $preference_lines[] = ($is_pattern ? 'Often mentions ' : 'Prior note mentioned ')
            . 'a ' . $preferences['common_occasion'] . '.';
    } elseif ($note_intelligence['latest_guest_note_preview']) {
        $preference_lines[] = 'Prior guest note: "' . $note_intelligence['latest_guest_note_preview'] . '".';
    }

    if (!empty($preferences['preferred_tables'])) {
        $preference_lines[] = 'Previously seated at ' . implode(', ', array_slice($preferences['preferred_tables'], 0, 2)) . '.';
    }

    if ((int) ($item['no_show_count'] ?? 0) > 0) {
        $risk_lines[] = 'Prior no-show recorded.';
    }

    if ((int) ($item['cancelled_count'] ?? 0) > 0) {
        $risk_lines[] = 'Prior cancellation recorded.';
    }

    if (!empty($note_intelligence['all_note_signals']['service_issue'])) {
        $service_lines[] = 'Prior service issue noted.';
    }

    if (!empty($note_intelligence['all_note_signals']['allergy'])) {
        $service_lines[] = 'Prior allergy note recorded.';
    }

    $last_seen_line = null;
    $last_seen_date = $item['last_seen_date'] ?? null;

    if ($last_seen_date) {
        $display_date = tryzub_guest_intelligence_format_display_date($last_seen_date);
        $last_seen_line = $display_date ? 'Last seen ' . $display_date . '.' : null;
    }

    return [
        'guest_name' => $guest_name,
        'identity_confidence' => $identity_confidence,
        'seen_before' => $seen_before,
        'safe_history_line' => $item['safe_copy'] ?? ($item['history']['safe_copy'] ?? null),
        'last_seen_line' => $last_seen_line,
        'preference_lines' => array_values(array_unique($preference_lines)),
        'risk_lines' => array_values(array_unique($risk_lines)),
        'service_lines' => array_values(array_unique($service_lines)),
        'preview_count' => count($matched_visit_preview),
    ];
}
