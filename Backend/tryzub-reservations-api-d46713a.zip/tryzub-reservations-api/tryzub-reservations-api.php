<?php

/**
 * Plugin Name: Tryzub Reservations API
 * Description: Private REST API for importing, reading, and managing Tryzub reservations.
 * Version: 0.5.4
 * Author: Solovey
 */
// Project overview:
// This plugin is the private reservation backend for Tryzub.
// Flamingo remains the raw intake history from Contact Form 7.
// The custom tryzub_reservations table is the managed operational state used by the app.
// The iOS app should eventually read and modify managed reservations, not raw Flamingo posts.
//
// Data flow:
// CF7 submission -> Flamingo inbound post -> automatic import -> tryzub_reservations table -> iOS app.
//
// Important rule:
// A Flamingo submission is not the final reservation. It is only the source record.
// A managed reservation is the editable restaurant record with status, staff notes, table assignment, and email timestamps.

// Prevent direct access to this PHP file outside of WordPress.
//MARK: - Guard
if (!defined('ABSPATH')) {
    exit;
}

define('TRYZUB_RESERVATIONS_API_URL', plugin_dir_url(__FILE__));

require_once __DIR__ . '/includes/activation.php';
require_once __DIR__ . '/includes/formatting.php';
require_once __DIR__ . '/includes/validation.php';
require_once __DIR__ . '/includes/restaurant-setup.php';
require_once __DIR__ . '/includes/auto-confirm.php';
require_once __DIR__ . '/includes/intelligence-helpers.php';
require_once __DIR__ . '/includes/intelligence-cache.php';
require_once __DIR__ . '/includes/business-intelligence.php';
require_once __DIR__ . '/includes/guest-intelligence.php';
require_once __DIR__ . '/includes/guest-profiles.php';
require_once __DIR__ . '/includes/reservation-pipeline-diagnostics.php';
require_once __DIR__ . '/includes/intelligence-system-status.php';
require_once __DIR__ . '/includes/restaurant-hours.php';
require_once __DIR__ . '/includes/restaurant-blocked-slots.php';
require_once __DIR__ . '/includes/floor-plan.php';
require_once __DIR__ . '/includes/reservation-slots.php';
require_once __DIR__ . '/includes/reservation-analytics.php';
require_once __DIR__ . '/includes/managed-reservations.php';
require_once __DIR__ . '/includes/reservation-activity.php';
require_once __DIR__ . '/includes/reservation-self-service.php';
require_once __DIR__ . '/includes/emails.php';
require_once __DIR__ . '/includes/routes.php';
require_once __DIR__ . '/includes/import.php';
require_once __DIR__ . '/includes/raw-reservations.php';
require_once __DIR__ . '/includes/health.php';
require_once __DIR__ . '/includes/permissions.php';
require_once __DIR__ . '/includes/assets.php';


//MARK: - Activation Setup
// Runs only when the plugin is activated, not on every request.
// If this code is added while the plugin is already active, deactivate and activate the plugin again.
// This is where database setup belongs because the table should be created once and then reused.
register_activation_hook(__FILE__, 'tryzub_reservations_activate');
register_deactivation_hook(__FILE__, 'tryzub_reservations_deactivate');
add_action('plugins_loaded', 'tryzub_ensure_reservations_auth_roles', 5);
add_action('plugins_loaded', 'tryzub_maybe_upgrade_reservations_table');
// Register custom REST API routes when WordPress initializes its REST API.
add_action('rest_api_init', 'tryzub_register_routes');
