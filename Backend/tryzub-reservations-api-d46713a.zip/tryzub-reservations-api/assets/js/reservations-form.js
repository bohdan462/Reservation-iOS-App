(function () {
    'use strict';

    const DEBUG = new URLSearchParams(window.location.search).has('tryzub_debug');

    const selectors = {
        bookingRoot: '#tryzub-booking-v2',
        guestName: 'input[name="text-583"]',
        email: 'input[name="email-90"]',
        phone: 'input[name="tel-299"]',
        date: '#tryzub-reservation-date',
        mobileDateWrap: '#tryzub-reservation-date-native-wrap',
        mobileDate: '#tryzub-reservation-date-native',
        mobileDateDisplay: '#tryzub-reservation-date-native-display',
        time: '#tryzub-reservation-time',
        partySize: '#tryzub-reservation-party-size, #tryzub-reservation-attendees, input[name="text-139"], select[name="text-139"]',
        notes: 'textarea[name="textarea-887"]'
    };
    const submitLockTimeoutMs = 30000;
    const messages = {
        initialTime: 'Select a date to see available times.',
        invalidDate: 'Enter a valid date to see available times.',
        loadingTimes: 'Loading available times...',
        closed: 'Reservations are not available for this date.',
        noSlots: 'No available times for this date.',
        noMoreToday: 'No more available times today.',
        fallback: 'Showing standard times. Availability may be confirmed by the restaurant.',
        missingTime: 'Please choose an available time.',
        missingParty: 'Please choose party size.',
        largeParty: 'Large parties may require confirmation.'
    };
    const defaultRestaurantSetup = {
        default_party_size: 2,
        max_online_party_size: 8,
        large_party_review_threshold: 7
    };

    // Ukrainian hospitality sayings shown (one at random) above the form.
    const hospitalityQuotes = [
        'In Ukraine, a guest is never just a visitor — they are someone to be fed, warmed, and welcomed.',
        'We say: sit down first, then we’ll talk. A Ukrainian table always begins with welcome.',
        'Bread, salt, and a kind word — that is how Ukrainians open the door.',
        'At our table, there is always room for one more chair.',
        'Ukrainians do not ask if you are hungry. They simply start placing food in front of you.',
        'A good evening is simple: people close to you, something warm on the table, and stories that last longer than dinner.',
        'Come as a guest, leave as someone we know.',
        'In Ukrainian homes, the table is where strangers become friends and friends become family.',
        'A full table is good, but a full table with good people is better.',
        'We pour, we share, we listen — that is how Ukrainians welcome people back.'
    ];

    const successRedirectUrl = 'https://www.tryzubchicago.com';
    const successRedirectSeconds = 15;

    let controls = null;
    let dateWatcher = null;
    let lastDateValue = '';
    let reservationSlotsRequestId = 0;
    let activeSlotsAbortController = null;
    let successModalLastFocus = null;
    let successRedirectTimer = null;
    let successCountdownTimer = null;
    let isSyncingTime = false;
    let isSyncingPartySize = false;
    const submitUnlockTimers = new WeakMap();

    const schedule = {
        0: null,                             // Monday closed
        1: { start: '17:00', end: '21:00' }, // Tuesday
        2: { start: '17:00', end: '21:00' }, // Wednesday
        3: { start: '17:00', end: '21:00' }, // Thursday
        4: { start: '17:00', end: '22:00' }, // Friday
        5: { start: '11:00', end: '22:00' }, // Saturday
        6: { start: '11:00', end: '21:00' }  // Sunday
    };

    // ----- Analytics (GTM dataLayer, no PII) -----
    // Never send name, email, phone, notes, exact date, exact time, or guest identity.

    const analyticsState = {
        ctaSeen: false,
        ctaHovered: false,
        formStarted: false,
        lastDateKey: '',
        lastTimeValue: '',
        lastPartySize: null
    };

    function ensureDataLayer() {
        window.dataLayer = window.dataLayer || [];
    }

    function pushAnalyticsEvent(eventName, payload) {
        ensureDataLayer();
        const event = Object.assign({ event: eventName }, payload || {});

        window.dataLayer.push(event);
        debug('Analytics', event);
    }

    function getPartySizeBucket(partySize) {
        const size = Number(partySize);

        if (!size || size < 1) {
            return null;
        }

        if (size <= 2) {
            return '1-2';
        }

        if (size <= 4) {
            return '3-4';
        }

        if (size <= 6) {
            return '5-6';
        }

        return '7+';
    }

    function isV2ReservationForm(form) {
        return Boolean(form && form.closest(selectors.bookingRoot));
    }

    function getCf7AnalyticsErrorType(event) {
        if (event.detail && event.detail.status) {
            return event.detail.status;
        }

        if (event.type === 'wpcf7invalid') {
            return 'validation_failed';
        }

        if (event.type === 'wpcf7spam') {
            return 'spam';
        }

        if (event.type === 'wpcf7mailfailed') {
            return 'mail_failed';
        }

        return 'unknown';
    }

    function isBookTableCta(element) {
        if (!element) {
            return false;
        }

        if (element.classList && element.classList.contains('tryzub-book-table-cta')) {
            return true;
        }

        const href = element.getAttribute('href') || '';

        return /\/book-table\/?/i.test(href);
    }

    function findBookTableCtas() {
        const matches = [];
        const seen = new Set();

        document.querySelectorAll('a[href], button, .tryzub-book-table-cta').forEach(function (element) {
            if (!isBookTableCta(element) || seen.has(element)) {
                return;
            }

            seen.add(element);
            matches.push(element);
        });

        return matches;
    }

    function initLandingPageCtaAnalytics() {
        const ctas = findBookTableCtas();

        if (!ctas.length) {
            return;
        }

        ctas.forEach(function (cta) {
            cta.addEventListener('click', function () {
                pushAnalyticsEvent('book_table_cta_clicked', {
                    cta_location: 'homepage_reservation_section',
                    destination: '/book-table/'
                });
            });

            cta.addEventListener('mouseenter', function () {
                if (analyticsState.ctaHovered) {
                    return;
                }

                analyticsState.ctaHovered = true;
                pushAnalyticsEvent('book_table_cta_hovered', {
                    cta_location: 'homepage_reservation_section'
                });
            });
        });

        if (!('IntersectionObserver' in window) || analyticsState.ctaSeen) {
            return;
        }

        const observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (!entry.isIntersecting || analyticsState.ctaSeen) {
                    return;
                }

                analyticsState.ctaSeen = true;
                pushAnalyticsEvent('book_table_cta_seen', {
                    cta_location: 'homepage_reservation_section'
                });
                observer.disconnect();
            });
        }, { threshold: 0.25 });

        ctas.forEach(function (cta) {
            observer.observe(cta);
        });
    }

    function isBookingFormInteractionTarget(target) {
        if (!target || !controls || !controls.form || !controls.form.contains(target)) {
            return false;
        }

        if (target.matches('input, select, textarea')) {
            return true;
        }

        return Boolean(target.closest('.tryzub-date-chip, .tryzub-time-chip, .tryzub-party-chip, .tryzub-panel-toggle'));
    }

    function trackReservationFormStarted() {
        if (analyticsState.formStarted) {
            return;
        }

        analyticsState.formStarted = true;
        pushAnalyticsEvent('reservation_form_started', {
            form_location: 'book_table_page'
        });
    }

    function initBookingFormAnalytics() {
        if (!controls || !controls.useChipUi || !controls.form) {
            return;
        }

        controls.form.addEventListener('focusin', function (event) {
            if (isBookingFormInteractionTarget(event.target)) {
                trackReservationFormStarted();
            }
        });

        controls.form.addEventListener('input', function (event) {
            if (isBookingFormInteractionTarget(event.target)) {
                trackReservationFormStarted();
            }
        });

        controls.form.addEventListener('click', function (event) {
            if (isBookingFormInteractionTarget(event.target)) {
                trackReservationFormStarted();
            }
        }, true);
    }

    function trackReservationDateSelected() {
        if (!controls || !controls.useChipUi) {
            return;
        }

        const date = parseReservationDate(controls.dateField.value);

        if (!date || !isWithinBookingWindow(date)) {
            return;
        }

        const dateKey = formatDateForNativeInput(date);

        if (analyticsState.lastDateKey === dateKey) {
            return;
        }

        analyticsState.lastDateKey = dateKey;
        pushAnalyticsEvent('reservation_date_selected', {
            form_location: 'book_table_page'
        });
    }

    function trackReservationTimeSelected() {
        if (!controls || !controls.useChipUi) {
            return;
        }

        const timeValue = normalizeTimeValue(controls.selectedTime);

        if (!timeValue) {
            return;
        }

        if (analyticsState.lastTimeValue === timeValue) {
            return;
        }

        analyticsState.lastTimeValue = timeValue;
        pushAnalyticsEvent('reservation_time_selected', {
            form_location: 'book_table_page'
        });
    }

    function trackReservationPartySizeSelected(partySize) {
        if (!controls || !controls.useChipUi) {
            return;
        }

        const bucket = getPartySizeBucket(partySize);

        if (!bucket) {
            return;
        }

        if (analyticsState.lastPartySize === partySize) {
            return;
        }

        analyticsState.lastPartySize = partySize;
        pushAnalyticsEvent('reservation_party_size_selected', {
            form_location: 'book_table_page',
            party_size_bucket: bucket
        });
    }

    function trackReservationFormSubmitted(form) {
        if (!isV2ReservationForm(form)) {
            return;
        }

        pushAnalyticsEvent('reservation_form_submitted', {
            form_location: 'book_table_page',
            reservation_source: 'cf7'
        });
    }

    function trackReservationFormError(event) {
        const form = event.target;

        if (!isReservationForm(form) || !isV2ReservationForm(form)) {
            return;
        }

        pushAnalyticsEvent('reservation_form_error', {
            form_location: 'book_table_page',
            error_type: getCf7AnalyticsErrorType(event)
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        initReservationTimeDropdown();
        initLandingPageCtaAnalytics();
    });
    document.addEventListener('submit', validateReservationFormBeforeSubmit, true);
    document.addEventListener('click', blockDuplicateReservationSubmitClick, true);
    document.addEventListener('wpcf7beforesubmit', lockReservationSubmit);
    document.addEventListener('wpcf7invalid', unlockReservationSubmit);
    document.addEventListener('wpcf7spam', unlockReservationSubmit);
    document.addEventListener('wpcf7mailfailed', unlockReservationSubmit);
    document.addEventListener('wpcf7mailsent', showReservationSubmittedMessage);
    document.addEventListener('wpcf7submit', handleReservationSubmitComplete);
    document.addEventListener('keydown', handleSuccessModalEscape);

    function initReservationTimeDropdown() {
        const bookingRoot = document.querySelector(selectors.bookingRoot);
        const scope = bookingRoot || document;
        const dateField = scope.querySelector(selectors.date);
        const timeField = scope.querySelector(selectors.time);

        if (!dateField || !timeField) {
            return;
        }

        if (timeField.dataset.tryzubReady === 'true') {
            return;
        }

        const useChipUi = Boolean(bookingRoot);
        const dateInput = createMobileDateInput(dateField, scope, useChipUi);
        const timeSelect = createTimeSelect(timeField, useChipUi);
        const form = timeField.closest('form');
        const clientRequestIdField = ensureClientRequestIdField(form);
        const partyField = useChipUi ? findPartySizeField(scope, form) : null;

        controls = {
            root: bookingRoot,
            scope,
            form,
            useChipUi,
            dateField,
            dateInput,
            timeField,
            timeSelect,
            clientRequestIdField,
            guestPanel: null,
            guestMessage: null,
            datePanel: null,
            dateChipGrid: null,
            dateMessage: null,
            timePanel: null,
            timeChipGrid: null,
            timeMessage: null,
            partyField,
            partyPanel: null,
            partyChipGrid: null,
            partyMessage: null,
            partyHelper: null,
            notesPanel: null,
            restaurantSetup: normalizeRestaurantSetup(window.tryzubReservationSetup) || defaultRestaurantSetup,
            selectedDateValue: '',
            loadedSlotsDate: '',
            isLoadingSlots: false,
            selectedTime: '',
            selectedPartySize: null
        };

        if (controls.useChipUi) {
            enhanceBookingLayout();
        }

        timeField.dataset.tryzubReady = 'true';
        dateField.setAttribute('autocomplete', 'off');
        dateInput.setAttribute('autocomplete', 'off');

        syncNativeDateToDateField();
        lastDateValue = dateField.value;

        dateInput.addEventListener('change', handleDateChange);
        dateInput.addEventListener('input', handleDateChange);
        dateInput.addEventListener('blur', handleDateChange);
        dateField.addEventListener('change', handleDateChange);
        dateField.addEventListener('input', handleDateChange);
        dateField.addEventListener('blur', handleDateChange);
        timeSelect.addEventListener('change', syncSelectedTime);

        if (controls.useChipUi) {
            loadRestaurantSetup();
        }

        bindDatepickerEvents(dateField);
        startDateValueWatcher();

        updateTimeOptions();

        debug(controls.useChipUi ? 'Tryzub reservation chips initialized' : 'Tryzub reservation time dropdown initialized');
    }

    function ensureClientRequestIdField(form) {
        if (!form) {
            return null;
        }

        let field = form.querySelector('input[name="tryzub_client_request_id"]');

        if (!field) {
            field = document.createElement('input');
            field.type = 'hidden';
            field.name = 'tryzub_client_request_id';
            form.appendChild(field);
        }

        if (!field.value) {
            field.value = generateClientRequestId();
        }

        return field;
    }

    function generateClientRequestId() {
        const datePart = new Date().toISOString().slice(0, 10).replace(/-/g, '');
        const cryptoObject = window.crypto || window.msCrypto;
        let uniquePart = '';

        if (cryptoObject && typeof cryptoObject.randomUUID === 'function') {
            uniquePart = cryptoObject.randomUUID();
        } else if (cryptoObject && typeof cryptoObject.getRandomValues === 'function') {
            const values = new Uint32Array(4);
            cryptoObject.getRandomValues(values);
            uniquePart = Array.prototype.map.call(values, function (value) {
                return value.toString(16).padStart(8, '0');
            }).join('');
        } else {
            uniquePart = String(Date.now()) + '_' + Math.random().toString(16).slice(2);
        }

        return 'tryzub_' + datePart + '_' + uniquePart;
    }

    // Build every enhanced V2 section, then order and de-clutter the form once.
    function enhanceBookingLayout() {
        if (!controls || !controls.root || !controls.form) {
            return;
        }

        controls.root.classList.add('tryzub-booking-enhanced');
        controls.form.classList.add('tryzub-booking-form');

        insertBookingIntro();
        buildGuestPanel();
        buildDatePanel();
        createTimeChipUi();
        initPartySizeChips();
        buildNotesPanel();

        bindGuestValidationEvents();
        initPhoneFormatting();

        reorderBookingSections();
        cleanupFormArtifacts();
        polishSubmitButton();
        initAccordionState();
        initBookingFormAnalytics();
        refreshSubmitState();
    }

    // Initial layout: Guest information stays open; every other step starts
    // folded (visible, showing a placeholder summary) so the guest can see
    // there is more to fill. Steps auto-open as the previous one is completed.
    function initAccordionState() {
        ['date', 'time', 'party', 'notes'].forEach(function (key) {
            collapseSection(key);
        });
    }

    // Creates a section panel with a header and a collapsible body. Collapsible
    // sections get a clickable toggle header (title + selection summary + chevron)
    // so completed steps can fold into a compact summary. Content goes in the
    // body (see getPanelBody). The panel is appended to the form here and moved
    // into final order later by reorderBookingSections().
    function createSectionPanel(key, title, collapsible) {
        const panel = document.createElement('div');
        const body = document.createElement('div');
        const bodyInner = document.createElement('div');

        panel.className = 'tryzub-panel tryzub-' + key + '-panel';
        panel.dataset.section = key;
        // The body is the animated collapser (grid-rows 1fr -> 0fr); content is
        // appended to the inner wrapper so it can be clipped smoothly.
        body.className = 'tryzub-panel-body';
        bodyInner.className = 'tryzub-panel-body-inner';
        body.appendChild(bodyInner);

        if (collapsible) {
            panel.dataset.collapsible = 'true';

            const toggle = document.createElement('button');
            const heading = document.createElement('h2');
            const summary = document.createElement('span');
            const chevron = document.createElement('span');

            toggle.type = 'button';
            toggle.className = 'tryzub-panel-toggle';
            toggle.setAttribute('aria-expanded', 'true');

            heading.className = 'tryzub-panel-title';
            heading.textContent = title;

            summary.className = 'tryzub-panel-summary';
            chevron.className = 'tryzub-panel-chevron';
            chevron.setAttribute('aria-hidden', 'true');

            toggle.appendChild(heading);
            toggle.appendChild(summary);
            toggle.appendChild(chevron);
            toggle.addEventListener('click', function () {
                togglePanel(key);
            });

            panel.appendChild(toggle);
        } else if (title) {
            const header = document.createElement('div');
            const heading = document.createElement('h2');

            header.className = 'tryzub-panel-header';
            heading.className = 'tryzub-panel-title';
            heading.textContent = title;
            header.appendChild(heading);
            panel.appendChild(header);
        }

        panel.appendChild(body);
        controls.form.appendChild(panel);

        return panel;
    }

    function getPanelBody(panel) {
        return panel ? panel.querySelector('.tryzub-panel-body-inner') : null;
    }

    // ----- Accordion state -----

    function getSectionPanel(key) {
        switch (key) {
            case 'guest': return controls.guestPanel;
            case 'date': return controls.datePanel;
            case 'time': return controls.timePanel;
            case 'party': return controls.partyPanel;
            case 'notes': return controls.notesPanel;
            default: return null;
        }
    }

    function expandSection(key) {
        const panel = getSectionPanel(key);

        if (!panel) {
            return;
        }

        panel.classList.remove('is-locked', 'is-collapsed');

        const toggle = panel.querySelector('.tryzub-panel-toggle');

        if (toggle) {
            toggle.setAttribute('aria-expanded', 'true');
        }
    }

    function collapseSection(key) {
        const panel = getSectionPanel(key);

        if (!panel || panel.dataset.collapsible !== 'true') {
            return;
        }

        updateSectionSummary(key);
        panel.classList.remove('is-locked');
        panel.classList.add('is-collapsed');

        const toggle = panel.querySelector('.tryzub-panel-toggle');

        if (toggle) {
            toggle.setAttribute('aria-expanded', 'false');
        }
    }

    function togglePanel(key) {
        const panel = getSectionPanel(key);

        if (!panel) {
            return;
        }

        if (panel.classList.contains('is-collapsed')) {
            expandSection(key);
        } else {
            collapseSection(key);
        }
    }

    // Folds the finished step into its summary and opens the next step.
    function completeSection(key, nextKey) {
        collapseSection(key);

        if (nextKey) {
            expandSection(nextKey);
        }
    }

    function updateSectionSummary(key) {
        const panel = getSectionPanel(key);
        const summary = panel ? panel.querySelector('.tryzub-panel-summary') : null;

        if (!summary) {
            return;
        }

        summary.textContent = getSectionSummaryText(key);
    }

    function getSectionSummaryText(key) {
        if (key === 'date') {
            const date = parseReservationDate(controls.dateField.value);
            return date ? formatDateForDisplay(date) : 'Choose a date';
        }

        if (key === 'time') {
            const time = normalizeTimeValue(controls.selectedTime || controls.timeField.value);
            return time ? minutesToTimeLabel(timeToMinutes(time)) : 'Choose a time';
        }

        if (key === 'party') {
            const size = controls.selectedPartySize;
            return size ? size + (size === 1 ? ' guest' : ' guests') : 'Party size';
        }

        if (key === 'notes') {
            const notesField = controls.scope.querySelector(selectors.notes);
            const value = notesField ? notesField.value.trim() : '';
            return value || 'Add a note (optional)';
        }

        return '';
    }

    // Opens the Date step once the guest details look complete. Auto-opens only
    // once, and only if no date is chosen yet, so it never fights the guest.
    function maybeRevealDateStep() {
        refreshSubmitState();

        if (!controls || !controls.datePanel || controls.dateAutoRevealed) {
            return;
        }

        if (isGuestSectionComplete()) {
            controls.dateAutoRevealed = true;

            if (!parseReservationDate(controls.dateField.value)) {
                expandSection('date');
            }
        }
    }

    // Submit button is muted and labelled "Complete all fields" until the whole
    // form is ready, then it turns into the highlighted "Request reservation".
    function refreshSubmitState() {
        if (!controls || !controls.form) {
            return;
        }

        const button = getReservationSubmitButton(controls.form);

        if (!button || controls.form.dataset.tryzubSubmitting === 'true') {
            return;
        }

        const complete = isReservationFormComplete();

        button.classList.toggle('tryzub-submit-incomplete', !complete);
        setSubmitButtonLabel(button, complete ? 'Request reservation' : 'Complete all fields');
    }

    function isReservationFormComplete() {
        if (!isGuestSectionComplete()) {
            return false;
        }

        const date = parseReservationDate(controls.dateField.value);

        if (!date || !isWithinBookingWindow(date)) {
            return false;
        }

        if (controls.useChipUi && !normalizeTimeValue(controls.timeField.value || controls.selectedTime)) {
            return false;
        }

        if (controls.partyField && !normalizePartySizeValue(controls.selectedPartySize || controls.partyField.value)) {
            return false;
        }

        return true;
    }

    function isGuestSectionComplete() {
        const nameField = controls.scope.querySelector(selectors.guestName);
        const emailField = controls.scope.querySelector(selectors.email);
        const phoneField = controls.scope.querySelector(selectors.phone);
        const nameValue = nameField ? nameField.value.trim() : '';
        const emailValue = emailField ? emailField.value.trim() : '';
        const phoneDigits = phoneField ? extractUsPhoneDigits(phoneField.value) : '';

        return Boolean(
            nameValue && isValidGuestName(nameValue) &&
            emailValue && isValidGuestEmail(emailValue) &&
            phoneDigits.length === 10
        );
    }

    // Returns the CF7 control wrapper so we can move/hide the real field as a
    // unit, keeping CF7 validation hooks intact.
    function getControlWrap(field) {
        return field.closest('.wpcf7-form-control-wrap') || getFieldBlock(field);
    }

    function buildGuestPanel() {
        if (!controls || !controls.form || controls.guestPanel) {
            return;
        }

        const fields = [
            controls.scope.querySelector(selectors.guestName),
            controls.scope.querySelector(selectors.email),
            controls.scope.querySelector(selectors.phone)
        ].filter(Boolean);

        if (!fields.length) {
            return;
        }

        // Guest information is always fully expanded (never folds).
        const panel = createSectionPanel('guest', 'Guest information', false);
        const body = getPanelBody(panel);

        fields.forEach(function (field) {
            const block = getFieldBlock(field);

            block.classList.add('tryzub-field-row');
            body.appendChild(block);
        });

        const message = document.createElement('p');

        message.className = 'tryzub-chip-message tryzub-guest-message';
        message.hidden = true;
        body.appendChild(message);

        controls.guestPanel = panel;
        controls.guestMessage = message;
    }

    function buildNotesPanel() {
        const notesField = controls.scope.querySelector(selectors.notes);

        if (!notesField || controls.notesPanel) {
            return;
        }

        notesField.placeholder = 'Special occasion, seating request, allergies, or notes?';

        const panel = createSectionPanel('notes', 'Notes', true);
        const block = getFieldBlock(notesField);

        block.classList.add('tryzub-field-row');
        getPanelBody(panel).appendChild(block);

        notesField.addEventListener('blur', function () {
            updateSectionSummary('notes');
            collapseSection('notes');
            refreshSubmitState();
        });

        controls.notesPanel = panel;
    }

    // Orders the form deterministically: panels first (so the first panel sits
    // directly under the header with no dead gap), then the submit control, then
    // the CF7 response output. A document fragment moves the panels to the front
    // in one operation; appendChild() re-parents the rest safely.
    function reorderBookingSections() {
        const form = controls.form;
        const fragment = document.createDocumentFragment();

        [
            controls.guestPanel,
            controls.datePanel,
            controls.timePanel,
            controls.partyPanel,
            controls.notesPanel
        ].forEach(function (panel) {
            if (panel) {
                fragment.appendChild(panel);
            }
        });

        form.insertBefore(fragment, form.firstChild);

        const submitBlock = getReservationSubmitBlock();

        if (submitBlock && submitBlock.parentNode) {
            form.appendChild(submitBlock);
        }

        const responseOutput = form.querySelector('.wpcf7-response-output');

        if (responseOutput) {
            form.appendChild(responseOutput);
        }
    }

    function getReservationSubmitBlock() {
        const button = getReservationSubmitButton(controls.form);

        if (!button) {
            return null;
        }

        return button.closest('p') || button;
    }

    // Collapses every leftover CF7/page-builder wrapper that no longer holds a
    // visible control, so nothing creates dead vertical space between sections.
    // Fixes the source of the gap, not the symptom (no negative margins).
    function cleanupFormArtifacts() {
        const panels = [
            controls.guestPanel,
            controls.datePanel,
            controls.timePanel,
            controls.partyPanel,
            controls.notesPanel
        ];
        const submitBlock = getReservationSubmitBlock();

        Array.prototype.slice.call(controls.form.children).forEach(function (child) {
            if (panels.indexOf(child) !== -1 || child === submitBlock) {
                return;
            }

            if (child.classList && child.classList.contains('wpcf7-response-output')) {
                return;
            }

            const hasVisibleControl = child.querySelector && child.querySelector(
                'input[type="submit"], button[type="submit"], input:not([type="hidden"]), textarea, select, .wpcf7-response-output'
            );

            if (hasVisibleControl || (child.textContent || '').trim()) {
                return;
            }

            // No visible control and no text: hidden CF7 fields (e.g. _wpcf7)
            // stay submittable while the empty wrapper stops taking up space.
            child.classList.add('tryzub-layout-hidden');
        });
    }

    function bindGuestValidationEvents() {
        if (!controls || !controls.form || controls.form.dataset.tryzubGuestValidationReady === 'true') {
            return;
        }

        const nameField = controls.scope.querySelector(selectors.guestName);
        const emailField = controls.scope.querySelector(selectors.email);

        if (nameField) {
            // Strip disallowed characters as the user types, capitalize only on
            // blur (so the caret never jumps mid-word).
            nameField.addEventListener('input', function () {
                sanitizeGuestNameField(nameField);
                validateGuestFields(false);
                maybeRevealDateStep();
            });

            nameField.addEventListener('blur', function () {
                capitalizeGuestNameField(nameField);
                validateGuestFields(false);
                maybeRevealDateStep();
            });
        }

        if (emailField) {
            // Only validate the email once the user finishes (blur) or on submit,
            // never while they are still typing it.
            emailField.addEventListener('blur', function () {
                emailField.dataset.tryzubTouched = 'true';
                validateGuestFields(false);
                maybeRevealDateStep();
            });

            emailField.addEventListener('input', function () {
                if (emailField.dataset.tryzubTouched === 'true') {
                    validateGuestFields(false);
                }

                maybeRevealDateStep();
            });
        }

        controls.form.dataset.tryzubGuestValidationReady = 'true';
    }

    // Removes characters that never appear in real names while preserving
    // letters (any language), spaces, apostrophes, curly apostrophes, hyphens,
    // and periods (so "O'Connor", "Anna-Maria", and "J. Smith" still work).
    function sanitizeGuestNameField(field) {
        if (!field || !field.value) {
            return;
        }

        const selectionStart = field.selectionStart;
        const sanitized = field.value.replace(/[^\p{L}\p{M}\s.'’\-]+/gu, '');

        if (sanitized === field.value) {
            return;
        }

        const removed = field.value.length - sanitized.length;
        const caret = Math.max(0, (selectionStart || field.value.length) - removed);

        field.value = sanitized;

        try {
            field.setSelectionRange(caret, caret);
        } catch (error) {
            // Selection range is not supported on every input state; ignore.
        }
    }

    function capitalizeGuestNameField(field) {
        if (!field || !field.value) {
            return;
        }

        const originalValue = field.value;
        const trimmedLeft = originalValue.replace(/^\s+/, '');

        if (!trimmedLeft) {
            field.value = '';
            return;
        }

        const capitalized = trimmedLeft.charAt(0).toUpperCase() + trimmedLeft.slice(1);

        if (field.value === capitalized) {
            return;
        }

        field.value = capitalized;
        triggerFieldEvents(field);
    }

    function validateGuestFields(showWhenEmpty) {
        if (!controls) {
            return true;
        }

        const nameField = controls.scope.querySelector(selectors.guestName);
        const emailField = controls.scope.querySelector(selectors.email);
        const nameValue = nameField ? nameField.value.trim() : '';
        const emailValue = emailField ? emailField.value.trim() : '';
        const emailCommitted = Boolean(emailField && (showWhenEmpty || emailField.dataset.tryzubTouched === 'true'));
        let message = '';

        if (showWhenEmpty && nameField) {
            capitalizeGuestNameField(nameField);
        }

        if (nameField && showWhenEmpty && !nameValue) {
            message = 'Please enter your name.';
        } else if (nameField && nameValue && !isValidGuestName(nameValue)) {
            message = 'Name can only use letters, spaces, apostrophes, and hyphens.';
        } else if (emailField && showWhenEmpty && !emailValue) {
            message = 'Please enter your email.';
        } else if (emailCommitted && emailValue && !isValidGuestEmail(emailValue)) {
            message = 'Please enter a valid email address.';
        }

        setGuestFieldInvalid(nameField, Boolean(message && message.toLowerCase().includes('name')));
        setGuestFieldInvalid(emailField, Boolean(message && message.toLowerCase().includes('email')));
        renderGuestMessage(message, Boolean(message));

        return !message;
    }

    function isValidGuestName(value) {
        return /^[\p{L}\p{M}][\p{L}\p{M}\s.'’\-]*$/u.test(value);
    }

    function isValidGuestEmail(value) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value);
    }

    function setGuestFieldInvalid(field, isInvalid) {
        if (!field) {
            return;
        }

        field.classList.toggle('tryzub-field-invalid', Boolean(isInvalid));

        if (isInvalid) {
            field.setAttribute('aria-invalid', 'true');
        } else {
            field.removeAttribute('aria-invalid');
        }
    }

    function renderGuestMessage(message, isError) {
        if (!controls || !controls.guestMessage) {
            return;
        }

        controls.guestMessage.textContent = message || '';
        controls.guestMessage.hidden = !message;
        controls.guestMessage.classList.toggle('is-error', Boolean(isError));
    }

    // ----- Date panel: quick date chips + "pick another date" control -----

    function buildDatePanel() {
        if (!controls || !controls.form || controls.datePanel) {
            return;
        }

        const panel = createSectionPanel('date', 'Date', true);
        const body = getPanelBody(panel);

        const grid = document.createElement('div');
        grid.className = 'tryzub-date-chip-grid';
        grid.setAttribute('role', 'group');
        grid.setAttribute('aria-label', 'Quick date selection');
        grid.addEventListener('click', handleDateChipClick);
        enablePointerDragScroll(grid);
        body.appendChild(grid);

        const pickLabel = document.createElement('span');
        pickLabel.className = 'tryzub-date-pick-label';
        pickLabel.textContent = 'Or pick another date';
        body.appendChild(pickLabel);

        const dateBlock = getFieldBlock(controls.dateField);
        dateBlock.classList.add('tryzub-date-field-row');
        body.appendChild(dateBlock);

        const message = document.createElement('p');
        message.className = 'tryzub-chip-message tryzub-date-message';
        message.hidden = true;
        body.appendChild(message);

        controls.datePanel = panel;
        controls.dateChipGrid = grid;
        controls.dateMessage = message;

        renderDateChips();
    }

    function renderDateChips() {
        if (!controls || !controls.dateChipGrid) {
            return;
        }

        controls.dateChipGrid.textContent = '';

        getNextBookingDays(7).forEach(function (date, index) {
            const button = document.createElement('button');
            const top = document.createElement('span');
            const bottom = document.createElement('span');

            button.type = 'button';
            button.className = 'tryzub-date-chip';
            button.dataset.date = formatDateForNativeInput(date);

            top.className = 'tryzub-date-chip-top';
            top.textContent = dateChipTopLabel(date, index);

            bottom.className = 'tryzub-date-chip-bottom';
            bottom.textContent = String(date.getDate());

            button.appendChild(top);
            button.appendChild(bottom);
            controls.dateChipGrid.appendChild(button);
        });

        syncDateChipSelection();
    }

    function getNextBookingDays(count) {
        const days = [];
        const cursor = getToday();

        for (let index = 0; index < count; index += 1) {
            days.push(new Date(cursor));
            cursor.setDate(cursor.getDate() + 1);
        }

        return days;
    }

    function dateChipTopLabel(date, index) {
        if (index === 0) {
            return 'Today';
        }

        if (index === 1) {
            return 'Tomorrow';
        }

        return ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][getRestaurantWeekday(date)];
    }

    function handleDateChipClick(event) {
        const button = event.target && event.target.closest
            ? event.target.closest('.tryzub-date-chip')
            : null;

        if (!button) {
            return;
        }

        const date = parseNativeDateValue(button.dataset.date);

        if (date) {
            setSelectedReservationDate(date);
        }
    }

    function setSelectedReservationDate(date) {
        if (!controls) {
            return;
        }

        if (controls.dateInput && controls.dateInput !== controls.dateField) {
            controls.dateInput.value = formatDateForNativeInput(date);
            updateMobileDateDisplay(controls.dateInput);
        }

        controls.dateField.value = formatDateForCf7Field(date);
        lastDateValue = controls.dateField.value;

        triggerFieldEvents(controls.dateField);
        updateTimeOptions();
        syncDateChipSelection();
    }

    function syncDateChipSelection() {
        if (!controls || !controls.dateChipGrid) {
            return;
        }

        const selectedDate = parseReservationDate(controls.dateField.value);
        const selectedKey = selectedDate ? formatDateForNativeInput(selectedDate) : '';

        controls.dateChipGrid.querySelectorAll('.tryzub-date-chip').forEach(function (button) {
            const isSelected = Boolean(selectedKey) && button.dataset.date === selectedKey;

            button.classList.toggle('is-selected', isSelected);
            button.setAttribute('aria-pressed', isSelected ? 'true' : 'false');
        });
    }

    // Lets the date row be scrolled by click-and-drag with a mouse (not just the
    // wheel). A drag past the threshold suppresses the chip click that follows.
    function enablePointerDragScroll(element) {
        let isPointerDown = false;
        let startX = 0;
        let startScrollLeft = 0;
        let didDrag = false;

        element.addEventListener('mousedown', function (event) {
            isPointerDown = true;
            didDrag = false;
            startX = event.pageX;
            startScrollLeft = element.scrollLeft;
            element.classList.add('is-grabbing');
        });

        document.addEventListener('mousemove', function (event) {
            if (!isPointerDown) {
                return;
            }

            const distance = event.pageX - startX;

            if (Math.abs(distance) > 4) {
                didDrag = true;
            }

            element.scrollLeft = startScrollLeft - distance;
        });

        document.addEventListener('mouseup', function () {
            if (!isPointerDown) {
                return;
            }

            isPointerDown = false;
            element.classList.remove('is-grabbing');
        });

        element.addEventListener('click', function (event) {
            if (didDrag) {
                event.preventDefault();
                event.stopPropagation();
                didDrag = false;
            }
        }, true);
    }

    // ----- Phone: USA-only progressive formatting -> +1 (XXX) XXX-XXXX -----

    function initPhoneFormatting() {
        const phoneField = controls.scope.querySelector(selectors.phone);

        if (!phoneField || phoneField.dataset.tryzubPhoneReady === 'true') {
            return;
        }

        phoneField.type = 'tel';
        phoneField.setAttribute('inputmode', 'tel');
        phoneField.setAttribute('autocomplete', 'tel');
        phoneField.placeholder = 'Phone number';

        phoneField.addEventListener('input', function () {
            applyPhoneFormat(phoneField);
            maybeRevealDateStep();
        });

        phoneField.addEventListener('blur', function () {
            if (!extractUsPhoneDigits(phoneField.value).length) {
                phoneField.value = '';
                phoneField.dataset.tryzubPhonePrev = '';
                phoneField.classList.remove('tryzub-phone-complete');
            }

            maybeRevealDateStep();
        });

        if (phoneField.value) {
            applyPhoneFormat(phoneField);
        }

        phoneField.dataset.tryzubPhoneReady = 'true';
    }

    function extractUsPhoneDigits(value) {
        let digits = (value || '').replace(/\D+/g, '');

        // US area codes never start with 1, so a leading 1 is the country code.
        if (digits.length && digits.charAt(0) === '1') {
            digits = digits.slice(1);
        }

        return digits.slice(0, 10);
    }

    function formatUsPhone(digits) {
        let formatted = '+1';

        if (digits.length > 0) {
            formatted += ' (' + digits.slice(0, 3);
        }

        if (digits.length >= 3) {
            formatted += ')';
        }

        if (digits.length >= 4) {
            formatted += ' ' + digits.slice(3, 6);
        }

        if (digits.length >= 7) {
            formatted += '-' + digits.slice(6, 10);
        }

        return formatted;
    }

    function applyPhoneFormat(phoneField) {
        const rawValue = phoneField.value;
        const previousValue = phoneField.dataset.tryzubPhonePrev || '';
        let digits = extractUsPhoneDigits(rawValue);
        const previousDigits = extractUsPhoneDigits(previousValue);

        // When a backspace removes a formatting character (")", " ", "-") the
        // digit count is unchanged, so the deletion appears to stall. Detect
        // that and drop the trailing digit instead, keeping deletion smooth.
        if (
            rawValue.length < previousValue.length &&
            digits.length === previousDigits.length &&
            digits.length > 0
        ) {
            digits = digits.slice(0, -1);
        }

        // Stay empty (showing the "Phone number" placeholder) until the guest
        // actually types a digit; the +1 prefix appears with the first digit.
        const formatted = digits.length ? formatUsPhone(digits) : '';

        if (phoneField.value !== formatted) {
            phoneField.value = formatted;

            try {
                phoneField.setSelectionRange(formatted.length, formatted.length);
            } catch (error) {
                // Selection range is not supported on every input state; ignore.
            }
        }

        phoneField.dataset.tryzubPhonePrev = formatted;
        phoneField.classList.toggle('tryzub-phone-complete', digits.length === 10);
    }

    function insertBookingIntro() {
        if (!controls.root || controls.root.querySelector('.tryzub-booking-intro')) {
            return;
        }

        const intro = document.createElement('div');
        const kicker = document.createElement('span');
        const title = document.createElement('h1');
        const divider = document.createElement('div');
        const quote = document.createElement('blockquote');

        intro.className = 'tryzub-booking-intro';

        kicker.className = 'tryzub-booking-kicker';
        kicker.textContent = 'Reservations';

        title.className = 'tryzub-booking-title';
        title.textContent = 'Book a table';

        divider.className = 'tryzub-booking-divider';
        divider.setAttribute('aria-hidden', 'true');

        quote.className = 'tryzub-booking-quote';
        quote.textContent = pickHospitalityQuote();

        intro.appendChild(kicker);
        intro.appendChild(title);
        intro.appendChild(divider);
        intro.appendChild(quote);
        controls.root.insertBefore(intro, controls.root.firstChild);

        // Trigger the subtle fade/rise once the element is in the DOM.
        window.requestAnimationFrame(function () {
            window.requestAnimationFrame(function () {
                quote.classList.add('is-visible');
            });
        });
    }

    function pickHospitalityQuote() {
        const index = Math.floor(Math.random() * hospitalityQuotes.length);

        return hospitalityQuotes[index] || hospitalityQuotes[0];
    }

    function getFieldBlock(field) {
        return field.closest('p') || field.closest('.wpcf7-form-control-wrap') || field;
    }

    function polishSubmitButton() {
        const submitButton = getReservationSubmitButton(controls.form);

        if (!submitButton) {
            return;
        }

        submitButton.classList.add('tryzub-v2-submit');

        if (submitButton.tagName.toLowerCase() === 'input' && submitButton.value === 'Send') {
            submitButton.value = 'Request reservation';
            return;
        }

        if (submitButton.textContent.trim() === 'Send') {
            submitButton.textContent = 'Request reservation';
        }
    }

    function handleDateChange() {
        if (!controls) {
            return;
        }

        syncNativeDateToDateField();
        lastDateValue = controls.dateField.value;
        updateTimeOptions();
        syncDateChipSelection();
        advanceFromDateStep();
        refreshSubmitState();
    }

    // Once a valid, bookable date is chosen (pill or custom pick), fold the Date
    // section into its summary and open Available Times.
    function advanceFromDateStep() {
        if (!controls || !controls.datePanel || controls.datePanel.classList.contains('is-locked')) {
            return;
        }

        const date = parseReservationDate(controls.dateField.value);

        if (date && isWithinBookingWindow(date)) {
            trackReservationDateSelected();
            updateSectionSummary('date');
            completeSection('date', 'time');
        }
    }

    function startDateValueWatcher() {
        if (dateWatcher) {
            return;
        }

        dateWatcher = window.setInterval(function () {
            if (!controls) {
                return;
            }

            syncNativeDateToDateField();

            const currentDateValue = controls.dateField.value;

            if (currentDateValue === lastDateValue) {
                return;
            }

            lastDateValue = currentDateValue;
            updateTimeOptions();
        }, 300);
    }

    function updateTimeOptions() {
        if (!controls) {
            return;
        }

        const dateField = controls.dateField;
        const timeField = controls.timeField;
        const timeSelect = controls.timeSelect;
        const rawDateValue = dateField.value.trim();
        const selectedDate = parseReservationDate(dateField.value);

        if (!selectedDate) {
            const timeMessage = controls.useChipUi
                ? (rawDateValue ? messages.invalidDate : messages.initialTime)
                : 'Select a date first';

            invalidateActiveSlotLoading();
            controls.selectedDateValue = '';
            controls.loadedSlotsDate = '';
            controls.isLoadingSlots = false;
            clearOptions(timeSelect);
            clearSubmittedTime();
            setTimeSelectDisabled(false);
            addPlaceholder(timeSelect, timeMessage);
            clearTimeChips();
            renderDateMessage(rawDateValue ? messages.invalidDate : '', false, Boolean(rawDateValue));
            renderTimeChipMessage(timeMessage, false, Boolean(rawDateValue));
            debug('No valid date selected', dateField.value);
            return;
        }

        if (!isWithinBookingWindow(selectedDate)) {
            invalidateActiveSlotLoading();
            controls.selectedDateValue = '';
            controls.loadedSlotsDate = '';
            controls.isLoadingSlots = false;
            clearOptions(timeSelect);
            clearSubmittedTime();
            setTimeSelectDisabled(false);
            addPlaceholder(timeSelect, 'Reservations are available up to 2 months ahead');
            clearTimeChips();
            renderDateMessage('Reservations are available up to 2 months ahead.', false, true);
            renderTimeChipMessage('Reservations are available up to 2 months ahead.', false);
            debug('Date outside booking window', dateField.value);
            return;
        }

        renderDateMessage('', false);

        const selectedDateValue = formatDateForNativeInput(selectedDate);
        const dateChanged = selectedDateValue !== controls.selectedDateValue;

        if (!dateChanged && (controls.isLoadingSlots || controls.loadedSlotsDate === selectedDateValue)) {
            return;
        }

        if (dateChanged) {
            controls.selectedDateValue = selectedDateValue;
            controls.loadedSlotsDate = '';
            clearSubmittedTime();
        }

        const previousValue = dateChanged ? '' : normalizeTimeValue(timeField.value || timeSelect.value);
        const requestId = ++reservationSlotsRequestId;

        abortActiveSlotsRequest();
        setTimeLoadingState();
        updateTimeOptionsFromBackend(selectedDate, previousValue, requestId);
    }

    function updateTimeOptionsFromBackend(selectedDate, previousValue, requestId) {
        if (typeof window.fetch !== 'function') {
            if (!isLatestSlotsRequest(requestId)) {
                return;
            }

            warnReservationSlotsFallback(new Error('Fetch API is not available.'));
            updateTimeOptionsFromFallback(selectedDate, previousValue, 'fetch-unavailable');
            return;
        }

        const endpoint = getReservationSlotsEndpoint(selectedDate);
        let abortController = null;
        const fetchOptions = {
            credentials: 'same-origin',
            cache: 'no-store',
            headers: {
                Accept: 'application/json'
            }
        };

        if (typeof window.AbortController === 'function') {
            abortController = new window.AbortController();
            activeSlotsAbortController = abortController;
            fetchOptions.signal = abortController.signal;
        }

        window.fetch(endpoint, fetchOptions)
            .then(function (response) {
                if (!response.ok) {
                    throw new Error('Reservation slots request failed with status ' + response.status);
                }

                return response.json();
            })
            .then(function (payload) {
                if (!isLatestSlotsRequest(requestId)) {
                    return;
                }

                const data = normalizeReservationSlotsResponse(payload);

                if (!data) {
                    throw new Error('Reservation slots response was not usable.');
                }

                if (data.is_open && data.slots.length > 0) {
                    applySlotOptions(data.slots, previousValue);
                    debug('Backend reservation slots loaded', data);
                    return;
                }

                applyClosedState(data.message || (data.is_open ? messages.noSlots : messages.closed));
                debug('Backend reported closed or empty slots', data);
            })
            .catch(function (error) {
                if (!isLatestSlotsRequest(requestId) || isAbortError(error)) {
                    return;
                }

                warnReservationSlotsFallback(error);
                updateTimeOptionsFromFallback(selectedDate, previousValue, 'backend-unavailable');
            })
            .finally(function () {
                if (activeSlotsAbortController === abortController) {
                    activeSlotsAbortController = null;
                }
            });
    }

    function updateTimeOptionsFromFallback(selectedDate, previousValue, reason) {
        if (!isSelectedDateStillActive(selectedDate)) {
            return;
        }

        const day = getRestaurantWeekday(selectedDate);
        const hours = schedule[day];

        if (!hours) {
            applyClosedState(messages.closed);
            debug('Fallback schedule closed on selected date', {
                date: formatDateForNativeInput(selectedDate),
                reason
            });
            return;
        }

        const slots = buildTimeSlots(hours.start, hours.end, 15);

        applySlotOptions(slots, previousValue, true);
        debug('Fallback available times for ' + formatDateForNativeInput(selectedDate), {
            reason,
            slots
        });
    }

    function applySlotOptions(slots, previousValue, isFallback) {
        if (!controls) {
            return;
        }

        const timeSelect = controls.timeSelect;
        const todaySelected = isTodaySelected();
        const normalizedSlots = filterPastSlotsForToday(normalizeSlotOptions(slots));

        controls.isLoadingSlots = false;
        controls.loadedSlotsDate = controls.selectedDateValue;
        clearOptions(timeSelect);

        if (!normalizedSlots.length) {
            applyClosedState(todaySelected ? messages.noMoreToday : messages.noSlots);
            return;
        }

        addPlaceholder(timeSelect, 'Select a time');

        normalizedSlots.forEach(function (slot) {
            const option = document.createElement('option');
            option.value = slot.value;
            option.textContent = slot.label;
            timeSelect.appendChild(option);
        });

        setTimeSelectDisabled(false);
        renderTimeChips(normalizedSlots);
        renderTimeChipMessage(isFallback ? messages.fallback : '', false, false, Boolean(isFallback));

        if (previousValue && normalizedSlots.some(function (slot) { return slot.value === previousValue; })) {
            setSelectedTime(previousValue);
        }
    }

    function isTodaySelected() {
        return Boolean(controls) && controls.selectedDateValue === formatDateForNativeInput(getToday());
    }

    // For today's date, never offer a slot that has already passed; show only
    // the next available time and onward.
    function filterPastSlotsForToday(slots) {
        if (!isTodaySelected()) {
            return slots;
        }

        const now = new Date();
        const nowMinutes = (now.getHours() * 60) + now.getMinutes();

        return slots.filter(function (slot) {
            const value = normalizeTimeValue(slot.value);

            if (!value) {
                return false;
            }

            const minutes = timeToMinutes(value);

            return !isNaN(minutes) && minutes > nowMinutes;
        });
    }

    function applyClosedState(message) {
        if (!controls) {
            return;
        }

        clearOptions(controls.timeSelect);
        addPlaceholder(controls.timeSelect, message || messages.closed);
        controls.isLoadingSlots = false;
        controls.loadedSlotsDate = controls.selectedDateValue;
        setTimeSelectDisabled(false);
        clearSubmittedTime();
        clearTimeChips();
        renderTimeChipMessage(message || messages.closed, false);
    }

    function setTimeLoadingState() {
        if (!controls) {
            return;
        }

        clearOptions(controls.timeSelect);
        addPlaceholder(controls.timeSelect, messages.loadingTimes);
        controls.isLoadingSlots = true;
        controls.loadedSlotsDate = '';
        setTimeSelectDisabled(true);
        clearTimeChips();
        if (controls.timeChipGrid) {
            controls.timeChipGrid.classList.add('is-loading');
        }
        renderTimeChipMessage(messages.loadingTimes, true);
    }

    function setTimeSelectDisabled(disabled) {
        if (!controls) {
            return;
        }

        controls.timeSelect.disabled = Boolean(disabled);
    }

    function getReservationSlotsEndpoint(date) {
        return getRestApiRoot()
            + 'tryzub/v1/reservation-slots?date='
            + encodeURIComponent(formatDateForNativeInput(date))
            + '&_t='
            + Date.now();
    }

    function getRestApiRoot() {
        const wpApiSettings = window.wpApiSettings || {};
        const apiLink = document.querySelector('link[rel="https://api.w.org/"]');
        const root = wpApiSettings.root || (apiLink ? apiLink.href : '');

        if (root) {
            return root.replace(/\/?$/, '/');
        }

        return window.location.origin.replace(/\/?$/, '') + '/wp-json/';
    }

    function normalizeReservationSlotsResponse(payload) {
        if (payload && payload.success === false) {
            return null;
        }

        const data = payload && payload.data && Array.isArray(payload.data.slots) ? payload.data : payload;

        if (!data || data.success === false || !Array.isArray(data.slots) || typeof data.is_open !== 'boolean') {
            return null;
        }

        return {
            is_open: data.is_open,
            message: typeof data.message === 'string' ? data.message : '',
            slots: normalizeSlotOptions(data.slots)
        };
    }

    function normalizeSlotOptions(slots) {
        if (!Array.isArray(slots)) {
            return [];
        }

        return slots.reduce(function (normalized, slot) {
            if (!slot || typeof slot.value !== 'string') {
                return normalized;
            }

            const value = normalizeTimeValue(slot.value);

            if (!value) {
                return normalized;
            }

            normalized.push({
                value,
                label: typeof slot.label === 'string' && slot.label ? slot.label : minutesToTimeLabel(timeToMinutes(value))
            });

            return normalized;
        }, []);
    }

    function abortActiveSlotsRequest() {
        if (!activeSlotsAbortController) {
            return;
        }

        activeSlotsAbortController.abort();
        activeSlotsAbortController = null;
    }

    function invalidateActiveSlotLoading() {
        reservationSlotsRequestId += 1;
        abortActiveSlotsRequest();
    }

    function isLatestSlotsRequest(requestId) {
        return requestId === reservationSlotsRequestId;
    }

    function isSelectedDateStillActive(date) {
        return Boolean(
            controls &&
            controls.selectedDateValue &&
            controls.selectedDateValue === formatDateForNativeInput(date)
        );
    }

    function isAbortError(error) {
        return error && error.name === 'AbortError';
    }

    function warnReservationSlotsFallback(error) {
        if (DEBUG) {
            console.warn('[Tryzub Reservations] Backend slots unavailable; using fallback schedule.', error);
            return;
        }

        console.warn('[Tryzub Reservations] Backend slots unavailable; using fallback schedule.');
    }

    function createMobileDateInput(dateField, scope, forceNative) {
        if (!shouldUseNativeMobileDatePicker(forceNative)) {
            return dateField;
        }

        const existingMobileDateInput = (scope || document).querySelector(selectors.mobileDate);

        if (existingMobileDateInput) {
            configureMobileDateInput(existingMobileDateInput, dateField, forceNative);
            return existingMobileDateInput;
        }

        const mobileDateWrap = document.createElement('div');
        const mobileDateDisplay = document.createElement('input');
        const mobileDateInput = document.createElement('input');

        mobileDateWrap.id = selectors.mobileDateWrap.slice(1);
        mobileDateWrap.className = 'tryzub-native-date-wrap';
        mobileDateDisplay.id = selectors.mobileDateDisplay.slice(1);
        mobileDateDisplay.type = 'text';
        mobileDateDisplay.readOnly = true;
        mobileDateDisplay.tabIndex = -1;
        mobileDateDisplay.setAttribute('aria-hidden', 'true');
        mobileDateDisplay.className = dateField.className;
        mobileDateDisplay.classList.remove('walcf7-datepicker');
        mobileDateDisplay.classList.add('tryzub-native-date-display');
        mobileDateInput.id = selectors.mobileDate.slice(1);

        mobileDateWrap.appendChild(mobileDateDisplay);
        mobileDateWrap.appendChild(mobileDateInput);

        configureMobileDateInput(mobileDateInput, dateField, forceNative);

        dateField.type = 'hidden';
        dateField.insertAdjacentElement('afterend', mobileDateWrap);

        return mobileDateInput;
    }

    // skipDefault (V2 chip UI) leaves the date empty so the guest actively picks
    // one, which keeps the progressive disclosure flow honest.
    function configureMobileDateInput(mobileDateInput, dateField, skipDefault) {
        const selectedDate = parseReservationDate(dateField.value);

        mobileDateInput.type = 'date';
        mobileDateInput.className = 'tryzub-native-date-input';
        mobileDateInput.setAttribute('aria-label', dateField.getAttribute('placeholder') || 'Reservation date');
        mobileDateInput.setAttribute('aria-required', 'true');
        mobileDateInput.min = formatDateForNativeInput(getToday());
        mobileDateInput.max = formatDateForNativeInput(getMaxBookingDate());

        if (selectedDate) {
            mobileDateInput.value = formatDateForNativeInput(selectedDate);
            dateField.value = formatDateForCf7Field(selectedDate);
        } else if (skipDefault) {
            mobileDateInput.value = '';
            dateField.value = '';
        } else {
            const defaultDate = getNextOpenBookingDate();

            if (!mobileDateInput.value) {
                mobileDateInput.value = formatDateForNativeInput(defaultDate);
            }

            dateField.value = formatDateForCf7Field(parseNativeDateValue(mobileDateInput.value) || defaultDate);
        }

        dateField.type = 'hidden';
        updateMobileDateDisplay(mobileDateInput);
        bindNativeDatePickerOpen(mobileDateInput);
    }

    // Native date inputs don't open on a plain click on desktop, so open the
    // picker programmatically (with a focus fallback) for tap-to-pick.
    function bindNativeDatePickerOpen(mobileDateInput) {
        if (mobileDateInput.dataset.tryzubPickerReady === 'true') {
            return;
        }

        const openPicker = function () {
            if (typeof mobileDateInput.showPicker === 'function') {
                try {
                    mobileDateInput.showPicker();
                    return;
                } catch (error) {
                    // showPicker can throw if not user-activated; fall back.
                }
            }

            mobileDateInput.focus();
        };

        mobileDateInput.addEventListener('click', openPicker);

        const wrap = mobileDateInput.closest(selectors.mobileDateWrap);

        if (wrap) {
            wrap.addEventListener('click', openPicker);
        }

        mobileDateInput.dataset.tryzubPickerReady = 'true';
    }

    // The V2 chip UI always uses the native date input: it fires reliable change
    // events (so a custom date stays hooked to the slot fetch, like the chips)
    // and enforces the min/max booking window.
    function shouldUseNativeMobileDatePicker(forceNative) {
        return Boolean(forceNative) || window.matchMedia('(pointer: coarse)').matches || window.innerWidth <= 768;
    }

    function syncNativeDateToDateField() {
        if (!controls || controls.dateInput === controls.dateField) {
            return;
        }

        const selectedDate = parseNativeDateValue(controls.dateInput.value);
        const nextValue = selectedDate ? formatDateForCf7Field(selectedDate) : '';

        updateMobileDateDisplay(controls.dateInput);

        if (controls.dateField.value === nextValue) {
            return;
        }

        controls.dateField.value = nextValue;
        triggerFieldEvents(controls.dateField);
    }

    function createTimeSelect(timeField, useChipUi) {
        if (timeField.tagName.toLowerCase() === 'select') {
            if (useChipUi) {
                hideEnhancedField(timeField);
            }

            debug('Time field is a CF7 select. If CF7 still rejects it, change the form tag to text* so this script can submit the selected time as plain text.');
            return timeField;
        }

        const timeSelect = document.createElement('select');

        timeSelect.id = selectors.time.slice(1) + '-select';
        timeSelect.className = timeField.className;
        timeSelect.setAttribute('aria-label', timeField.getAttribute('placeholder') || 'Reservation time');
        timeSelect.setAttribute('aria-required', 'true');
        timeSelect.setAttribute('autocomplete', 'off');

        if (useChipUi) {
            hideEnhancedField(timeField);
            hideEnhancedField(timeSelect);
        } else {
            timeField.type = 'hidden';
        }

        timeField.setAttribute('autocomplete', 'off');
        timeField.insertAdjacentElement('afterend', timeSelect);

        return timeSelect;
    }

    function syncSelectedTime() {
        if (!controls) {
            return;
        }

        if (isSyncingTime) {
            return;
        }

        setSelectedTime(controls.timeSelect.value);

        debug('Selected reservation time', controls.timeField.value);
    }

    function clearSubmittedTime() {
        if (!controls) {
            return;
        }

        const wasSyncingTime = isSyncingTime;

        isSyncingTime = true;
        controls.selectedTime = '';
        controls.timeField.value = '';

        if (controls.timeSelect) {
            controls.timeSelect.value = '';
        }

        syncAdditionalTimeFields('');
        updateTimeValueState();
        updateTimeChipSelection();

        if (controls.timeField !== controls.timeSelect) {
            triggerFieldEvents(controls.timeField);
        }

        if (controls.timeSelect) {
            triggerFieldEvents(controls.timeSelect);
        }

        isSyncingTime = wasSyncingTime;
    }

    function updateTimeValueState() {
        if (!controls) {
            return;
        }

        const hasValue = Boolean(controls.timeField.value);

        controls.timeField.classList.toggle('tryzub-reservation-time-has-value', hasValue);
        controls.timeSelect.classList.toggle('tryzub-reservation-time-has-value', hasValue);
    }

    function renderDateMessage(message, isLoading, isError) {
        if (!controls || !controls.dateMessage) {
            return;
        }

        controls.dateMessage.textContent = message || '';
        controls.dateMessage.hidden = !message;
        controls.dateMessage.classList.toggle('is-loading', Boolean(isLoading));
        controls.dateMessage.classList.toggle('is-error', Boolean(isError));
        controls.dateField.classList.toggle('tryzub-field-invalid', Boolean(isError));
        getFieldBlock(controls.dateField).classList.toggle('tryzub-field-invalid', Boolean(isError));

        if (isError) {
            controls.dateField.setAttribute('aria-invalid', 'true');
        } else {
            controls.dateField.removeAttribute('aria-invalid');
        }
    }

    function createTimeChipUi() {
        if (!controls || !controls.useChipUi || controls.timePanel) {
            return;
        }

        const panel = createSectionPanel('time', 'Available times', true);
        const body = getPanelBody(panel);
        const wrap = getControlWrap(controls.timeField);
        const grid = document.createElement('div');
        const message = document.createElement('p');

        hideEnhancedField(wrap);
        body.appendChild(wrap);

        grid.className = 'tryzub-time-chip-grid';
        grid.setAttribute('role', 'group');
        grid.setAttribute('aria-label', 'Available reservation times');
        grid.addEventListener('click', handleTimeChipClick);

        message.className = 'tryzub-chip-message tryzub-time-message';
        message.hidden = true;

        body.appendChild(grid);
        body.appendChild(message);

        controls.timePanel = panel;
        controls.timeChipGrid = grid;
        controls.timeMessage = message;
    }

    function handleTimeChipClick(event) {
        const button = event.target && event.target.closest
            ? event.target.closest('.tryzub-time-chip')
            : null;

        if (!button || button.disabled) {
            return;
        }

        setSelectedTime(button.dataset.value || '');
        if (controls.timeMessage && controls.timeMessage.classList.contains('is-error')) {
            renderTimeChipMessage('', false);
        }

        if (normalizeTimeValue(controls.selectedTime)) {
            trackReservationTimeSelected();
            updateSectionSummary('time');
            completeSection('time', 'party');
        }

        refreshSubmitState();
    }

    function renderTimeChips(slots) {
        if (!controls || !controls.useChipUi || !controls.timeChipGrid) {
            return;
        }

        clearTimeChips();

        slots.forEach(function (slot) {
            const button = document.createElement('button');

            button.type = 'button';
            button.className = 'tryzub-time-chip';
            button.dataset.value = slot.value;
            button.textContent = slot.label;
            button.setAttribute('aria-pressed', slot.value === controls.selectedTime ? 'true' : 'false');

            controls.timeChipGrid.appendChild(button);
        });

        controls.timeChipGrid.classList.remove('is-loading');
        updateTimeChipSelection();
    }

    function clearTimeChips() {
        if (!controls || !controls.timeChipGrid) {
            return;
        }

        controls.timeChipGrid.textContent = '';
        controls.timeChipGrid.classList.remove('is-loading');
    }

    function updateTimeChipSelection() {
        if (!controls || !controls.timeChipGrid) {
            return;
        }

        controls.timeChipGrid.querySelectorAll('.tryzub-time-chip').forEach(function (button) {
            const isSelected = button.dataset.value === controls.selectedTime;

            button.classList.toggle('is-selected', isSelected);
            button.setAttribute('aria-pressed', isSelected ? 'true' : 'false');
        });
    }

    function renderTimeChipMessage(message, isLoading, isError, isNotice) {
        if (!controls || !controls.timeMessage) {
            return;
        }

        controls.timeMessage.textContent = message || '';
        controls.timeMessage.hidden = !message;
        controls.timeMessage.classList.toggle('is-loading', Boolean(isLoading));
        controls.timeMessage.classList.toggle('is-error', Boolean(isError));
        controls.timeMessage.classList.toggle('is-notice', Boolean(isNotice));
    }

    function setSelectedTime(value) {
        if (!controls) {
            return;
        }

        const normalized = normalizeTimeValue(value);

        if (!normalized) {
            clearSubmittedTime();
            return;
        }

        isSyncingTime = true;
        controls.selectedTime = normalized;
        controls.timeField.value = normalized;

        if (controls.timeSelect) {
            controls.timeSelect.value = normalized;
        }

        syncAdditionalTimeFields(normalized);
        updateTimeValueState();
        updateTimeChipSelection();
        clearTimeValidationState();

        if (controls.timeField !== controls.timeSelect) {
            triggerFieldEvents(controls.timeField);
        }

        if (controls.timeSelect) {
            triggerFieldEvents(controls.timeSelect);
        }

        isSyncingTime = false;
    }

    function syncAdditionalTimeFields(value) {
        if (!controls || !controls.form) {
            return;
        }

        controls.form.querySelectorAll('input[type="hidden"][name="text-196"]').forEach(function (field) {
            if (field === controls.timeField || field === controls.timeSelect) {
                return;
            }

            field.value = value;
            triggerFieldEvents(field);
        });
    }

    function hideEnhancedField(field) {
        if (!field) {
            return;
        }

        field.classList.add('tryzub-visually-hidden-field');
    }

    function findPartySizeField(scope, form) {
        const field = (scope || document).querySelector(selectors.partySize);

        if (field) {
            return field;
        }

        return form ? form.querySelector(selectors.partySize) : null;
    }

    function initPartySizeChips() {
        if (!controls || !controls.useChipUi || !controls.partyField) {
            return;
        }

        controls.partyField.setAttribute('autocomplete', 'off');
        controls.partyField.addEventListener('input', syncPartySizeFromField);
        controls.partyField.addEventListener('change', syncPartySizeFromField);
        createPartySizeChipUi();

        const initialValue = normalizePartySizeValue(controls.partyField.value);
        const defaultValue = clampPartySize(
            initialValue || controls.restaurantSetup.default_party_size,
            controls.restaurantSetup
        );

        setSelectedPartySize(defaultValue);
        renderPartySizeChips();
    }

    function createPartySizeChipUi() {
        if (!controls || controls.partyPanel) {
            return;
        }

        const panel = createSectionPanel('party', 'Party size', true);
        const body = getPanelBody(panel);
        const wrap = getControlWrap(controls.partyField);
        const grid = document.createElement('div');
        const helper = document.createElement('p');
        const message = document.createElement('p');

        hideEnhancedField(wrap);
        body.appendChild(wrap);

        grid.className = 'tryzub-party-chip-grid';
        grid.setAttribute('role', 'group');
        grid.setAttribute('aria-label', 'Party size');
        grid.addEventListener('click', handlePartySizeChipClick);

        helper.className = 'tryzub-chip-message tryzub-party-helper';
        helper.hidden = true;

        message.className = 'tryzub-chip-message tryzub-party-message';
        message.hidden = true;

        body.appendChild(grid);
        body.appendChild(helper);
        body.appendChild(message);

        controls.partyPanel = panel;
        controls.partyChipGrid = grid;
        controls.partyHelper = helper;
        controls.partyMessage = message;
    }

    function handlePartySizeChipClick(event) {
        const button = event.target && event.target.closest
            ? event.target.closest('.tryzub-party-chip')
            : null;

        if (!button || button.disabled) {
            return;
        }

        setSelectedPartySize(Number(button.dataset.value));
        renderPartyMessage('', false);

        if (controls.selectedPartySize) {
            trackReservationPartySizeSelected(controls.selectedPartySize);
            updateSectionSummary('party');
            completeSection('party', 'notes');
        }

        refreshSubmitState();
    }

    function syncPartySizeFromField() {
        if (!controls || isSyncingPartySize) {
            return;
        }

        const value = normalizePartySizeValue(controls.partyField.value);

        if (!value) {
            controls.selectedPartySize = null;
            updatePartyChipSelection();
            updateLargePartyHelper();
            return;
        }

        controls.selectedPartySize = clampPartySize(value, controls.restaurantSetup);
        updatePartyChipSelection();
        updateLargePartyHelper();
    }

    function loadRestaurantSetup() {
        if (!controls || !controls.useChipUi) {
            return;
        }

        const preloaded = normalizeRestaurantSetup(window.tryzubReservationSetup);

        if (preloaded) {
            applyRestaurantSetup(preloaded);
            return;
        }

        if (typeof window.fetch !== 'function') {
            return;
        }

        window.fetch(getRestApiRoot() + 'tryzub/v1/restaurant-setup', {
            credentials: 'same-origin',
            headers: {
                Accept: 'application/json'
            }
        })
            .then(function (response) {
                if (!response.ok) {
                    throw new Error('Restaurant setup request failed with status ' + response.status);
                }

                return response.json();
            })
            .then(function (payload) {
                const setup = normalizeRestaurantSetup(payload && payload.data ? payload.data : payload);

                if (setup) {
                    applyRestaurantSetup(setup);
                }
            })
            .catch(function (error) {
                if (DEBUG) {
                    console.warn('[Tryzub Reservations] Restaurant setup unavailable; using party-size defaults.', error);
                }
            });
    }

    function applyRestaurantSetup(setup) {
        if (!controls || !setup) {
            return;
        }

        controls.restaurantSetup = setup;

        if (controls.partyField) {
            const selected = normalizePartySizeValue(controls.partyField.value) || setup.default_party_size;
            setSelectedPartySize(clampPartySize(selected, setup));
            renderPartySizeChips();
        }
    }

    function normalizeRestaurantSetup(setup) {
        if (!setup) {
            return null;
        }

        const source = setup || {};
        const defaultPartySize = normalizePartySizeValue(source.default_party_size);
        const maxOnlinePartySize = normalizePartySizeValue(source.max_online_party_size);
        const largePartyReviewThreshold = normalizePartySizeValue(source.large_party_review_threshold);

        return {
            default_party_size: defaultPartySize || defaultRestaurantSetup.default_party_size,
            max_online_party_size: maxOnlinePartySize || defaultRestaurantSetup.max_online_party_size,
            large_party_review_threshold: largePartyReviewThreshold || defaultRestaurantSetup.large_party_review_threshold
        };
    }

    function renderPartySizeChips() {
        if (!controls || !controls.partyChipGrid) {
            return;
        }

        const setup = controls.restaurantSetup;
        const maxPartySize = Math.max(1, setup.max_online_party_size);

        controls.partyChipGrid.textContent = '';

        for (let partySize = 1; partySize <= maxPartySize; partySize += 1) {
            const button = document.createElement('button');

            button.type = 'button';
            button.className = 'tryzub-party-chip';
            button.dataset.value = String(partySize);
            button.textContent = String(partySize);
            button.setAttribute('aria-pressed', partySize === controls.selectedPartySize ? 'true' : 'false');

            controls.partyChipGrid.appendChild(button);
        }

        updatePartyChipSelection();
        updateLargePartyHelper();
    }

    function setSelectedPartySize(value) {
        if (!controls || !controls.partyField) {
            return;
        }

        const partySize = clampPartySize(normalizePartySizeValue(value), controls.restaurantSetup);

        if (!partySize) {
            return;
        }

        isSyncingPartySize = true;
        controls.selectedPartySize = partySize;
        controls.partyField.value = String(partySize);
        syncAdditionalPartySizeFields(String(partySize));
        updatePartyChipSelection();
        updateLargePartyHelper();
        clearPartyValidationState();
        triggerFieldEvents(controls.partyField);
        isSyncingPartySize = false;
    }

    function syncAdditionalPartySizeFields(value) {
        if (!controls || !controls.form) {
            return;
        }

        controls.form.querySelectorAll('input[type="hidden"][name="text-139"]').forEach(function (field) {
            if (field === controls.partyField) {
                return;
            }

            field.value = value;
            triggerFieldEvents(field);
        });
    }

    function normalizePartySizeValue(value) {
        const parsed = Number(value);

        if (!Number.isInteger(parsed) || parsed < 1) {
            return null;
        }

        return parsed;
    }

    function clampPartySize(value, setup) {
        const normalized = normalizePartySizeValue(value);

        if (!normalized) {
            return null;
        }

        return Math.min(Math.max(1, normalized), Math.max(1, setup.max_online_party_size));
    }

    function updatePartyChipSelection() {
        if (!controls || !controls.partyChipGrid) {
            return;
        }

        controls.partyChipGrid.querySelectorAll('.tryzub-party-chip').forEach(function (button) {
            const isSelected = Number(button.dataset.value) === controls.selectedPartySize;

            button.classList.toggle('is-selected', isSelected);
            button.setAttribute('aria-pressed', isSelected ? 'true' : 'false');
        });
    }

    function updateLargePartyHelper() {
        if (!controls || !controls.partyHelper) {
            return;
        }

        const shouldShow = Boolean(
            controls.selectedPartySize &&
            controls.selectedPartySize >= controls.restaurantSetup.large_party_review_threshold
        );

        controls.partyHelper.textContent = shouldShow ? messages.largeParty : '';
        controls.partyHelper.hidden = !shouldShow;
    }

    function renderPartyMessage(message, isError) {
        if (!controls || !controls.partyMessage) {
            return;
        }

        controls.partyMessage.textContent = message || '';
        controls.partyMessage.hidden = !message;
        controls.partyMessage.classList.toggle('is-error', Boolean(isError));
    }

    function clearPartyValidationState() {
        if (!controls || !controls.partyField) {
            return;
        }

        controls.partyField.classList.remove('wpcf7-not-valid');
        controls.partyField.removeAttribute('aria-invalid');
        renderPartyMessage('', false);

        const wrapper = controls.partyField.closest('.wpcf7-form-control-wrap');

        if (!wrapper) {
            return;
        }

        wrapper.querySelectorAll('.wpcf7-not-valid-tip').forEach(function (message) {
            message.remove();
        });
    }

    function bindDatepickerEvents(dateInput) {
        if (!window.jQuery) {
            return;
        }

        window.jQuery(dateInput).on(
            'change input blur xchange.xdsoft afterChange',
            handleDateChange
        );
    }

    function parseReservationDate(value) {
        if (!value) {
            return null;
        }

        const parts = value.trim().split('-');

        if (parts.length !== 3) {
            return null;
        }

        const isNativeDateFormat = parts[0].length === 4;

        if ((!isNativeDateFormat && parts[2].length !== 4) || (isNativeDateFormat && parts[0].length !== 4)) {
            return null;
        }

        const year = Number(isNativeDateFormat ? parts[0] : parts[2]);
        const month = Number(isNativeDateFormat ? parts[1] : parts[0]);
        const day = Number(isNativeDateFormat ? parts[2] : parts[1]);

        if (!month || !day || !year) {
            return null;
        }

        const date = new Date(year, month - 1, day);

        if (
            date.getFullYear() !== year ||
            date.getMonth() !== month - 1 ||
            date.getDate() !== day
        ) {
            return null;
        }

        date.setHours(0, 0, 0, 0);

        return date;
    }

    function isWithinBookingWindow(date) {
        const today = getToday();
        const maxDate = getMaxBookingDate();

        return date >= today && date <= maxDate;
    }

    function getToday() {
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        return today;
    }

    function getMaxBookingDate() {
        const maxDate = getToday();
        maxDate.setMonth(maxDate.getMonth() + 2);

        return maxDate;
    }

    function getNextOpenBookingDate() {
        const date = getToday();
        const maxDate = getMaxBookingDate();

        while (date <= maxDate) {
            if (schedule[getRestaurantWeekday(date)]) {
                return new Date(date);
            }

            date.setDate(date.getDate() + 1);
        }

        return getToday();
    }

    function getRestaurantWeekday(date) {
        return (date.getDay() + 6) % 7;
    }

    function buildTimeSlots(start, end, stepMinutes) {
        const slots = [];
        let current = timeToMinutes(start);
        const lastBookable = timeToMinutes(end) - 30;

        if (lastBookable < current) {
            return slots;
        }

        while (current <= lastBookable) {
            slots.push({
                value: minutesToTimeValue(current),
                label: minutesToTimeLabel(current)
            });

            current += stepMinutes;
        }

        return slots;
    }

    function timeToMinutes(value) {
        const parts = value.split(':');
        return Number(parts[0]) * 60 + Number(parts[1]);
    }

    function minutesToTimeValue(minutes) {
        const hour = Math.floor(minutes / 60);
        const minute = minutes % 60;

        return String(hour).padStart(2, '0') + ':' + String(minute).padStart(2, '0');
    }

    function minutesToTimeLabel(minutes) {
        const hour24 = Math.floor(minutes / 60);
        const minute = minutes % 60;
        const suffix = hour24 >= 12 ? 'PM' : 'AM';
        const hour12 = hour24 % 12 || 12;

        return hour12 + ':' + String(minute).padStart(2, '0') + ' ' + suffix;
    }

    function normalizeTimeValue(value) {
        if (!value) {
            return '';
        }

        const trimmed = value.trim();
        const twentyFourHourMatch = trimmed.match(/^(\d{1,2}):(\d{2})(?::\d{2})?$/);

        if (twentyFourHourMatch) {
            return String(Number(twentyFourHourMatch[1])).padStart(2, '0') + ':' + twentyFourHourMatch[2];
        }

        const twelveHourMatch = trimmed.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);

        if (!twelveHourMatch) {
            return '';
        }

        let hour = Number(twelveHourMatch[1]);
        const minute = twelveHourMatch[2];
        const suffix = twelveHourMatch[3].toUpperCase();

        if (suffix === 'PM' && hour < 12) {
            hour += 12;
        }

        if (suffix === 'AM' && hour === 12) {
            hour = 0;
        }

        return String(hour).padStart(2, '0') + ':' + minute;
    }

    function parseNativeDateValue(value) {
        if (!value) {
            return null;
        }

        const parts = value.split('-');

        if (parts.length !== 3) {
            return null;
        }

        const year = Number(parts[0]);
        const month = Number(parts[1]);
        const day = Number(parts[2]);

        if (!year || !month || !day) {
            return null;
        }

        const date = new Date(year, month - 1, day);

        if (
            date.getFullYear() !== year ||
            date.getMonth() !== month - 1 ||
            date.getDate() !== day
        ) {
            return null;
        }

        date.setHours(0, 0, 0, 0);

        return date;
    }

    function formatDateForNativeInput(date) {
        return (
            date.getFullYear() +
            '-' +
            String(date.getMonth() + 1).padStart(2, '0') +
            '-' +
            String(date.getDate()).padStart(2, '0')
        );
    }

    function formatDateForCf7Field(date) {
        return (
            String(date.getMonth() + 1).padStart(2, '0') +
            '-' +
            String(date.getDate()).padStart(2, '0') +
            '-' +
            date.getFullYear()
        );
    }

    function updateMobileDateDisplay(mobileDateInput) {
        const display = document.querySelector(selectors.mobileDateDisplay);

        if (!display) {
            return;
        }

        const selectedDate = parseNativeDateValue(mobileDateInput.value);

        const label = selectedDate ? formatDateForDisplay(selectedDate) : 'Date';

        if ('value' in display) {
            display.value = label;
        } else {
            display.textContent = label;
        }
    }

    function formatDateForDisplay(date) {
        const months = [
            'January',
            'February',
            'March',
            'April',
            'May',
            'June',
            'July',
            'August',
            'September',
            'October',
            'November',
            'December'
        ];

        return months[date.getMonth()] + ' ' + date.getDate() + ', ' + date.getFullYear();
    }

    function clearOptions(select) {
        while (select.firstChild) {
            select.removeChild(select.firstChild);
        }
    }

    function addPlaceholder(select, label) {
        const option = document.createElement('option');

        option.value = '';
        option.textContent = label;
        option.selected = true;

        select.appendChild(option);
    }

    function clearTimeValidationState() {
        const fields = [controls.timeField, controls.timeSelect];

        fields.forEach(function (field) {
            if (!field) {
                return;
            }

            field.classList.remove('wpcf7-not-valid');
            field.removeAttribute('aria-invalid');
        });

        if (controls.timeMessage && controls.timeMessage.classList.contains('is-error')) {
            renderTimeChipMessage('', false);
        }

        const wrapper = controls.timeField.closest('.wpcf7-form-control-wrap');

        if (!wrapper) {
            return;
        }

        wrapper.querySelectorAll('.wpcf7-not-valid-tip').forEach(function (message) {
            message.remove();
        });
    }

    function triggerFieldEvents(field) {
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));
    }

    function debug(message, data) {
        if (!DEBUG) {
            return;
        }

        console.log('[Tryzub Reservations]', message, data || '');
    }

    function isReservationForm(form) {
        return Boolean(
            form &&
            form.querySelector(selectors.date) &&
            form.querySelector(selectors.time)
        );
    }

    function getReservationSubmitButton(form) {
        if (!form) {
            return null;
        }

        return form.querySelector('input[type="submit"], button[type="submit"]');
    }

    function getSubmitButtonLabel(button) {
        if (!button) {
            return '';
        }

        if (button.tagName.toLowerCase() === 'input') {
            return button.value || '';
        }

        return button.textContent || '';
    }

    function setSubmitButtonLabel(button, label) {
        if (!button || !label) {
            return;
        }

        if (button.tagName.toLowerCase() === 'input') {
            button.value = label;
            return;
        }

        button.textContent = label;
    }

    function validateReservationFormBeforeSubmit(event) {
        const form = event.target;

        if (!isReservationForm(form)) {
            return;
        }

        // A submission is already in flight (e.g. double-click / double-tap or a
        // second Enter press). Block it before CF7 can fire another request.
        if (form.dataset.tryzubSubmitting === 'true') {
            event.preventDefault();
            event.stopImmediatePropagation();
            debug('Blocked duplicate reservation submit (native submit)');
            return;
        }

        if (!syncReservationFieldsBeforeSubmit(form)) {
            event.preventDefault();
            event.stopImmediatePropagation();
            restoreReservationSubmitButton(form);
            clearSubmitUnlockTimer(form);
            delete form.dataset.tryzubSubmitting;
            refreshSubmitState();
            return;
        }

        // Validation passed: lock immediately on the native submit (capture
        // phase) so a rapid second submit cannot reach CF7.
        applyReservationSubmitLock(form);
    }

    function applyReservationSubmitLock(form) {
        if (!form || form.dataset.tryzubSubmitting === 'true') {
            return;
        }

        form.dataset.tryzubSubmitting = 'true';
        startSubmitUnlockTimer(form);

        const submitButton = getReservationSubmitButton(form);

        if (!submitButton) {
            debug('Reservation submit button not found');
            return;
        }

        if (!submitButton.dataset.tryzubOriginalLabel) {
            submitButton.dataset.tryzubOriginalLabel = getSubmitButtonLabel(submitButton);
        }

        submitButton.disabled = true;
        submitButton.classList.add('tryzub-submit-disabled');
        submitButton.setAttribute('aria-disabled', 'true');
        setSubmitButtonLabel(submitButton, 'Sending...');
    }

    function syncReservationFieldsBeforeSubmit(form) {
        if (!controls || !form || !form.contains(controls.timeField)) {
            return true;
        }

        syncNativeDateToDateField();

        const selectedDate = parseReservationDate(controls.dateField.value);
        const selectedDateValue = selectedDate ? formatDateForNativeInput(selectedDate) : '';
        const dateMatchesLoadedSlots = Boolean(
            selectedDateValue &&
            selectedDateValue === controls.selectedDateValue &&
            (!controls.loadedSlotsDate || controls.loadedSlotsDate === selectedDateValue)
        );
        let isValid = true;

        if (!validateGuestFields(true)) {
            isValid = false;
        }

        if (!selectedDateValue || !dateMatchesLoadedSlots) {
            clearSubmittedTime();

            if (controls.useChipUi && !selectedDateValue) {
                expandSection('date');
                renderDateMessage(messages.invalidDate, false, true);
                isValid = false;
            }
        } else {
            const timeValue = normalizeTimeValue(controls.selectedTime || controls.timeField.value || controls.timeSelect.value);

            if (timeValue) {
                setSelectedTime(timeValue);
            } else {
                clearSubmittedTime();
            }
        }

        if (controls.useChipUi && !normalizeTimeValue(controls.timeField.value)) {
            expandSection('time');
            renderTimeChipMessage(messages.missingTime, false, true);
            isValid = false;
        }

        if (controls.partyField) {
            const partySize = normalizePartySizeValue(controls.selectedPartySize || controls.partyField.value);

            if (partySize) {
                setSelectedPartySize(partySize);
            } else if (controls.useChipUi) {
                expandSection('party');
                renderPartyMessage(messages.missingParty, true);
                isValid = false;
            }
        }

        return isValid;
    }

    function lockReservationSubmit(event) {
        const form = event.target;

        if (!isReservationForm(form)) {
            return;
        }

        // The native submit handler normally locks first. This stays as an
        // idempotent fallback (e.g. legacy/programmatic CF7 submissions): if the
        // form is already marked submitting, do not unlock or duplicate work.
        if (form.dataset.tryzubSubmitting === 'true') {
            debug('Reservation form submit already in progress');
            return;
        }

        if (!syncReservationFieldsBeforeSubmit(form)) {
            return;
        }

        applyReservationSubmitLock(form);
    }

    function syncReservationTimeBeforeSubmit(form) {
        if (!controls || !form || !form.contains(controls.timeField)) {
            return;
        }

        syncReservationFieldsBeforeSubmit(form);
    }

    function blockDuplicateReservationSubmitClick(event) {
        const button = event.target && event.target.closest
            ? event.target.closest('input[type="submit"], button[type="submit"]')
            : null;

        if (!button) {
            return;
        }

        const form = button.closest('form');

        if (!isReservationForm(form) || form.dataset.tryzubSubmitting !== 'true') {
            return;
        }

        event.preventDefault();
        event.stopImmediatePropagation();
        debug('Blocked duplicate reservation submit click');
    }

    function unlockReservationSubmit(event) {
        const form = event.target;

        if (!isReservationForm(form)) {
            return;
        }

        restoreReservationSubmitButton(form);
        clearSubmitUnlockTimer(form);
        delete form.dataset.tryzubSubmitting;
    }

    function markReservationSubmitted(form) {
        const submitButton = getReservationSubmitButton(form);

        clearSubmitUnlockTimer(form);
        delete form.dataset.tryzubSubmitting;

        if (!submitButton) {
            return;
        }

        if (!submitButton.dataset.tryzubOriginalLabel) {
            submitButton.dataset.tryzubOriginalLabel = getSubmitButtonLabel(submitButton);
        }

        submitButton.disabled = true;
        submitButton.classList.add('tryzub-submit-disabled');
        submitButton.setAttribute('aria-disabled', 'true');
        setSubmitButtonLabel(submitButton, 'Submitted');
    }

    function handleReservationSubmitComplete(event) {
        const form = event.target;

        if (!isReservationForm(form)) {
            return;
        }

        const status = event.detail && event.detail.status ? event.detail.status : '';

        debug('Reservation CF7 submit complete', status);

        if (status === 'mail_sent') {
            showReservationSubmittedMessage(event);
            return;
        }

        if (
            status === 'validation_failed' ||
            status === 'acceptance_missing' ||
            status === 'spam' ||
            status === 'mail_failed' ||
            status === 'aborted' ||
            status === ''
        ) {
            unlockReservationSubmit(event);
            trackReservationFormError(event);
        }
    }

    function startSubmitUnlockTimer(form) {
        clearSubmitUnlockTimer(form);

        const timer = window.setTimeout(function () {
            if (!form || form.dataset.tryzubSubmitting !== 'true') {
                return;
            }

            debug('Reservation submit timed out; unlocking form');
            restoreReservationSubmitButton(form);
            delete form.dataset.tryzubSubmitting;
            form.classList.remove('submitting');
            submitUnlockTimers.delete(form);
        }, submitLockTimeoutMs);

        submitUnlockTimers.set(form, timer);
    }

    function clearSubmitUnlockTimer(form) {
        const timer = submitUnlockTimers.get(form);

        if (!timer) {
            return;
        }

        window.clearTimeout(timer);
        submitUnlockTimers.delete(form);
    }

    function restoreReservationSubmitButton(form) {
        const submitButton = getReservationSubmitButton(form);

        if (!submitButton) {
            return;
        }

        submitButton.disabled = false;
        submitButton.classList.remove('tryzub-submit-disabled');
        submitButton.removeAttribute('aria-disabled');
        setSubmitButtonLabel(submitButton, submitButton.dataset.tryzubOriginalLabel || 'Submit');
    }

    function getSuccessModal() {
        const existingModal = document.getElementById('tryzub-reservation-success-modal');

        if (existingModal) {
            return existingModal;
        }

        const overlay = document.createElement('div');
        const dialog = document.createElement('div');
        const title = document.createElement('h2');
        const body = document.createElement('p');
        const button = document.createElement('button');

        overlay.id = 'tryzub-reservation-success-modal';
        overlay.className = 'tryzub-reservation-success-overlay';
        overlay.hidden = true;

        dialog.className = 'tryzub-reservation-success-dialog';
        dialog.setAttribute('role', 'dialog');
        dialog.setAttribute('aria-modal', 'true');
        dialog.setAttribute('aria-labelledby', 'tryzub-reservation-success-title');
        dialog.setAttribute('aria-describedby', 'tryzub-reservation-success-description');
        dialog.setAttribute('aria-live', 'polite');

        title.id = 'tryzub-reservation-success-title';
        title.textContent = 'Thank you!';

        body.id = 'tryzub-reservation-success-description';
        body.textContent = 'Your request is in — we\u2019ll email you shortly to confirm your table.';

        const countdown = document.createElement('p');
        countdown.className = 'tryzub-reservation-success-countdown';

        button.type = 'button';
        button.className = 'tryzub-reservation-success-done';
        button.textContent = 'Return to homepage now';
        button.addEventListener('click', redirectToHomepage);

        dialog.appendChild(title);
        dialog.appendChild(body);
        dialog.appendChild(countdown);
        dialog.appendChild(button);
        overlay.appendChild(dialog);
        document.body.appendChild(overlay);

        return overlay;
    }

    function openSuccessModal() {
        const modal = getSuccessModal();
        const doneButton = modal.querySelector('.tryzub-reservation-success-done');

        successModalLastFocus = document.activeElement;
        modal.hidden = false;
        modal.classList.add('is-visible');
        startSuccessRedirectCountdown(modal);

        if (doneButton) {
            doneButton.focus();
        }
    }

    // On success only, count down from 15s in the dialog, then redirect home.
    function startSuccessRedirectCountdown(modal) {
        const countdown = modal.querySelector('.tryzub-reservation-success-countdown');
        let remaining = successRedirectSeconds;

        clearSuccessRedirectTimers();

        const render = function () {
            if (countdown) {
                countdown.textContent = 'Returning to the homepage in ' + remaining +
                    (remaining === 1 ? ' second…' : ' seconds…');
            }
        };

        render();

        successCountdownTimer = window.setInterval(function () {
            remaining -= 1;

            if (remaining <= 0) {
                render();
                clearSuccessRedirectTimers();
                redirectToHomepage();
                return;
            }

            render();
        }, 1000);

        successRedirectTimer = window.setTimeout(redirectToHomepage, successRedirectSeconds * 1000);
    }

    function clearSuccessRedirectTimers() {
        if (successCountdownTimer) {
            window.clearInterval(successCountdownTimer);
            successCountdownTimer = null;
        }

        if (successRedirectTimer) {
            window.clearTimeout(successRedirectTimer);
            successRedirectTimer = null;
        }
    }

    function redirectToHomepage() {
        clearSuccessRedirectTimers();
        window.location.assign(successRedirectUrl);
    }

    function closeSuccessModal() {
        const modal = document.getElementById('tryzub-reservation-success-modal');

        if (!modal) {
            return;
        }

        clearSuccessRedirectTimers();
        modal.hidden = true;
        modal.classList.remove('is-visible');

        if (successModalLastFocus && typeof successModalLastFocus.focus === 'function') {
            successModalLastFocus.focus();
        }

        successModalLastFocus = null;
    }

    function handleSuccessModalEscape(event) {
        if (event.key !== 'Escape') {
            return;
        }

        const modal = document.getElementById('tryzub-reservation-success-modal');

        if (!modal || modal.hidden) {
            return;
        }
    }

    function showReservationSubmittedMessage(event) {
        const form = event.target;

        if (!isReservationForm(form)) {
            return;
        }

        const response = form ? form.querySelector('.wpcf7-response-output') : null;

        markReservationSubmitted(form);
        trackReservationFormSubmitted(form);

        if (response) {
            response.textContent = 'Reservation request submitted. We will email you once it is confirmed.';
            response.setAttribute('role', 'alert');
            response.setAttribute('aria-live', 'polite');
        }

        openSuccessModal();
    }
})();
