<?php

function tryzub_register_routes() {
    register_rest_route('tryzub/v1', '/ping', [
        'methods' => 'GET',
        'callback' => 'tryzub_api_ping',
        'permission_callback' => '__return_true'
    ]);

    register_rest_route('tryzub/v1', '/restaurant-setup', [
        [
            'methods' => 'GET',
            'callback' => 'tryzub_get_restaurant_setup',
            'permission_callback' => 'tryzub_can_read_reservations',
        ],
        [
            'methods' => 'PATCH',
            'callback' => 'tryzub_update_restaurant_setup',
            'permission_callback' => 'tryzub_can_read_reservations',
        ],
    ]);

    register_rest_route('tryzub/v1', '/restaurant-hours', [
        [
            'methods' => 'GET',
            'callback' => 'tryzub_get_restaurant_hours',
            'permission_callback' => 'tryzub_can_read_reservations',
            'args' => [
                'from' => [
                    'required' => false,
                    'sanitize_callback' => 'sanitize_text_field'
                ],
                'to' => [
                    'required' => false,
                    'sanitize_callback' => 'sanitize_text_field'
                ]
            ]
        ],
        [
            'methods' => 'PATCH',
            'callback' => 'tryzub_update_restaurant_hours',
            'permission_callback' => 'tryzub_can_read_reservations',
        ],
    ]);

    register_rest_route('tryzub/v1', '/restaurant-day-availability', [
        [
            'methods' => 'GET',
            'callback' => 'tryzub_get_restaurant_day_availability',
            'permission_callback' => 'tryzub_can_read_reservations',
            'args' => [
                'date' => [
                    'required' => true,
                    'sanitize_callback' => 'sanitize_text_field'
                ]
            ]
        ],
        [
            'methods' => 'PATCH',
            'callback' => 'tryzub_update_restaurant_day_availability',
            'permission_callback' => 'tryzub_can_read_reservations',
            'args' => [
                'date' => [
                    'required' => true,
                    'sanitize_callback' => 'sanitize_text_field'
                ]
            ]
        ],
    ]);

    register_rest_route('tryzub/v1', '/auto-confirm/candidates', [
        'methods' => 'GET',
        'callback' => 'tryzub_get_auto_confirm_candidates_rest',
        'permission_callback' => 'tryzub_can_read_reservations',
        'args' => [
            'date' => [
                'required' => true,
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ],
    ]);

    register_rest_route('tryzub/v1', '/reservation-slots', [
        'methods' => 'GET',
        'callback' => 'tryzub_get_reservation_slots',
        'permission_callback' => '__return_true',
        'args' => [
            'date' => [
                'required' => true,
                'sanitize_callback' => 'sanitize_text_field'
            ]
        ]
    ]);

    register_rest_route('tryzub/v1', '/restaurant-tables', [
        [
            'methods' => 'GET',
            'callback' => 'tryzub_get_restaurant_tables',
            'permission_callback' => 'tryzub_can_read_reservations',
        ],
        [
            'methods' => 'PUT',
            'callback' => 'tryzub_put_restaurant_tables',
            'permission_callback' => 'tryzub_can_read_reservations',
        ],
    ]);

    register_rest_route('tryzub/v1', '/floor-plan', [
        'methods' => 'GET',
        'callback' => 'tryzub_get_floor_plan',
        'permission_callback' => 'tryzub_can_read_reservations',
        'args' => [
            'date' => [
                'required' => true,
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ],
    ]);

    register_rest_route('tryzub/v1', '/restaurant-blocked-slots', [
        [
            'methods' => 'GET',
            'callback' => 'tryzub_get_restaurant_blocked_slots',
            'permission_callback' => 'tryzub_can_read_reservations',
            'args' => [
                'date' => [
                    'required' => true,
                    'sanitize_callback' => 'sanitize_text_field'
                ]
            ]
        ],
        [
            'methods' => 'POST',
            'callback' => 'tryzub_create_restaurant_blocked_slots',
            'permission_callback' => 'tryzub_can_read_reservations',
        ],
        [
            'methods' => 'DELETE',
            'callback' => 'tryzub_delete_restaurant_blocked_slots',
            'permission_callback' => 'tryzub_can_read_reservations',
            'args' => [
                'date' => [
                    'required' => false,
                    'sanitize_callback' => 'sanitize_text_field'
                ]
            ]
        ],
    ]);

    register_rest_route('tryzub/v1', '/reservation-analytics/summary', [
        'methods' => 'GET',
        'callback' => 'tryzub_get_reservation_analytics_summary',
        'permission_callback' => 'tryzub_can_read_reservations',
        'args' => [
            'from' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field'
            ],
            'to' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field'
            ]
        ]
    ]);

    register_rest_route('tryzub/v1', '/business-intelligence/summary', [
        'methods' => 'GET',
        'callback' => 'tryzub_get_business_intelligence_summary',
        'permission_callback' => 'tryzub_can_read_reservations',
        'args' => [
            'from' => [
                'required' => true,
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'to' => [
                'required' => true,
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'force' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'cache_bust' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ],
    ]);

    register_rest_route('tryzub/v1', '/guest-intelligence/reservation/(?P<id>\d+)', [
        'methods' => 'GET',
        'callback' => 'tryzub_get_guest_intelligence_for_reservation',
        'permission_callback' => 'tryzub_can_read_reservations',
        'args' => [
            'id' => [
                'required' => true,
                'sanitize_callback' => 'absint',
                'validate_callback' => function ($value) {
                    return absint($value) > 0;
                },
            ],
        ],
    ]);

    register_rest_route('tryzub/v1', '/guest-intelligence', [
        'methods' => 'GET',
        'callback' => 'tryzub_get_guest_intelligence',
        'permission_callback' => 'tryzub_can_read_reservations',
        'args' => [
            'date' => [
                'required' => true,
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ],
    ]);

    register_rest_route('tryzub/v1', '/guest-profiles', [
        'methods' => 'GET',
        'callback' => 'tryzub_get_guest_profiles',
        'permission_callback' => 'tryzub_can_read_reservations',
        'args' => [
            'q' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'filter' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'sort' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'page' => [
                'required' => false,
                'sanitize_callback' => 'absint',
            ],
            'per_page' => [
                'required' => false,
                'sanitize_callback' => 'absint',
            ],
            'updated_since' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ],
    ]);

    register_rest_route('tryzub/v1', '/guest-profiles/(?P<guest_key_path>[a-fA-F0-9]{64})', [
        'methods' => 'GET',
        'callback' => 'tryzub_get_guest_profile',
        'permission_callback' => 'tryzub_can_read_reservations',
        'args' => [
            'guest_key_path' => [
                'required' => true,
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ],
    ]);

    register_rest_route('tryzub/v1', '/guest-profile', [
        'methods' => 'GET',
        'callback' => 'tryzub_get_guest_profile',
        'permission_callback' => 'tryzub_can_read_reservations',
        'args' => [
            'guest_key' => [
                'required' => true,
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ],
    ]);

    register_rest_route('tryzub/v1', '/guest-profiles/by-reservation/(?P<id>\d+)', [
        'methods' => 'GET',
        'callback' => 'tryzub_get_guest_profile_by_reservation',
        'permission_callback' => 'tryzub_can_read_reservations',
        'args' => [
            'id' => [
                'required' => true,
                'sanitize_callback' => 'absint',
                'validate_callback' => function ($value) {
                    return absint($value) > 0;
                },
            ],
        ],
    ]);

    register_rest_route('tryzub/v1', '/guest-profiles/rebuild', [
        'methods' => 'POST',
        'callback' => 'tryzub_rebuild_guest_profiles',
        'permission_callback' => 'tryzub_can_hard_delete_reservations',
    ]);

    register_rest_route('tryzub/v1', '/intelligence/system-status', [
        'methods' => 'GET',
        'callback' => 'tryzub_get_intelligence_system_status',
        'permission_callback' => 'tryzub_can_read_reservations',
        'args' => [
            'from' => [
                'required' => true,
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'to' => [
                'required' => true,
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ],
    ]);

    register_rest_route('tryzub/v1', '/intelligence/reservation-pipeline-diagnostics', [
        'methods' => 'GET',
        'callback' => 'tryzub_get_reservation_pipeline_diagnostics',
        'permission_callback' => 'tryzub_can_read_reservations',
        'args' => [
            'from' => [
                'required' => true,
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'to' => [
                'required' => true,
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'include_items' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'classification' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'page' => [
                'required' => false,
                'sanitize_callback' => 'absint',
            ],
            'per_page' => [
                'required' => false,
                'sanitize_callback' => 'absint',
            ],
        ],
    ]);

    // Main read-only endpoint for reservation submissions.
    register_rest_route('tryzub/v1', '/reservations', [
        'methods' => 'GET',
        'callback' => 'tryzub_get_reservations',
        'permission_callback' => 'tryzub_can_read_reservations',
        'args' => [
            'per_page' => [
                'default' => 20,
                'sanitize_callback' => 'absint'
            ],
            'page' => [
                'default' => 1,
                'sanitize_callback' => 'absint'
            ],
            // Optional filters use the reservation date submitted through CF7, not the WordPress post date.
            'date' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field'
            ],
            'from' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field'
            ],
            'to' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field'
            ]
        ],
    ]);

    // Import endpoint.
    // This copies new Flamingo submissions into the managed reservations table.
    // It can be called multiple times safely because source_submission_id prevents importing the same Flamingo post twice.
    // First run imports missing submissions; later runs usually skip already-imported submissions and only add new ones.
    register_rest_route('tryzub/v1', '/managed-reservations/import', [
        'methods' => 'POST',
        'callback' => 'tryzub_import_managed_reservations',
        'permission_callback' => 'tryzub_can_read_reservations',
    ] );

    register_rest_route('tryzub/v1', '/managed-reservations/import-failures', [
        'methods' => 'GET',
        'callback' => 'tryzub_get_managed_reservation_import_failures',
        'permission_callback' => 'tryzub_can_read_reservations',
        'args' => [
            'per_page' => [
                'default' => 20,
                'sanitize_callback' => 'absint'
            ],
            'page' => [
                'default' => 1,
                'sanitize_callback' => 'absint'
            ]
        ]
    ]);

    register_rest_route('tryzub/v1', '/activity', [
        'methods' => 'GET',
        'callback' => 'tryzub_get_reservation_activity_feed',
        'permission_callback' => 'tryzub_can_read_reservations',
        'args' => [
            'date' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'from' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'to' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'reservation_id' => [
                'required' => false,
                'sanitize_callback' => 'absint',
            ],
            'event_type' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'page' => [
                'required' => false,
                'sanitize_callback' => 'absint',
            ],
            'per_page' => [
                'required' => false,
                'sanitize_callback' => 'absint',
            ],
            'include_debug' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ],
    ]);

    register_rest_route('tryzub/v1', '/managed-reservations', [
        [
            'methods' => 'GET',
            'callback' => 'tryzub_get_managed_reservations',
            'permission_callback' => 'tryzub_can_read_reservations',
            'args' => [
                'per_page' => [
                    'default' => 20,
                    'sanitize_callback' => 'absint'
                ],
                'page' => [
                    'default' => 1,
                    'sanitize_callback' => 'absint'
                ],
                'date' => [
                    'required' => false,
                    'sanitize_callback' => 'sanitize_text_field'
                ],
                'from' => [
                    'required' => false,
                    'sanitize_callback' => 'sanitize_text_field'
                ],
                'to' => [
                    'required' => false,
                    'sanitize_callback' => 'sanitize_text_field'
                ],
                'status' => [
                    'required' => false,
                    'sanitize_callback' => 'sanitize_text_field'
                ],
                'search' => [
                    'required' => false,
                    'sanitize_callback' => 'sanitize_text_field'
                ],
                'include_hidden' => [
                    'required' => false,
                    'sanitize_callback' => 'sanitize_text_field'
                ],
                'updated_since' => [
                    'required' => false,
                    'sanitize_callback' => 'sanitize_text_field'
                ]
            ]
        ],
        [
            'methods' => 'POST',
            'callback' => 'tryzub_create_managed_reservation',
            'permission_callback' => 'tryzub_can_read_reservations',
        ]
    ]);

    register_rest_route('tryzub/v1', '/managed-reservations/(?P<id>\d+)', [
        [
            'methods' => 'GET',
            'callback' => 'tryzub_get_managed_reservation',
            'permission_callback' => 'tryzub_can_read_reservations',
            'args' => [
                'id' => [
                    'required' => true,
                    'sanitize_callback' => 'absint',
                    'validate_callback' => function ($value) {
                        return absint($value) > 0;
                    }
                ]
            ]
        ],
        [
            'methods' => 'PATCH',
            'callback' => 'tryzub_update_managed_reservation',
            'permission_callback' => 'tryzub_can_read_reservations',
            'args' => [
                'id' => [
                    'required' => true,
                    'sanitize_callback' => 'absint',
                    'validate_callback' => function ($value) {
                        return absint($value) > 0;
                    }
                ]
            ]
        ],
        [
            'methods' => 'DELETE',
            'callback' => 'tryzub_delete_managed_reservation',
            'permission_callback' => 'tryzub_can_hard_delete_reservations',
            'args' => [
                'id' => [
                    'required' => true,
                    'sanitize_callback' => 'absint',
                    'validate_callback' => function ($value) {
                        return absint($value) > 0;
                    }
                ],
                'force' => [
                    'required' => false,
                    'sanitize_callback' => 'sanitize_text_field'
                ]
            ]
        ]
    ]);

    register_rest_route('tryzub/v1', '/managed-reservations/(?P<id>\d+)/activity', [
        'methods' => 'GET',
        'callback' => 'tryzub_get_managed_reservation_activity',
        'permission_callback' => 'tryzub_can_read_reservations',
        'args' => [
            'id' => [
                'required' => true,
                'sanitize_callback' => 'absint',
                'validate_callback' => function ($value) {
                    return absint($value) > 0;
                },
            ],
            'page' => [
                'required' => false,
                'sanitize_callback' => 'absint',
            ],
            'per_page' => [
                'required' => false,
                'sanitize_callback' => 'absint',
            ],
            'include_debug' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ],
    ]);

    register_rest_route('tryzub/v1', '/managed-reservations/(?P<id>\d+)/guest-manage-link', [
        'methods' => 'POST',
        'callback' => 'tryzub_create_guest_manage_link',
        'permission_callback' => 'tryzub_can_read_reservations',
        'args' => [
            'id' => [
                'required' => true,
                'sanitize_callback' => 'absint',
                'validate_callback' => function ($value) {
                    return absint($value) > 0;
                }
            ]
        ]
    ]);

    register_rest_route('tryzub/v1', '/reservation-self', [
        'methods' => 'GET',
        'callback' => 'tryzub_get_reservation_self',
        'permission_callback' => '__return_true',
        'args' => [
            'token' => [
                'required' => true,
                'sanitize_callback' => 'sanitize_text_field'
            ]
        ]
    ]);

    register_rest_route('tryzub/v1', '/reservation-self/change-request', [
        'methods' => 'POST',
        'callback' => 'tryzub_create_reservation_self_change_request',
        'permission_callback' => '__return_true',
    ]);

    register_rest_route('tryzub/v1', '/reservation-self/cancel', [
        'methods' => 'POST',
        'callback' => 'tryzub_cancel_reservation_self',
        'permission_callback' => '__return_true',
    ]);

    register_rest_route('tryzub/v1', '/managed-reservations/(?P<id>\d+)/tables', [
        'methods' => 'PATCH',
        'callback' => 'tryzub_patch_managed_reservation_tables',
        'permission_callback' => 'tryzub_can_read_reservations',
        'args' => [
            'id' => [
                'required' => true,
                'sanitize_callback' => 'absint',
                'validate_callback' => function ($value) {
                    return absint($value) > 0;
                },
            ],
        ],
    ]);

    register_rest_route('tryzub/v1', '/managed-reservations/(?P<id>\d+)/confirm', [
        'methods' => 'POST',
        'callback' => 'tryzub_confirm_managed_reservation',
        'permission_callback' => 'tryzub_can_read_reservations',
        'args' => [
            'id' => [
                'required' => true,
                'sanitize_callback' => 'absint',
                'validate_callback' => function ($value) {
                    return absint($value) > 0;
                }
            ]
        ]
    ]);

    register_rest_route('tryzub/v1', '/managed-reservations/(?P<id>\d+)/manual-email-log', [
        'methods' => 'POST',
        'callback' => 'tryzub_log_manual_reservation_email',
        'permission_callback' => 'tryzub_can_read_reservations',
        'args' => [
            'id' => [
                'required' => true,
                'sanitize_callback' => 'absint',
                'validate_callback' => function ($value) {
                    return absint($value) > 0;
                }
            ]
        ]
    ]);

    register_rest_route('tryzub/v1', '/managed-reservations/send-due-reminders', [
        'methods' => 'POST',
        'callback' => 'tryzub_send_due_reservation_reminders_rest',
        'permission_callback' => 'tryzub_can_read_reservations',
        'args' => [
            'date' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'force' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'cache_bust' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ],
    ]);

    register_rest_route('tryzub/v1', '/managed-reservations/reminder-status', [
        'methods' => 'GET',
        'callback' => 'tryzub_get_reservation_reminder_status_rest',
        'permission_callback' => 'tryzub_can_read_reservations',
        'args' => [
            'date' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ],
    ]);
}
