<?php

function tryzub_auto_confirm_default_policy() {
    return [
        'rules' => [],
        'excluded_dates' => [],
    ];
}

function tryzub_auto_confirm_settings() {
    $settings = tryzub_get_restaurant_settings();

    return [
        'enabled' => (bool) ($settings['auto_confirm_enabled'] ?? false),
        'require_email' => (bool) ($settings['auto_confirm_require_email'] ?? true),
        'block_guest_notes' => (bool) ($settings['auto_confirm_block_guest_notes'] ?? true),
        'block_duplicates' => (bool) ($settings['auto_confirm_block_duplicates'] ?? true),
        'block_suspicious' => (bool) ($settings['auto_confirm_block_suspicious'] ?? true),
        'policy' => $settings['auto_confirm_policy'] ?? tryzub_auto_confirm_default_policy(),
    ];
}

function tryzub_auto_confirm_policy_from_row($row) {
    $row = is_array($row) ? $row : [];
    $raw_policy = $row['auto_confirm_policy_json'] ?? ($row['auto_confirm_policy'] ?? null);

    if (is_string($raw_policy) && trim($raw_policy) !== '') {
        $decoded = json_decode($raw_policy, true);
    } elseif (is_array($raw_policy)) {
        $decoded = $raw_policy;
    } else {
        $decoded = tryzub_auto_confirm_default_policy();
    }

    if (!is_array($decoded)) {
        $decoded = tryzub_auto_confirm_default_policy();
    }

    $validated = tryzub_auto_confirm_validate_policy($decoded);

    if (is_wp_error($validated)) {
        return tryzub_auto_confirm_default_policy();
    }

    return $validated;
}

function tryzub_auto_confirm_validate_policy($policy) {
    if (is_string($policy)) {
        $policy = json_decode($policy, true);
    }

    if (!is_array($policy)) {
        return new WP_Error(
            'tryzub_invalid_auto_confirm_policy',
            'Auto-confirm policy must be an object.',
            ['status' => 400]
        );
    }

    $rules = $policy['rules'] ?? [];
    $excluded_dates = $policy['excluded_dates'] ?? [];

    if (!is_array($rules) || !is_array($excluded_dates)) {
        return new WP_Error(
            'tryzub_invalid_auto_confirm_policy',
            'Auto-confirm policy rules and excluded_dates must be arrays.',
            ['status' => 400]
        );
    }

    $normalized_rules = [];
    $seen_rule_ids = [];

    foreach ($rules as $index => $rule) {
        if (!is_array($rule)) {
            return new WP_Error(
                'tryzub_invalid_auto_confirm_rule',
                'Each auto-confirm rule must be an object.',
                ['status' => 400, 'index' => $index]
            );
        }

        $start_time = tryzub_auto_confirm_normalize_time($rule['start_time'] ?? '');
        $end_time = tryzub_auto_confirm_normalize_time($rule['end_time'] ?? '');
        $weekday = tryzub_parse_restaurant_setup_integer($rule['weekday'] ?? null);
        $max_party_size = tryzub_parse_restaurant_setup_integer($rule['max_party_size'] ?? null);
        $enabled = tryzub_normalize_boolean_value($rule['enabled'] ?? true);

        if ($enabled === null) {
            return new WP_Error(
                'tryzub_invalid_auto_confirm_enabled',
                'Auto-confirm rule enabled must be true or false.',
                ['status' => 400, 'index' => $index]
            );
        }

        if ($weekday === null || $weekday < 0 || $weekday > 6) {
            return new WP_Error(
                'tryzub_invalid_auto_confirm_weekday',
                'Auto-confirm rule weekday must be between 0 and 6.',
                ['status' => 400, 'index' => $index]
            );
        }

        if ($start_time === null || $end_time === null || $end_time <= $start_time) {
            return new WP_Error(
                'tryzub_invalid_auto_confirm_time_window',
                'Auto-confirm rule end_time must be after start_time.',
                ['status' => 400, 'index' => $index]
            );
        }

        if ($max_party_size === null || $max_party_size < 1 || $max_party_size > 20) {
            return new WP_Error(
                'tryzub_invalid_auto_confirm_max_party_size',
                'Auto-confirm rule max_party_size must be between 1 and 20.',
                ['status' => 400, 'index' => $index]
            );
        }

        $rule_id = sanitize_key((string) ($rule['id'] ?? ('rule_' . ($index + 1))));
        $rule_id = $rule_id !== '' ? $rule_id : 'rule_' . ($index + 1);

        if (isset($seen_rule_ids[$rule_id])) {
            return new WP_Error(
                'tryzub_duplicate_auto_confirm_rule_id',
                'Auto-confirm rule ids must be unique.',
                ['status' => 400, 'id' => $rule_id]
            );
        }

        $seen_rule_ids[$rule_id] = true;

        $normalized_rules[] = [
            'id' => $rule_id,
            'enabled' => (bool) $enabled,
            'weekday' => $weekday,
            'start_time' => $start_time,
            'end_time' => $end_time,
            'max_party_size' => $max_party_size,
        ];
    }

    $normalized_excluded_dates = [];

    foreach ($excluded_dates as $date) {
        $date = sanitize_text_field((string) $date);

        if (!tryzub_is_valid_managed_reservation_date($date)) {
            return new WP_Error(
                'tryzub_invalid_auto_confirm_excluded_date',
                'Auto-confirm excluded_dates must contain YYYY-MM-DD values.',
                ['status' => 400]
            );
        }

        $normalized_excluded_dates[] = $date;
    }

    return [
        'rules' => $normalized_rules,
        'excluded_dates' => array_values(array_unique($normalized_excluded_dates)),
    ];
}

function tryzub_auto_confirm_normalize_time($value) {
    if (function_exists('tryzub_normalize_restaurant_setup_time')) {
        return tryzub_normalize_restaurant_setup_time($value);
    }

    $value = trim(sanitize_text_field((string) $value));

    if (!preg_match('/^([01]?\d|2[0-3]):([0-5]\d)(?::([0-5]\d))?$/', $value, $matches)) {
        return null;
    }

    $seconds = isset($matches[3]) && $matches[3] !== '' ? (int) $matches[3] : 0;

    return sprintf('%02d:%02d:%02d', (int) $matches[1], (int) $matches[2], $seconds);
}

function tryzub_auto_confirm_matching_rule($reservation, $settings) {
    $reservation = is_array($reservation) ? $reservation : [];
    $settings = is_array($settings) ? $settings : tryzub_auto_confirm_settings();
    $policy = $settings['policy'] ?? tryzub_auto_confirm_default_policy();
    $date = sanitize_text_field((string) ($reservation['reservation_date'] ?? ''));
    $time = tryzub_auto_confirm_normalize_time($reservation['reservation_time'] ?? '');

    if ($date === '' || $time === '' || in_array($date, $policy['excluded_dates'] ?? [], true)) {
        return null;
    }

    $date_time = DateTimeImmutable::createFromFormat('!Y-m-d', $date);

    if (!$date_time instanceof DateTimeImmutable) {
        return null;
    }

    $weekday = ((int) $date_time->format('N')) - 1;
    $best_rule = null;

    foreach (($policy['rules'] ?? []) as $rule) {
        if (empty($rule['enabled']) || (int) ($rule['weekday'] ?? -1) !== $weekday) {
            continue;
        }

        if ($time < (string) $rule['start_time'] || $time >= (string) $rule['end_time']) {
            continue;
        }

        if ($best_rule === null || (int) $rule['max_party_size'] > (int) $best_rule['max_party_size']) {
            $best_rule = $rule;
        }
    }

    return $best_rule;
}

function tryzub_auto_confirm_evaluate($reservation) {
    $reservation = is_array($reservation) ? $reservation : [];
    $settings = tryzub_auto_confirm_settings();
    $blocked = [];
    $rule = tryzub_auto_confirm_matching_rule($reservation, $settings);
    $date = sanitize_text_field((string) ($reservation['reservation_date'] ?? ''));
    $policy = $settings['policy'] ?? tryzub_auto_confirm_default_policy();

    if (empty($settings['enabled'])) {
        $blocked[] = 'auto_confirm_disabled';
    }

    if (($reservation['source_type'] ?? '') !== 'form') {
        $blocked[] = 'not_form_source';
    }

    if (in_array(($reservation['status'] ?? ''), ['cancelled', 'completed', 'no_show'], true)) {
        $blocked[] = 'terminal_status';
    } elseif (($reservation['status'] ?? '') !== 'new') {
        $blocked[] = 'not_new_status';
    }

    if (!empty($reservation['is_hidden']) || !empty($reservation['superseded_by_id'])) {
        $blocked[] = 'hidden_or_superseded';
    }

    if ($date !== '' && in_array($date, $policy['excluded_dates'] ?? [], true)) {
        $blocked[] = 'excluded_date';
    }

    if (!$rule) {
        $blocked[] = 'no_matching_auto_confirm_rule';
    } elseif ((int) ($reservation['party_size'] ?? 0) > (int) ($rule['max_party_size'] ?? 0)) {
        $blocked[] = 'party_too_large_for_rule';
    }

    if (!empty($settings['require_email']) && !tryzub_reservation_has_usable_guest_email($reservation)) {
        $blocked[] = 'no_email';
    }

    $staff_notes = trim((string) ($reservation['staff_notes'] ?? ''));

    if (!empty($settings['block_duplicates']) && tryzub_auto_confirm_has_duplicate_markers($reservation)) {
        $blocked[] = 'duplicate_or_correction';
    }

    if (!empty($settings['block_suspicious']) && tryzub_auto_confirm_has_suspicious_contact($reservation)) {
        $blocked[] = 'suspicious_contact';
    }

    if ($staff_notes !== '') {
        $blocked[] = 'has_staff_notes';
    }

    if (!empty($settings['block_guest_notes']) && trim((string) ($reservation['guest_notes'] ?? '')) !== '') {
        $blocked[] = 'has_guest_notes';
    }

    if (!empty($reservation['confirmation_email_sent_at']) || tryzub_reservation_email_already_sent((int) ($reservation['id'] ?? 0), 'confirmation')) {
        $blocked[] = 'confirmation_already_sent';
    }

    if (tryzub_get_reservation_email_provider() !== 'resend' || !tryzub_get_resend_api_key()) {
        $blocked[] = 'provider_not_configured';
    } elseif (function_exists('tryzub_email_usage_can_send')) {
        $usage_gate = tryzub_email_usage_can_send('confirmation');

        if (empty($usage_gate['allowed']) && !empty($usage_gate['code'])) {
            $blocked[] = sanitize_key((string) $usage_gate['code']);
        }
    }

    return [
        'reservation_id' => (int) ($reservation['id'] ?? 0),
        'reservation_time' => substr((string) ($reservation['reservation_time'] ?? ''), 0, 5),
        'party_size' => (int) ($reservation['party_size'] ?? 0),
        'status' => sanitize_text_field((string) ($reservation['status'] ?? '')),
        'source_type' => sanitize_text_field((string) ($reservation['source_type'] ?? '')),
        'eligible' => empty($blocked),
        'matching_rule_id' => $rule['id'] ?? null,
        'matching_rule_max_party_size' => isset($rule['max_party_size']) ? (int) $rule['max_party_size'] : null,
        'blocked_reasons' => array_values(array_unique($blocked)),
    ];
}

function tryzub_auto_confirm_has_duplicate_markers(array $reservation) {
    if (!empty($reservation['duplicate_of_reservation_id']) || trim((string) ($reservation['duplicate_reason'] ?? '')) !== '') {
        return true;
    }

    return stripos((string) ($reservation['staff_notes'] ?? ''), 'possible duplicate') !== false
        || stripos((string) ($reservation['staff_notes'] ?? ''), 'correction') !== false;
}

function tryzub_auto_confirm_has_suspicious_contact(array $reservation) {
    return tryzub_name_needs_review($reservation['guest_name'] ?? '')
        || tryzub_phone_needs_review($reservation['phone'] ?? '')
        || !is_email(sanitize_email((string) ($reservation['email'] ?? '')));
}

function tryzub_auto_confirm_apply_if_eligible($reservation_id, $source = 'form_import') {
    $reservation = tryzub_get_managed_reservation_row_by_id(absint($reservation_id));

    if (!$reservation) {
        return null;
    }

    $evaluation = tryzub_auto_confirm_evaluate($reservation);

    if (empty($evaluation['eligible'])) {
        return [
            'attempted' => false,
            'evaluation' => $evaluation,
        ];
    }

    $result = tryzub_execute_managed_reservation_confirmation(absint($reservation_id), [
        'source' => 'auto_confirm',
        'activity_event_type' => 'auto_confirmed',
        'activity_summary' => 'Reservation auto-confirmed after website form import.',
        'request_body' => [
            'source' => sanitize_text_field((string) $source),
        ],
    ]);

    if (is_wp_error($result)) {
        tryzub_reservation_activity_log(
            absint($reservation_id),
            'auto_confirm_failed',
            'Reservation auto-confirm failed after website form import.',
            [
                'source' => 'auto_confirm',
                'metadata' => [
                    'error_code' => $result->get_error_code(),
                    'error_message' => $result->get_error_message(),
                ],
            ]
        );

        return [
            'attempted' => true,
            'confirmed' => false,
            'evaluation' => $evaluation,
            'error_code' => $result->get_error_code(),
        ];
    }

    $confirmed = !empty($result['response']['success']) && ($result['email_result']['status'] ?? '') === 'sent';

    if (!$confirmed) {
        tryzub_reservation_activity_log(
            absint($reservation_id),
            'auto_confirm_failed',
            'Reservation auto-confirm failed after website form import.',
            [
                'source' => 'auto_confirm',
                'metadata' => [
                    'email_status' => sanitize_text_field((string) ($result['email_result']['status'] ?? '')),
                    'email_error' => sanitize_text_field((string) ($result['email_result']['error_message'] ?? '')),
                ],
            ]
        );
    }

    return [
        'attempted' => true,
        'confirmed' => $confirmed,
        'evaluation' => $evaluation,
        'email_status' => sanitize_text_field((string) ($result['email_result']['status'] ?? '')),
    ];
}

function tryzub_auto_confirm_list_candidates_for_date($date) {
    global $wpdb;

    $date = sanitize_text_field((string) $date);

    if (!tryzub_is_valid_managed_reservation_date($date)) {
        return new WP_Error(
            'tryzub_invalid_auto_confirm_date',
            'date must be a valid YYYY-MM-DD value.',
            ['status' => 400]
        );
    }

    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT *
            FROM " . tryzub_get_reservations_table_name() . "
            WHERE reservation_date = %s
            AND source_type = %s
            AND status = %s
            ORDER BY reservation_time ASC, id ASC",
            $date,
            'form',
            'new'
        ),
        ARRAY_A
    );

    if (!is_array($rows)) {
        return new WP_Error(
            'tryzub_database_error',
            'Failed to load auto-confirm candidates.',
            ['status' => 500]
        );
    }

    return array_map('tryzub_auto_confirm_evaluate', $rows);
}

function tryzub_get_auto_confirm_candidates_rest(WP_REST_Request $request) {
    $date = sanitize_text_field((string) $request->get_param('date'));
    $items = tryzub_auto_confirm_list_candidates_for_date($date);

    if (is_wp_error($items)) {
        return $items;
    }

    return rest_ensure_response([
        'success' => true,
        'date' => $date,
        'data' => $items,
    ]);
}
