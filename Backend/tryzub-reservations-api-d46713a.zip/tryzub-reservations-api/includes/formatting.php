<?php

// Converts one raw Flamingo post into a stable PHP array.
// This is still raw intake formatting, not the final managed reservation state.
// The import endpoint uses this as the bridge between Flamingo and the managed table.
// Converts one Flamingo post into the clean reservation JSON contract used by the iOS app.
function tryzub_format_reservation(WP_Post $post) {
    $fields = tryzub_extract_submission_fields($post->ID);

    // Production CF7 field mapping:
    // text-583     = guest name
    // email-90     = guest email
    // tel-299      = guest phone
    // text-446     = reservation date
    // text-196     = reservation time
    // text-139     = party size
    // textarea-887 = reservation notes
    return [
        'id' => (int) $post->ID,
        'created_at' => $post->post_date,
        'created_at_gmt' => $post->post_date_gmt,
        'guest_name' => $fields['text-583'] ?? null,
        'email' => $fields['email-90'] ?? null,
        'phone' => $fields['tel-299'] ?? null,
        'reservation_date' => tryzub_normalize_reservation_date($fields['text-446'] ?? null),
        'reservation_time' => $fields['text-196'] ?? null,
        'party_size' => isset($fields['text-139']) ? absint($fields['text-139']) : null,
        'notes' => $fields['textarea-887'] ?? null,
        'client_request_id' => tryzub_normalize_client_request_id($fields['tryzub_client_request_id'] ?? null),
        // 'raw_fields' => $fields
    ];
}

// Extracts submitted CF7 fields from Flamingo post meta.
// Flamingo stores field values with keys like _field_text-583, so this removes the _field_ prefix.
function tryzub_extract_submission_fields($post_id) {
    $fields = [];
    $meta = get_post_meta($post_id);

    foreach ($meta as $key => $value) {
        // Only read actual submitted form fields and ignore unrelated/private WordPress metadata.
        if (strpos($key, '_field_') === 0) {
            $field_name = substr($key, strlen('_field_'));
            $raw_value = $value[0] ?? '';
            $fields[$field_name] = tryzub_clean_field_value($raw_value);
        }
    }

    return $fields;
}

// Normalizes and sanitizes one submitted field value before it is included in the API response.
function tryzub_clean_field_value($value) {
    $decoded_value = maybe_unserialize($value);

    // Some field values can decode into arrays; flatten them into a readable string.
    if (is_array($decoded_value)) {
        return implode(', ', array_map('sanitize_text_field', $decoded_value));
    } else {
        return sanitize_textarea_field((string) $decoded_value);
    }
}

function tryzub_normalize_reservation_date($value) {
    if (!$value) {
        return null;
    }

    $value = sanitize_text_field($value);
    $formats = ['m-d-Y', 'n-j-Y', 'Y-m-d', 'm/d/Y', 'n/j/Y', 'F j, Y', 'F d, Y', 'M j, Y', 'M d, Y'];

    foreach ($formats as $format) {
        $date = DateTime::createFromFormat($format, $value);
        $errors = DateTime::getLastErrors();

        if (
            $date instanceof DateTime &&
            (
                $errors === false ||
                ((int) $errors['warning_count'] === 0 && (int) $errors['error_count'] === 0)
            )
        ) {
            return $date->format('Y-m-d');
        }
    }

    return null; // Invalid date format
}

function tryzub_normalize_reservation_time($value) {
    if (!$value) {
        return null;
    }

    $value = sanitize_text_field($value);

    $formats = ['H:i', 'H:i:s', 'g:i A', 'g:i a', 'g A', 'g a', 'gA', 'ga'];

    foreach ($formats as $format) {
        $time = DateTime::createFromFormat($format, $value);
        $errors = DateTime::getLastErrors();

        if (
            $time instanceof DateTime &&
            (
                $errors === false ||
                ((int) $errors['warning_count'] === 0 && (int) $errors['error_count'] === 0)
            )
        ) {
            return $time->format('H:i:s');
        }
    }

    return null;
}

function tryzub_normalize_phone_digits($phone) {
    return preg_replace('/\D+/', '', (string) $phone);
}

function tryzub_normalize_client_request_id($value) {
    $value = trim(sanitize_text_field((string) $value));

    if ($value === '') {
        return null;
    }

    return substr($value, 0, 191);
}

function tryzub_get_reservation_form_field_signatures() {
    return [
        'text-583',
        'email-90',
        'tel-299',
        'text-446',
        'text-196',
        'text-139',
        'textarea-887',
        'tryzub_client_request_id',
    ];
}

function tryzub_detect_submission_form_source($post_id, $field_keys = null) {
    $post_id = absint($post_id);
    $field_keys = is_array($field_keys) ? array_values(array_unique($field_keys)) : array_keys(tryzub_extract_submission_fields($post_id));
    $signature_fields = tryzub_get_reservation_form_field_signatures();
    $matched_fields = array_values(array_intersect($signature_fields, $field_keys));
    $has_reservation_date = in_array('text-446', $field_keys, true);
    $has_guest_name = in_array('text-583', $field_keys, true);
    $has_party_size = in_array('text-139', $field_keys, true);
    $matches_reservation_field_set = ($has_reservation_date && ($has_guest_name || $has_party_size))
        || count($matched_fields) >= 3;

    $form_id = absint(get_post_meta($post_id, '_wpcf7_contact_form', true));
    $form_title = null;

    if ($form_id > 0) {
        $form_post = get_post($form_id);

        if ($form_post instanceof WP_Post) {
            $form_title = sanitize_text_field((string) $form_post->post_title);
        }
    }

    if (!$matches_reservation_field_set && count($matched_fields) === 0) {
        $form_source_kind = 'non_reservation_form';
        $is_reservation_form = false;
    } elseif ($matches_reservation_field_set) {
        $form_source_kind = 'reservation_form';
        $is_reservation_form = true;
    } else {
        $form_source_kind = 'form_source_unknown';
        $is_reservation_form = false;
    }

    return [
        'form_id' => $form_id > 0 ? $form_id : null,
        'form_title' => $form_title !== '' ? $form_title : null,
        'is_reservation_form' => $is_reservation_form,
        'form_source_kind' => $form_source_kind,
        'matches_reservation_field_set' => $matches_reservation_field_set,
        'matched_reservation_field_count' => count($matched_fields),
    ];
}
