<?php

function tryzub_intelligence_normalize_email($email) {
    $email = strtolower(trim(sanitize_email((string) $email)));

    if ($email === '' || !is_email($email)) {
        return '';
    }

    if (strcasecmp($email, 'callinreservation@tryzubchicago.com') === 0) {
        return '';
    }

    if (function_exists('tryzub_is_call_in_placeholder_email') && tryzub_is_call_in_placeholder_email($email)) {
        return '';
    }

    return $email;
}

function tryzub_intelligence_normalize_phone($phone) {
    if (!function_exists('tryzub_normalize_phone_digits')) {
        return '';
    }

    $digits = tryzub_normalize_phone_digits($phone);

    if (strlen($digits) < 7) {
        return '';
    }

    return $digits;
}

function tryzub_intelligence_normalize_name($name) {
    $name = strtolower(trim((string) $name));
    $name = preg_replace('/[^\p{L}\p{N}\s]+/u', ' ', $name);
    $name = preg_replace('/\s+/u', ' ', $name);
    $name = trim($name);

    if ($name === '' || strlen($name) < 2) {
        return '';
    }

    return $name;
}

function tryzub_intelligence_guest_key($basis) {
    $basis = trim((string) $basis);

    if ($basis === '') {
        return null;
    }

    return hash_hmac('sha256', $basis, wp_salt('tryzub_guest_key'));
}

function tryzub_intelligence_identity_from_row($row) {
    $row = is_object($row) ? (array) $row : $row;

    if (!is_array($row)) {
        $row = [];
    }

    $normalized_email = tryzub_intelligence_normalize_email($row['email'] ?? '');
    $normalized_phone = tryzub_intelligence_normalize_phone($row['phone'] ?? '');
    $normalized_name = tryzub_intelligence_normalize_name($row['guest_name'] ?? '');

    $basis = '';
    $confidence = 'unknown';

    if ($normalized_email !== '') {
        $basis = 'email:' . $normalized_email;
        $confidence = 'exact';
    } elseif ($normalized_phone !== '') {
        $basis = 'phone:' . $normalized_phone;

        if (strlen($normalized_phone) >= 10) {
            $confidence = 'strong';
        } else {
            $confidence = 'possible';
        }
    } elseif (tryzub_intelligence_name_is_identity_candidate($normalized_name)) {
        $basis = 'name:' . $normalized_name;
        $confidence = 'possible';
    } else {
        $confidence = 'weak';

        if ($normalized_name === '') {
            $confidence = 'unknown';
        }
    }

    return [
        'basis' => $basis,
        'guest_key' => tryzub_intelligence_guest_key($basis),
        'confidence' => $confidence,
        'normalized_email' => $normalized_email,
        'normalized_phone' => $normalized_phone,
        'normalized_name' => $normalized_name,
    ];
}

function tryzub_intelligence_name_is_identity_candidate($normalized_name) {
    if ($normalized_name === '') {
        return false;
    }

    $parts = preg_split('/\s+/u', $normalized_name, -1, PREG_SPLIT_NO_EMPTY);

    if (count($parts) < 2) {
        return false;
    }

    return !tryzub_intelligence_is_generic_name($normalized_name);
}

function tryzub_intelligence_is_generic_name($normalized_name) {
    $normalized_name = tryzub_intelligence_normalize_name($normalized_name);

    if ($normalized_name === '') {
        return true;
    }

    $generic_names = [
        'guest',
        'test',
        'testing',
        'unknown',
        'customer',
        'reservation',
        'caller',
        'walk in',
        'walkin',
        'walk in guest',
        'no name',
        'noname',
        'name',
        'party',
        'table',
        'test test',
        'guest guest',
        'test user',
        'test guest',
    ];

    if (in_array($normalized_name, $generic_names, true)) {
        return true;
    }

    $parts = preg_split('/\s+/u', $normalized_name, -1, PREG_SPLIT_NO_EMPTY);

    if (count($parts) === 1 && in_array($parts[0], ['guest', 'test', 'testing', 'unknown', 'customer', 'caller', 'party'], true)) {
        return true;
    }

    return (bool) preg_match('/^(test|guest|unknown)(\s+(test|guest|user|name))+$/', $normalized_name);
}

function tryzub_intelligence_active_statuses() {
    return ['new', 'needs_review', 'confirmed', 'seated'];
}

function tryzub_intelligence_terminal_statuses() {
    return ['completed', 'cancelled', 'no_show'];
}

function tryzub_intelligence_is_clean_visit_status($status) {
    return in_array(sanitize_text_field((string) $status), ['confirmed', 'seated', 'completed'], true);
}

function tryzub_intelligence_is_operational_row($row) {
    $row = is_object($row) ? (array) $row : $row;

    if (!is_array($row)) {
        return false;
    }

    if (!empty($row['is_hidden'])) {
        return false;
    }

    if (!empty($row['superseded_by_id'])) {
        return false;
    }

    return true;
}

function tryzub_intelligence_is_clean_history_row($row) {
    if (!tryzub_intelligence_is_operational_row($row)) {
        return false;
    }

    $row = is_object($row) ? (array) $row : $row;

    if (!empty($row['duplicate_of_reservation_id'])) {
        return false;
    }

    return tryzub_intelligence_is_clean_visit_status($row['status'] ?? '');
}

function tryzub_intelligence_validate_date($date) {
    if (!function_exists('tryzub_normalize_reservation_date')) {
        return new WP_Error(
            'tryzub_intelligence_missing_date_normalizer',
            'Reservation date normalizer is unavailable.',
            ['status' => 500]
        );
    }

    $normalized = tryzub_normalize_reservation_date($date);

    if (!$normalized) {
        return new WP_Error(
            'tryzub_intelligence_invalid_date',
            'Date must be valid.',
            ['status' => 400]
        );
    }

    return $normalized;
}

function tryzub_intelligence_validate_date_range($from, $to, $max_days = 366) {
    $from = tryzub_intelligence_validate_date($from);

    if (is_wp_error($from)) {
        return $from;
    }

    $to = tryzub_intelligence_validate_date($to);

    if (is_wp_error($to)) {
        return $to;
    }

    if ($from > $to) {
        return new WP_Error(
            'tryzub_intelligence_invalid_date_range',
            'from must be before or equal to to.',
            ['status' => 400]
        );
    }

    $from_date = DateTimeImmutable::createFromFormat('!Y-m-d', $from);
    $to_date = DateTimeImmutable::createFromFormat('!Y-m-d', $to);

    if (!$from_date instanceof DateTimeImmutable || !$to_date instanceof DateTimeImmutable) {
        return new WP_Error(
            'tryzub_intelligence_invalid_date_range',
            'Date range could not be validated.',
            ['status' => 400]
        );
    }

    $inclusive_days = (int) $from_date->diff($to_date)->days + 1;

    if ($inclusive_days > absint($max_days)) {
        return new WP_Error(
            'tryzub_intelligence_date_range_too_large',
            'Date range must not exceed ' . absint($max_days) . ' days.',
            ['status' => 400]
        );
    }

    return [
        'from' => $from,
        'to' => $to,
    ];
}

function tryzub_intelligence_generated_at_iso() {
    if (function_exists('current_datetime')) {
        return current_datetime()->format(DateTimeInterface::ATOM);
    }

    $timezone = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC');
    $date_time = new DateTimeImmutable('now', $timezone);

    return $date_time->format(DateTimeInterface::ATOM);
}

function tryzub_intelligence_time_15min_bucket($time) {
    $time = trim(sanitize_text_field((string) $time));

    if ($time === '') {
        return null;
    }

    if (function_exists('tryzub_normalize_reservation_time')) {
        $normalized = tryzub_normalize_reservation_time($time);

        if ($normalized) {
            $time = $normalized;
        }
    }

    if (!preg_match('/^(\d{1,2}):(\d{2})(?::\d{2})?$/', $time, $matches)) {
        return null;
    }

    $hour = (int) $matches[1];
    $minute = (int) $matches[2];

    if ($hour < 0 || $hour > 23 || $minute < 0 || $minute > 59) {
        return null;
    }

    $bucket_minute = (int) (floor($minute / 15) * 15);

    return sprintf('%02d:%02d', $hour, $bucket_minute);
}

function tryzub_intelligence_lead_time_bucket($days) {
    if ($days === null || $days === '' || !is_numeric($days)) {
        return 'unknown';
    }

    $days = (int) $days;

    if ($days < 0) {
        return 'unknown';
    }

    if ($days === 0) {
        return 'same_day';
    }

    if ($days <= 2) {
        return '1_2_days';
    }

    if ($days <= 6) {
        return '3_6_days';
    }

    if ($days <= 14) {
        return '1_2_weeks';
    }

    return '2_plus_weeks';
}

function tryzub_intelligence_party_size_bucket($party_size, $large_party_threshold = 7) {
    $party_size = absint($party_size);

    if ($party_size <= 2) {
        return '1-2';
    }

    if ($party_size <= 4) {
        return '3-4';
    }

    if ($party_size <= 6) {
        return '5-6';
    }

    return '7+';
}

function tryzub_intelligence_weekday_label($weekday) {
    $labels = [
        0 => 'Monday',
        1 => 'Tuesday',
        2 => 'Wednesday',
        3 => 'Thursday',
        4 => 'Friday',
        5 => 'Saturday',
        6 => 'Sunday',
    ];

    $weekday = (int) $weekday;

    return $labels[$weekday] ?? 'Sunday';
}

function tryzub_intelligence_response(array $data) {
    $response = rest_ensure_response([
        'success' => true,
        'data' => $data,
    ]);

    $response->header('Cache-Control', 'private, no-store, max-age=0');
    $response->header('Pragma', 'no-cache');

    return $response;
}

function tryzub_intelligence_safe_enum($value, array $allowed, $fallback) {
    $value = sanitize_text_field((string) $value);

    if (in_array($value, $allowed, true)) {
        return $value;
    }

    return $fallback;
}

function tryzub_intelligence_normalize_note_text($guest_notes, $staff_notes = '') {
    $text = trim((string) $guest_notes . "\n" . (string) $staff_notes);

    if ($text === '') {
        return '';
    }

    if (function_exists('mb_strtolower')) {
        $text = mb_strtolower($text, 'UTF-8');
    } else {
        $text = strtolower($text);
    }

    $text = preg_replace('/\s+/u', ' ', $text);

    return trim($text);
}

function tryzub_intelligence_get_note_flag_keyword_sets() {
    return [
        'has_seating_preference' => [
            'booth',
            'window seat',
            'by the window',
            'near window',
            'window',
            'quiet',
            'quiet table',
            'patio',
            'outside',
            'outdoor',
            'at the bar',
            'near bar',
            'bar area',
            'wall',
            'corner',
            'high chair',
            'highchair',
            'будка',
            'кабінка',
            'біля вікна',
            'вікно',
            'тихо',
            'тихий',
            'тихе місце',
            'кут',
            'в кутку',
            'стіна',
            'біля стіни',
            'патіо',
            'надворі',
            'на вулиці',
            'біля бару',
            'дитячий стілець',
            'стільчик',
        ],
        'has_allergy_note' => [
            'allergy',
            'allergic',
            'gluten',
            'gluten free',
            'gluten-free',
            'dairy',
            'dairy free',
            'nut allergy',
            'nuts',
            'peanut',
            'shellfish',
            'vegan',
            'vegetarian',
            'celiac',
            'алергія',
            'алергік',
            'алергічна',
            'алергічний',
            'глютен',
            'без глютену',
            'лактоза',
            'молочне',
            'без молочного',
            'горіх',
            'горіхи',
            'арахіс',
            'морепродукти',
            'веган',
            'веганський',
            'вегетаріанець',
            'вегетаріанський',
            'целіакія',
            'часник',
            'без часнику',
            'аллергия',
            'без глютена',
            'орехи',
            'alergiya',
            'bez hliutenu',
        ],
        'has_accessibility_note' => [
            'wheelchair',
            'walker',
            'accessible',
            'accessibility',
            'stroller',
            'mobility',
            'cane',
            'інвалідний візок',
            'візок',
            'доступність',
            'доступний',
            'ходунки',
            'тростина',
            'милиці',
            'коляска',
            'дитяча коляска',
            'мобільність',
        ],
        'has_special_occasion_note' => [
            'birthday',
            'anniversary',
            'celebration',
            'date night',
            'proposal',
            'graduation',
            'baby shower',
            'bridal shower',
            'wedding shower',
            'baptism',
            'christening',
            'communion',
            'first communion',
            'engagement',
            'rehearsal dinner',
            'wedding',
            'memorial',
            'family gathering',
            'family celebration',
            'retirement',
            'christening lunch',
            'christening dinner',
            'день народження',
            'народження',
            'річниця',
            'ювілей',
            'святкування',
            'свято',
            'побачення',
            'пропозиція',
            'заручини',
            'випускний',
            'бейбі шауер',
            'бебі шауер',
            'свято для дитини',
            'народження дитини',
            'очікування дитини',
            'хрестини',
            'хрещення',
            'хрестини дитини',
            'причастя',
            'перше причастя',
            'весілля',
            'передвесільна вечеря',
            'весільна вечеря',
            'дівич-вечір',
            'парубочий вечір',
            'родинне свято',
            'сімейне свято',
            'сімейна зустріч',
            'родинна зустріч',
            'поминки',
            'вшанування памʼяті',
            'вшанування пам\'яті',
            'пенсія',
            'вихід на пенсію',
            'день рождения',
            'крестины',
            'крещение',
            'годовщина',
            'свадьба',
            'семейный праздник',
            'den narodzhennya',
            'richnytsya',
            'khrestyny',
            'khreshchennia',
            'zaruchyny',
            'vesillia',
            'pomynky',
        ],
        'has_prior_service_issue' => [
            'upset',
            'complaint',
            'complained',
            'rude',
            'bad experience',
            'refund',
            'remake',
            'wrong order',
            'скарга',
            'скаржився',
            'скаржилась',
            'проблема',
            'проблеми',
            'поганий досвід',
            'незадоволений',
            'незадоволена',
            'грубо',
            'грубий',
            'повернення коштів',
            'переробити',
            'неправильне замовлення',
            'помилка',
            'жалоба',
        ],
    ];
}

// Heuristic boolean flags only. Not medical, legal, or operational truth.
function tryzub_intelligence_detect_note_flags($guest_notes, $staff_notes = '') {
    $text = tryzub_intelligence_normalize_note_text($guest_notes, $staff_notes);
    $keyword_sets = tryzub_intelligence_get_note_flag_keyword_sets();
    $flags = [];

    foreach ($keyword_sets as $flag => $keywords) {
        $flags[$flag] = tryzub_intelligence_text_contains_keyword($text, $keywords);
    }

    return $flags;
}

function tryzub_intelligence_text_contains_keyword($text, array $keywords) {
    if ($text === '') {
        return false;
    }

    foreach ($keywords as $keyword) {
        $keyword = trim((string) $keyword);

        if ($keyword === '') {
            continue;
        }

        if (function_exists('mb_strtolower')) {
            $keyword = mb_strtolower($keyword, 'UTF-8');
        } else {
            $keyword = strtolower($keyword);
        }

        if (tryzub_intelligence_note_keyword_matches($text, $keyword)) {
            return true;
        }
    }

    return false;
}

function tryzub_intelligence_note_keyword_matches($text, $keyword) {
    if ($keyword === '') {
        return false;
    }

    if (function_exists('mb_strpos')) {
        return mb_strpos($text, $keyword) !== false;
    }

    return strpos($text, $keyword) !== false;
}

function tryzub_intelligence_classify_guest($clean_visits, $confidence, $needs_review = false, $possible_duplicate = false) {
    if ($possible_duplicate || $needs_review) {
        return 'needs_review';
    }

    $confidence = sanitize_text_field((string) $confidence);

    if (in_array($confidence, ['weak', 'unknown'], true)) {
        return 'unknown';
    }

    $clean_visits = max(0, (int) $clean_visits);

    if ($clean_visits <= 0) {
        return 'new';
    }

    if ($clean_visits <= 2) {
        return 'returning';
    }

    if ($clean_visits <= 5) {
        return 'regular';
    }

    return 'frequent_regular';
}

function tryzub_intelligence_source_bucket($source_type) {
    $source_type = sanitize_text_field((string) $source_type);

    if ($source_type === 'form') {
        return 'online';
    }

    if ($source_type === 'manual_call_in') {
        return 'call_in';
    }

    if (in_array($source_type, ['manual_walk_in', 'known_guest_manual', 'import_repair'], true)) {
        return 'manual';
    }

    return 'unknown';
}
