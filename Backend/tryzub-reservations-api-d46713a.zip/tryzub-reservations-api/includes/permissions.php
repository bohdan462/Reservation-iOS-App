<?php

function tryzub_auth_current_user_snapshot() {
    $user = wp_get_current_user();

    if (!$user || $user->ID <= 0) {
        return [
            'id' => 0,
            'login' => 'anonymous',
            'roles' => [],
            'can_manage_tryzub' => false,
            'can_manage_options' => false,
        ];
    }

    return [
        'id' => (int) $user->ID,
        'login' => (string) $user->user_login,
        'roles' => array_values((array) $user->roles),
        'can_manage_tryzub' => user_can($user, 'manage_tryzub_reservations'),
        'can_manage_options' => user_can($user, 'manage_options'),
    ];
}

function tryzub_auth_should_emit_trace() {
    return defined('WP_DEBUG') && WP_DEBUG;
}

function tryzub_auth_trace_permission_decision(WP_REST_Request $request, $policy, $allowed, $reason) {
    if (!tryzub_auth_should_emit_trace()) {
        return;
    }

    $snapshot = tryzub_auth_current_user_snapshot();
    $route = sanitize_text_field((string) $request->get_route());
    $decision = $allowed ? 'allow' : 'deny';

    error_log(
        '[AUTH_TRACE] route=' . $route
        . ' user=' . $snapshot['login']
        . ' roles=' . implode(',', $snapshot['roles'])
        . ' can_manage_tryzub=' . ($snapshot['can_manage_tryzub'] ? 'true' : 'false')
        . ' can_manage_options=' . ($snapshot['can_manage_options'] ? 'true' : 'false')
        . ' decision=' . $decision
        . ' reason=' . sanitize_text_field((string) $reason)
    );

    error_log(
        '[AUTH_ROUTE_POLICY_TRACE] route=' . $route
        . ' required=' . sanitize_text_field((string) $policy)
        . ' decision=' . $decision
    );
}

// Restricts protected endpoints to authenticated users allowed to manage Tryzub reservations.
// Administrators stay allowed during development; the staff app should use a limited user with manage_tryzub_reservations.
function tryzub_can_read_reservations(WP_REST_Request $request) {
    $snapshot = tryzub_auth_current_user_snapshot();
    $allowed = $snapshot['can_manage_tryzub'] || $snapshot['can_manage_options'];
    $reason = $allowed
        ? ($snapshot['can_manage_options'] ? 'manage_options' : 'manage_tryzub_reservations')
        : ($snapshot['id'] > 0 ? 'missing_staff_or_admin_cap' : 'not_authenticated');

    tryzub_auth_trace_permission_decision($request, 'staff_or_admin', $allowed, $reason);

    return $allowed;
}

// Permanent deletion is reserved for administrators/developers. Staff should use soft hide.
function tryzub_can_hard_delete_reservations(WP_REST_Request $request) {
    $snapshot = tryzub_auth_current_user_snapshot();
    $allowed = $snapshot['can_manage_options'];
    $reason = $allowed
        ? 'manage_options'
        : ($snapshot['id'] > 0 ? 'missing_manage_options' : 'not_authenticated');

    tryzub_auth_trace_permission_decision($request, 'admin_only', $allowed, $reason);

    return $allowed;
}

function tryzub_auth_probe_payload() {
    $snapshot = tryzub_auth_current_user_snapshot();

    if (tryzub_auth_should_emit_trace()) {
        error_log(
            '[AUTH_PROBE_TRACE] user=' . $snapshot['login']
            . ' canManageTryzub=' . ($snapshot['can_manage_tryzub'] ? 'true' : 'false')
            . ' canManageOptions=' . ($snapshot['can_manage_options'] ? 'true' : 'false')
        );
    }

    return [
        'id' => $snapshot['id'],
        'login' => $snapshot['login'],
        'roles' => $snapshot['roles'],
        'can_manage_tryzub_reservations' => $snapshot['can_manage_tryzub'],
        'can_manage_options' => $snapshot['can_manage_options'],
    ];
}
