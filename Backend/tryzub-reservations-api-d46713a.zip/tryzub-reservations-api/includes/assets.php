<?php

function tryzub_reservations_enqueue_assets() {
    $style_path = dirname(__DIR__) . '/assets/css/reservations-form.css';
    $style_version = file_exists($style_path) ? (string) filemtime($style_path) : '0.1.0';

    $script_path = dirname(__DIR__) . '/assets/js/reservations-form.js';
    $script_version = file_exists($script_path) ? (string) filemtime($script_path) : '0.1.0';

    wp_enqueue_style(
        'tryzub-reservations-form',
        TRYZUB_RESERVATIONS_API_URL . 'assets/css/reservations-form.css',
        [],
        $style_version
    );

    wp_enqueue_script(
        'tryzub-reservations-form',
        TRYZUB_RESERVATIONS_API_URL . 'assets/js/reservations-form.js',
        [],
        $script_version,
        true
    );

    if (function_exists('tryzub_get_restaurant_settings')) {
        $settings = tryzub_get_restaurant_settings();
        $public_setup = [
            'default_party_size' => (int) ($settings['default_party_size'] ?? 2),
            'max_online_party_size' => (int) ($settings['max_online_party_size'] ?? 8),
            'large_party_review_threshold' => (int) ($settings['large_party_review_threshold'] ?? 7),
        ];

        wp_add_inline_script(
            'tryzub-reservations-form',
            'window.tryzubReservationSetup = ' . wp_json_encode($public_setup) . ';',
            'before'
        );
    }
}

add_action('wp_enqueue_scripts', 'tryzub_reservations_enqueue_assets');
