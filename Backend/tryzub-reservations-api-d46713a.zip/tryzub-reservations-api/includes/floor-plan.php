<?php

function tryzub_get_restaurant_tables(WP_REST_Request $request) {
    return rest_ensure_response([
        'success' => true,
        'data' => tryzub_fetch_restaurant_table_rows(true),
    ]);
}

function tryzub_put_restaurant_tables(WP_REST_Request $request) {
    $body = tryzub_get_rest_request_body($request);
    $allowed_fields = ['tables'];
    $unknown_fields = array_diff(array_keys($body), $allowed_fields);

    if (!empty($unknown_fields)) {
        return new WP_Error(
            'tryzub_unknown_restaurant_tables_field',
            'Unknown restaurant tables field: ' . implode(', ', array_values($unknown_fields)),
            ['status' => 400]
        );
    }

    if (!array_key_exists('tables', $body) || !is_array($body['tables'])) {
        return new WP_Error(
            'tryzub_invalid_restaurant_tables',
            'tables must be an array.',
            ['status' => 400]
        );
    }

    $parsed_tables = tryzub_parse_restaurant_table_definitions($body['tables']);

    if (is_wp_error($parsed_tables)) {
        return $parsed_tables;
    }

    $existing_overlap = tryzub_validate_restaurant_tables_against_existing_layout($parsed_tables);

    if (is_wp_error($existing_overlap)) {
        return $existing_overlap;
    }

    $saved = tryzub_upsert_restaurant_table_definitions($parsed_tables);

    if (is_wp_error($saved)) {
        return $saved;
    }

    return rest_ensure_response([
        'success' => true,
        'upsert_mode' => 'partial_by_table_key',
        'contract_note' => 'Upserts only the provided table_key rows. Omitted tables are not deleted or auto-deactivated.',
        'data' => tryzub_fetch_restaurant_table_rows(true),
    ]);
}

function tryzub_get_floor_plan(WP_REST_Request $request) {
    tryzub_complete_past_active_reservations();

    $date = tryzub_normalize_reservation_date($request->get_param('date'));

    if (!$date) {
        return new WP_Error(
            'tryzub_invalid_date',
            'date must be a valid reservation date.',
            ['status' => 400]
        );
    }

    return rest_ensure_response([
        'success' => true,
        'date' => $date,
        'server_time' => current_time('mysql'),
        'tables' => tryzub_fetch_restaurant_table_rows(false),
        'assignments' => tryzub_fetch_floor_plan_assignments_for_date($date),
        'reservations' => tryzub_fetch_floor_plan_reservations_for_date($date),
    ]);
}

function tryzub_patch_managed_reservation_tables(WP_REST_Request $request) {
    tryzub_complete_past_active_reservations();

    $reservation_id = absint($request->get_param('id'));
    $row = tryzub_get_managed_reservation_row_by_id($reservation_id);

    if (!$row) {
        return new WP_Error(
            'tryzub_reservation_not_found',
            'Managed reservation not found.',
            ['status' => 404]
        );
    }

    if (!empty($row['is_hidden'])) {
        return new WP_Error(
            'tryzub_hidden_reservation_assignment',
            'Hidden reservations cannot be assigned tables.',
            ['status' => 400]
        );
    }

    $body = tryzub_get_rest_request_body($request);

    // Reject stale table assignments when the client supplies the version it last saw.
    $lock_conflict = tryzub_check_reservation_optimistic_lock($row, $body);

    if ($lock_conflict instanceof WP_REST_Response) {
        return $lock_conflict;
    }

    unset($body['expected_updated_at']);
    $allowed_fields = ['table_keys'];
    $unknown_fields = array_diff(array_keys($body), $allowed_fields);

    if (!empty($unknown_fields)) {
        return new WP_Error(
            'tryzub_unknown_table_assignment_field',
            'Unknown table assignment field: ' . implode(', ', array_values($unknown_fields)),
            ['status' => 400]
        );
    }

    if (!array_key_exists('table_keys', $body) || !is_array($body['table_keys'])) {
        return new WP_Error(
            'tryzub_invalid_table_keys',
            'table_keys must be an array.',
            ['status' => 400]
        );
    }

    $table_keys = tryzub_normalize_table_keys_list($body['table_keys']);

    if (is_wp_error($table_keys)) {
        return $table_keys;
    }

    $status = sanitize_text_field((string) ($row['status'] ?? ''));

    if (!empty($table_keys) && in_array($status, ['cancelled', 'completed', 'no_show'], true)) {
        return new WP_Error(
            'tryzub_terminal_reservation_assignment',
            'Cancelled, completed, and no-show reservations cannot receive new table assignments.',
            ['status' => 400]
        );
    }

    $table_rows = [];

    if (!empty($table_keys)) {
        $table_rows = tryzub_fetch_active_restaurant_tables_by_keys($table_keys);

        if (count($table_rows) !== count($table_keys)) {
            $found_keys = array_map(
                function ($table_row) {
                    return (string) ($table_row['table_key'] ?? '');
                },
                $table_rows
            );
            $missing = array_values(array_diff($table_keys, $found_keys));

            return new WP_Error(
                'tryzub_invalid_table_key',
                'One or more table keys are missing or inactive: ' . implode(', ', $missing),
                ['status' => 400]
            );
        }
    }

    $before_table_name = $row['table_name'] ?? null;
    $activity_context = tryzub_reservation_activity_request_context($body);

    $saved = tryzub_replace_reservation_table_assignments($reservation_id, $row, $table_keys, $table_rows);

    if (is_wp_error($saved)) {
        if ($saved->get_error_code() === 'tryzub_table_assignment_conflict') {
            $error_data = $saved->get_error_data();
            $conflicts = is_array($error_data) ? ($error_data['conflicts'] ?? []) : [];

            return new WP_REST_Response([
                'success' => false,
                'code' => 'tryzub_table_assignment_conflict',
                'message' => $saved->get_error_message(),
                'conflicts' => $conflicts,
            ], 409);
        }

        return $saved;
    }

    $after_row = tryzub_get_managed_reservation_row_by_id($reservation_id);
    $logged_activity = tryzub_reservation_activity_log_table_assignment_change(
        $reservation_id,
        $before_table_name,
        $after_row['table_name'] ?? null,
        $activity_context
    );

    return rest_ensure_response(
        tryzub_reservation_activity_attach_to_response([
            'success' => true,
            'server_time' => current_time('mysql'),
            'data' => [
                'reservation' => tryzub_get_managed_reservation_by_id($reservation_id),
                'assignment' => tryzub_build_assignment_block_for_reservation($reservation_id),
            ],
        ], $logged_activity)
    );
}

function tryzub_fetch_restaurant_table_rows($include_inactive = true) {
    global $wpdb;

    $table_name = tryzub_get_restaurant_tables_table_name();
    $restaurant_key = tryzub_get_restaurant_key();
    $sql = "SELECT *
        FROM $table_name
        WHERE restaurant_key = %s";

    if (!$include_inactive) {
        $sql .= ' AND is_active = 1';
    }

    $sql .= ' ORDER BY sort_order ASC, table_key ASC';

    $rows = $wpdb->get_results(
        $wpdb->prepare($sql, $restaurant_key),
        ARRAY_A
    );

    return array_map('tryzub_format_restaurant_table_row', $rows ?: []);
}

function tryzub_format_restaurant_table_row(array $row) {
    return [
        'id' => (int) ($row['id'] ?? 0),
        'restaurant_key' => (string) ($row['restaurant_key'] ?? tryzub_get_restaurant_key()),
        'table_key' => (string) ($row['table_key'] ?? ''),
        'label' => (string) ($row['label'] ?? ''),
        'x' => (int) ($row['x'] ?? 0),
        'y' => (int) ($row['y'] ?? 0),
        'width_units' => (int) ($row['width_units'] ?? 1),
        'height_units' => (int) ($row['height_units'] ?? 1),
        'min_capacity' => (int) ($row['min_capacity'] ?? 1),
        'max_capacity' => (int) ($row['max_capacity'] ?? 4),
        'section' => isset($row['section']) && $row['section'] !== null && $row['section'] !== ''
            ? (string) $row['section']
            : null,
        'sort_order' => (int) ($row['sort_order'] ?? 0),
        'is_active' => (bool) (int) ($row['is_active'] ?? 0),
        'created_at' => (string) ($row['created_at'] ?? ''),
        'updated_at' => (string) ($row['updated_at'] ?? ''),
    ];
}

function tryzub_parse_restaurant_table_definitions(array $tables) {
    $parsed = [];
    $seen_keys = [];

    foreach ($tables as $index => $table) {
        if (!is_array($table)) {
            return new WP_Error(
                'tryzub_invalid_restaurant_table',
                'Each table definition must be an object.',
                ['status' => 400]
            );
        }

        $allowed_fields = [
            'table_key',
            'label',
            'x',
            'y',
            'width_units',
            'height_units',
            'min_capacity',
            'max_capacity',
            'section',
            'sort_order',
            'is_active',
        ];
        $unknown_fields = array_diff(array_keys($table), $allowed_fields);

        if (!empty($unknown_fields)) {
            return new WP_Error(
                'tryzub_unknown_restaurant_table_field',
                'Unknown restaurant table field: ' . implode(', ', array_values($unknown_fields)),
                ['status' => 400]
            );
        }

        $table_key = sanitize_text_field((string) ($table['table_key'] ?? ''));

        if (!tryzub_is_valid_table_key($table_key)) {
            return new WP_Error(
                'tryzub_invalid_table_key',
                'table_key must be 1-32 characters using letters, numbers, underscore, or hyphen.',
                ['status' => 400]
            );
        }

        if (isset($seen_keys[$table_key])) {
            return new WP_Error(
                'tryzub_duplicate_table_key',
                'Duplicate table_key in request: ' . $table_key,
                ['status' => 400]
            );
        }

        $seen_keys[$table_key] = true;

        $label = sanitize_text_field((string) ($table['label'] ?? ''));

        if ($label === '') {
            return new WP_Error(
                'tryzub_invalid_table_label',
                'label is required for table_key ' . $table_key . '.',
                ['status' => 400]
            );
        }

        if (!array_key_exists('x', $table) || !array_key_exists('y', $table)) {
            return new WP_Error(
                'tryzub_invalid_table_position',
                'x and y are required for table_key ' . $table_key . '.',
                ['status' => 400]
            );
        }

        $parsed_row = [
            'table_key' => $table_key,
            'label' => $label,
            'x' => (int) $table['x'],
            'y' => (int) $table['y'],
            'width_units' => array_key_exists('width_units', $table) ? (int) $table['width_units'] : 1,
            'height_units' => array_key_exists('height_units', $table) ? (int) $table['height_units'] : 1,
            'min_capacity' => array_key_exists('min_capacity', $table) ? (int) $table['min_capacity'] : null,
            'max_capacity' => array_key_exists('max_capacity', $table) ? (int) $table['max_capacity'] : null,
            'section' => array_key_exists('section', $table) ? sanitize_text_field((string) $table['section']) : null,
            'sort_order' => array_key_exists('sort_order', $table) ? (int) $table['sort_order'] : 0,
            'is_active' => array_key_exists('is_active', $table)
                ? tryzub_rest_request_bool($table['is_active'])
                : true,
        ];

        $validated = tryzub_validate_restaurant_table_definition($parsed_row);

        if (is_wp_error($validated)) {
            return $validated;
        }

        $parsed[] = $validated;
    }

    $overlap_error = tryzub_validate_restaurant_tables_do_not_overlap($parsed);

    if (is_wp_error($overlap_error)) {
        return $overlap_error;
    }

    return $parsed;
}

function tryzub_is_valid_table_key($table_key) {
    $table_key = (string) $table_key;

    if ($table_key === '' || strlen($table_key) > 32) {
        return false;
    }

    return (bool) preg_match('/^[A-Za-z0-9_-]+$/', $table_key);
}

function tryzub_validate_restaurant_table_definition(array $table) {
    if ($table['x'] < 0 || $table['y'] < 0) {
        return new WP_Error(
            'tryzub_invalid_table_position',
            'x and y must be zero or greater for table_key ' . $table['table_key'] . '.',
            ['status' => 400]
        );
    }

    if ($table['width_units'] < 1 || $table['width_units'] > 3) {
        return new WP_Error(
            'tryzub_invalid_table_width',
            'width_units must be between 1 and 3 for table_key ' . $table['table_key'] . '.',
            ['status' => 400]
        );
    }

    if ($table['height_units'] < 1 || $table['height_units'] > 2) {
        return new WP_Error(
            'tryzub_invalid_table_height',
            'height_units must be between 1 and 2 for table_key ' . $table['table_key'] . '.',
            ['status' => 400]
        );
    }

    $default_capacities = tryzub_default_capacity_for_table_size($table['width_units']);

    if ($table['min_capacity'] === null) {
        $table['min_capacity'] = $default_capacities['min_capacity'];
    }

    if ($table['max_capacity'] === null) {
        $table['max_capacity'] = $default_capacities['max_capacity'];
    }

    if ($table['min_capacity'] < 1) {
        return new WP_Error(
            'tryzub_invalid_table_capacity',
            'min_capacity must be at least 1 for table_key ' . $table['table_key'] . '.',
            ['status' => 400]
        );
    }

    if ($table['max_capacity'] > 20) {
        return new WP_Error(
            'tryzub_invalid_table_capacity',
            'max_capacity must be 20 or less for table_key ' . $table['table_key'] . '.',
            ['status' => 400]
        );
    }

    if ($table['max_capacity'] < $table['min_capacity']) {
        return new WP_Error(
            'tryzub_invalid_table_capacity',
            'max_capacity must be greater than or equal to min_capacity for table_key ' . $table['table_key'] . '.',
            ['status' => 400]
        );
    }

    if ($table['section'] === '') {
        $table['section'] = null;
    }

    return $table;
}

function tryzub_default_capacity_for_table_size($width_units) {
    $width_units = (int) $width_units;

    if ($width_units <= 1) {
        return ['min_capacity' => 1, 'max_capacity' => 4];
    }

    if ($width_units === 2) {
        return ['min_capacity' => 4, 'max_capacity' => 6];
    }

    return ['min_capacity' => 6, 'max_capacity' => 8];
}

function tryzub_restaurant_tables_overlap(array $left, array $right) {
    $left_right = (int) $left['x'] + (int) $left['width_units'];
    $right_right = (int) $right['x'] + (int) $right['width_units'];
    $left_bottom = (int) $left['y'] + (int) $left['height_units'];
    $right_bottom = (int) $right['y'] + (int) $right['height_units'];

    if ($left_right <= (int) $right['x'] || $right_right <= (int) $left['x']) {
        return false;
    }

    if ($left_bottom <= (int) $right['y'] || $right_bottom <= (int) $left['y']) {
        return false;
    }

    return true;
}

function tryzub_validate_restaurant_tables_against_existing_layout(array $tables) {
    global $wpdb;

    $table_name = tryzub_get_restaurant_tables_table_name();
    $restaurant_key = tryzub_get_restaurant_key();
    $existing_rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT table_key, x, y, width_units, height_units
            FROM $table_name
            WHERE restaurant_key = %s",
            $restaurant_key
        ),
        ARRAY_A
    ) ?: [];
    $incoming_keys = array_column($tables, 'table_key');

    foreach ($existing_rows as $existing_row) {
        if (in_array((string) ($existing_row['table_key'] ?? ''), $incoming_keys, true)) {
            continue;
        }

        foreach ($tables as $table) {
            if (tryzub_restaurant_tables_overlap($table, $existing_row)) {
                return new WP_Error(
                    'tryzub_table_layout_overlap',
                    'Table layout overlap detected between '
                        . $table['table_key']
                        . ' and existing table '
                        . $existing_row['table_key']
                        . '.',
                    ['status' => 400]
                );
            }
        }
    }

    return true;
}

function tryzub_validate_restaurant_tables_do_not_overlap(array $tables) {
    $count = count($tables);

    for ($left_index = 0; $left_index < $count; $left_index++) {
        for ($right_index = $left_index + 1; $right_index < $count; $right_index++) {
            if (tryzub_restaurant_tables_overlap($tables[$left_index], $tables[$right_index])) {
                return new WP_Error(
                    'tryzub_table_layout_overlap',
                    'Table layout overlap detected between '
                        . $tables[$left_index]['table_key']
                        . ' and '
                        . $tables[$right_index]['table_key']
                        . '.',
                    ['status' => 400]
                );
            }
        }
    }

    return true;
}

function tryzub_upsert_restaurant_table_definitions(array $tables) {
    global $wpdb;

    $table_name = tryzub_get_restaurant_tables_table_name();
    $restaurant_key = tryzub_get_restaurant_key();
    $now = current_time('mysql');

    foreach ($tables as $table) {
        $existing_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM $table_name WHERE restaurant_key = %s AND table_key = %s LIMIT 1",
                $restaurant_key,
                $table['table_key']
            )
        );

        $data = [
            'restaurant_key' => $restaurant_key,
            'table_key' => $table['table_key'],
            'label' => $table['label'],
            'x' => (int) $table['x'],
            'y' => (int) $table['y'],
            'width_units' => (int) $table['width_units'],
            'height_units' => (int) $table['height_units'],
            'min_capacity' => (int) $table['min_capacity'],
            'max_capacity' => (int) $table['max_capacity'],
            'section' => $table['section'],
            'sort_order' => (int) $table['sort_order'],
            'is_active' => $table['is_active'] ? 1 : 0,
            'updated_at' => $now,
        ];
        $formats = ['%s', '%s', '%s', '%d', '%d', '%d', '%d', '%d', '%d', '%s', '%d', '%d', '%s'];

        if ($existing_id) {
            $updated = $wpdb->update(
                $table_name,
                $data,
                [
                    'id' => (int) $existing_id,
                ],
                $formats,
                ['%d']
            );

            if ($updated === false) {
                return new WP_Error(
                    'tryzub_database_error',
                    'Failed to update restaurant table ' . $table['table_key'] . '.',
                    ['status' => 500]
                );
            }

            continue;
        }

        $data['created_at'] = $now;
        $insert_formats = array_merge($formats, ['%s']);
        $inserted = $wpdb->insert($table_name, $data, $insert_formats);

        if ($inserted === false) {
            return new WP_Error(
                'tryzub_database_error',
                'Failed to create restaurant table ' . $table['table_key'] . '.',
                ['status' => 500]
            );
        }
    }

    return true;
}

function tryzub_fetch_active_restaurant_tables_by_keys(array $table_keys) {
    global $wpdb;

    if (empty($table_keys)) {
        return [];
    }

    $table_name = tryzub_get_restaurant_tables_table_name();
    $restaurant_key = tryzub_get_restaurant_key();
    $placeholders = implode(', ', array_fill(0, count($table_keys), '%s'));
    $values = array_merge([$restaurant_key], $table_keys);

    return $wpdb->get_results(
        $wpdb->prepare(
            "SELECT *
            FROM $table_name
            WHERE restaurant_key = %s
            AND is_active = 1
            AND table_key IN ($placeholders)
            ORDER BY sort_order ASC, table_key ASC",
            $values
        ),
        ARRAY_A
    ) ?: [];
}

function tryzub_normalize_table_keys_list(array $table_keys) {
    $normalized = [];

    foreach ($table_keys as $table_key) {
        $table_key = sanitize_text_field((string) $table_key);

        if (!tryzub_is_valid_table_key($table_key)) {
            return new WP_Error(
                'tryzub_invalid_table_key',
                'Each table_key must be 1-32 characters using letters, numbers, underscore, or hyphen.',
                ['status' => 400]
            );
        }

        if (in_array($table_key, $normalized, true)) {
            return new WP_Error(
                'tryzub_duplicate_table_key',
                'Duplicate table_key in assignment request: ' . $table_key,
                ['status' => 400]
            );
        }

        $normalized[] = $table_key;
    }

    return $normalized;
}

function tryzub_build_table_name_display(array $table_rows) {
    if (empty($table_rows)) {
        return null;
    }

    $labels = array_map(
        function ($table_row) {
            $label = trim((string) ($table_row['label'] ?? ''));

            if ($label !== '') {
                return $label;
            }

            return (string) ($table_row['table_key'] ?? '');
        },
        $table_rows
    );

    $labels = array_values(array_filter($labels, 'strlen'));

    if (count($labels) === 1) {
        return $labels[0];
    }

    return implode(' + ', $labels);
}

function tryzub_find_table_assignment_conflicts($reservation_id, $reservation_date, $reservation_time, array $table_keys) {
    global $wpdb;

    if (empty($table_keys) || $reservation_date === '') {
        return [];
    }

    $assignments_table = tryzub_get_reservation_table_assignments_table_name();
    $reservations_table = tryzub_get_reservations_table_name();
    $tables_table = tryzub_get_restaurant_tables_table_name();
    $restaurant_key = tryzub_get_restaurant_key();
    $same_time_statuses = ['new', 'needs_review', 'confirmed'];
    $same_time_placeholders = implode(', ', array_fill(0, count($same_time_statuses), '%s'));
    $table_placeholders = implode(', ', array_fill(0, count($table_keys), '%s'));
    $values = array_merge(
        [$restaurant_key, $reservation_date, absint($reservation_id)],
        $table_keys,
        [$reservation_time],
        $same_time_statuses
    );

    $sql = "
        SELECT
            a.reservation_id,
            a.table_key,
            r.guest_name,
            r.reservation_time,
            r.status,
            COALESCE(NULLIF(t.label, ''), a.table_key) AS table_label
        FROM $assignments_table a
        INNER JOIN $reservations_table r ON r.id = a.reservation_id
        LEFT JOIN $tables_table t
            ON t.restaurant_key = %s
            AND t.table_key = a.table_key
        WHERE a.reservation_date = %s
        AND a.reservation_id <> %d
        AND a.table_key IN ($table_placeholders)
        AND r.is_hidden = 0
        AND (r.superseded_by_id IS NULL OR r.superseded_by_id = 0)
        AND (
            r.status = 'seated'
            OR (
                r.reservation_time = %s
                AND r.status IN ($same_time_placeholders)
            )
        )
        ORDER BY a.table_key ASC, a.reservation_id ASC
    ";

    $rows = $wpdb->get_results($wpdb->prepare($sql, $values), ARRAY_A) ?: [];
    $conflicts = [];

    foreach ($rows as $row) {
        $status = sanitize_text_field((string) ($row['status'] ?? ''));
        $reason = $status === 'seated' ? 'table_already_seated' : 'same_time_assignment';

        $conflicts[] = [
            'reservation_id' => (int) ($row['reservation_id'] ?? 0),
            'guest_name' => (string) ($row['guest_name'] ?? ''),
            'reservation_time' => (string) ($row['reservation_time'] ?? ''),
            'table_key' => (string) ($row['table_key'] ?? ''),
            'table_label' => (string) ($row['table_label'] ?? ''),
            'status' => $status,
            'reason' => $reason,
        ];
    }

    return $conflicts;
}

// Serializes table assignments for a single service date with a MySQL advisory lock before running the
// transaction. This closes the residual race where two devices assign the same not-yet-used table to two
// different reservations at the same instant (the in-transaction conflict recheck cannot see a row that
// neither transaction has inserted yet).
function tryzub_replace_reservation_table_assignments($reservation_id, array $reservation_row, array $table_keys, array $table_rows) {
    $reservation_date = (string) ($reservation_row['reservation_date'] ?? '');
    $lock_name = tryzub_floor_plan_assignment_lock_name($reservation_date);
    $lock_acquired = tryzub_acquire_named_lock($lock_name, 5);

    if (!$lock_acquired) {
        return new WP_Error(
            'tryzub_floor_plan_locked',
            'The floor plan for this date is being updated on another device. Please retry.',
            ['status' => 409]
        );
    }

    try {
        return tryzub_replace_reservation_table_assignments_do(
            $reservation_id,
            $reservation_row,
            $table_keys,
            $table_rows
        );
    } finally {
        tryzub_release_named_lock($lock_name);
    }
}

function tryzub_floor_plan_assignment_lock_name($reservation_date) {
    // MySQL advisory lock names are global per server and capped at 64 chars; namespace by restaurant + date.
    $key = tryzub_get_restaurant_key() . '_floor_' . preg_replace('/[^0-9A-Za-z_-]/', '', (string) $reservation_date);

    return substr('tryzub_' . md5($key), 0, 64);
}

function tryzub_acquire_named_lock($lock_name, $timeout_seconds = 5) {
    global $wpdb;

    $result = $wpdb->get_var(
        $wpdb->prepare('SELECT GET_LOCK(%s, %d)', $lock_name, max(0, (int) $timeout_seconds))
    );

    return $result === '1' || $result === 1;
}

function tryzub_release_named_lock($lock_name) {
    global $wpdb;

    $wpdb->query($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock_name));
}

function tryzub_replace_reservation_table_assignments_do($reservation_id, array $reservation_row, array $table_keys, array $table_rows) {
    global $wpdb;

    $assignments_table = tryzub_get_reservation_table_assignments_table_name();
    $reservations_table = tryzub_get_reservations_table_name();
    $reservation_id = absint($reservation_id);
    $reservation_date = (string) ($reservation_row['reservation_date'] ?? '');
    $now = current_time('mysql');
    $user_id = get_current_user_id() ?: null;

    $wpdb->query('START TRANSACTION');

    if (!empty($table_keys)) {
        $table_placeholders = implode(', ', array_fill(0, count($table_keys), '%s'));
        $lock_values = array_merge([$reservation_date], $table_keys);
        $locked = $wpdb->query(
            $wpdb->prepare(
                "SELECT a.id
                FROM $assignments_table a
                WHERE a.reservation_date = %s
                AND a.table_key IN ($table_placeholders)
                FOR UPDATE",
                $lock_values
            )
        );

        if ($locked === false) {
            $wpdb->query('ROLLBACK');

            return new WP_Error(
                'tryzub_database_error',
                'Failed to lock table assignments for update.',
                ['status' => 500]
            );
        }
    }

    $conflicts = tryzub_find_table_assignment_conflicts(
        $reservation_id,
        $reservation_date,
        (string) ($reservation_row['reservation_time'] ?? ''),
        $table_keys
    );

    if (!empty($conflicts)) {
        $wpdb->query('ROLLBACK');

        return new WP_Error(
            'tryzub_table_assignment_conflict',
            'Table is already assigned for this time or currently seated.',
            [
                'status' => 409,
                'conflicts' => $conflicts,
            ]
        );
    }

    $deleted = $wpdb->delete(
        $assignments_table,
        ['reservation_id' => $reservation_id],
        ['%d']
    );

    if ($deleted === false) {
        $wpdb->query('ROLLBACK');

        return new WP_Error(
            'tryzub_database_error',
            'Failed to clear existing table assignments.',
            ['status' => 500]
        );
    }

    foreach ($table_keys as $table_key) {
        $inserted = $wpdb->insert(
            $assignments_table,
            [
                'reservation_id' => $reservation_id,
                'reservation_date' => $reservation_date,
                'table_key' => $table_key,
                'assigned_by_user_id' => $user_id,
                'assigned_at' => $now,
                'updated_at' => $now,
            ],
            ['%d', '%s', '%s', '%d', '%s', '%s']
        );

        if ($inserted === false) {
            $wpdb->query('ROLLBACK');

            return new WP_Error(
                'tryzub_database_error',
                'Failed to save table assignment.',
                ['status' => 500]
            );
        }
    }

    $table_name_display = tryzub_build_table_name_display($table_rows);
    $updated = $wpdb->update(
        $reservations_table,
        [
            'table_name' => $table_name_display,
            'updated_at' => $now,
        ],
        ['id' => $reservation_id],
        ['%s', '%s'],
        ['%d']
    );

    if ($updated === false) {
        $wpdb->query('ROLLBACK');

        return new WP_Error(
            'tryzub_database_error',
            'Failed to update reservation table_name compatibility field.',
            ['status' => 500]
        );
    }

    $wpdb->query('COMMIT');
    tryzub_bump_intelligence_cache_version();
    tryzub_guest_profiles_mark_dirty_for_reservation($reservation_id, 'table_assignment_changed');

    return true;
}

function tryzub_fetch_floor_plan_assignments_for_date($date) {
    global $wpdb;

    $assignments_table = tryzub_get_reservation_table_assignments_table_name();
    $tables_table = tryzub_get_restaurant_tables_table_name();
    $restaurant_key = tryzub_get_restaurant_key();
    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT
                a.reservation_id,
                a.reservation_date,
                a.table_key,
                a.assigned_at,
                a.updated_at,
                t.label
            FROM $assignments_table a
            LEFT JOIN $tables_table t
                ON t.restaurant_key = %s
                AND t.table_key = a.table_key
            WHERE a.reservation_date = %s
            ORDER BY a.reservation_id ASC, a.table_key ASC",
            $restaurant_key,
            $date
        ),
        ARRAY_A
    ) ?: [];

    $grouped = [];

    foreach ($rows as $row) {
        $reservation_id = (int) ($row['reservation_id'] ?? 0);

        if (!isset($grouped[$reservation_id])) {
            $grouped[$reservation_id] = [
                'reservation_id' => $reservation_id,
                'reservation_date' => (string) ($row['reservation_date'] ?? $date),
                'table_keys' => [],
                'labels' => [],
                'assigned_at' => (string) ($row['assigned_at'] ?? ''),
                'updated_at' => (string) ($row['updated_at'] ?? ''),
            ];
        }

        $grouped[$reservation_id]['table_keys'][] = (string) ($row['table_key'] ?? '');
        $label = trim((string) ($row['label'] ?? ''));

        if ($label !== '') {
            $grouped[$reservation_id]['labels'][] = $label;
        } else {
            $grouped[$reservation_id]['labels'][] = (string) ($row['table_key'] ?? '');
        }

        $assigned_at = (string) ($row['assigned_at'] ?? '');
        $updated_at = (string) ($row['updated_at'] ?? '');

        if ($grouped[$reservation_id]['assigned_at'] === '' || $assigned_at < $grouped[$reservation_id]['assigned_at']) {
            $grouped[$reservation_id]['assigned_at'] = $assigned_at;
        }

        if ($updated_at > $grouped[$reservation_id]['updated_at']) {
            $grouped[$reservation_id]['updated_at'] = $updated_at;
        }
    }

    $assignments = [];

    foreach ($grouped as $assignment) {
        $table_label = count($assignment['labels']) === 1
            ? $assignment['labels'][0]
            : implode(' + ', $assignment['labels']);

        $assignments[] = [
            'reservation_id' => $assignment['reservation_id'],
            'reservation_date' => $assignment['reservation_date'],
            'table_keys' => $assignment['table_keys'],
            'table_label' => $table_label,
            'assigned_at' => $assignment['assigned_at'],
            'updated_at' => $assignment['updated_at'],
        ];
    }

    return $assignments;
}

function tryzub_build_assignment_block_for_reservation($reservation_id) {
    global $wpdb;

    $assignments_table = tryzub_get_reservation_table_assignments_table_name();
    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT reservation_id, reservation_date, table_key, assigned_at, updated_at
            FROM $assignments_table
            WHERE reservation_id = %d
            ORDER BY table_key ASC",
            absint($reservation_id)
        ),
        ARRAY_A
    ) ?: [];

    if (empty($rows)) {
        $reservation_row = tryzub_get_managed_reservation_row_by_id($reservation_id);

        return [
            'reservation_id' => absint($reservation_id),
            'reservation_date' => (string) ($reservation_row['reservation_date'] ?? ''),
            'table_keys' => [],
            'table_label' => null,
            'assigned_at' => null,
            'updated_at' => null,
        ];
    }

    $table_keys = array_map(
        function ($row) {
            return (string) ($row['table_key'] ?? '');
        },
        $rows
    );
    $table_rows = tryzub_fetch_active_restaurant_tables_by_keys($table_keys);

    if (count($table_rows) !== count($table_keys)) {
        $table_rows = array_map(
            function ($table_key) {
                return [
                    'table_key' => $table_key,
                    'label' => $table_key,
                ];
            },
            $table_keys
        );
    }

    return [
        'reservation_id' => absint($reservation_id),
        'reservation_date' => (string) ($rows[0]['reservation_date'] ?? ''),
        'table_keys' => $table_keys,
        'table_label' => tryzub_build_table_name_display($table_rows),
        'assigned_at' => (string) ($rows[0]['assigned_at'] ?? ''),
        'updated_at' => max(
            array_map(
                function ($row) {
                    return (string) ($row['updated_at'] ?? '');
                },
                $rows
            )
        ),
    ];
}

function tryzub_fetch_floor_plan_reservations_for_date($date) {
    global $wpdb;

    $table_name = tryzub_get_reservations_table_name();
    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT
                id,
                source_submission_id,
                source_type,
                created_by_user_id,
                created_by_device,
                guest_name,
                email,
                phone,
                reservation_date,
                reservation_time,
                party_size,
                guest_notes,
                staff_notes,
                status,
                table_name,
                created_at,
                updated_at,
                confirmed_at,
                seated_at,
                completed_at,
                confirmation_email_sent_at,
                reminder_email_sent_at,
                superseded_by_id,
                is_hidden,
                hidden_at,
                hidden_reason,
                hidden_by_user_id
            FROM $table_name
            WHERE reservation_date = %s
            AND is_hidden = 0
            ORDER BY reservation_time ASC, id ASC",
            $date
        ),
        ARRAY_A
    ) ?: [];

    return array_map('tryzub_format_managed_reservation_row', $rows);
}
