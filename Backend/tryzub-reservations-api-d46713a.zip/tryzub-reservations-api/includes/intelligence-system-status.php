<?php

function tryzub_get_intelligence_system_status(WP_REST_Request $request) {
    $range = tryzub_intelligence_validate_date_range(
        $request->get_param('from'),
        $request->get_param('to'),
        366
    );

    if (is_wp_error($range)) {
        return $range;
    }

    $metrics = tryzub_intelligence_system_status_collect_metrics($range['from'], $range['to']);
    $pipeline_diagnostics = tryzub_collect_reservation_pipeline_diagnostics(
        $range['from'],
        $range['to'],
        ['include_items' => false]
    );
    $pipeline_summary = tryzub_pipeline_finalize_summary($pipeline_diagnostics['summary'] ?? []);
    $developer_pipeline_keys = [
        'flamingo_inbound_total',
        'flamingo_non_spam_total',
        'reservation_intake_total',
        'reservation_intake_non_spam_total',
        'managed_active_with_source',
        'managed_hidden_with_source',
        'managed_terminal_with_source',
        'failed_imports',
        'duplicate_imports',
        'hard_deleted',
        'unexplained_missing',
        'spam_or_rejected',
        'non_reservation_form',
        'form_source_unknown',
        'manual_rows_without_flamingo_source',
        'non_spam_reservation_intake_without_active_managed_row',
        'explained_missing_submissions',
        'unexplained_missing_submissions',
    ];
    $developer_pipeline_summary = [];

    foreach ($developer_pipeline_keys as $key) {
        $developer_pipeline_summary[$key] = (int) ($pipeline_summary[$key] ?? 0);
    }

    $warnings = tryzub_intelligence_system_status_build_warnings($metrics, $pipeline_summary);
    $checks = tryzub_intelligence_system_status_build_checks($metrics, $warnings, $pipeline_summary);
    $status = tryzub_intelligence_system_status_resolve_status($checks, $warnings);

    $payload = [
        'contract_version' => '1.0',
        'scope' => 'intelligence_system_status',
        'generated_at' => tryzub_intelligence_generated_at_iso(),
        'range' => [
            'from' => $range['from'],
            'to' => $range['to'],
        ],
        'status' => tryzub_intelligence_safe_enum($status, ['ok', 'warning', 'needs_attention'], 'ok'),
        'manager_summary' => [
            'reservations_available' => $metrics['managed_rows_in_range'] > 0,
            'new_imports_detected' => $metrics['new_status_rows_in_range'],
            'items_needing_review' => $metrics['needs_review_rows_in_range'],
            'hidden_or_superseded_count' => $metrics['hidden_rows_in_range'] + $metrics['superseded_rows_in_range'],
            'possible_duplicates_count' => $metrics['possible_duplicates_in_range'],
        ],
        'developer_summary' => array_merge([
            'managed_rows_in_range' => $metrics['managed_rows_in_range'],
            'form_source_rows_in_range' => $metrics['form_source_rows_in_range'],
            'manual_source_rows_in_range' => $metrics['manual_source_rows_in_range'],
            'hidden_rows_in_range' => $metrics['hidden_rows_in_range'],
            'superseded_rows_in_range' => $metrics['superseded_rows_in_range'],
            'duplicate_marked_rows_in_range' => $metrics['duplicate_marked_rows_in_range'],
            'import_failure_count' => $metrics['import_failure_count'],
            'spam_or_rejected_submission_count' => $metrics['spam_or_rejected_submission_count'],
            'last_managed_update_at' => $metrics['last_managed_update_at'],
            'last_generated_at' => tryzub_intelligence_generated_at_iso(),
            'email_usage' => function_exists('tryzub_email_usage_summary') ? tryzub_email_usage_summary() : null,
        ], $developer_pipeline_summary),
        'checks' => $checks,
        'warnings' => $warnings,
        'pipeline_diagnostics' => [
            'summary' => $pipeline_summary,
            'warnings' => $pipeline_diagnostics['warnings'] ?? [],
            'endpoint' => '/tryzub/v1/intelligence/reservation-pipeline-diagnostics',
            'manager_message' => tryzub_pipeline_diagnostics_manager_message($pipeline_summary),
            'developer_message' => tryzub_pipeline_diagnostics_developer_message($pipeline_summary),
        ],
    ];

    return tryzub_intelligence_response($payload);
}

function tryzub_intelligence_system_status_collect_metrics($from, $to) {
    global $wpdb;

    $table_name = tryzub_get_reservations_table_name();
    $range_sql = 'reservation_date BETWEEN %s AND %s';
    $range_values = [$from, $to];

    $managed_rows_in_range = (int) $wpdb->get_var(
        $wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE $range_sql", $range_values)
    );

    $form_source_rows_in_range = (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE $range_sql AND source_type = %s",
            array_merge($range_values, ['form'])
        )
    );

    $manual_source_rows_in_range = (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name
            WHERE $range_sql
            AND source_type IN ('manual_call_in', 'manual_walk_in', 'known_guest_manual', 'import_repair')",
            $range_values
        )
    );

    $hidden_rows_in_range = (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE $range_sql AND is_hidden = 1",
            $range_values
        )
    );

    $superseded_rows_in_range = (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE $range_sql AND superseded_by_id IS NOT NULL",
            $range_values
        )
    );

    $duplicate_marked_rows_in_range = (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name
            WHERE $range_sql
            AND (
                duplicate_of_reservation_id IS NOT NULL
                OR TRIM(COALESCE(duplicate_reason, '')) <> ''
            )",
            $range_values
        )
    );

    $new_status_rows_in_range = (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name
            WHERE $range_sql
            AND is_hidden = 0
            AND superseded_by_id IS NULL
            AND status = %s",
            array_merge($range_values, ['new'])
        )
    );

    $needs_review_rows_in_range = (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name
            WHERE $range_sql
            AND is_hidden = 0
            AND superseded_by_id IS NULL
            AND status = %s",
            array_merge($range_values, ['needs_review'])
        )
    );

    $possible_duplicates_in_range = (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name
            WHERE $range_sql
            AND is_hidden = 0
            AND superseded_by_id IS NULL
            AND (
                duplicate_of_reservation_id IS NOT NULL
                OR TRIM(COALESCE(duplicate_reason, '')) <> ''
                OR staff_notes LIKE %s
            )",
            array_merge($range_values, ['%Possible duplicate%'])
        )
    );

    $last_managed_update_at = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT MAX(updated_at) FROM $table_name WHERE $range_sql",
            $range_values
        )
    );

    return [
        'managed_rows_in_range' => $managed_rows_in_range,
        'form_source_rows_in_range' => $form_source_rows_in_range,
        'manual_source_rows_in_range' => $manual_source_rows_in_range,
        'hidden_rows_in_range' => $hidden_rows_in_range,
        'superseded_rows_in_range' => $superseded_rows_in_range,
        'duplicate_marked_rows_in_range' => $duplicate_marked_rows_in_range,
        'new_status_rows_in_range' => $new_status_rows_in_range,
        'needs_review_rows_in_range' => $needs_review_rows_in_range,
        'possible_duplicates_in_range' => $possible_duplicates_in_range,
        'import_failure_count' => tryzub_intelligence_system_status_count_import_failures($from, $to),
        'spam_or_rejected_submission_count' => tryzub_intelligence_system_status_count_spam_submissions($from, $to),
        'last_managed_update_at' => $last_managed_update_at ?: null,
        'table_exists' => tryzub_reservations_table_exists(),
    ];
}

function tryzub_intelligence_system_status_count_import_failures($from, $to) {
    global $wpdb;

    if (!function_exists('tryzub_get_import_failures_table_name')) {
        return 0;
    }

    $table_name = tryzub_get_import_failures_table_name();

    return (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*)
            FROM $table_name
            WHERE DATE(created_at) BETWEEN %s AND %s
            AND status = %s",
            $from,
            $to,
            'open'
        )
    );
}

function tryzub_intelligence_system_status_count_spam_submissions($from, $to) {
    global $wpdb;

    if (!function_exists('tryzub_get_reservation_analytics_submission_status_join_sql')) {
        return null;
    }

    $posts_table = $wpdb->posts;
    $postmeta_table = $wpdb->postmeta;
    $submission_status_sql = tryzub_get_reservation_analytics_submission_status_join_sql($postmeta_table);

    $count = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(DISTINCT p.ID)
            FROM $posts_table p
            $submission_status_sql
            WHERE p.post_type = 'flamingo_inbound'
            AND UPPER(COALESCE(submission_status.meta_value, '')) = 'SPAM'
            AND DATE(p.post_date) BETWEEN %s AND %s",
            $from,
            $to
        )
    );

    if ($count === null) {
        return null;
    }

    return (int) $count;
}

function tryzub_intelligence_system_status_build_warnings(array $metrics, array $pipeline_summary = []) {
    $warnings = [
        'intelligence_metrics_are_deterministic_v1',
        'note_flags_are_heuristic',
    ];

    if ($metrics['spam_or_rejected_submission_count'] === null) {
        $warnings[] = 'spam_count_not_available';
    }

    if ($metrics['needs_review_rows_in_range'] > 0) {
        $warnings[] = 'items_need_staff_review';
    }

    if ($metrics['possible_duplicates_in_range'] > 0) {
        $warnings[] = 'possible_duplicates_detected';
    }

    if ($metrics['hidden_rows_in_range'] > 0 || $metrics['superseded_rows_in_range'] > 0) {
        $warnings[] = 'hidden_or_superseded_rows_excluded_from_intelligence_base';
    }

    if (!empty($pipeline_summary['explained_missing_submissions'])) {
        $warnings[] = 'some_form_submissions_are_not_active_managed_reservations';
    }

    if (!empty($pipeline_summary['unexplained_missing_submissions'])) {
        $warnings[] = 'unexplained_non_spam_submissions_present';
    }

    return array_values(array_unique($warnings));
}

function tryzub_intelligence_system_status_build_checks(array $metrics, array $warnings, array $pipeline_summary = []) {
    $checks = [];

    $checks[] = [
        'key' => 'managed_reservations_table',
        'status' => $metrics['table_exists'] ? 'ok' : 'needs_attention',
        'severity' => $metrics['table_exists'] ? 'info' : 'critical',
        'manager_message' => $metrics['table_exists']
            ? 'Reservation records are available.'
            : 'Reservation records are not available right now.',
        'developer_message' => $metrics['table_exists']
            ? 'Managed reservation table exists.'
            : 'Managed reservation table is missing.',
    ];

    $checks[] = [
        'key' => 'managed_rows_in_range',
        'status' => $metrics['managed_rows_in_range'] > 0 ? 'ok' : 'warning',
        'severity' => $metrics['managed_rows_in_range'] > 0 ? 'info' : 'warning',
        'manager_message' => $metrics['managed_rows_in_range'] > 0
            ? 'Reservations exist for the selected range.'
            : 'No reservations were found for the selected range.',
        'developer_message' => 'Managed rows in range: ' . (int) $metrics['managed_rows_in_range'],
    ];

    $checks[] = [
        'key' => 'review_queue',
        'status' => $metrics['needs_review_rows_in_range'] > 0 ? 'warning' : 'ok',
        'severity' => $metrics['needs_review_rows_in_range'] > 0 ? 'warning' : 'info',
        'manager_message' => $metrics['needs_review_rows_in_range'] > 0
            ? 'Some reservations need staff review.'
            : 'No reservations are waiting for review in this range.',
        'developer_message' => 'Needs review rows in range: ' . (int) $metrics['needs_review_rows_in_range'],
    ];

    $checks[] = [
        'key' => 'import_failures',
        'status' => $metrics['import_failure_count'] > 0 ? 'warning' : 'ok',
        'severity' => $metrics['import_failure_count'] > 0 ? 'warning' : 'info',
        'manager_message' => $metrics['import_failure_count'] > 0
            ? 'Some reservation imports need attention.'
            : 'No open import failures were found for this range.',
        'developer_message' => 'Open import failures in range: ' . (int) $metrics['import_failure_count'],
    ];

    if (in_array('spam_count_not_available', $warnings, true)) {
        $checks[] = [
            'key' => 'spam_tracking',
            'status' => 'warning',
            'severity' => 'warning',
            'manager_message' => 'Spam volume is not tracked as a first-class manager metric yet.',
            'developer_message' => 'Flamingo spam count could not be resolved for this range.',
        ];
    } else {
        $checks[] = [
            'key' => 'spam_submissions',
            'status' => $metrics['spam_or_rejected_submission_count'] > 0 ? 'warning' : 'ok',
            'severity' => $metrics['spam_or_rejected_submission_count'] > 0 ? 'warning' : 'info',
            'manager_message' => $metrics['spam_or_rejected_submission_count'] > 0
                ? 'Spam submissions were detected in the selected intake range.'
                : 'No spam submissions were detected in the selected intake range.',
            'developer_message' => 'Flamingo spam submissions in intake-date range: ' . (int) $metrics['spam_or_rejected_submission_count'],
        ];
    }

    $pipeline_summary = tryzub_pipeline_finalize_summary($pipeline_summary);
    $unexplained_missing = (int) ($pipeline_summary['unexplained_missing_submissions'] ?? 0);
    $non_active_non_spam = (int) ($pipeline_summary['non_spam_reservation_intake_without_active_managed_row'] ?? 0);

    $checks[] = [
        'key' => 'pipeline_reconciliation',
        'status' => $unexplained_missing > 0 ? 'warning' : 'ok',
        'severity' => $unexplained_missing > 0 ? 'warning' : 'info',
        'manager_message' => tryzub_pipeline_diagnostics_manager_message($pipeline_summary),
        'developer_message' => tryzub_pipeline_diagnostics_developer_message($pipeline_summary)
            . ' Reservation-intake submissions without active managed rows in intake range: '
            . $non_active_non_spam
            . '. Manual reservations without Flamingo source in reservation-date range: '
            . (int) ($pipeline_summary['manual_rows_without_flamingo_source'] ?? 0)
            . '.',
    ];

    foreach ($checks as &$check) {
        $check['status'] = tryzub_intelligence_safe_enum(
            $check['status'],
            ['ok', 'warning', 'needs_attention'],
            'warning'
        );
        $check['severity'] = tryzub_intelligence_safe_enum(
            $check['severity'],
            ['info', 'warning', 'critical'],
            'info'
        );
    }
    unset($check);

    return $checks;
}

function tryzub_intelligence_system_status_resolve_status(array $checks, array $warnings) {
    foreach ($checks as $check) {
        if (($check['status'] ?? '') === 'needs_attention' || ($check['severity'] ?? '') === 'critical') {
            return 'needs_attention';
        }
    }

    foreach ($checks as $check) {
        if (($check['status'] ?? '') === 'warning' || ($check['severity'] ?? '') === 'warning') {
            return 'warning';
        }
    }

    if (
        in_array('items_need_staff_review', $warnings, true) ||
        in_array('possible_duplicates_detected', $warnings, true)
    ) {
        return 'warning';
    }

    return 'ok';
}
