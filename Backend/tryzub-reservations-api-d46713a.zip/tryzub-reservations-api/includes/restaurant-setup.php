<?php

function tryzub_get_restaurant_setup(WP_REST_Request $request) {
    return rest_ensure_response([
        'success' => true,
        'data' => tryzub_get_restaurant_settings(),
    ]);
}

function tryzub_update_restaurant_setup(WP_REST_Request $request) {
    global $wpdb;

    $body = tryzub_get_rest_request_body($request);
    $allowed_fields = [
        'business_name',
        'timezone',
        'default_party_size',
        'booking_window_days',
        'slot_interval_minutes',
        'max_online_party_size',
        'large_party_review_threshold',
        'same_day_booking_enabled',
        'minimum_lead_time_minutes',
        'automatic_reminders_enabled',
        'reminder_lead_hours',
        'manual_batch_reminders_enabled',
        'morning_reminder_time',
        'auto_confirm_enabled',
        'auto_confirm_require_email',
        'auto_confirm_block_guest_notes',
        'auto_confirm_block_duplicates',
        'auto_confirm_block_suspicious',
        'auto_confirm_policy',
        'auto_confirm_policy_json',
        'email_daily_limit',
        'email_monthly_limit',
        'call_in_placeholder_email',
        'from_email',
        'reply_to_email',
    ];
    $unknown_fields = array_diff(array_keys($body), $allowed_fields);

    if (!empty($unknown_fields)) {
        return new WP_Error(
            'tryzub_unknown_setup_field',
            'Unknown setup field: ' . implode(', ', array_values($unknown_fields)),
            ['status' => 400]
        );
    }

    $updates = [];
    $formats = [];

    if (array_key_exists('business_name', $body)) {
        $business_name = sanitize_text_field((string) $body['business_name']);

        if ($business_name === '') {
            return new WP_Error(
                'tryzub_invalid_business_name',
                'Business name cannot be empty.',
                ['status' => 400]
            );
        }

        $updates['business_name'] = $business_name;
        $formats[] = '%s';
    }

    if (array_key_exists('timezone', $body)) {
        $timezone = sanitize_text_field((string) $body['timezone']);

        if (!in_array($timezone, timezone_identifiers_list(), true)) {
            return new WP_Error(
                'tryzub_invalid_timezone',
                'Timezone must be a valid timezone identifier.',
                ['status' => 400]
            );
        }

        $updates['timezone'] = $timezone;
        $formats[] = '%s';
    }

    if (array_key_exists('default_party_size', $body)) {
        $default_party_size = tryzub_parse_restaurant_setup_integer($body['default_party_size']);

        if ($default_party_size === null || $default_party_size < 1 || $default_party_size > 100) {
            return new WP_Error(
                'tryzub_invalid_default_party_size',
                'Default party size must be between 1 and 100.',
                ['status' => 400]
            );
        }

        $updates['default_party_size'] = $default_party_size;
        $formats[] = '%d';
    }

    if (array_key_exists('booking_window_days', $body)) {
        $booking_window_days = tryzub_parse_restaurant_setup_integer($body['booking_window_days']);

        if ($booking_window_days === null || $booking_window_days < 1 || $booking_window_days > 365) {
            return new WP_Error(
                'tryzub_invalid_booking_window_days',
                'Booking window days must be between 1 and 365.',
                ['status' => 400]
            );
        }

        $updates['booking_window_days'] = $booking_window_days;
        $formats[] = '%d';
    }

    if (array_key_exists('slot_interval_minutes', $body)) {
        $slot_interval_minutes = tryzub_parse_restaurant_setup_integer($body['slot_interval_minutes']);

        if ($slot_interval_minutes === null || !in_array($slot_interval_minutes, [15, 30, 45, 60], true)) {
            return new WP_Error(
                'tryzub_invalid_slot_interval_minutes',
                'Slot interval minutes must be one of 15, 30, 45, or 60.',
                ['status' => 400]
            );
        }

        $updates['slot_interval_minutes'] = $slot_interval_minutes;
        $formats[] = '%d';
    }

    if (array_key_exists('max_online_party_size', $body)) {
        $max_online_party_size = tryzub_parse_restaurant_setup_integer($body['max_online_party_size']);

        if ($max_online_party_size === null || $max_online_party_size < 1 || $max_online_party_size > 100) {
            return new WP_Error(
                'tryzub_invalid_max_online_party_size',
                'Max online party size must be between 1 and 100.',
                ['status' => 400]
            );
        }

        $updates['max_online_party_size'] = $max_online_party_size;
        $formats[] = '%d';
    }

    if (array_key_exists('large_party_review_threshold', $body)) {
        $large_party_review_threshold = tryzub_parse_restaurant_setup_integer($body['large_party_review_threshold']);

        if ($large_party_review_threshold === null || $large_party_review_threshold < 1 || $large_party_review_threshold > 100) {
            return new WP_Error(
                'tryzub_invalid_large_party_review_threshold',
                'Large party review threshold must be between 1 and 100.',
                ['status' => 400]
            );
        }

        $updates['large_party_review_threshold'] = $large_party_review_threshold;
        $formats[] = '%d';
    }

    if (array_key_exists('same_day_booking_enabled', $body)) {
        $same_day_booking_enabled = tryzub_normalize_boolean_value($body['same_day_booking_enabled']);

        if ($same_day_booking_enabled === null) {
            return new WP_Error(
                'tryzub_invalid_same_day_booking_enabled',
                'Same day booking enabled must be true or false.',
                ['status' => 400]
            );
        }

        $updates['same_day_booking_enabled'] = $same_day_booking_enabled ? 1 : 0;
        $formats[] = '%d';
    }

    if (array_key_exists('minimum_lead_time_minutes', $body)) {
        $minimum_lead_time_minutes = tryzub_parse_restaurant_setup_integer($body['minimum_lead_time_minutes']);

        if ($minimum_lead_time_minutes === null || $minimum_lead_time_minutes < 0 || $minimum_lead_time_minutes > 1440) {
            return new WP_Error(
                'tryzub_invalid_minimum_lead_time_minutes',
                'Minimum lead time minutes must be between 0 and 1440.',
                ['status' => 400]
            );
        }

        $updates['minimum_lead_time_minutes'] = $minimum_lead_time_minutes;
        $formats[] = '%d';
    }

    if (array_key_exists('automatic_reminders_enabled', $body)) {
        $automatic_reminders_enabled = tryzub_normalize_boolean_value($body['automatic_reminders_enabled']);

        if ($automatic_reminders_enabled === null) {
            return new WP_Error(
                'tryzub_invalid_automatic_reminders_enabled',
                'Automatic reminders enabled must be true or false.',
                ['status' => 400]
            );
        }

        $updates['automatic_reminders_enabled'] = $automatic_reminders_enabled ? 1 : 0;
        $formats[] = '%d';
    }

    if (array_key_exists('manual_batch_reminders_enabled', $body)) {
        $manual_batch_reminders_enabled = tryzub_normalize_boolean_value($body['manual_batch_reminders_enabled']);

        if ($manual_batch_reminders_enabled === null) {
            return new WP_Error(
                'tryzub_invalid_manual_batch_reminders_enabled',
                'Manual batch reminders enabled must be true or false.',
                ['status' => 400]
            );
        }

        $updates['manual_batch_reminders_enabled'] = $manual_batch_reminders_enabled ? 1 : 0;
        $formats[] = '%d';
    }

    if (array_key_exists('reminder_lead_hours', $body)) {
        $reminder_lead_hours = tryzub_parse_restaurant_setup_integer($body['reminder_lead_hours']);

        if ($reminder_lead_hours === null || $reminder_lead_hours < 1 || $reminder_lead_hours > 24) {
            return new WP_Error(
                'tryzub_invalid_reminder_lead_hours',
                'Reminder lead hours must be between 1 and 24.',
                ['status' => 400]
            );
        }

        $updates['reminder_lead_hours'] = $reminder_lead_hours;
        $formats[] = '%d';
    }

    if (array_key_exists('morning_reminder_time', $body)) {
        $morning_reminder_time = tryzub_normalize_restaurant_setup_time($body['morning_reminder_time']);

        if ($morning_reminder_time === null) {
            return new WP_Error(
                'tryzub_invalid_morning_reminder_time',
                'Morning reminder time must be a valid HH:MM or HH:MM:SS value.',
                ['status' => 400]
            );
        }

        $updates['morning_reminder_time'] = $morning_reminder_time;
        $formats[] = '%s';
    }

    foreach (['auto_confirm_enabled', 'auto_confirm_require_email', 'auto_confirm_block_guest_notes', 'auto_confirm_block_duplicates', 'auto_confirm_block_suspicious'] as $boolean_field) {
        if (!array_key_exists($boolean_field, $body)) {
            continue;
        }

        $boolean_value = tryzub_normalize_boolean_value($body[$boolean_field]);

        if ($boolean_value === null) {
            return new WP_Error(
                'tryzub_invalid_' . $boolean_field,
                $boolean_field . ' must be true or false.',
                ['status' => 400]
            );
        }

        $updates[$boolean_field] = $boolean_value ? 1 : 0;
        $formats[] = '%d';
    }

    if (array_key_exists('auto_confirm_policy', $body) || array_key_exists('auto_confirm_policy_json', $body)) {
        $policy_value = array_key_exists('auto_confirm_policy', $body)
            ? $body['auto_confirm_policy']
            : $body['auto_confirm_policy_json'];
        $policy = tryzub_auto_confirm_validate_policy($policy_value);

        if (is_wp_error($policy)) {
            return $policy;
        }

        $updates['auto_confirm_policy_json'] = wp_json_encode($policy);
        $formats[] = '%s';
    }

    foreach (['email_daily_limit' => 10000, 'email_monthly_limit' => 100000] as $limit_field => $max_value) {
        if (!array_key_exists($limit_field, $body)) {
            continue;
        }

        $limit_value = tryzub_parse_restaurant_setup_integer($body[$limit_field]);

        if ($limit_value === null || $limit_value < 1 || $limit_value > $max_value) {
            return new WP_Error(
                'tryzub_invalid_' . $limit_field,
                $limit_field . ' must be a positive integer.',
                ['status' => 400]
            );
        }

        $updates[$limit_field] = $limit_value;
        $formats[] = '%d';
    }

    foreach (['call_in_placeholder_email', 'from_email', 'reply_to_email'] as $email_field) {
        if (!array_key_exists($email_field, $body)) {
            continue;
        }

        $email = sanitize_email((string) $body[$email_field]);

        if (!is_email($email)) {
            return new WP_Error(
                'tryzub_invalid_email',
                $email_field . ' must be a valid email address.',
                ['status' => 400]
            );
        }

        $updates[$email_field] = $email;
        $formats[] = '%s';
    }

    if (empty($updates)) {
        return new WP_Error(
            'tryzub_no_setup_fields',
            'No valid setup fields were provided.',
            ['status' => 400]
        );
    }

    $settings = tryzub_get_restaurant_settings();
    $updates['updated_at'] = current_time('mysql');
    $formats[] = '%s';

    $updated = $wpdb->update(
        tryzub_get_restaurant_settings_table_name(),
        $updates,
        ['restaurant_key' => $settings['restaurant_key']],
        $formats,
        ['%s']
    );

    if ($updated === false) {
        error_log('Tryzub restaurant setup update failed: ' . $wpdb->last_error);

        return new WP_Error(
            'tryzub_database_error',
            'Failed to update restaurant setup.',
            ['status' => 500]
        );
    }

    return rest_ensure_response([
        'success' => true,
        'data' => tryzub_get_restaurant_settings(),
    ]);
}

function tryzub_get_restaurant_settings() {
    global $wpdb;

    $table_name = tryzub_get_restaurant_settings_table_name();
    $row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM $table_name WHERE restaurant_key = %s LIMIT 1",
            'tryzub'
        ),
        ARRAY_A
    );

    if (!$row) {
        tryzub_seed_default_restaurant_settings();
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM $table_name WHERE restaurant_key = %s LIMIT 1",
                'tryzub'
            ),
            ARRAY_A
        );
    }

    if (!$row) {
        $defaults = tryzub_get_default_restaurant_settings_values();
        $defaults['created_at'] = null;
        $defaults['updated_at'] = null;

        return tryzub_format_restaurant_settings_row($defaults);
    }

    return tryzub_format_restaurant_settings_row($row);
}

function tryzub_format_restaurant_settings_row(array $row) {
    return [
        'restaurant_key' => $row['restaurant_key'],
        'business_name' => $row['business_name'],
        'timezone' => $row['timezone'],
        'default_party_size' => (int) $row['default_party_size'],
        'booking_window_days' => (int) $row['booking_window_days'],
        'slot_interval_minutes' => (int) $row['slot_interval_minutes'],
        'max_online_party_size' => (int) $row['max_online_party_size'],
        'large_party_review_threshold' => (int) $row['large_party_review_threshold'],
        'same_day_booking_enabled' => (bool) (int) $row['same_day_booking_enabled'],
        'minimum_lead_time_minutes' => (int) $row['minimum_lead_time_minutes'],
        'automatic_reminders_enabled' => (bool) (int) ($row['automatic_reminders_enabled'] ?? 1),
        'reminder_lead_hours' => max(1, min(24, (int) ($row['reminder_lead_hours'] ?? 3))),
        'manual_batch_reminders_enabled' => (bool) (int) ($row['manual_batch_reminders_enabled'] ?? 0),
        'morning_reminder_time' => tryzub_normalize_restaurant_setup_time($row['morning_reminder_time'] ?? '09:00:00') ?: '09:00:00',
        'auto_confirm_enabled' => (bool) (int) ($row['auto_confirm_enabled'] ?? 0),
        'auto_confirm_require_email' => (bool) (int) ($row['auto_confirm_require_email'] ?? 1),
        'auto_confirm_block_guest_notes' => (bool) (int) ($row['auto_confirm_block_guest_notes'] ?? 1),
        'auto_confirm_block_duplicates' => (bool) (int) ($row['auto_confirm_block_duplicates'] ?? 1),
        'auto_confirm_block_suspicious' => (bool) (int) ($row['auto_confirm_block_suspicious'] ?? 1),
        'auto_confirm_policy' => tryzub_auto_confirm_policy_from_row($row),
        'email_daily_limit' => max(1, (int) ($row['email_daily_limit'] ?? 100)),
        'email_monthly_limit' => max(1, (int) ($row['email_monthly_limit'] ?? 3000)),
        'call_in_placeholder_email' => $row['call_in_placeholder_email'],
        'from_email' => $row['from_email'],
        'reply_to_email' => $row['reply_to_email'],
        'created_at' => $row['created_at'],
        'updated_at' => $row['updated_at'],
    ];
}

function tryzub_parse_restaurant_setup_integer($value) {
    if (is_int($value)) {
        return $value;
    }

    if (is_float($value) && floor($value) === $value) {
        return (int) $value;
    }

    if (is_string($value) && preg_match('/^-?\d+$/', trim($value))) {
        return (int) trim($value);
    }

    return null;
}

function tryzub_normalize_restaurant_setup_time($value) {
    $value = trim(sanitize_text_field((string) $value));

    if (!preg_match('/^([01]?\d|2[0-3]):([0-5]\d)(?::([0-5]\d))?$/', $value, $matches)) {
        return null;
    }

    $seconds = isset($matches[3]) && $matches[3] !== '' ? (int) $matches[3] : 0;

    return sprintf('%02d:%02d:%02d', (int) $matches[1], (int) $matches[2], $seconds);
}

function tryzub_get_call_in_placeholder_email() {
    $settings = tryzub_get_restaurant_settings();
    return sanitize_email((string) ($settings['call_in_placeholder_email'] ?? 'callinreservation@tryzubchicago.com'));
}

function tryzub_is_call_in_placeholder_email($email) {
    $email = sanitize_email((string) $email);
    return $email !== '' && strcasecmp($email, tryzub_get_call_in_placeholder_email()) === 0;
}
