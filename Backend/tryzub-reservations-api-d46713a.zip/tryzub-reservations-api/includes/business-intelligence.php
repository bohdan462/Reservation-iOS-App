<?php

function tryzub_get_business_intelligence_summary(WP_REST_Request $request) {
    $range = tryzub_intelligence_validate_date_range(
        $request->get_param('from'),
        $request->get_param('to'),
        366
    );

    if (is_wp_error($range)) {
        return $range;
    }

    $force_param = $request->get_param('force') ?: $request->get_param('cache_bust');
    $force = current_user_can('manage_options')
        && in_array($force_param, ['1', 'true', 1, true], true);
    $generated_date = current_time('Y-m-d');
    $range_key = tryzub_bi_resolve_range_key($range['from'], $range['to']);
    $cache_version = tryzub_bi_cache_version();
    $cache_key = tryzub_bi_cache_build_key($range_key, $range['from'], $range['to'], $generated_date, $cache_version);

    if (!$force) {
        $cached = tryzub_bi_cache_get($cache_key);

        if ($cached) {
            return tryzub_intelligence_response(
                tryzub_business_intelligence_payload_with_cache($cached['payload'], array_merge($cached['meta'], [
                    'hit' => true,
                    'generated_at' => $cached['payload']['generated_at'] ?? ($cached['meta']['generated_at'] ?? ''),
                ]))
            );
        }
    }

    $lock_key = 'tryzub_bi_compute_' . md5($cache_key);
    $locked = (bool) get_transient($lock_key);
    $owns_lock = false;

    if ($locked && !$force) {
        $stale = tryzub_bi_cache_get_latest_for_range($range_key, $range['from'], $range['to'], $cache_version);

        if ($stale) {
            return tryzub_intelligence_response(
                tryzub_business_intelligence_payload_with_cache($stale['payload'], array_merge($stale['meta'], [
                    'hit' => true,
                    'generated_at' => $stale['payload']['generated_at'] ?? ($stale['meta']['generated_at'] ?? ''),
                    'stale' => true,
                    'stale_reason' => 'compute_in_progress',
                    'recompute_in_progress' => true,
                ]))
            );
        }
    } else {
        set_transient($lock_key, 1, 5 * MINUTE_IN_SECONDS);
        $owns_lock = true;
    }

    $start = microtime(true);

    try {
        $payload = tryzub_business_intelligence_compute_payload($range);
        $duration_ms = (int) round((microtime(true) - $start) * 1000);
        $saved = tryzub_bi_cache_put(
            $cache_key,
            [
                'range_key' => $range_key,
                'range_from' => $range['from'],
                'range_to' => $range['to'],
                'generated_date' => $generated_date,
                'cache_version' => $cache_version,
            ],
            $payload,
            $duration_ms
        );
        $cache_meta = [
            'hit' => false,
            'forced' => $force,
            'range_key' => $range_key,
            'generated_at' => $payload['generated_at'] ?? tryzub_intelligence_generated_at_iso(),
            'generated_date' => $generated_date,
            'compute_duration_ms' => $duration_ms,
            'cache_version' => $cache_version,
        ];

        if (!$saved) {
            $cache_meta['write_failed'] = true;
        }

        return tryzub_intelligence_response(
            tryzub_business_intelligence_payload_with_cache($payload, $cache_meta)
        );
    } catch (Throwable $exception) {
        $stale = tryzub_bi_cache_get_latest_for_range($range_key, $range['from'], $range['to'], $cache_version);

        if ($stale) {
            return tryzub_intelligence_response(
                tryzub_business_intelligence_payload_with_cache($stale['payload'], array_merge($stale['meta'], [
                    'hit' => true,
                    'generated_at' => $stale['payload']['generated_at'] ?? ($stale['meta']['generated_at'] ?? ''),
                    'stale' => true,
                    'stale_reason' => 'compute_failed',
                ]))
            );
        }

        error_log('Tryzub BI summary compute failed: ' . $exception->getMessage());

        return new WP_Error(
            'tryzub_business_intelligence_compute_failed',
            'Business intelligence summary could not be generated.',
            ['status' => 500]
        );
    } finally {
        if ($owns_lock) {
            delete_transient($lock_key);
        }
    }
}

function tryzub_business_intelligence_compute_payload(array $range) {
    $threshold = tryzub_business_intelligence_get_large_party_threshold();
    $rows = tryzub_business_intelligence_fetch_base_rows($range['from'], $range['to']);
    $payload = tryzub_business_intelligence_empty_payload($range);

    if (!empty($rows)) {
        $payload['summary'] = tryzub_business_intelligence_build_summary($rows, $threshold);
        $payload['demand'] = tryzub_business_intelligence_build_demand($rows, $range);
        $payload['risk'] = tryzub_business_intelligence_build_risk($rows, $range, $threshold);
        $payload['breakdowns'] = tryzub_business_intelligence_build_breakdowns($rows, $threshold);
        $payload['peak_windows'] = tryzub_business_intelligence_build_peak_windows($rows);
        $payload['pipeline'] = tryzub_business_intelligence_build_pipeline($rows);
        $payload['guest_relationships'] = tryzub_business_intelligence_build_guest_relationships(
            $rows,
            $range['to']
        );
    }

    $payload['data_quality']['warnings'] = tryzub_business_intelligence_build_warnings($rows);

    return $payload;
}

function tryzub_business_intelligence_payload_with_cache(array $payload, array $cache_meta) {
    $payload['cache'] = [
        'hit' => (bool) ($cache_meta['hit'] ?? false),
        'range_key' => sanitize_key((string) ($cache_meta['range_key'] ?? 'custom')),
        'generated_at' => sanitize_text_field((string) ($cache_meta['generated_at'] ?? ($payload['generated_at'] ?? ''))),
        'generated_date' => sanitize_text_field((string) ($cache_meta['generated_date'] ?? current_time('Y-m-d'))),
        'compute_duration_ms' => isset($cache_meta['compute_duration_ms']) ? (int) $cache_meta['compute_duration_ms'] : null,
        'cache_version' => isset($cache_meta['cache_version']) ? (int) $cache_meta['cache_version'] : tryzub_bi_cache_version(),
    ];

    foreach (['forced', 'stale', 'recompute_in_progress', 'write_failed'] as $flag_key) {
        if (array_key_exists($flag_key, $cache_meta)) {
            $payload['cache'][$flag_key] = (bool) $cache_meta[$flag_key];
        }
    }

    if (!empty($cache_meta['stale_reason'])) {
        $payload['cache']['stale_reason'] = sanitize_key((string) $cache_meta['stale_reason']);
    }

    return $payload;
}

function tryzub_business_intelligence_contract_metadata() {
    return [
        'contract_version' => '1.0',
        'scope' => 'business_range',
        'source' => 'managed_reservations',
        'data_quality' => [
            'includes_all_source_types' => true,
            'excludes_hidden' => true,
            'excludes_superseded' => true,
            'relationship_metrics_mode' => 'approximate_v1',
            'identity_matching' => 'email_phone_hmac_v1',
            'notes_mode' => 'multilingual_boolean_flags_v1',
            'warnings' => [],
        ],
    ];
}

function tryzub_business_intelligence_build_warnings(array $rows) {
    $warnings = [
        'relationship_metrics_are_approximate',
        'note_flags_are_heuristic',
        'history_matching_limited_to_email_phone',
        'name_only_identity_not_used_for_history',
    ];

    if (empty($rows)) {
        return $warnings;
    }

    $identity_keys = 0;

    foreach ($rows as $row) {
        $identity = tryzub_intelligence_identity_from_row($row);

        if (!empty($identity['guest_key'])) {
            $identity_keys++;
        }
    }

    if ($identity_keys === 0) {
        $warnings[] = 'no_identity_keys_available';
    }

    return array_values(array_unique($warnings));
}

function tryzub_business_intelligence_empty_payload(array $range) {
    $metadata = tryzub_business_intelligence_contract_metadata();

    return array_merge($metadata, [
        'range' => [
            'from' => $range['from'],
            'to' => $range['to'],
        ],
        'generated_at' => tryzub_intelligence_generated_at_iso(),
        'summary' => [
            'total_reservations' => 0,
            'active_reservations' => 0,
            'completed_reservations' => 0,
            'cancelled_reservations' => 0,
            'no_show_reservations' => 0,
            'total_guests' => 0,
            'active_guests' => 0,
            'average_party_size' => 0.0,
            'largest_party_size' => 0,
            'large_party_count' => 0,
        ],
        'demand' => [
            'busiest_date' => null,
            'busiest_weekday' => null,
            'busiest_weekday_label' => null,
            'busiest_hour' => null,
            'peak_15_min_window' => null,
            'average_lead_time_days' => null,
            'same_day_booking_count' => 0,
            'same_day_booking_rate' => 0.0,
            'future_booked_guests' => null,
        ],
        'guest_relationships' => [
            'estimated_unique_guests' => 0,
            'first_time_guest_count' => 0,
            'returning_guest_count' => 0,
            'regular_guest_count' => 0,
            'frequent_regular_count' => 0,
            'repeat_guest_rate' => 0.0,
            'guests_with_preferences' => 0,
            'guests_with_allergy_or_accessibility_notes' => 0,
            'guests_with_prior_notes' => 0,
        ],
        'risk' => [
            'cancel_rate' => 0.0,
            'no_show_rate' => 0.0,
            'needs_review_count' => 0,
            'unconfirmed_count' => 0,
            'no_table_count' => 0,
            'large_party_without_table_count' => 0,
            'possible_duplicate_count' => 0,
            'correction_or_superseded_count' => 0,
        ],
        'breakdowns' => [
            'by_status' => [],
            'by_weekday' => [],
            'by_hour' => [],
            'by_15_min_window' => [],
            'by_party_size_bucket' => [],
            'by_source' => [],
            'by_lead_time_bucket' => [],
        ],
        'peak_windows' => [],
        'pipeline' => [
            'new_count' => 0,
            'needs_review_count' => 0,
            'confirmed_count' => 0,
            'seated_count' => 0,
            'completed_count' => 0,
            'cancelled_count' => 0,
            'no_show_count' => 0,
        ],
    ]);
}

function tryzub_business_intelligence_get_large_party_threshold() {
    if (!function_exists('tryzub_get_restaurant_settings')) {
        return 7;
    }

    $settings = tryzub_get_restaurant_settings();

    return max(1, (int) ($settings['large_party_review_threshold'] ?? 7));
}

function tryzub_business_intelligence_fetch_base_rows($from, $to) {
    global $wpdb;

    $table_name = tryzub_get_reservations_table_name();

    return $wpdb->get_results(
        $wpdb->prepare(
            "SELECT
                id,
                email,
                phone,
                guest_name,
                reservation_date,
                reservation_time,
                party_size,
                status,
                table_name,
                source_type,
                created_at,
                guest_notes,
                staff_notes,
                duplicate_of_reservation_id,
                duplicate_reason
            FROM $table_name
            WHERE reservation_date BETWEEN %s AND %s
            AND is_hidden = 0
            AND superseded_by_id IS NULL
            ORDER BY reservation_date ASC, reservation_time ASC, id ASC",
            $from,
            $to
        ),
        ARRAY_A
    );
}

function tryzub_business_intelligence_build_summary(array $rows, $threshold) {
    $active_statuses = tryzub_intelligence_active_statuses();
    $total_reservations = count($rows);
    $total_guests = 0;
    $active_guests = 0;
    $active_reservations = 0;
    $completed_reservations = 0;
    $cancelled_reservations = 0;
    $no_show_reservations = 0;
    $largest_party_size = 0;
    $large_party_count = 0;

    foreach ($rows as $row) {
        $party_size = (int) ($row['party_size'] ?? 0);
        $status = sanitize_text_field((string) ($row['status'] ?? ''));

        $total_guests += $party_size;
        $largest_party_size = max($largest_party_size, $party_size);

        if ($party_size >= $threshold) {
            $large_party_count++;
        }

        if (in_array($status, $active_statuses, true)) {
            $active_reservations++;
            $active_guests += $party_size;
        } elseif ($status === 'completed') {
            $completed_reservations++;
        } elseif ($status === 'cancelled') {
            $cancelled_reservations++;
        } elseif ($status === 'no_show') {
            $no_show_reservations++;
        }
    }

    return [
        'total_reservations' => $total_reservations,
        'active_reservations' => $active_reservations,
        'completed_reservations' => $completed_reservations,
        'cancelled_reservations' => $cancelled_reservations,
        'no_show_reservations' => $no_show_reservations,
        'total_guests' => $total_guests,
        'active_guests' => $active_guests,
        'average_party_size' => $total_reservations > 0
            ? round($total_guests / $total_reservations, 2)
            : 0.0,
        'largest_party_size' => $largest_party_size,
        'large_party_count' => $large_party_count,
    ];
}

function tryzub_business_intelligence_build_demand(array $rows, array $range) {
    $by_date = [];
    $by_weekday = [];
    $by_hour = [];
    $by_15_min = [];
    $lead_time_total = 0;
    $lead_time_count = 0;
    $same_day_booking_count = 0;
    $total_reservations = count($rows);
    $today = current_time('Y-m-d');
    $active_statuses = tryzub_intelligence_active_statuses();
    $future_booked_guests = null;

    foreach ($rows as $row) {
        $party_size = (int) ($row['party_size'] ?? 0);
        $date = (string) ($row['reservation_date'] ?? '');
        $weekday = tryzub_business_intelligence_mysql_weekday($date);
        $hour = tryzub_business_intelligence_hour_label($row['reservation_time'] ?? '');
        $bucket_15 = tryzub_intelligence_time_15min_bucket($row['reservation_time'] ?? '');
        $lead_time_days = tryzub_business_intelligence_lead_time_days($row);

        tryzub_business_intelligence_increment_bucket($by_date, $date, $party_size);
        tryzub_business_intelligence_increment_bucket($by_weekday, (string) $weekday, $party_size);

        if ($hour !== null) {
            tryzub_business_intelligence_increment_bucket($by_hour, $hour, $party_size);
        }

        if ($bucket_15 !== null) {
            tryzub_business_intelligence_increment_bucket($by_15_min, $bucket_15, $party_size);
        }

        if ($lead_time_days !== null && $lead_time_days >= 0) {
            $lead_time_total += $lead_time_days;
            $lead_time_count++;

            if ($lead_time_days === 0) {
                $same_day_booking_count++;
            }
        }
    }

    if ($range['to'] >= $today) {
        $future_booked_guests = 0;

        foreach ($rows as $row) {
            $status = sanitize_text_field((string) ($row['status'] ?? ''));

            if (
                (string) ($row['reservation_date'] ?? '') > $today &&
                in_array($status, $active_statuses, true)
            ) {
                $future_booked_guests += (int) ($row['party_size'] ?? 0);
            }
        }
    }

    $busiest_date = tryzub_business_intelligence_pick_busiest_key($by_date, true);
    $busiest_weekday = tryzub_business_intelligence_pick_busiest_key($by_weekday, false);
    $busiest_hour = tryzub_business_intelligence_pick_busiest_key($by_hour, false);
    $peak_15_min_window = tryzub_business_intelligence_pick_busiest_key($by_15_min, false);

    return [
        'busiest_date' => $busiest_date,
        'busiest_weekday' => $busiest_weekday !== null ? (int) $busiest_weekday : null,
        'busiest_weekday_label' => $busiest_weekday !== null
            ? tryzub_intelligence_weekday_label((int) $busiest_weekday)
            : null,
        'busiest_hour' => $busiest_hour,
        'peak_15_min_window' => $peak_15_min_window,
        'average_lead_time_days' => $lead_time_count > 0
            ? round($lead_time_total / $lead_time_count, 2)
            : null,
        'same_day_booking_count' => $same_day_booking_count,
        'same_day_booking_rate' => $total_reservations > 0
            ? round($same_day_booking_count / $total_reservations, 4)
            : 0.0,
        'future_booked_guests' => $future_booked_guests,
    ];
}

function tryzub_business_intelligence_build_risk(array $rows, array $range, $threshold) {
    $active_statuses = tryzub_intelligence_active_statuses();
    $total_reservations = count($rows);
    $completed = 0;
    $cancelled = 0;
    $no_show = 0;
    $needs_review_count = 0;
    $unconfirmed_count = 0;
    $no_table_count = 0;
    $large_party_without_table_count = 0;
    $possible_duplicate_count = 0;

    foreach ($rows as $row) {
        $status = sanitize_text_field((string) ($row['status'] ?? ''));
        $party_size = (int) ($row['party_size'] ?? 0);
        $table_name = trim((string) ($row['table_name'] ?? ''));
        $is_active = in_array($status, $active_statuses, true);

        if ($status === 'completed') {
            $completed++;
        } elseif ($status === 'cancelled') {
            $cancelled++;
        } elseif ($status === 'no_show') {
            $no_show++;
        }

        if ($status === 'needs_review') {
            $needs_review_count++;
        }

        if (in_array($status, ['new', 'needs_review'], true)) {
            $unconfirmed_count++;
        }

        if ($is_active && $table_name === '') {
            $no_table_count++;
        }

        if ($is_active && $party_size >= $threshold && $table_name === '') {
            $large_party_without_table_count++;
        }

        if (tryzub_business_intelligence_row_is_possible_duplicate($row)) {
            $possible_duplicate_count++;
        }
    }

    $denominator = $completed + $cancelled + $no_show;

    if ($denominator <= 0) {
        $denominator = $total_reservations;
    }

    return [
        'cancel_rate' => $denominator > 0 ? round($cancelled / $denominator, 4) : 0.0,
        'no_show_rate' => $denominator > 0 ? round($no_show / $denominator, 4) : 0.0,
        'needs_review_count' => $needs_review_count,
        'unconfirmed_count' => $unconfirmed_count,
        'no_table_count' => $no_table_count,
        'large_party_without_table_count' => $large_party_without_table_count,
        'possible_duplicate_count' => $possible_duplicate_count,
        'correction_or_superseded_count' => tryzub_business_intelligence_count_correction_or_superseded(
            $range['from'],
            $range['to']
        ),
    ];
}

function tryzub_business_intelligence_count_correction_or_superseded($from, $to) {
    global $wpdb;

    $table_name = tryzub_get_reservations_table_name();

    return (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*)
            FROM $table_name
            WHERE reservation_date BETWEEN %s AND %s
            AND (
                superseded_by_id IS NOT NULL
                OR is_hidden = 1
            )",
            $from,
            $to
        )
    );
}

function tryzub_business_intelligence_build_breakdowns(array $rows, $threshold) {
    $by_status = [];
    $by_weekday = [];
    $by_hour = [];
    $by_15_min_window = [];
    $by_party_size_bucket = [];
    $by_source = [];
    $by_lead_time_bucket = [];

    foreach ($rows as $row) {
        $party_size = (int) ($row['party_size'] ?? 0);
        $status = sanitize_text_field((string) ($row['status'] ?? ''));
        $weekday = tryzub_business_intelligence_mysql_weekday((string) ($row['reservation_date'] ?? ''));
        $hour = tryzub_business_intelligence_hour_label($row['reservation_time'] ?? '');
        $bucket_15 = tryzub_intelligence_time_15min_bucket($row['reservation_time'] ?? '');
        $party_bucket = tryzub_intelligence_party_size_bucket($party_size, $threshold);
        $source_bucket = tryzub_intelligence_source_bucket($row['source_type'] ?? '');
        $lead_days = tryzub_business_intelligence_lead_time_days($row);
        $lead_bucket = tryzub_intelligence_lead_time_bucket($lead_days);

        tryzub_business_intelligence_increment_bucket($by_status, $status, $party_size);
        tryzub_business_intelligence_increment_bucket($by_weekday, (string) $weekday, $party_size);

        if ($hour !== null) {
            tryzub_business_intelligence_increment_bucket($by_hour, $hour, $party_size);
        }

        if ($bucket_15 !== null) {
            tryzub_business_intelligence_increment_bucket($by_15_min_window, $bucket_15, $party_size);
        }

        tryzub_business_intelligence_increment_bucket($by_party_size_bucket, $party_bucket, $party_size);
        tryzub_business_intelligence_increment_bucket($by_source, $source_bucket, $party_size);
        tryzub_business_intelligence_increment_bucket($by_lead_time_bucket, $lead_bucket, $party_size);
    }

    return [
        'by_status' => tryzub_business_intelligence_format_status_breakdown($by_status),
        'by_weekday' => tryzub_business_intelligence_format_weekday_breakdown($by_weekday),
        'by_hour' => tryzub_business_intelligence_format_simple_breakdown($by_hour, 'hour'),
        'by_15_min_window' => tryzub_business_intelligence_format_simple_breakdown($by_15_min_window, 'time'),
        'by_party_size_bucket' => tryzub_business_intelligence_format_simple_breakdown($by_party_size_bucket, 'bucket'),
        'by_source' => tryzub_business_intelligence_format_simple_breakdown($by_source, 'source'),
        'by_lead_time_bucket' => tryzub_business_intelligence_format_simple_breakdown($by_lead_time_bucket, 'bucket'),
    ];
}

function tryzub_business_intelligence_build_peak_windows(array $rows) {
    $groups = [];

    foreach ($rows as $row) {
        $weekday = tryzub_business_intelligence_mysql_weekday((string) ($row['reservation_date'] ?? ''));
        $bucket_15 = tryzub_intelligence_time_15min_bucket($row['reservation_time'] ?? '');

        if ($bucket_15 === null) {
            continue;
        }

        $key = $weekday . '|' . $bucket_15;

        if (!isset($groups[$key])) {
            $groups[$key] = [
                'weekday' => $weekday,
                'time' => $bucket_15,
                'reservation_count' => 0,
                'total_guests' => 0,
                'dates' => [],
            ];
        }

        $groups[$key]['reservation_count']++;
        $groups[$key]['total_guests'] += (int) ($row['party_size'] ?? 0);
        $groups[$key]['dates'][(string) ($row['reservation_date'] ?? '')] = true;
    }

    $windows = [];

    foreach ($groups as $group) {
        $sample_count = count($group['dates']);
        $average_guests = $sample_count > 0
            ? round($group['total_guests'] / $sample_count, 2)
            : 0.0;

        $windows[] = [
            'weekday' => (int) $group['weekday'],
            'weekday_label' => tryzub_intelligence_weekday_label((int) $group['weekday']),
            'time' => $group['time'],
            'average_guests' => $average_guests,
            'reservation_count' => (int) $group['reservation_count'],
            'sample_count' => $sample_count,
        ];
    }

    usort(
        $windows,
        function ($left, $right) {
            if ($left['average_guests'] !== $right['average_guests']) {
                return $right['average_guests'] <=> $left['average_guests'];
            }

            if ($left['reservation_count'] !== $right['reservation_count']) {
                return $right['reservation_count'] <=> $left['reservation_count'];
            }

            if ($left['weekday'] !== $right['weekday']) {
                return $left['weekday'] <=> $right['weekday'];
            }

            return strcmp((string) $left['time'], (string) $right['time']);
        }
    );

    return array_slice($windows, 0, 5);
}

function tryzub_business_intelligence_build_pipeline(array $rows) {
    $pipeline = [
        'new_count' => 0,
        'needs_review_count' => 0,
        'confirmed_count' => 0,
        'seated_count' => 0,
        'completed_count' => 0,
        'cancelled_count' => 0,
        'no_show_count' => 0,
    ];

    foreach ($rows as $row) {
        $status = sanitize_text_field((string) ($row['status'] ?? ''));
        $key = $status . '_count';

        if (array_key_exists($key, $pipeline)) {
            $pipeline[$key]++;
        }
    }

    return $pipeline;
}

function tryzub_business_intelligence_build_guest_relationships(array $rows, $to) {
  // v1 counts relationship metrics per reservation occurrence in the range, not per unique guest entity.
  // estimated_unique_guests uses distinct guest_key values; rows without a guest_key count as one anonymous guest each.
    $history_rows = tryzub_business_intelligence_fetch_history_rows($rows, $to);

    $estimated_unique_guests = 0;
    $guest_keys = [];
    $anonymous_rows = 0;
    $first_time_guest_count = 0;
    $returning_guest_count = 0;
    $regular_guest_count = 0;
    $frequent_regular_count = 0;
    $classified_guest_reservations = 0;
    $guests_with_preferences = 0;
    $guests_with_allergy_or_accessibility_notes = 0;
    $guests_with_prior_notes = 0;

    foreach ($rows as $row) {
        $identity = tryzub_intelligence_identity_from_row($row);
        $possible_duplicate = tryzub_business_intelligence_row_is_possible_duplicate($row);
        $needs_review = sanitize_text_field((string) ($row['status'] ?? '')) === 'needs_review';
        $clean_visits = tryzub_business_intelligence_count_prior_clean_visits($row, $identity, $history_rows);
        $relationship_confidence = tryzub_business_intelligence_identity_supports_history_matching($identity)
            ? $identity['confidence']
            : 'unknown';
        $classification = tryzub_intelligence_classify_guest(
            $clean_visits,
            $relationship_confidence,
            $needs_review,
            $possible_duplicate
        );

        if (!empty($identity['guest_key'])) {
            $guest_keys[$identity['guest_key']] = true;
        } else {
            $anonymous_rows++;
        }

        if (!in_array($classification, ['unknown', 'needs_review'], true)) {
            $classified_guest_reservations++;
        }

        if ($classification === 'new') {
            $first_time_guest_count++;
        } elseif ($classification === 'returning') {
            $returning_guest_count++;
        } elseif ($classification === 'regular') {
            $regular_guest_count++;
        } elseif ($classification === 'frequent_regular') {
            $frequent_regular_count++;
        }

        $current_flags = tryzub_intelligence_detect_note_flags(
            $row['guest_notes'] ?? '',
            $row['staff_notes'] ?? ''
        );
        $historical_flags = tryzub_business_intelligence_collect_historical_note_flags(
            $row,
            $identity,
            $history_rows
        );

        if ($current_flags['has_seating_preference'] || $historical_flags['has_seating_preference']) {
            $guests_with_preferences++;
        }

        if (
            $current_flags['has_allergy_note'] ||
            $current_flags['has_accessibility_note'] ||
            $historical_flags['has_allergy_note'] ||
            $historical_flags['has_accessibility_note']
        ) {
            $guests_with_allergy_or_accessibility_notes++;
        }

        if (tryzub_business_intelligence_has_prior_notes($row, $identity, $history_rows)) {
            $guests_with_prior_notes++;
        }
    }

    $estimated_unique_guests = count($guest_keys) + $anonymous_rows;
    $repeat_guest_count = $returning_guest_count + $regular_guest_count + $frequent_regular_count;

    return [
        'estimated_unique_guests' => $estimated_unique_guests,
        'first_time_guest_count' => $first_time_guest_count,
        'returning_guest_count' => $returning_guest_count,
        'regular_guest_count' => $regular_guest_count,
        'frequent_regular_count' => $frequent_regular_count,
        'repeat_guest_rate' => $classified_guest_reservations > 0
            ? round($repeat_guest_count / $classified_guest_reservations, 4)
            : 0.0,
        'guests_with_preferences' => $guests_with_preferences,
        'guests_with_allergy_or_accessibility_notes' => $guests_with_allergy_or_accessibility_notes,
        'guests_with_prior_notes' => $guests_with_prior_notes,
    ];
}

function tryzub_business_intelligence_fetch_history_rows(array $base_rows, $to) {
    global $wpdb;

    $emails = [];
    $phones = [];

    foreach ($base_rows as $row) {
        $identity = tryzub_intelligence_identity_from_row($row);

        if ($identity['normalized_email'] !== '') {
            $emails[$identity['normalized_email']] = true;
        }

        if ($identity['normalized_phone'] !== '') {
            $phones[$identity['normalized_phone']] = true;
        }
    }

    $emails = array_keys($emails);
    $phones = array_keys($phones);

    if (empty($emails) && empty($phones)) {
        return [];
    }

    $table_name = tryzub_get_reservations_table_name();
    $conditions = [];
    $values = [$to];

    if (!empty($emails)) {
        $email_placeholders = implode(', ', array_fill(0, count($emails), '%s'));
        $conditions[] = "LOWER(email) IN ($email_placeholders)";
        $values = array_merge($values, $emails);
    }

    if (!empty($phones)) {
        $phone_placeholders = implode(', ', array_fill(0, count($phones), '%s'));
        $conditions[] = "phone IN ($phone_placeholders)";
        $values = array_merge($values, $phones);
    }

    $sql = "
        SELECT
            id,
            email,
            phone,
            guest_name,
            reservation_date,
            status,
            guest_notes,
            staff_notes,
            duplicate_of_reservation_id,
            is_hidden,
            superseded_by_id
        FROM $table_name
        WHERE reservation_date <= %s
        AND (" . implode(' OR ', $conditions) . ")
        ORDER BY reservation_date ASC, id ASC
    ";

    return $wpdb->get_results($wpdb->prepare($sql, $values), ARRAY_A);
}

function tryzub_business_intelligence_count_prior_clean_visits(array $row, array $identity, array $history_rows) {
    if (!tryzub_business_intelligence_identity_supports_history_matching($identity)) {
        return 0;
    }

    $row_id = (int) ($row['id'] ?? 0);
    $row_date = (string) ($row['reservation_date'] ?? '');
    $count = 0;

    foreach ($history_rows as $history_row) {
        if ((int) ($history_row['id'] ?? 0) === $row_id) {
            continue;
        }

        if ((string) ($history_row['reservation_date'] ?? '') >= $row_date) {
            continue;
        }

        if (!tryzub_intelligence_is_clean_history_row($history_row)) {
            continue;
        }

        if (!tryzub_business_intelligence_row_matches_identity($history_row, $identity)) {
            continue;
        }

        $count++;
    }

    return $count;
}

function tryzub_business_intelligence_identity_supports_history_matching(array $identity) {
    if (in_array($identity['confidence'] ?? '', ['weak', 'unknown'], true)) {
        return false;
    }

    if (strpos((string) ($identity['basis'] ?? ''), 'name:') === 0) {
        return false;
    }

    return $identity['normalized_email'] !== '' || $identity['normalized_phone'] !== '';
}

function tryzub_business_intelligence_row_matches_identity(array $history_row, array $identity) {
    if (!tryzub_business_intelligence_identity_supports_history_matching($identity)) {
        return false;
    }

    if ($identity['normalized_email'] !== '') {
        $history_email = tryzub_intelligence_normalize_email($history_row['email'] ?? '');

        if ($history_email !== '' && $history_email === $identity['normalized_email']) {
            return true;
        }
    }

    if ($identity['normalized_phone'] !== '') {
        $history_phone = tryzub_intelligence_normalize_phone($history_row['phone'] ?? '');

        if ($history_phone !== '' && $history_phone === $identity['normalized_phone']) {
            return true;
        }
    }

    return false;
}

function tryzub_business_intelligence_collect_historical_note_flags(array $row, array $identity, array $history_rows) {
    $flags = [
        'has_seating_preference' => false,
        'has_allergy_note' => false,
        'has_accessibility_note' => false,
        'has_special_occasion_note' => false,
        'has_prior_service_issue' => false,
    ];
    $row_date = (string) ($row['reservation_date'] ?? '');
    $row_id = (int) ($row['id'] ?? 0);

    foreach ($history_rows as $history_row) {
        if ((int) ($history_row['id'] ?? 0) === $row_id) {
            continue;
        }

        if ((string) ($history_row['reservation_date'] ?? '') >= $row_date) {
            continue;
        }

        if (!tryzub_business_intelligence_row_matches_identity($history_row, $identity)) {
            continue;
        }

        $history_flags = tryzub_intelligence_detect_note_flags(
            $history_row['guest_notes'] ?? '',
            $history_row['staff_notes'] ?? ''
        );

        foreach ($flags as $key => $value) {
            if ($history_flags[$key]) {
                $flags[$key] = true;
            }
        }
    }

    return $flags;
}

function tryzub_business_intelligence_has_prior_notes(array $row, array $identity, array $history_rows) {
    $row_date = (string) ($row['reservation_date'] ?? '');
    $row_id = (int) ($row['id'] ?? 0);

    foreach ($history_rows as $history_row) {
        if ((int) ($history_row['id'] ?? 0) === $row_id) {
            continue;
        }

        if ((string) ($history_row['reservation_date'] ?? '') >= $row_date) {
            continue;
        }

        if (!tryzub_business_intelligence_row_matches_identity($history_row, $identity)) {
            continue;
        }

        if (trim((string) ($history_row['guest_notes'] ?? '')) !== '') {
            return true;
        }

        if (trim((string) ($history_row['staff_notes'] ?? '')) !== '') {
            return true;
        }
    }

    return false;
}

function tryzub_business_intelligence_row_is_possible_duplicate(array $row) {
    if (!empty($row['duplicate_of_reservation_id'])) {
        return true;
    }

    if (trim((string) ($row['duplicate_reason'] ?? '')) !== '') {
        return true;
    }

    return stripos((string) ($row['staff_notes'] ?? ''), 'Possible duplicate') !== false;
}

function tryzub_business_intelligence_lead_time_days(array $row) {
    $reservation_date = (string) ($row['reservation_date'] ?? '');
    $created_at = (string) ($row['created_at'] ?? '');

    if ($reservation_date === '' || $created_at === '') {
        return null;
    }

    $created_date = substr($created_at, 0, 10);
    $reservation = DateTimeImmutable::createFromFormat('!Y-m-d', $reservation_date);
    $created = DateTimeImmutable::createFromFormat('!Y-m-d', $created_date);

    if (!$reservation instanceof DateTimeImmutable || !$created instanceof DateTimeImmutable) {
        return null;
    }

    return (int) $created->diff($reservation)->format('%r%a');
}

function tryzub_business_intelligence_mysql_weekday($date) {
    $date_time = DateTimeImmutable::createFromFormat('!Y-m-d', (string) $date);

    if (!$date_time instanceof DateTimeImmutable) {
        return 0;
    }

    return ((int) $date_time->format('N')) - 1;
}

function tryzub_business_intelligence_hour_label($time) {
    $time = trim(sanitize_text_field((string) $time));

    if ($time === '') {
        return null;
    }

    if (function_exists('tryzub_normalize_reservation_time')) {
        $normalized = tryzub_normalize_reservation_time($time);

        if ($normalized) {
            $time = $normalized;
        }
    }

    if (!preg_match('/^(\d{1,2}):\d{2}/', $time, $matches)) {
        return null;
    }

    $hour = (int) $matches[1];

    if ($hour < 0 || $hour > 23) {
        return null;
    }

    return sprintf('%02d:00', $hour);
}

function tryzub_business_intelligence_increment_bucket(array &$bucket, $key, $party_size) {
    if (!isset($bucket[$key])) {
        $bucket[$key] = [
            'reservations_count' => 0,
            'guests_count' => 0,
        ];
    }

    $bucket[$key]['reservations_count']++;
    $bucket[$key]['guests_count'] += (int) $party_size;
}

function tryzub_business_intelligence_pick_busiest_key(array $bucket, $prefer_ascending_key) {
    if (empty($bucket)) {
        return null;
    }

    $best_key = null;
    $best_guests = -1;
    $best_reservations = -1;

    foreach ($bucket as $key => $values) {
        $guests = (int) ($values['guests_count'] ?? 0);
        $reservations = (int) ($values['reservations_count'] ?? 0);
        $is_better = false;

        if ($guests > $best_guests) {
            $is_better = true;
        } elseif ($guests === $best_guests) {
            if ($reservations > $best_reservations) {
                $is_better = true;
            } elseif ($reservations === $best_reservations) {
                // Deterministic tie-break: prefer the lexicographically smallest key (earliest date/hour/window).
                $is_better = $best_key === null || strcmp((string) $key, (string) $best_key) < 0;
            }
        }

        if ($is_better) {
            $best_key = $key;
            $best_guests = $guests;
            $best_reservations = $reservations;
        }
    }

    return $best_key;
}

function tryzub_business_intelligence_format_status_breakdown(array $bucket) {
    $rows = [];

    foreach ($bucket as $status => $values) {
        $rows[] = [
            'status' => (string) $status,
            'reservations_count' => (int) $values['reservations_count'],
            'guests_count' => (int) $values['guests_count'],
        ];
    }

    usort(
        $rows,
        function ($left, $right) {
            return strcmp((string) $left['status'], (string) $right['status']);
        }
    );

    return $rows;
}

function tryzub_business_intelligence_format_weekday_breakdown(array $bucket) {
    $rows = [];

    foreach ($bucket as $weekday => $values) {
        $weekday = (int) $weekday;
        $rows[] = [
            'weekday' => $weekday,
            'weekday_label' => tryzub_intelligence_weekday_label($weekday),
            'reservations_count' => (int) $values['reservations_count'],
            'guests_count' => (int) $values['guests_count'],
        ];
    }

    usort(
        $rows,
        function ($left, $right) {
            return $left['weekday'] <=> $right['weekday'];
        }
    );

    return $rows;
}

function tryzub_business_intelligence_format_simple_breakdown(array $bucket, $key_name) {
    $rows = [];

    foreach ($bucket as $key => $values) {
        $rows[] = [
            $key_name => (string) $key,
            'reservations_count' => (int) $values['reservations_count'],
            'guests_count' => (int) $values['guests_count'],
        ];
    }

    usort(
        $rows,
        function ($left, $right) use ($key_name) {
            return strcmp((string) $left[$key_name], (string) $right[$key_name]);
        }
    );

    return $rows;
}
