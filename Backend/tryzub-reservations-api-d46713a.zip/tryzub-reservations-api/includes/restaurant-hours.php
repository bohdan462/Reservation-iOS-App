<?php

function tryzub_get_restaurant_key() {
    return 'tryzub';
}

function tryzub_get_restaurant_hours(WP_REST_Request $request) {
    $range = tryzub_get_restaurant_hours_range_from_request($request);

    if (is_wp_error($range)) {
        return $range;
    }

    $restaurant_key = tryzub_get_restaurant_key();

    return rest_ensure_response([
        'success' => true,
        'data' => [
            'restaurant_key' => $restaurant_key,
            'weekly_hours' => tryzub_get_restaurant_weekly_hours_rows($restaurant_key),
            'special_hours' => tryzub_get_restaurant_special_hours_rows($restaurant_key, $range['from'], $range['to']),
        ],
    ]);
}

function tryzub_update_restaurant_hours(WP_REST_Request $request) {
    $body = tryzub_get_rest_request_body($request);
    $allowed_fields = ['weekly_hours'];
    $unknown_fields = array_diff(array_keys($body), $allowed_fields);

    if (!empty($unknown_fields)) {
        return new WP_Error(
            'tryzub_unknown_restaurant_hours_field',
            'Unknown restaurant hours field: ' . implode(', ', array_values($unknown_fields)),
            ['status' => 400]
        );
    }

    if (!isset($body['weekly_hours']) || !is_array($body['weekly_hours']) || empty($body['weekly_hours'])) {
        return new WP_Error(
            'tryzub_invalid_weekly_hours',
            'weekly_hours must be a non-empty array.',
            ['status' => 400]
        );
    }

    $restaurant_key = tryzub_get_restaurant_key();

    foreach ($body['weekly_hours'] as $index => $item) {
        if (!is_array($item)) {
            return new WP_Error(
                'tryzub_invalid_weekly_hours',
                'weekly_hours[' . $index . '] must be an object.',
                ['status' => 400]
            );
        }

        $hours = tryzub_prepare_weekly_hours_update($item);

        if (is_wp_error($hours)) {
            return $hours;
        }

        $saved = tryzub_upsert_restaurant_weekly_hours($restaurant_key, $hours);

        if (is_wp_error($saved)) {
            return $saved;
        }
    }

    return rest_ensure_response([
        'success' => true,
        'data' => [
            'restaurant_key' => $restaurant_key,
            'weekly_hours' => tryzub_get_restaurant_weekly_hours_rows($restaurant_key),
            'special_hours' => tryzub_get_restaurant_special_hours_rows($restaurant_key, null, null),
        ],
    ]);
}

function tryzub_get_restaurant_day_availability(WP_REST_Request $request) {
    $date = tryzub_get_required_restaurant_date_param($request);

    if (is_wp_error($date)) {
        return $date;
    }

    return rest_ensure_response([
        'success' => true,
        'data' => tryzub_get_effective_restaurant_day_availability($date),
    ]);
}

function tryzub_update_restaurant_day_availability(WP_REST_Request $request) {
    $date = tryzub_get_required_restaurant_date_param($request);

    if (is_wp_error($date)) {
        return $date;
    }

    $body = tryzub_get_rest_request_body($request);
    $allowed_fields = ['is_open', 'open_time', 'close_time', 'reason'];
    $unknown_fields = array_diff(array_keys($body), $allowed_fields);

    if (!empty($unknown_fields)) {
        return new WP_Error(
            'tryzub_unknown_day_availability_field',
            'Unknown day availability field: ' . implode(', ', array_values($unknown_fields)),
            ['status' => 400]
        );
    }

    $hours = tryzub_prepare_special_hours_update($body);

    if (is_wp_error($hours)) {
        return $hours;
    }

    $saved = tryzub_upsert_restaurant_special_hours(tryzub_get_restaurant_key(), $date, $hours);

    if (is_wp_error($saved)) {
        return $saved;
    }

    return rest_ensure_response([
        'success' => true,
        'data' => tryzub_get_effective_restaurant_day_availability($date),
    ]);
}

function tryzub_get_effective_restaurant_day_availability($date) {
    global $wpdb;

    $restaurant_key = tryzub_get_restaurant_key();
    $settings = tryzub_get_restaurant_settings();
    $weekday = tryzub_get_weekday_from_restaurant_date($date);
    $special_table = tryzub_get_restaurant_special_hours_table_name();
    $weekly_table = tryzub_get_restaurant_weekly_hours_table_name();

    $special = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT reservation_date, is_open, open_time, close_time, reason
            FROM $special_table
            WHERE restaurant_key = %s AND reservation_date = %s
            LIMIT 1",
            $restaurant_key,
            $date
        ),
        ARRAY_A
    );

    if ($special) {
        return tryzub_format_effective_restaurant_availability($date, $weekday, 'special', $special, $settings);
    }

    $weekly = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT weekday, is_open, open_time, close_time
            FROM $weekly_table
            WHERE restaurant_key = %s AND weekday = %d
            LIMIT 1",
            $restaurant_key,
            $weekday
        ),
        ARRAY_A
    );

    if ($weekly) {
        $weekly['reason'] = null;
        return tryzub_format_effective_restaurant_availability($date, $weekday, 'weekly', $weekly, $settings);
    }

    return [
        'date' => $date,
        'weekday' => $weekday,
        'source' => 'none',
        'is_open' => false,
        'open_time' => null,
        'close_time' => null,
        'reason' => null,
        'slot_interval_minutes' => (int) $settings['slot_interval_minutes'],
        'max_online_party_size' => (int) $settings['max_online_party_size'],
        'minimum_lead_time_minutes' => (int) $settings['minimum_lead_time_minutes'],
    ];
}

function tryzub_get_restaurant_weekly_hours_rows($restaurant_key) {
    global $wpdb;

    $table_name = tryzub_get_restaurant_weekly_hours_table_name();

    if (function_exists('tryzub_repair_known_restaurant_weekly_hours_seed_rows')) {
        tryzub_repair_known_restaurant_weekly_hours_seed_rows();
    }

    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT weekday, is_open, open_time, close_time
            FROM $table_name
            WHERE restaurant_key = %s
            ORDER BY weekday ASC",
            $restaurant_key
        ),
        ARRAY_A
    );

    if (count($rows) < 7) {
        tryzub_seed_default_restaurant_weekly_hours();
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT weekday, is_open, open_time, close_time
                FROM $table_name
                WHERE restaurant_key = %s
                ORDER BY weekday ASC",
                $restaurant_key
            ),
            ARRAY_A
        );
    }

    return array_map('tryzub_format_restaurant_weekly_hours_row', $rows);
}

function tryzub_get_restaurant_special_hours_rows($restaurant_key, $from, $to) {
    global $wpdb;

    $table_name = tryzub_get_restaurant_special_hours_table_name();
    $where = ['restaurant_key = %s'];
    $values = [$restaurant_key];

    if ($from) {
        $where[] = 'reservation_date >= %s';
        $values[] = $from;
    }

    if ($to) {
        $where[] = 'reservation_date <= %s';
        $values[] = $to;
    }

    if (!$from && !$to) {
        $where[] = 'reservation_date >= %s';
        $values[] = current_time('Y-m-d');
    }

    $where_sql = implode(' AND ', $where);
    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT reservation_date, is_open, open_time, close_time, reason
            FROM $table_name
            WHERE $where_sql
            ORDER BY reservation_date ASC",
            $values
        ),
        ARRAY_A
    );

    return array_map('tryzub_format_restaurant_special_hours_row', $rows);
}

function tryzub_prepare_weekly_hours_update(array $item) {
    $allowed_fields = ['weekday', 'is_open', 'open_time', 'close_time'];
    $unknown_fields = array_diff(array_keys($item), $allowed_fields);

    if (!empty($unknown_fields)) {
        return new WP_Error(
            'tryzub_unknown_weekly_hours_field',
            'Unknown weekly hours field: ' . implode(', ', array_values($unknown_fields)),
            ['status' => 400]
        );
    }

    if (!array_key_exists('weekday', $item)) {
        return new WP_Error(
            'tryzub_invalid_weekday',
            'weekday is required.',
            ['status' => 400]
        );
    }

    $weekday = tryzub_parse_restaurant_setup_integer($item['weekday']);

    if ($weekday === null || $weekday < 0 || $weekday > 6) {
        return new WP_Error(
            'tryzub_invalid_weekday',
            'weekday must be between 0 and 6.',
            ['status' => 400]
        );
    }

    $hours = tryzub_prepare_restaurant_hours_window($item, false);

    if (is_wp_error($hours)) {
        return $hours;
    }

    $hours['weekday'] = $weekday;

    return $hours;
}

function tryzub_prepare_special_hours_update(array $body) {
    $has_time = array_key_exists('open_time', $body) || array_key_exists('close_time', $body);

    if (!array_key_exists('is_open', $body) && $has_time) {
        $body['is_open'] = true;
    }

    $hours = tryzub_prepare_restaurant_hours_window($body, true);

    if (is_wp_error($hours)) {
        return $hours;
    }

    $hours['reason_provided'] = array_key_exists('reason', $body);
    $hours['reason'] = $hours['reason_provided'] ? sanitize_textarea_field((string) $body['reason']) : null;

    return $hours;
}

function tryzub_prepare_restaurant_hours_window(array $body, $allow_default_open) {
    if (!array_key_exists('is_open', $body)) {
        if (!$allow_default_open) {
            return new WP_Error(
                'tryzub_invalid_is_open',
                'is_open is required.',
                ['status' => 400]
            );
        }

        return new WP_Error(
            'tryzub_invalid_is_open',
            'is_open is required unless open_time or close_time is supplied.',
            ['status' => 400]
        );
    }

    $is_open = tryzub_normalize_boolean_value($body['is_open']);

    if ($is_open === null) {
        return new WP_Error(
            'tryzub_invalid_is_open',
            'is_open must be true or false.',
            ['status' => 400]
        );
    }

    if (!$is_open) {
        return [
            'is_open' => 0,
            'open_time' => null,
            'close_time' => null,
        ];
    }

    $open_time = tryzub_normalize_restaurant_hours_time($body['open_time'] ?? null);
    $close_time = tryzub_normalize_restaurant_hours_time($body['close_time'] ?? null);

    if (!$open_time || !$close_time) {
        return new WP_Error(
            'tryzub_invalid_hours_time',
            'open_time and close_time are required when is_open is true.',
            ['status' => 400]
        );
    }

    if (!tryzub_restaurant_close_time_is_after_open_time($open_time, $close_time)) {
        return new WP_Error(
            'tryzub_invalid_hours_range',
            'close_time must be after open_time.',
            ['status' => 400]
        );
    }

    return [
        'is_open' => 1,
        'open_time' => $open_time,
        'close_time' => $close_time,
    ];
}

function tryzub_upsert_restaurant_weekly_hours($restaurant_key, array $hours) {
    global $wpdb;

    $table_name = tryzub_get_restaurant_weekly_hours_table_name();
    $now = current_time('mysql');
    $existing_id = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT id FROM $table_name WHERE restaurant_key = %s AND weekday = %d LIMIT 1",
            $restaurant_key,
            $hours['weekday']
        )
    );

    if ($existing_id) {
        $updated = $wpdb->update(
            $table_name,
            [
                'is_open' => $hours['is_open'],
                'open_time' => $hours['open_time'],
                'close_time' => $hours['close_time'],
                'updated_at' => $now,
            ],
            ['id' => (int) $existing_id],
            ['%d', '%s', '%s', '%s'],
            ['%d']
        );

        if ($updated === false) {
            return tryzub_restaurant_hours_database_error('Failed to update weekly hours.');
        }

        return true;
    }

    $inserted = $wpdb->insert(
        $table_name,
        [
            'restaurant_key' => $restaurant_key,
            'weekday' => $hours['weekday'],
            'is_open' => $hours['is_open'],
            'open_time' => $hours['open_time'],
            'close_time' => $hours['close_time'],
            'created_at' => $now,
            'updated_at' => null,
        ],
        ['%s', '%d', '%d', '%s', '%s', '%s', '%s']
    );

    if ($inserted === false) {
        return tryzub_restaurant_hours_database_error('Failed to insert weekly hours.');
    }

    return true;
}

function tryzub_upsert_restaurant_special_hours($restaurant_key, $date, array $hours) {
    global $wpdb;

    $table_name = tryzub_get_restaurant_special_hours_table_name();
    $now = current_time('mysql');
    $user_id = get_current_user_id() ?: null;
    $existing_id = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT id FROM $table_name WHERE restaurant_key = %s AND reservation_date = %s LIMIT 1",
            $restaurant_key,
            $date
        )
    );

    if ($existing_id) {
        $updates = [
            'is_open' => $hours['is_open'],
            'open_time' => $hours['open_time'],
            'close_time' => $hours['close_time'],
            'updated_by_user_id' => $user_id,
            'updated_at' => $now,
        ];
        $formats = ['%d', '%s', '%s', '%d', '%s'];

        if ($hours['reason_provided']) {
            $updates['reason'] = $hours['reason'];
            $formats[] = '%s';
        }

        $updated = $wpdb->update(
            $table_name,
            $updates,
            ['id' => (int) $existing_id],
            $formats,
            ['%d']
        );

        if ($updated === false) {
            return tryzub_restaurant_hours_database_error('Failed to update day availability.');
        }

        return true;
    }

    $inserted = $wpdb->insert(
        $table_name,
        [
            'restaurant_key' => $restaurant_key,
            'reservation_date' => $date,
            'is_open' => $hours['is_open'],
            'open_time' => $hours['open_time'],
            'close_time' => $hours['close_time'],
            'reason' => $hours['reason_provided'] ? $hours['reason'] : null,
            'created_by_user_id' => $user_id,
            'updated_by_user_id' => null,
            'created_at' => $now,
            'updated_at' => null,
        ],
        ['%s', '%s', '%d', '%s', '%s', '%s', '%d', '%d', '%s', '%s']
    );

    if ($inserted === false) {
        return tryzub_restaurant_hours_database_error('Failed to insert day availability.');
    }

    return true;
}

function tryzub_format_restaurant_weekly_hours_row(array $row) {
    $is_open = (bool) (int) $row['is_open'];

    return [
        'weekday' => (int) $row['weekday'],
        'is_open' => $is_open,
        'open_time' => $is_open ? $row['open_time'] : null,
        'close_time' => $is_open ? $row['close_time'] : null,
    ];
}

function tryzub_format_restaurant_special_hours_row(array $row) {
    $is_open = (bool) (int) $row['is_open'];

    return [
        'reservation_date' => $row['reservation_date'],
        'is_open' => $is_open,
        'open_time' => $is_open ? $row['open_time'] : null,
        'close_time' => $is_open ? $row['close_time'] : null,
        'reason' => $row['reason'],
    ];
}

function tryzub_format_effective_restaurant_availability($date, $weekday, $source, array $row, array $settings) {
    $is_open = (bool) (int) $row['is_open'];

    return [
        'date' => $date,
        'weekday' => $weekday,
        'source' => $source,
        'is_open' => $is_open,
        'open_time' => $is_open ? $row['open_time'] : null,
        'close_time' => $is_open ? $row['close_time'] : null,
        'reason' => $row['reason'] ?? null,
        'slot_interval_minutes' => (int) $settings['slot_interval_minutes'],
        'max_online_party_size' => (int) $settings['max_online_party_size'],
        'minimum_lead_time_minutes' => (int) $settings['minimum_lead_time_minutes'],
    ];
}

function tryzub_get_restaurant_hours_range_from_request(WP_REST_Request $request) {
    $from = $request->get_param('from');
    $to = $request->get_param('to');

    $from = $from ? tryzub_normalize_reservation_date($from) : null;
    $to = $to ? tryzub_normalize_reservation_date($to) : null;

    if ($request->get_param('from') && !$from) {
        return new WP_Error(
            'tryzub_invalid_from_date',
            'from must be a valid date.',
            ['status' => 400]
        );
    }

    if ($request->get_param('to') && !$to) {
        return new WP_Error(
            'tryzub_invalid_to_date',
            'to must be a valid date.',
            ['status' => 400]
        );
    }

    if ($from && $to && $from > $to) {
        return new WP_Error(
            'tryzub_invalid_date_range',
            'from must be before or equal to to.',
            ['status' => 400]
        );
    }

    return [
        'from' => $from,
        'to' => $to,
    ];
}

function tryzub_get_required_restaurant_date_param(WP_REST_Request $request) {
    $date = $request->get_param('date');

    if (!$date) {
        return new WP_Error(
            'tryzub_missing_date',
            'date is required.',
            ['status' => 400]
        );
    }

    $date = tryzub_normalize_reservation_date($date);

    if (!$date) {
        return new WP_Error(
            'tryzub_invalid_date',
            'date must be a valid date.',
            ['status' => 400]
        );
    }

    return $date;
}

function tryzub_get_weekday_from_restaurant_date($date) {
    $parsed = DateTime::createFromFormat('Y-m-d', $date);

    return $parsed instanceof DateTime ? ((int) $parsed->format('N')) - 1 : 0;
}

function tryzub_normalize_restaurant_hours_time($value) {
    if ($value === null || $value === '') {
        return null;
    }

    return tryzub_normalize_reservation_time($value);
}

function tryzub_restaurant_close_time_is_after_open_time($open_time, $close_time) {
    return tryzub_restaurant_time_to_seconds($close_time) > tryzub_restaurant_time_to_seconds($open_time);
}

function tryzub_restaurant_time_to_seconds($time) {
    $parts = array_map('absint', explode(':', (string) $time));

    return (($parts[0] ?? 0) * HOUR_IN_SECONDS) + (($parts[1] ?? 0) * MINUTE_IN_SECONDS) + ($parts[2] ?? 0);
}

function tryzub_restaurant_hours_database_error($message) {
    global $wpdb;

    error_log('Tryzub restaurant hours database error: ' . $wpdb->last_error);

    return new WP_Error(
        'tryzub_database_error',
        $message,
        ['status' => 500]
    );
}
