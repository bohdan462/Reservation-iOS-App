<?php

// Decides whether a new managed reservation can enter as normal new intake or needs human review.
// Missing required fields are handled before this function.
// Suspicious-but-present values are still imported so staff can see and verify them instead of losing the request.
function tryzub_determine_initial_status(array $reservation, $requested_status = null) {
    $reasons = [];

    $party_size = absint($reservation['party_size'] ?? 0);
    $name = $reservation['guest_name'] ?? '';
    $email = $reservation['email'] ?? '';
    $phone = $reservation['phone'] ?? '';
    $reservation_date = sanitize_text_field($reservation['reservation_date'] ?? '');
    $source_type = sanitize_text_field((string) ($reservation['source_type'] ?? 'form'));
    $is_past_reservation = tryzub_is_past_reservation_date($reservation_date);
    $email_is_optional_placeholder = tryzub_reservation_source_allows_missing_email($source_type)
        && function_exists('tryzub_is_call_in_placeholder_email')
        && tryzub_is_call_in_placeholder_email($email);

    if ($party_size <= 0) {
        $reasons[] = 'Invalid party size';
    }

    if ($party_size >= 7) {
        $reasons[] = 'Large party size requires review';
    }

    if ($party_size >= 30) {
        $reasons[] = 'Suspiciously large party size requires review';
    }

    if (tryzub_name_needs_review($name)) {
        $reasons[] = 'Guest name requires review';
    }

    if (tryzub_phone_needs_review($phone)) {
        $reasons[] = 'Guest phone requires review';
    }
    if (!$email_is_optional_placeholder && !is_email($email)) {
        $reasons[] = 'Invalid email format';
    }
    if ($is_past_reservation) {
        $reasons[] = 'Reservation date is in the past; marked completed';
    }

    $related_id = null;

    if (!$is_past_reservation) {
        // Same guest/date submissions are not auto-merged or deleted.
        // They are flagged for staff because they may be accidental duplicates or real corrections.
        $related_id = tryzub_find_related_active_reservation($reservation);

        if ($related_id) {
            $reasons[] = 'Possible duplicate or correction of reservation ID ' . $related_id;
        }
    }

    if ($is_past_reservation) {
        $status = 'completed';
    } elseif ($requested_status && in_array($requested_status, tryzub_get_allowed_reservation_statuses(), true)) {
        $status = $requested_status;
    } else {
        $status = empty($reasons) ? 'new' : 'needs_review';
    }

    return [
        'status' => $status,
        'reasons' => $reasons,
        'related_reservation_id' => $related_id
    ];
}

function tryzub_is_past_reservation_date($date) {
    if (!$date || !tryzub_is_valid_managed_reservation_date($date)) {
        return false;
    }

    return $date < current_time('Y-m-d');
}

// Applies optional date, from, and to filters against the submitted reservation date.
// Dates must stay in YYYY-MM-DD format for string comparison to work correctly.
function tryzub_reservation_matches_date_filter(array $reservation, $date, $from, $to) {
    if (!$date && !$from && !$to) {
        return true; // No date filters applied
    }

    $reservation_date = $reservation['reservation_date'] ?? null;

    if (!$reservation_date) {
        return false; // Skip if no reservation date
    }

    if ($date && $reservation_date !== $date) {
        return false; // Date filter does not match
    }

    if ($from && $reservation_date < $from) {
        return false; // Date is before the filter range
    }

    if ($to && $reservation_date > $to) {
        return false; // Date is after the filter range
    }

    return true; // Date filter matches
}

// Looks for an already-active reservation with the same email or phone on the same reservation date.
// This catches likely duplicate submissions and corrections, including cases where the guest changes time or party size.
// It returns one related managed reservation ID so staff_notes can point staff to the possible original record.
function tryzub_find_related_active_reservation(array $reservation) {
    global $wpdb;

    $table_name = tryzub_get_reservations_table_name();

    $email = sanitize_email($reservation['email'] ?? '');
    $phone = tryzub_normalize_phone_digits($reservation['phone'] ?? '');
    $date = sanitize_text_field($reservation['reservation_date'] ?? '');

    if (function_exists('tryzub_is_call_in_placeholder_email') && tryzub_is_call_in_placeholder_email($email)) {
        $email = '';
    }

    if (!$date || (!$email && !$phone)) {
        return null;
    }

    $active_statuses = ['new', 'needs_review', 'confirmed'];
    $status_placeholders = implode(', ', array_fill(0, count($active_statuses), '%s'));

    $query = $wpdb->prepare(
        "SELECT id
        FROM $table_name
        WHERE reservation_date = %s
        AND status IN ($status_placeholders)
        AND (email = %s OR phone = %s)
        ORDER BY id ASC
        LIMIT 1",
        array_merge(
            [$date],
            $active_statuses,
            [$email, $phone]
        )
    );

    $existing_id = $wpdb->get_var($query);

    return $existing_id ? (int) $existing_id : null;
}

function tryzub_get_allowed_reservation_source_types() {
    return [
        'form',
        'manual_call_in',
        'manual_walk_in',
        'known_guest_manual',
        'import_repair',
    ];
}

function tryzub_reservation_source_allows_missing_email($source_type) {
    return in_array(
        sanitize_text_field((string) $source_type),
        ['manual_call_in', 'manual_walk_in', 'known_guest_manual'],
        true
    );
}

function tryzub_name_needs_review($name) {
    $name = trim((string) $name);

    if (strlen($name) < 2) {
        return true; // Too short to be valid
    }

    if (!preg_match('/\p{L}/u', $name)) {
        return true; // No letters, not a real name
    }
    if (preg_match('/^\d+$/', $name)) {
        return true; // Name is just numbers, not valid
    }
    return false;
}

function tryzub_phone_needs_review($phone) {
    $digits = tryzub_normalize_phone_digits($phone);

    if (strlen($digits) < 10) {
        return true; // Too few digits to be valid
    }

    if (preg_match('/^(\d)\1+$/', $digits)) {
        return true;
    }

    return false;
}
