<?php

function tryzub_get_reservation_analytics_summary(WP_REST_Request $request) {
    $range = tryzub_get_reservation_analytics_range_from_request($request);

    if (is_wp_error($range)) {
        return $range;
    }

    $summary = tryzub_get_reservation_analytics_summary_row($range['from'], $range['to']);

    return rest_ensure_response([
        'success' => true,
        'range' => [
            'from' => $range['from'] ?: $summary['first_reservation_date'],
            'to' => $range['to'] ?: $summary['last_reservation_date'],
        ],
        'summary' => $summary,
        'by_status' => tryzub_get_reservation_analytics_grouped_rows($range['from'], $range['to'], 'r.status', 'status', 'status ASC'),
        'by_month' => tryzub_get_reservation_analytics_grouped_rows($range['from'], $range['to'], "DATE_FORMAT(r.reservation_date, '%Y-%m')", 'month', 'month ASC'),
        'by_weekday' => tryzub_get_reservation_analytics_grouped_rows($range['from'], $range['to'], 'WEEKDAY(r.reservation_date)', 'weekday', 'weekday ASC'),
        'by_hour' => tryzub_get_reservation_analytics_grouped_rows($range['from'], $range['to'], 'HOUR(r.reservation_time)', 'hour', 'hour ASC'),
        'by_party_size' => tryzub_get_reservation_analytics_grouped_rows($range['from'], $range['to'], 'r.party_size', 'party_size', 'party_size ASC'),
        'lead_time_buckets' => tryzub_get_reservation_analytics_lead_time_buckets($range['from'], $range['to']),
        'field_completeness' => tryzub_get_reservation_analytics_field_completeness($range['from'], $range['to']),
        'pipeline_health' => tryzub_get_reservation_analytics_pipeline_health(),
    ]);
}

function tryzub_get_reservation_analytics_summary_row($from, $to) {
    global $wpdb;

    $parts = tryzub_get_reservation_analytics_base_query_parts($from, $to);
    $sql = "
        SELECT
            COUNT(*) AS reservations_count,
            COALESCE(SUM(r.party_size), 0) AS guests_count,
            ROUND(AVG(r.party_size), 2) AS avg_party_size,
            MIN(r.reservation_date) AS first_reservation_date,
            MAX(r.reservation_date) AS last_reservation_date,
            MIN(p.post_date) AS first_submission_date,
            MAX(p.post_date) AS last_submission_date
        {$parts['from_sql']}
        WHERE {$parts['where_sql']}
    ";

    $row = $wpdb->get_row(tryzub_prepare_reservation_analytics_sql($sql, $parts['values']), ARRAY_A);

    return [
        'reservations_count' => (int) ($row['reservations_count'] ?? 0),
        'guests_count' => (int) ($row['guests_count'] ?? 0),
        'avg_party_size' => isset($row['avg_party_size']) ? (float) $row['avg_party_size'] : 0.0,
        'first_reservation_date' => $row['first_reservation_date'] ?? null,
        'last_reservation_date' => $row['last_reservation_date'] ?? null,
        'first_submission_date' => $row['first_submission_date'] ?? null,
        'last_submission_date' => $row['last_submission_date'] ?? null,
    ];
}

function tryzub_get_reservation_analytics_grouped_rows($from, $to, $expression, $alias, $order_by) {
    global $wpdb;

    $parts = tryzub_get_reservation_analytics_base_query_parts($from, $to);
    $sql = "
        SELECT
            $expression AS $alias,
            COUNT(*) AS reservations_count,
            COALESCE(SUM(r.party_size), 0) AS guests_count
        {$parts['from_sql']}
        WHERE {$parts['where_sql']}
        GROUP BY $alias
        ORDER BY $order_by
    ";

    $rows = $wpdb->get_results(tryzub_prepare_reservation_analytics_sql($sql, $parts['values']), ARRAY_A);

    return array_map(
        function ($row) use ($alias) {
            $value = $row[$alias];

            if (in_array($alias, ['weekday', 'hour', 'party_size'], true)) {
                $value = (int) $value;
            }

            return [
                $alias => $value,
                'reservations_count' => (int) $row['reservations_count'],
                'guests_count' => (int) $row['guests_count'],
            ];
        },
        $rows
    );
}

function tryzub_get_reservation_analytics_lead_time_buckets($from, $to) {
    global $wpdb;

    $parts = tryzub_get_reservation_analytics_base_query_parts($from, $to);
    $bucket_expression = "
        CASE
            WHEN DATEDIFF(r.reservation_date, DATE(p.post_date)) < 0 THEN 'past_invalid'
            WHEN DATEDIFF(r.reservation_date, DATE(p.post_date)) = 0 THEN 'same_day'
            WHEN DATEDIFF(r.reservation_date, DATE(p.post_date)) = 1 THEN 'one_day'
            WHEN DATEDIFF(r.reservation_date, DATE(p.post_date)) BETWEEN 2 AND 3 THEN 'two_three_days'
            WHEN DATEDIFF(r.reservation_date, DATE(p.post_date)) BETWEEN 4 AND 7 THEN 'four_seven_days'
            WHEN DATEDIFF(r.reservation_date, DATE(p.post_date)) BETWEEN 8 AND 14 THEN 'eight_fourteen_days'
            WHEN DATEDIFF(r.reservation_date, DATE(p.post_date)) BETWEEN 15 AND 30 THEN 'fifteen_thirty_days'
            ELSE 'thirty_one_plus_days'
        END
    ";
    $sql = "
        SELECT
            $bucket_expression AS bucket,
            COUNT(*) AS reservations_count,
            COALESCE(SUM(r.party_size), 0) AS guests_count
        {$parts['from_sql']}
        WHERE {$parts['where_sql']}
        GROUP BY bucket
    ";
    $rows = $wpdb->get_results(tryzub_prepare_reservation_analytics_sql($sql, $parts['values']), ARRAY_A);
    $counts = [];

    foreach ($rows as $row) {
        $counts[$row['bucket']] = [
            'reservations_count' => (int) $row['reservations_count'],
            'guests_count' => (int) $row['guests_count'],
        ];
    }

    return array_map(
        function ($bucket) use ($counts) {
            return [
                'bucket' => $bucket,
                'reservations_count' => $counts[$bucket]['reservations_count'] ?? 0,
                'guests_count' => $counts[$bucket]['guests_count'] ?? 0,
            ];
        },
        [
            'past_invalid',
            'same_day',
            'one_day',
            'two_three_days',
            'four_seven_days',
            'eight_fourteen_days',
            'fifteen_thirty_days',
            'thirty_one_plus_days',
        ]
    );
}

function tryzub_get_reservation_analytics_field_completeness($from, $to) {
    global $wpdb;

    $parts = tryzub_get_reservation_analytics_base_query_parts($from, $to);
    $sql = "
        SELECT
            COUNT(*) AS total,
            SUM(CASE WHEN TRIM(COALESCE(r.guest_name, '')) <> '' THEN 1 ELSE 0 END) AS guest_name_present,
            SUM(CASE WHEN TRIM(COALESCE(r.email, '')) <> '' THEN 1 ELSE 0 END) AS email_present,
            SUM(CASE WHEN TRIM(COALESCE(r.phone, '')) <> '' THEN 1 ELSE 0 END) AS phone_present,
            SUM(CASE WHEN TRIM(COALESCE(r.guest_notes, '')) <> '' THEN 1 ELSE 0 END) AS guest_notes_present,
            SUM(CASE WHEN TRIM(COALESCE(r.staff_notes, '')) <> '' THEN 1 ELSE 0 END) AS staff_notes_present,
            SUM(CASE WHEN TRIM(COALESCE(r.table_name, '')) <> '' THEN 1 ELSE 0 END) AS table_name_present
        {$parts['from_sql']}
        WHERE {$parts['where_sql']}
    ";
    $row = $wpdb->get_row(tryzub_prepare_reservation_analytics_sql($sql, $parts['values']), ARRAY_A);
    $total = (int) ($row['total'] ?? 0);
    $fields = ['guest_name', 'email', 'phone', 'guest_notes', 'staff_notes', 'table_name'];
    $completeness = [];

    foreach ($fields as $field) {
        $present = (int) ($row[$field . '_present'] ?? 0);
        $missing = max(0, $total - $present);

        $completeness[$field] = [
            'present' => $present,
            'missing' => $missing,
            'percent' => $total > 0 ? round(($present / $total) * 100, 2) : 0.0,
        ];
    }

    return $completeness;
}

function tryzub_get_reservation_analytics_pipeline_health() {
    global $wpdb;

    $reservations_table = tryzub_get_reservations_table_name();
    $posts_table = $wpdb->posts;
    $postmeta_table = $wpdb->postmeta;
    $submission_status_sql = tryzub_get_reservation_analytics_submission_status_join_sql($postmeta_table);
    $non_spam_where = "
        p.post_type = 'flamingo_inbound'
        AND UPPER(COALESCE(submission_status.meta_value, '')) NOT IN ('SPAM')
    ";
    $flamingo_total = (int) $wpdb->get_var("
        SELECT COUNT(DISTINCT p.ID)
        FROM $posts_table p
        $submission_status_sql
        WHERE $non_spam_where
    ");
    $managed_total = (int) $wpdb->get_var("
        SELECT COUNT(DISTINCT r.source_submission_id)
        FROM $reservations_table r
        INNER JOIN $posts_table p
            ON p.ID = r.source_submission_id
        $submission_status_sql
        WHERE r.source_submission_id IS NOT NULL
        AND $non_spam_where
    ");
    $missing_total = (int) $wpdb->get_var("
        SELECT COUNT(DISTINCT p.ID)
        FROM $posts_table p
        $submission_status_sql
        LEFT JOIN $reservations_table r
            ON r.source_submission_id = p.ID
        WHERE $non_spam_where
        AND r.id IS NULL
    ");

    return [
        'flamingo_inbound_total' => $flamingo_total,
        'managed_rows_with_source_submission_id' => $managed_total,
        'missing_non_spam_flamingo' => $missing_total,
    ];
}

function tryzub_get_reservation_analytics_base_query_parts($from, $to) {
    global $wpdb;

    $reservations_table = tryzub_get_reservations_table_name();
    $posts_table = $wpdb->posts;
    $postmeta_table = $wpdb->postmeta;
    $submission_status_sql = tryzub_get_reservation_analytics_submission_status_join_sql($postmeta_table);
    $where = [
        'r.source_submission_id IS NOT NULL',
        "p.post_type = 'flamingo_inbound'",
        "UPPER(COALESCE(submission_status.meta_value, '')) NOT IN ('SPAM')",
    ];
    $values = [];

    if ($from) {
        $where[] = 'r.reservation_date >= %s';
        $values[] = $from;
    }

    if ($to) {
        $where[] = 'r.reservation_date <= %s';
        $values[] = $to;
    }

    return [
        'from_sql' => "
            FROM $reservations_table r
            INNER JOIN $posts_table p
                ON p.ID = r.source_submission_id
            $submission_status_sql
        ",
        'where_sql' => implode(' AND ', $where),
        'values' => $values,
    ];
}

function tryzub_get_reservation_analytics_submission_status_join_sql($postmeta_table) {
    return "
        LEFT JOIN (
            SELECT post_id, MAX(meta_value) AS meta_value
            FROM $postmeta_table
            WHERE meta_key = '_submission_status'
            GROUP BY post_id
        ) submission_status
            ON submission_status.post_id = p.ID
    ";
}

function tryzub_get_reservation_analytics_range_from_request(WP_REST_Request $request) {
    $from_param = $request->get_param('from');
    $to_param = $request->get_param('to');
    $from = $from_param ? tryzub_normalize_reservation_date($from_param) : null;
    $to = $to_param ? tryzub_normalize_reservation_date($to_param) : null;

    if ($from_param && !$from) {
        return new WP_Error(
            'tryzub_invalid_from_date',
            'from must be a valid date.',
            ['status' => 400]
        );
    }

    if ($to_param && !$to) {
        return new WP_Error(
            'tryzub_invalid_to_date',
            'to must be a valid date.',
            ['status' => 400]
        );
    }

    if ($from && $to && $from > $to) {
        return new WP_Error(
            'tryzub_invalid_date_range',
            'from must be before or equal to to.',
            ['status' => 400]
        );
    }

    return [
        'from' => $from,
        'to' => $to,
    ];
}

function tryzub_prepare_reservation_analytics_sql($sql, array $values) {
    global $wpdb;

    if (empty($values)) {
        return $sql;
    }

    return $wpdb->prepare($sql, $values);
}
