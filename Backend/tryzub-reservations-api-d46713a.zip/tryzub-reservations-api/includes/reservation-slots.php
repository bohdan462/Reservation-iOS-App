<?php

function tryzub_get_reservation_slots(WP_REST_Request $request) {
    $date = tryzub_get_required_restaurant_date_param($request);

    if (is_wp_error($date)) {
        return $date;
    }

    $availability = tryzub_get_effective_restaurant_day_availability($date);

    // This endpoint is public, so the payload is intentionally limited to what
    // the booking form needs. Internal scheduling details (availability source,
    // blocked-slot counts) stay on the authenticated staff endpoints.
    if (!$availability['is_open'] || !$availability['open_time'] || !$availability['close_time']) {
        return tryzub_reservation_slots_no_cache_response([
            'success' => true,
            'date' => $date,
            'is_open' => false,
            'slots' => [],
            'message' => 'Reservations are not available for this date.',
        ]);
    }

    $slots = tryzub_generate_reservation_slots(
        $date,
        $availability['open_time'],
        $availability['close_time'],
        (int) $availability['slot_interval_minutes']
    );
    $filtered_slots = tryzub_remove_blocked_reservation_slots($slots, tryzub_get_blocked_slots_for_date($date));

    return tryzub_reservation_slots_no_cache_response([
        'success' => true,
        'date' => $date,
        'is_open' => true,
        'slots' => $filtered_slots,
        'message' => null,
    ]);
}

// Slots reflect live staff edits (hours, blocked times), so the response must
// never be cached by the browser, CDN, or any proxy in between.
function tryzub_reservation_slots_no_cache_response($data) {
    nocache_headers();

    $response = rest_ensure_response($data);
    $response->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
    $response->header('Pragma', 'no-cache');
    $response->header('Expires', 'Wed, 11 Jan 1984 05:00:00 GMT');

    return $response;
}

function tryzub_generate_reservation_slots($date, $open_time, $close_time, $slot_interval_minutes) {
    $slots = [];
    $interval_seconds = max(1, $slot_interval_minutes) * MINUTE_IN_SECONDS;
    $open_seconds = tryzub_restaurant_time_to_seconds($open_time);
    $close_seconds = tryzub_restaurant_time_to_seconds($close_time);
    $last_bookable_seconds = $close_seconds - (30 * MINUTE_IN_SECONDS);

    for ($seconds = $open_seconds; $seconds <= $last_bookable_seconds; $seconds += $interval_seconds) {
        $hours = (int) floor($seconds / HOUR_IN_SECONDS);
        $minutes = (int) floor(($seconds % HOUR_IN_SECONDS) / MINUTE_IN_SECONDS);
        $value = sprintf('%02d:%02d', $hours, $minutes);

        $slots[] = [
            'value' => $value,
            'label' => date_i18n('g:i A', strtotime($date . ' ' . $value . ':00')),
        ];
    }

    return $slots;
}

function tryzub_remove_blocked_reservation_slots(array $slots, array $blocked_slot_values) {
    if (empty($blocked_slot_values)) {
        return $slots;
    }

    $blocked_lookup = array_flip($blocked_slot_values);

    return array_values(array_filter($slots, function ($slot) use ($blocked_lookup) {
        return !isset($blocked_lookup[$slot['value']]);
    }));
}
