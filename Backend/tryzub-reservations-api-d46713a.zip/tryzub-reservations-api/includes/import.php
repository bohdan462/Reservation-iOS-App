<?php

// REST wrapper for manual/admin import runs.
function tryzub_import_managed_reservations(WP_REST_Request $request) {
    return rest_ensure_response(tryzub_run_managed_reservations_import());
}

function tryzub_get_managed_reservation_import_failures(WP_REST_Request $request) {
    global $wpdb;

    $per_page = min(max((int) $request->get_param('per_page'), 1), 100);
    $page = max((int) $request->get_param('page'), 1);
    $offset = ($page - 1) * $per_page;
    $table_name = tryzub_get_import_failures_table_name();

    $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT *
            FROM $table_name
            ORDER BY created_at DESC, id DESC
            LIMIT %d OFFSET %d",
            $per_page,
            $offset
        ),
        ARRAY_A
    );

    return rest_ensure_response([
        'success' => true,
        'page' => $page,
        'per_page' => $per_page,
        'total' => $total,
        'total_pages' => (int) ceil($total / $per_page),
        'data' => array_map('tryzub_format_import_failure_row', $rows)
    ]);
}

// Import runner.
// This can be called manually by the REST endpoint or internally after Flamingo saves a new CF7 submission.
// Current behavior walks Flamingo in date order, skips already-imported source_submission_id values, and inserts only missing records.
function tryzub_import_managed_reservations_now() {
    return tryzub_run_managed_reservations_import();
}

function tryzub_run_managed_reservations_import() {
    // Pull Flamingo submissions in bounded pages so the importer does not miss newer records after the site has more than 100 submissions.
    // ASC order means older submissions are imported first, so later same-day submissions can be flagged as possible corrections.
    $per_page = 100;
    $page = 1;

    $imported = 0;
    $skipped = 0;
    $failed = 0;
    $total_checked = 0;
    $errors = [];

    do {
        $query = new WP_Query([
            'post_type' => 'flamingo_inbound',
            'post_status' => 'publish',
            'posts_per_page' => $per_page,
            'paged' => $page,
            'orderby' => 'date',
            'order' => 'ASC'
        ]);

        if (empty($query->posts)) {
            break;
        }

        $total_checked += count($query->posts);

        foreach ($query->posts as $post) {
            $import_result = tryzub_import_managed_reservation_from_post($post, 'manual_import');

            if (!is_wp_error($import_result) && $import_result['status'] === 'skipped') {
                $skipped++;
                continue;
            }

            if (is_wp_error($import_result)) {
                $failed++;
                $errors[] = tryzub_format_import_error($import_result);
                continue;
            }

            if ($import_result['status'] === 'imported') {
                $imported++;
            }
        }

        $page++;
    } while (count($query->posts) === $per_page);

    return [
        'success' => true,
        'has_errors' => $failed > 0,
        'imported' => $imported,
        'skipped' => $skipped,
        'failed' => $failed,
        'total_checked' => $total_checked,
        'errors' => $errors
     ];
}

function tryzub_get_import_failure_rows() {
    global $wpdb;

    $table_name = tryzub_get_import_failures_table_name();
    $rows = $wpdb->get_results(
        "SELECT * FROM $table_name ORDER BY created_at DESC, id DESC",
        ARRAY_A
    );

    return array_map('tryzub_format_import_failure_row', $rows);
}

// Import exactly one Flamingo inbound post.
// Used by the automatic CF7/Flamingo hook so new reservations become visible to the app without calling the manual import endpoint.
function tryzub_import_managed_reservation_by_source_id($source_submission_id) {
    $source_submission_id = absint($source_submission_id);

    if (!$source_submission_id) {
        return new WP_Error(
            'tryzub_import_missing_source_id',
            'Missing Flamingo source submission ID.'
        );
    }

    $post = get_post($source_submission_id);

    if (!$post || $post->post_type !== 'flamingo_inbound') {
        return new WP_Error(
            'tryzub_import_source_not_found',
            'Flamingo source submission was not found.',
            ['source_submission_id' => $source_submission_id]
        );
    }

    return tryzub_import_managed_reservation_from_post($post);
}

function tryzub_import_managed_reservation_from_post(WP_Post $post, $activity_source = 'flamingo_auto_import') {
    $reservation = tryzub_format_reservation($post);
    $source_submission_id = (int) $reservation['id'];

    if (tryzub_managed_reservation_exists($source_submission_id)) {
        tryzub_mark_import_failure_resolved($source_submission_id, 'Managed reservation already exists for this source.');

        return [
            'status' => 'skipped',
            'source_submission_id' => $source_submission_id
        ];
    }

    $validation_error = tryzub_validate_importable_reservation($reservation);

    if (is_wp_error($validation_error)) {
        tryzub_record_import_failure($validation_error, $post);
        return $validation_error;
    }

    $reservation['client_request_id'] = tryzub_normalize_client_request_id($reservation['client_request_id'] ?? null);
    $reservation['submission_fingerprint'] = tryzub_build_submission_fingerprint($reservation);

    if (!empty($reservation['client_request_id'])) {
        $existing_id = tryzub_find_managed_reservation_by_client_request_id($reservation['client_request_id']);

        if ($existing_id) {
            tryzub_record_duplicate_import($post, $existing_id, 'client_request_id_match', $reservation);
            tryzub_mark_import_failure_resolved($source_submission_id, 'Skipped duplicate import by client_request_id.');

            return [
                'status' => 'skipped',
                'source_submission_id' => $source_submission_id,
                'duplicate_of_reservation_id' => $existing_id,
                'duplicate_reason' => 'client_request_id_match'
            ];
        }
    }

    $existing_fingerprint_id = tryzub_find_recent_reservation_by_submission_fingerprint(
        $reservation['submission_fingerprint'],
        $post->post_date
    );

    if ($existing_fingerprint_id) {
        tryzub_record_duplicate_import($post, $existing_fingerprint_id, 'fingerprint_recent_match', $reservation);
        tryzub_mark_import_failure_resolved($source_submission_id, 'Skipped duplicate import by recent submission fingerprint.');

        return [
            'status' => 'skipped',
            'source_submission_id' => $source_submission_id,
            'duplicate_of_reservation_id' => $existing_fingerprint_id,
            'duplicate_reason' => 'fingerprint_recent_match'
        ];
    }

    $insert_result = tryzub_insert_managed_reservation($reservation);

    if (is_wp_error($insert_result)) {
        tryzub_record_import_failure($insert_result, $post);
        $error_data = $insert_result->get_error_data();

        if (!is_array($error_data)) {
            $error_data = [];
        }

        $error_data['source_submission_id'] = $source_submission_id;

        return new WP_Error(
            $insert_result->get_error_code(),
            $insert_result->get_error_message(),
            $error_data
        );
    }

    tryzub_mark_import_failure_resolved($source_submission_id, 'Imported into managed reservations.');

    $managed_reservation_id = (int) $insert_result;
    tryzub_reservation_activity_log(
        $managed_reservation_id,
        'imported',
        'Reservation imported from website form.',
        [
            'source' => tryzub_reservation_activity_normalize_source($activity_source),
            'metadata' => [
                'source_submission_id' => $source_submission_id,
            ],
        ]
    );

    $auto_confirm_result = null;

    if (($reservation['source_type'] ?? 'form') === 'form') {
        $auto_confirm_result = tryzub_auto_confirm_apply_if_eligible($managed_reservation_id, 'form_import');
    }

    return [
        'status' => 'imported',
        'source_submission_id' => $source_submission_id,
        'managed_reservation_id' => $managed_reservation_id,
        'auto_confirm' => $auto_confirm_result,
    ];
}

function tryzub_build_submission_fingerprint(array $reservation) {
    $time = tryzub_normalize_reservation_time($reservation['reservation_time'] ?? '');
    $notes = $reservation['notes'] ?? ($reservation['guest_notes'] ?? '');
    $parts = [
        'guest_name' => tryzub_fingerprint_text($reservation['guest_name'] ?? '', true),
        'email' => strtolower(trim(sanitize_email((string) ($reservation['email'] ?? '')))),
        'phone' => tryzub_normalize_phone_digits($reservation['phone'] ?? ''),
        'reservation_date' => sanitize_text_field((string) ($reservation['reservation_date'] ?? '')),
        'reservation_time' => $time ?: '',
        'party_size' => absint($reservation['party_size'] ?? 0),
        'guest_notes' => tryzub_fingerprint_text($notes, true),
    ];

    return hash('sha256', wp_json_encode($parts));
}

function tryzub_fingerprint_text($value, $lowercase = false) {
    $value = preg_replace('/\s+/', ' ', trim(sanitize_textarea_field((string) $value)));

    return $lowercase ? strtolower($value) : $value;
}

function tryzub_find_managed_reservation_by_client_request_id($client_request_id) {
    global $wpdb;

    $client_request_id = tryzub_normalize_client_request_id($client_request_id);

    if (!$client_request_id) {
        return null;
    }

    $table_name = tryzub_get_reservations_table_name();
    $existing_id = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT id FROM $table_name WHERE client_request_id = %s ORDER BY id ASC LIMIT 1",
            $client_request_id
        )
    );

    return $existing_id ? (int) $existing_id : null;
}

function tryzub_find_recent_reservation_by_submission_fingerprint($fingerprint, $submitted_at, $window_seconds = 300) {
    global $wpdb;

    $fingerprint = sanitize_text_field((string) $fingerprint);

    if ($fingerprint === '') {
        return null;
    }

    $submitted_timestamp = strtotime((string) $submitted_at);

    if (!$submitted_timestamp) {
        $submitted_timestamp = current_time('timestamp');
    }

    $window_seconds = max(60, absint($window_seconds));
    $window_start = date('Y-m-d H:i:s', $submitted_timestamp - $window_seconds);
    $window_end = date('Y-m-d H:i:s', $submitted_timestamp + $window_seconds);
    $table_name = tryzub_get_reservations_table_name();
    $posts_table = $wpdb->posts;

    $existing_id = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT r.id
            FROM $table_name r
            LEFT JOIN $posts_table p ON p.ID = r.source_submission_id
            WHERE r.submission_fingerprint = %s
            AND (
                (r.source_submission_id IS NOT NULL AND p.post_date BETWEEN %s AND %s)
                OR (r.source_submission_id IS NULL AND r.created_at BETWEEN %s AND %s)
                OR (r.source_submission_id IS NOT NULL AND p.ID IS NULL AND r.created_at BETWEEN %s AND %s)
            )
            ORDER BY r.id ASC
            LIMIT 1",
            $fingerprint,
            $window_start,
            $window_end,
            $window_start,
            $window_end,
            $window_start,
            $window_end
        )
    );

    return $existing_id ? (int) $existing_id : null;
}

function tryzub_record_duplicate_import(WP_Post $post, $existing_reservation_id, $duplicate_reason, array $reservation) {
    global $wpdb;

    $table_name = tryzub_get_reservation_duplicate_imports_table_name();
    $raw_fields = tryzub_extract_submission_fields($post->ID);
    $raw_payload = [
        'id' => (int) $post->ID,
        'post_date' => $post->post_date,
        'post_date_gmt' => $post->post_date_gmt,
        'post_status' => $post->post_status,
        'post_type' => $post->post_type,
        'submission_status' => get_post_meta($post->ID, '_submission_status', true),
    ];
    $now = current_time('mysql');
    $data = [
        'source_submission_id' => (int) $post->ID,
        'existing_reservation_id' => absint($existing_reservation_id),
        'duplicate_reason' => sanitize_text_field((string) $duplicate_reason),
        'client_request_id' => tryzub_normalize_client_request_id($reservation['client_request_id'] ?? null),
        'submission_fingerprint' => sanitize_text_field((string) ($reservation['submission_fingerprint'] ?? '')),
        'reservation_snapshot_json' => wp_json_encode($reservation),
        'raw_fields_json' => wp_json_encode($raw_fields),
        'raw_payload_json' => wp_json_encode($raw_payload),
        'created_at' => $now,
    ];
    $formats = ['%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s'];

    $existing_log_id = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT id FROM $table_name WHERE source_submission_id = %d LIMIT 1",
            (int) $post->ID
        )
    );

    if ($existing_log_id) {
        $updated = $wpdb->update(
            $table_name,
            $data,
            ['id' => absint($existing_log_id)],
            $formats,
            ['%d']
        );

        if ($updated === false) {
            error_log('Tryzub duplicate import log update failed: ' . $wpdb->last_error);
        }

        return;
    }

    $inserted = $wpdb->insert($table_name, $data, $formats);

    if ($inserted === false) {
        error_log('Tryzub duplicate import log insert failed: ' . $wpdb->last_error);
    }
}

function tryzub_validate_importable_reservation(array $reservation) {
    $source_submission_id = (int) ($reservation['id'] ?? 0);

    // Required-field validation happens on the backend even though CF7 also requires these fields.
    // Form-level validation is not enough because old data, spam, field-name changes, or plugin issues can still produce bad records.
    if (empty($reservation['guest_name']) || empty($reservation['email']) || empty($reservation['phone']) || empty($reservation['reservation_date']) || empty($reservation['reservation_time']) || $reservation['party_size'] === null) {
        return new WP_Error(
            'tryzub_import_missing_required_fields',
            'Required reservation fields are missing.',
            [
                'source_submission_id' => $source_submission_id,
                'reservation' => $reservation
            ]
        );
    }

    // Validate time before insert because the managed table stores reservation_time as SQL TIME.
    $normalized_time = tryzub_normalize_reservation_time($reservation['reservation_time'] ?? '');

    if (!$normalized_time) {
        return new WP_Error(
            'tryzub_import_invalid_time',
            'Invalid reservation time format.',
            [
                'source_submission_id' => $source_submission_id,
                'reservation_time' => $reservation['reservation_time'] ?? null,
                'reservation' => $reservation
            ]
        );
    }

    return null;
}

function tryzub_format_import_error(WP_Error $error) {
    $error_data = $error->get_error_data();

    if (!is_array($error_data)) {
        $error_data = [];
    }

    $formatted = [
        'source_submission_id' => isset($error_data['source_submission_id']) ? (int) $error_data['source_submission_id'] : null,
        'error_code' => $error->get_error_code(),
        'error_message' => $error->get_error_message()
    ];

    foreach (['reservation', 'reservation_time'] as $key) {
        if (array_key_exists($key, $error_data)) {
            $formatted[$key] = $error_data[$key];
        }
    }

    return $formatted;
}

function tryzub_record_import_failure(WP_Error $error, $post = null) {
    global $wpdb;

    $error_data = $error->get_error_data();

    if (!is_array($error_data)) {
        $error_data = [];
    }

    $source_submission_id = absint($error_data['source_submission_id'] ?? 0);

    if (!$source_submission_id && $post instanceof WP_Post) {
        $source_submission_id = absint($post->ID);
    }

    $reservation = $error_data['reservation'] ?? null;

    if (!$reservation && $post instanceof WP_Post) {
        $reservation = tryzub_format_reservation($post);
    }

    $raw_fields = $post instanceof WP_Post ? tryzub_extract_submission_fields($post->ID) : null;
    $raw_payload = $post instanceof WP_Post ? [
        'id' => (int) $post->ID,
        'post_date' => $post->post_date,
        'post_date_gmt' => $post->post_date_gmt,
        'post_status' => $post->post_status,
        'post_type' => $post->post_type,
        'submission_status' => get_post_meta($post->ID, '_submission_status', true),
    ] : null;

    $table_name = tryzub_get_import_failures_table_name();
    $now = current_time('mysql');
    $data = [
        'source_submission_id' => $source_submission_id ?: null,
        'error_code' => sanitize_text_field($error->get_error_code()),
        'error_message' => sanitize_text_field($error->get_error_message()),
        'reservation_snapshot_json' => $reservation ? wp_json_encode($reservation) : null,
        'raw_fields_json' => $raw_fields ? wp_json_encode($raw_fields) : null,
        'raw_payload_json' => $raw_payload ? wp_json_encode($raw_payload) : null,
        'submission_status' => $post instanceof WP_Post ? sanitize_text_field((string) get_post_meta($post->ID, '_submission_status', true)) : null,
        'status' => 'open',
        'submitted_at' => $post instanceof WP_Post ? $post->post_date : null,
        'submitted_at_gmt' => $post instanceof WP_Post ? $post->post_date_gmt : null,
        'updated_at' => $now,
    ];
    $formats = [
        '%d',
        '%s',
        '%s',
        '%s',
        '%s',
        '%s',
        '%s',
        '%s',
        '%s',
        '%s',
        '%s',
    ];

    $existing_id = $source_submission_id ? $wpdb->get_var(
        $wpdb->prepare(
            "SELECT id FROM $table_name WHERE source_submission_id = %d LIMIT 1",
            $source_submission_id
        )
    ) : null;

    if ($existing_id) {
        $updated = $wpdb->update(
            $table_name,
            $data,
            ['id' => absint($existing_id)],
            $formats,
            ['%d']
        );

        if ($updated === false) {
            error_log('Tryzub failed import update failed: ' . $wpdb->last_error);
        }

        return;
    }

    $data['created_at'] = $now;
    $formats[] = '%s';

    $inserted = $wpdb->insert($table_name, $data, $formats);

    if ($inserted === false) {
        error_log('Tryzub failed import insert failed: ' . $wpdb->last_error);
    }
}

function tryzub_mark_import_failure_resolved($source_submission_id, $note = '') {
    global $wpdb;

    $source_submission_id = absint($source_submission_id);

    if (!$source_submission_id) {
        return;
    }

    $table_name = tryzub_get_import_failures_table_name();
    $wpdb->update(
        $table_name,
        [
            'status' => 'resolved',
            'staff_notes' => sanitize_textarea_field($note),
            'resolved_at' => current_time('mysql'),
            'updated_at' => current_time('mysql'),
        ],
        ['source_submission_id' => $source_submission_id],
        ['%s', '%s', '%s', '%s'],
        ['%d']
    );
}

function tryzub_format_import_failure_row(array $row) {
    return [
        'id' => (int) $row['id'],
        'source_submission_id' => $row['source_submission_id'] !== null ? (int) $row['source_submission_id'] : null,
        'error_code' => $row['error_code'],
        'error_message' => $row['error_message'],
        'reservation' => tryzub_decode_json_column($row['reservation_snapshot_json'] ?? null),
        'raw_fields' => tryzub_decode_json_column($row['raw_fields_json'] ?? null),
        'raw_payload' => tryzub_decode_json_column($row['raw_payload_json'] ?? null),
        'submitted_at' => $row['submitted_at'],
        'submitted_at_gmt' => $row['submitted_at_gmt'],
        'submission_status' => $row['submission_status'],
        'status' => $row['status'],
        'staff_notes' => $row['staff_notes'],
        'resolved_at' => $row['resolved_at'],
        'created_at' => $row['created_at'],
        'updated_at' => $row['updated_at'],
    ];
}

function tryzub_decode_json_column($value) {
    if (!$value) {
        return null;
    }

    $decoded = json_decode((string) $value, true);

    return is_array($decoded) ? $decoded : null;
}

// Flamingo fires this action after it has saved the CF7 submission as an inbound post.
// Importing here makes the managed table update automatically, so the iOS app can see new reservations on refresh.
function tryzub_import_after_flamingo_submission($result) {
    $status = is_array($result) ? ($result['status'] ?? '') : '';

    // Flamingo stores spam too, but the managed reservation table should only receive real booking attempts.
    // mail_failed is included because a valid reservation should not be lost just because the notification email failed.
    if (!in_array($status, ['mail_sent', 'mail_failed'], true)) {
        return;
    }

    $source_submission_id = is_array($result) ? absint($result['flamingo_inbound_id'] ?? 0) : 0;
    $import_result = tryzub_import_managed_reservation_by_source_id($source_submission_id);

    if (is_wp_error($import_result)) {
        error_log(
            'Tryzub reservation auto-import failed for Flamingo ID '
            . $source_submission_id
            . ': '
            . $import_result->get_error_message()
        );
    }
}

add_action('wpcf7_after_flamingo', 'tryzub_import_after_flamingo_submission', 20, 1);
