<?php

function tryzub_get_restaurant_blocked_slots(WP_REST_Request $request) {
    $date = tryzub_get_required_blocked_slots_date($request);

    if (is_wp_error($date)) {
        return $date;
    }

    return rest_ensure_response([
        'success' => true,
        'date' => $date,
        'data' => tryzub_get_blocked_slot_rows_for_date($date),
    ]);
}

function tryzub_create_restaurant_blocked_slots(WP_REST_Request $request) {
    $body = tryzub_get_rest_request_body($request);
    $allowed_fields = ['date', 'slots', 'reason'];
    $unknown_fields = array_diff(array_keys($body), $allowed_fields);

    if (!empty($unknown_fields)) {
        return new WP_Error(
            'tryzub_unknown_blocked_slots_field',
            'Unknown blocked slots field: ' . implode(', ', array_values($unknown_fields)),
            ['status' => 400]
        );
    }

    $date = tryzub_get_required_blocked_slots_date($request, $body);

    if (is_wp_error($date)) {
        return $date;
    }

    $slot_times = tryzub_prepare_blocked_slot_times($body['slots'] ?? null);

    if (is_wp_error($slot_times)) {
        return $slot_times;
    }

    $valid_slots = tryzub_validate_blocked_slots_are_generated($date, $slot_times);

    if (is_wp_error($valid_slots)) {
        return $valid_slots;
    }

    $reason = array_key_exists('reason', $body) ? sanitize_textarea_field((string) $body['reason']) : null;
    $saved = tryzub_upsert_blocked_slots($date, $slot_times, $reason);

    if (is_wp_error($saved)) {
        return $saved;
    }

    return rest_ensure_response([
        'success' => true,
        'date' => $date,
        'data' => tryzub_get_blocked_slot_rows_for_date($date),
    ]);
}

function tryzub_delete_restaurant_blocked_slots(WP_REST_Request $request) {
    $body = tryzub_get_rest_request_body($request);
    $allowed_fields = ['date', 'slots'];
    $unknown_fields = array_diff(array_keys($body), $allowed_fields);

    if (!empty($unknown_fields)) {
        return new WP_Error(
            'tryzub_unknown_blocked_slots_field',
            'Unknown blocked slots field: ' . implode(', ', array_values($unknown_fields)),
            ['status' => 400]
        );
    }

    $date = tryzub_get_required_blocked_slots_date($request, $body);

    if (is_wp_error($date)) {
        return $date;
    }

    $slot_times = null;

    if (array_key_exists('slots', $body)) {
        $slot_times = tryzub_prepare_blocked_slot_times($body['slots']);

        if (is_wp_error($slot_times)) {
            return $slot_times;
        }
    }

    $deleted = tryzub_delete_blocked_slots($date, $slot_times);

    if (is_wp_error($deleted)) {
        return $deleted;
    }

    return rest_ensure_response([
        'success' => true,
        'date' => $date,
        'data' => tryzub_get_blocked_slot_rows_for_date($date),
    ]);
}

function tryzub_get_blocked_slots_for_date($date) {
    global $wpdb;

    $table_name = tryzub_get_restaurant_blocked_slots_table_name();
    $rows = $wpdb->get_col(
        $wpdb->prepare(
            "SELECT slot_time
            FROM $table_name
            WHERE restaurant_key = %s AND reservation_date = %s
            ORDER BY slot_time ASC",
            tryzub_get_restaurant_key(),
            $date
        )
    );

    return array_map('tryzub_format_blocked_slot_time_value', $rows ?: []);
}

function tryzub_get_blocked_slot_rows_for_date($date) {
    global $wpdb;

    $table_name = tryzub_get_restaurant_blocked_slots_table_name();
    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT id, reservation_date, slot_time, reason, created_by_user_id, created_at
            FROM $table_name
            WHERE restaurant_key = %s AND reservation_date = %s
            ORDER BY slot_time ASC",
            tryzub_get_restaurant_key(),
            $date
        ),
        ARRAY_A
    );

    return array_map('tryzub_format_blocked_slot_row', $rows ?: []);
}

function tryzub_format_blocked_slot_row(array $row) {
    return [
        'id' => (int) $row['id'],
        'reservation_date' => $row['reservation_date'],
        'slot_time' => tryzub_format_blocked_slot_time_value($row['slot_time']),
        'reason' => $row['reason'],
        'created_by_user_id' => $row['created_by_user_id'] === null ? null : (int) $row['created_by_user_id'],
        'created_at' => $row['created_at'],
    ];
}

function tryzub_normalize_slot_time($value) {
    $normalized = tryzub_normalize_reservation_time($value);

    if (!$normalized) {
        return new WP_Error(
            'tryzub_invalid_blocked_slot_time',
            'Blocked slot time must be a valid time.',
            ['status' => 400]
        );
    }

    $parts = array_map('absint', explode(':', $normalized));
    $minute = (int) ($parts[1] ?? 0);
    $second = (int) ($parts[2] ?? 0);

    if ($second !== 0 || !in_array($minute, [0, 15, 30, 45], true)) {
        return new WP_Error(
            'tryzub_invalid_blocked_slot_boundary',
            'Blocked slot time must be on a 15-minute boundary.',
            ['status' => 400]
        );
    }

    return $normalized;
}

function tryzub_prepare_blocked_slot_times($slots) {
    if (!is_array($slots) || empty($slots)) {
        return new WP_Error(
            'tryzub_invalid_blocked_slots',
            'slots must be a non-empty array.',
            ['status' => 400]
        );
    }

    if (count($slots) > 100) {
        return new WP_Error(
            'tryzub_too_many_blocked_slots',
            'A maximum of 100 blocked slots can be updated at once.',
            ['status' => 400]
        );
    }

    $normalized_slots = [];

    foreach ($slots as $slot) {
        $normalized = tryzub_normalize_slot_time($slot);

        if (is_wp_error($normalized)) {
            return $normalized;
        }

        $normalized_slots[] = $normalized;
    }

    return array_values(array_unique($normalized_slots));
}

function tryzub_validate_blocked_slots_are_generated($date, array $slot_times) {
    $availability = tryzub_get_effective_restaurant_day_availability($date);

    if (!$availability['is_open'] || !$availability['open_time'] || !$availability['close_time']) {
        return new WP_Error(
            'tryzub_blocked_slots_date_closed',
            'Cannot block slots because reservations are not available for this date.',
            ['status' => 400]
        );
    }

    $generated_slots = tryzub_generate_reservation_slots(
        $date,
        $availability['open_time'],
        $availability['close_time'],
        (int) $availability['slot_interval_minutes']
    );
    $generated_slot_values = array_flip(array_column($generated_slots, 'value'));

    foreach ($slot_times as $slot_time) {
        $slot_value = tryzub_format_blocked_slot_time_value($slot_time);

        if (!isset($generated_slot_values[$slot_value])) {
            return new WP_Error(
                'tryzub_blocked_slot_outside_available_slots',
                'Blocked slot is outside available reservation slots for this date: ' . $slot_value,
                ['status' => 400]
            );
        }
    }

    return true;
}

function tryzub_upsert_blocked_slots($date, array $slot_times, $reason) {
    global $wpdb;

    $table_name = tryzub_get_restaurant_blocked_slots_table_name();
    $restaurant_key = tryzub_get_restaurant_key();
    $user_id = get_current_user_id() ?: null;
    $reason = $reason === '' ? null : $reason;
    $now = current_time('mysql');

    foreach ($slot_times as $slot_time) {
        $reason_sql = $reason === null ? 'NULL' : '%s';
        $user_id_sql = $user_id === null ? 'NULL' : '%d';
        $params = [$restaurant_key, $date, $slot_time];

        if ($reason !== null) {
            $params[] = $reason;
        }

        if ($user_id !== null) {
            $params[] = $user_id;
        }

        $params[] = $now;

        $inserted = $wpdb->query(
            $wpdb->prepare(
                "INSERT INTO $table_name
                (restaurant_key, reservation_date, slot_time, reason, created_by_user_id, created_at, updated_at)
                VALUES (%s, %s, %s, $reason_sql, $user_id_sql, %s, NULL)
                ON DUPLICATE KEY UPDATE reason = VALUES(reason), updated_at = VALUES(created_at)",
                $params
            )
        );

        if ($inserted === false) {
            return tryzub_blocked_slots_database_error('Failed to save blocked slots.');
        }
    }

    return true;
}

function tryzub_delete_blocked_slots($date, $slot_times = null) {
    global $wpdb;

    $table_name = tryzub_get_restaurant_blocked_slots_table_name();
    $restaurant_key = tryzub_get_restaurant_key();

    if ($slot_times === null) {
        $deleted = $wpdb->delete(
            $table_name,
            [
                'restaurant_key' => $restaurant_key,
                'reservation_date' => $date,
            ],
            ['%s', '%s']
        );

        if ($deleted === false) {
            return tryzub_blocked_slots_database_error('Failed to delete blocked slots.');
        }

        return true;
    }

    $slot_placeholders = implode(', ', array_fill(0, count($slot_times), '%s'));
    $deleted = $wpdb->query(
        $wpdb->prepare(
            "DELETE FROM $table_name
            WHERE restaurant_key = %s
            AND reservation_date = %s
            AND slot_time IN ($slot_placeholders)",
            array_merge([$restaurant_key, $date], $slot_times)
        )
    );

    if ($deleted === false) {
        return tryzub_blocked_slots_database_error('Failed to delete blocked slots.');
    }

    return true;
}

function tryzub_get_required_blocked_slots_date(WP_REST_Request $request, ?array $body = null) {
    $date = $body && array_key_exists('date', $body) ? $body['date'] : $request->get_param('date');

    if (!$date) {
        return new WP_Error(
            'tryzub_missing_date',
            'date is required.',
            ['status' => 400]
        );
    }

    return tryzub_normalize_blocked_slots_date($date);
}

function tryzub_normalize_blocked_slots_date($value) {
    $value = sanitize_text_field((string) $value);
    $date = DateTime::createFromFormat('Y-m-d', $value);
    $errors = DateTime::getLastErrors();

    if (
        !$date instanceof DateTime ||
        $date->format('Y-m-d') !== $value ||
        (
            $errors !== false &&
            ((int) $errors['warning_count'] > 0 || (int) $errors['error_count'] > 0)
        )
    ) {
        return new WP_Error(
            'tryzub_invalid_date',
            'date must be a valid YYYY-MM-DD date.',
            ['status' => 400]
        );
    }

    return $value;
}

function tryzub_format_blocked_slot_time_value($time) {
    return substr((string) $time, 0, 5);
}

function tryzub_blocked_slots_database_error($message) {
    global $wpdb;

    error_log('Tryzub blocked slots database error: ' . $wpdb->last_error);

    return new WP_Error(
        'tryzub_database_error',
        $message,
        ['status' => 500]
    );
}
