<?php

// Legacy/raw read endpoint.
// Reads formatted Flamingo submissions directly.
// Useful for debugging and comparing raw form intake, but the iOS app should move to GET /managed-reservations.
// Reads Flamingo inbound messages, formats them as reservations, optionally filters by reservation date, and returns paginated JSON.
function tryzub_get_reservations(WP_REST_Request $request) {
    $per_page = min(max((int) $request->get_param('per_page'), 1), 100);
    $page = max((int) $request->get_param('page'), 1);
    $date = $request->get_param('date');
    $from = $request->get_param('from');
    $to = $request->get_param('to');

    // Date filters are applied after formatting because reservation_date lives inside Flamingo field metadata.
    $has_date_filter = $date || $from || $to;

    $query = new WP_Query([
        'post_type' => 'flamingo_inbound',
        'post_status' => 'any',
        // When filtering by reservation date, fetch a larger recent batch and filter in PHP.
        // This is acceptable for the current low reservation volume.
        'posts_per_page' => $has_date_filter ? 100 : $per_page,
        // Force page 1 when date-filtering so we do not filter only page 2 or later.
        'paged' => $has_date_filter ? 1 : $page,
        'orderby' => 'date',
        'order' => 'ASC'
    ]);

    $reservations = [];
    // Convert each raw Flamingo post into the stable reservation shape used by the API.
    foreach ($query->posts as $post) {
        $reservation = tryzub_format_reservation($post);
        if (tryzub_reservation_matches_date_filter($reservation, $date, $from, $to)) {
            $reservations[] = $reservation;
        }
    }

    return rest_ensure_response([
        // When filtering in PHP, response metadata describes the filtered result set.
        'page' => $has_date_filter ? 1 : $page,
        'per_page' => $has_date_filter ? 100 : $per_page,
        'total' => $has_date_filter ? count($reservations) : (int) $query->found_posts,
        'total_pages' => $has_date_filter ? 1 : (int) $query->max_num_pages,
        'data' => $reservations
    ]);
}
