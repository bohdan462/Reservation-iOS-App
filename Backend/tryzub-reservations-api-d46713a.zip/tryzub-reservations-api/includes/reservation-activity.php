<?php

function tryzub_reservation_activity_event_types() {
    return [
        'created',
        'imported',
        'updated',
        'status_changed',
        'cancelled',
        'confirmed',
        'seated',
        'completed',
        'no_show',
        'table_assigned',
        'table_cleared',
        'guest_note_updated',
        'staff_note_updated',
        'manager_note_updated',
        'deposit_updated',
        'preorder_updated',
        'attachment_added',
        'attachment_removed',
        'email_draft_created',
        'manual_email_sent',
        'manual_email_failed',
        'guest_manage_link_created',
        'guest_cancelled',
        'guest_change_requested',
        'hidden',
        'restored',
        'hard_deleted',
        'auto_completed',
        'auto_confirmed',
        'auto_confirm_failed',
    ];
}

function tryzub_reservation_activity_allowed_sources() {
    return [
        'backend',
        'ios',
        'flamingo_auto_import',
        'manual_import',
        'guest_self_service',
        'auto_confirm',
    ];
}

function tryzub_reservation_activity_normalize_source($source) {
    $source = sanitize_text_field((string) $source);

    if (in_array($source, tryzub_reservation_activity_allowed_sources(), true)) {
        return $source;
    }

    return 'backend';
}

function tryzub_reservation_activity_request_context(array $body = []) {
    $source = 'backend';

    if (!empty($_SERVER['HTTP_X_TRYZUB_SOURCE'])) {
        $source = tryzub_reservation_activity_normalize_source($_SERVER['HTTP_X_TRYZUB_SOURCE']);
    }

    return ['source' => $source];
}

function tryzub_reservation_activity_sensitive_field_keys() {
    return ['email', 'phone', 'guest_notes', 'staff_notes', 'hidden_reason'];
}

function tryzub_reservation_activity_scrub_value($value) {
    if ($value === null || $value === '') {
        return $value;
    }

    $text = is_scalar($value) ? (string) $value : wp_json_encode($value);

    if ($text === false || $text === '') {
        return $text;
    }

    $text = preg_replace('/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/', '[email]', $text);
    $text = preg_replace('/\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b/', '[phone]', $text);
    $text = preg_replace('/\b(token|bearer)\s*[:\=]\s*\S+/i', '[token]', $text);

    return $text;
}

function tryzub_reservation_activity_scrub_field_value($field, $value) {
    if (in_array($field, ['email', 'phone'], true)) {
        return '[redacted]';
    }

    if (in_array($field, ['guest_notes', 'staff_notes', 'hidden_reason'], true)) {
        return tryzub_reservation_activity_scrub_value($value);
    }

    return $value;
}

function tryzub_reservation_activity_scrub_metadata($metadata) {
    if (!is_array($metadata)) {
        return [];
    }

    $scrubbed = [];

    foreach ($metadata as $key => $value) {
        $key = sanitize_key((string) $key);

        if ($key === '') {
            continue;
        }

        if (is_array($value)) {
            $scrubbed[$key] = tryzub_reservation_activity_scrub_metadata($value);
            continue;
        }

        $scrubbed[$key] = tryzub_reservation_activity_scrub_value($value);
    }

    return $scrubbed;
}

function tryzub_reservation_activity_resolve_actor(array $args = []) {
    $user_id = array_key_exists('actor_user_id', $args) ? absint($args['actor_user_id']) : get_current_user_id();

    if ($user_id < 1) {
        return [
            'actor_user_id' => null,
            'actor_name' => !empty($args['actor_name']) ? sanitize_text_field((string) $args['actor_name']) : null,
            'actor_role' => !empty($args['actor_role']) ? sanitize_text_field((string) $args['actor_role']) : null,
        ];
    }

    $user = get_userdata($user_id);
    $display_name = !empty($args['actor_name'])
        ? sanitize_text_field((string) $args['actor_name'])
        : ($user ? sanitize_text_field((string) $user->display_name) : null);

    $role = !empty($args['actor_role'])
        ? sanitize_text_field((string) $args['actor_role'])
        : tryzub_reservation_activity_resolve_actor_role($user_id);

    return [
        'actor_user_id' => $user_id,
        'actor_name' => $display_name !== '' ? $display_name : null,
        'actor_role' => $role,
    ];
}

function tryzub_reservation_activity_resolve_actor_role($user_id) {
    $user_id = absint($user_id);

    if ($user_id < 1) {
        return null;
    }

    if (user_can($user_id, 'manage_options')) {
        return 'administrator';
    }

    if (user_can($user_id, 'manage_tryzub_reservations')) {
        return 'manager';
    }

    return 'staff';
}

function tryzub_reservation_activity_log($reservation_id, $event_type, $summary, $args = []) {
    global $wpdb;

    $reservation_id = absint($reservation_id);
    $event_type = sanitize_text_field((string) $event_type);
    $summary = trim(sanitize_textarea_field((string) $summary));

    if ($reservation_id < 1 || $summary === '') {
        return false;
    }

    if (!in_array($event_type, tryzub_reservation_activity_event_types(), true)) {
        error_log('Tryzub reservation activity skipped unknown event_type: ' . $event_type);

        return false;
    }

    if (!function_exists('tryzub_get_reservation_activity_table_name')) {
        error_log('Tryzub reservation activity table helper unavailable for reservation ' . $reservation_id);

        return false;
    }

    $actor = tryzub_reservation_activity_resolve_actor(is_array($args) ? $args : []);
    $source = tryzub_reservation_activity_normalize_source($args['source'] ?? 'backend');
    $created_at = !empty($args['created_at']) ? sanitize_text_field((string) $args['created_at']) : current_time('mysql');
    $created_at_gmt = !empty($args['created_at_gmt']) ? sanitize_text_field((string) $args['created_at_gmt']) : current_time('mysql', true);

    $old_value = null;
    $new_value = null;

    if (array_key_exists('old_value', $args)) {
        $old_value = is_scalar($args['old_value'])
            ? tryzub_reservation_activity_scrub_value((string) $args['old_value'])
            : tryzub_reservation_activity_scrub_value(wp_json_encode($args['old_value']));
    }

    if (array_key_exists('new_value', $args)) {
        $new_value = is_scalar($args['new_value'])
            ? tryzub_reservation_activity_scrub_value((string) $args['new_value'])
            : tryzub_reservation_activity_scrub_value(wp_json_encode($args['new_value']));
    }

    $metadata = [];

    if (!empty($args['metadata']) && is_array($args['metadata'])) {
        $metadata = tryzub_reservation_activity_scrub_metadata($args['metadata']);
    }

    $inserted = $wpdb->insert(
        tryzub_get_reservation_activity_table_name(),
        [
            'reservation_id' => $reservation_id,
            'event_type' => $event_type,
            'actor_user_id' => $actor['actor_user_id'],
            'actor_name' => $actor['actor_name'],
            'actor_role' => $actor['actor_role'],
            'source' => $source,
            'summary' => $summary,
            'old_value' => $old_value,
            'new_value' => $new_value,
            'metadata_json' => !empty($metadata) ? wp_json_encode($metadata) : null,
            'created_at' => $created_at,
            'created_at_gmt' => $created_at_gmt,
        ],
        ['%d', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s']
    );

    if ($inserted === false) {
        error_log(
            'Tryzub reservation activity insert failed for reservation '
            . $reservation_id
            . ' event '
            . $event_type
            . ': '
            . $wpdb->last_error
        );

        return false;
    }

    return (int) $wpdb->insert_id;
}

function tryzub_reservation_activity_log_many($reservation_id, array $events, array $shared_args = []) {
    $logged = [];

    foreach ($events as $event) {
        if (!is_array($event)) {
            continue;
        }

        $event_type = $event['event_type'] ?? '';
        $summary = $event['summary'] ?? '';

        if ($event_type === '' || $summary === '') {
            continue;
        }

        $args = array_merge($shared_args, $event);
        unset($args['event_type'], $args['summary']);

        $insert_id = tryzub_reservation_activity_log($reservation_id, $event_type, $summary, $args);

        if ($insert_id) {
            $logged[] = [
                'id' => $insert_id,
                'event_type' => sanitize_text_field((string) $event_type),
            ];
        }
    }

    return $logged;
}

function tryzub_reservation_activity_mutation_meta(array $logged_events) {
    if (empty($logged_events)) {
        return null;
    }

    $event_types = [];

    foreach ($logged_events as $event) {
        if (!empty($event['event_type'])) {
            $event_types[] = sanitize_text_field((string) $event['event_type']);
        }
    }

    $event_types = array_values(array_unique($event_types));

    if (empty($event_types)) {
        return null;
    }

    return [
        'created' => true,
        'event_types' => $event_types,
    ];
}

function tryzub_reservation_activity_attach_to_response(array $response_data, array $logged_events) {
    $activity = tryzub_reservation_activity_mutation_meta($logged_events);

    if ($activity !== null) {
        $response_data['activity'] = $activity;
    }

    return $response_data;
}

function tryzub_reservation_activity_compare_values($field, $before, $after) {
    if (in_array($field, ['is_hidden'], true)) {
        return (int) $before !== (int) $after;
    }

    if (in_array($field, ['superseded_by_id'], true)) {
        return absint($before) !== absint($after);
    }

    if (in_array($field, ['party_size'], true)) {
        return absint($before) !== absint($after);
    }

    return trim((string) $before) !== trim((string) $after);
}

function tryzub_reservation_activity_format_time_label($time) {
    $normalized = function_exists('tryzub_normalize_reservation_time')
        ? tryzub_normalize_reservation_time($time)
        : null;

    return $normalized ?: sanitize_text_field((string) $time);
}

function tryzub_reservation_activity_format_table_label($table_name) {
    $table_name = trim(sanitize_text_field((string) $table_name));

    return $table_name !== '' ? $table_name : null;
}

function tryzub_reservation_activity_status_event_type($status) {
    $status = sanitize_text_field((string) $status);

    if (in_array($status, ['confirmed', 'seated', 'completed', 'cancelled', 'no_show'], true)) {
        return $status;
    }

    return 'status_changed';
}

function tryzub_reservation_activity_created_summary($source_type) {
    $source_type = sanitize_text_field((string) $source_type);

    if ($source_type === 'manual_call_in') {
        return 'Call-in reservation created.';
    }

    if ($source_type === 'manual_walk_in') {
        return 'Walk-in reservation created.';
    }

    if ($source_type === 'known_guest_manual') {
        return 'Known guest reservation created manually.';
    }

    if ($source_type === 'import_repair') {
        return 'Reservation created from import repair.';
    }

    return 'Reservation created manually.';
}

function tryzub_reservation_activity_summarize_update(array $before, array $after) {
    $events = [];
    $meaningful_fields = [
        'guest_name',
        'email',
        'phone',
        'reservation_date',
        'reservation_time',
        'party_size',
        'guest_notes',
        'staff_notes',
        'status',
        'table_name',
        'superseded_by_id',
        'is_hidden',
        'hidden_reason',
    ];
    $general_changes = [];

    foreach ($meaningful_fields as $field) {
        $before_value = $before[$field] ?? null;
        $after_value = $after[$field] ?? null;

        if (!tryzub_reservation_activity_compare_values($field, $before_value, $after_value)) {
            continue;
        }

        if ($field === 'is_hidden') {
            if ((int) $after_value === 1) {
                $events[] = [
                    'event_type' => 'hidden',
                    'summary' => 'Reservation hidden from active staff views.',
                    'metadata' => [
                        'hidden_reason_present' => trim((string) ($after['hidden_reason'] ?? '')) !== '',
                    ],
                ];
            } else {
                $events[] = [
                    'event_type' => 'restored',
                    'summary' => 'Reservation restored to active staff views.',
                ];
            }

            continue;
        }

        if ($field === 'status') {
            $from_status = sanitize_text_field((string) $before_value);
            $to_status = sanitize_text_field((string) $after_value);
            $event_type = tryzub_reservation_activity_status_event_type($to_status);
            $events[] = [
                'event_type' => $event_type,
                'summary' => 'Status changed from ' . $from_status . ' to ' . $to_status . '.',
                'metadata' => [
                    'from_status' => $from_status,
                    'to_status' => $to_status,
                ],
                'old_value' => $from_status,
                'new_value' => $to_status,
            ];

            continue;
        }

        if ($field === 'guest_notes') {
            $events[] = [
                'event_type' => 'guest_note_updated',
                'summary' => 'Guest note updated.',
                'metadata' => ['changed_fields' => ['guest_notes']],
            ];

            continue;
        }

        if ($field === 'staff_notes') {
            $events[] = [
                'event_type' => 'staff_note_updated',
                'summary' => 'Staff note updated.',
                'metadata' => ['changed_fields' => ['staff_notes']],
            ];

            continue;
        }

        if ($field === 'table_name') {
            $old_label = tryzub_reservation_activity_format_table_label($before_value);
            $new_label = tryzub_reservation_activity_format_table_label($after_value);

            if ($old_label === null && $new_label !== null) {
                $events[] = [
                    'event_type' => 'table_assigned',
                    'summary' => 'Table assigned: ' . $new_label . '.',
                    'metadata' => ['table_label' => $new_label],
                    'old_value' => null,
                    'new_value' => $new_label,
                ];
            } elseif ($old_label !== null && $new_label === null) {
                $events[] = [
                    'event_type' => 'table_cleared',
                    'summary' => 'Tables cleared.',
                    'metadata' => ['previous_table_label' => $old_label],
                    'old_value' => $old_label,
                    'new_value' => null,
                ];
            } else {
                $events[] = [
                    'event_type' => 'table_assigned',
                    'summary' => 'Table changed from ' . $old_label . ' to ' . $new_label . '.',
                    'metadata' => [
                        'previous_table_label' => $old_label,
                        'table_label' => $new_label,
                    ],
                    'old_value' => $old_label,
                    'new_value' => $new_label,
                ];
            }

            continue;
        }

        $general_changes[] = $field;
    }

    if (empty($general_changes)) {
        return $events;
    }

    $contact_fields = ['email', 'phone'];
    $only_contact = !array_diff($general_changes, $contact_fields);

    if ($only_contact) {
        $events[] = [
            'event_type' => 'updated',
            'summary' => 'Contact details updated.',
            'metadata' => ['changed_fields' => array_values($general_changes)],
        ];

        return $events;
    }

    $summary_parts = [];

    if (in_array('reservation_time', $general_changes, true)) {
        $summary_parts[] = 'Time changed from '
            . tryzub_reservation_activity_format_time_label($before['reservation_time'] ?? '')
            . ' to '
            . tryzub_reservation_activity_format_time_label($after['reservation_time'] ?? '')
            . '.';
    }

    if (in_array('party_size', $general_changes, true)) {
        $summary_parts[] = 'Party size changed from '
            . absint($before['party_size'] ?? 0)
            . ' to '
            . absint($after['party_size'] ?? 0)
            . '.';
    }

    if (in_array('reservation_date', $general_changes, true)) {
        $summary_parts[] = 'Date changed from '
            . sanitize_text_field((string) ($before['reservation_date'] ?? ''))
            . ' to '
            . sanitize_text_field((string) ($after['reservation_date'] ?? ''))
            . '.';
    }

    if (in_array('guest_name', $general_changes, true)) {
        $summary_parts[] = 'Guest name updated.';
    }

    if (array_intersect($contact_fields, $general_changes)) {
        $summary_parts[] = 'Contact details updated.';
    }

    $remaining = array_values(array_diff(
        $general_changes,
        ['reservation_time', 'party_size', 'reservation_date', 'guest_name', 'email', 'phone']
    ));

    foreach ($remaining as $field) {
        if ($field === 'superseded_by_id') {
            $summary_parts[] = 'Superseded reservation link updated.';
        } elseif ($field === 'hidden_reason') {
            $summary_parts[] = 'Hidden reason updated.';
        }
    }

    $summary = !empty($summary_parts)
        ? implode(' ', $summary_parts)
        : 'Reservation details updated.';

    $events[] = [
        'event_type' => 'updated',
        'summary' => $summary,
        'metadata' => ['changed_fields' => array_values($general_changes)],
    ];

    return $events;
}

function tryzub_reservation_activity_log_table_assignment_change($reservation_id, $before_label, $after_label, array $args = []) {
    $before_label = tryzub_reservation_activity_format_table_label($before_label);
    $after_label = tryzub_reservation_activity_format_table_label($after_label);

    if ($before_label === $after_label) {
        return [];
    }

    if ($before_label === null && $after_label !== null) {
        return tryzub_reservation_activity_log_many($reservation_id, [[
            'event_type' => 'table_assigned',
            'summary' => 'Table assigned: ' . $after_label . '.',
            'metadata' => ['table_label' => $after_label],
            'old_value' => null,
            'new_value' => $after_label,
        ]], $args);
    }

    if ($before_label !== null && $after_label === null) {
        return tryzub_reservation_activity_log_many($reservation_id, [[
            'event_type' => 'table_cleared',
            'summary' => 'Tables cleared.',
            'metadata' => ['previous_table_label' => $before_label],
            'old_value' => $before_label,
            'new_value' => null,
        ]], $args);
    }

    return tryzub_reservation_activity_log_many($reservation_id, [[
        'event_type' => 'table_assigned',
        'summary' => 'Table changed from ' . $before_label . ' to ' . $after_label . '.',
        'metadata' => [
            'previous_table_label' => $before_label,
            'table_label' => $after_label,
        ],
        'old_value' => $before_label,
        'new_value' => $after_label,
    ]], $args);
}

function tryzub_reservation_activity_public_item(array $row, $include_debug = false) {
    $metadata = null;

    if (!empty($row['metadata_json'])) {
        $decoded = json_decode((string) $row['metadata_json'], true);
        $metadata = is_array($decoded) ? tryzub_reservation_activity_scrub_metadata($decoded) : null;
    }

    $item = [
        'id' => (int) ($row['id'] ?? 0),
        'reservation_id' => (int) ($row['reservation_id'] ?? 0),
        'event_type' => sanitize_text_field((string) ($row['event_type'] ?? '')),
        'summary' => sanitize_textarea_field((string) ($row['summary'] ?? '')),
        'actor_name' => !empty($row['actor_name']) ? sanitize_text_field((string) $row['actor_name']) : null,
        'actor_role' => !empty($row['actor_role']) ? sanitize_text_field((string) $row['actor_role']) : null,
        'source' => sanitize_text_field((string) ($row['source'] ?? 'backend')),
        'created_at' => sanitize_text_field((string) ($row['created_at'] ?? '')),
        'created_at_gmt' => sanitize_text_field((string) ($row['created_at_gmt'] ?? '')),
        'metadata' => $metadata,
    ];

    if ($include_debug) {
        $item['old_value'] = array_key_exists('old_value', $row) ? $row['old_value'] : null;
        $item['new_value'] = array_key_exists('new_value', $row) ? $row['new_value'] : null;
        $item['actor_user_id'] = !empty($row['actor_user_id']) ? (int) $row['actor_user_id'] : null;
    }

    return $item;
}

function tryzub_reservation_activity_get_for_reservation($reservation_id, $limit = 25, $page = 1, $include_debug = false) {
    global $wpdb;

    $reservation_id = absint($reservation_id);
    $limit = min(max(absint($limit), 1), 100);
    $page = max(absint($page), 1);
    $offset = ($page - 1) * $limit;
    $table_name = tryzub_get_reservation_activity_table_name();

    $total = (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE reservation_id = %d",
            $reservation_id
        )
    );

    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT *
            FROM $table_name
            WHERE reservation_id = %d
            ORDER BY created_at DESC, id DESC
            LIMIT %d OFFSET %d",
            $reservation_id,
            $limit,
            $offset
        ),
        ARRAY_A
    );

    return [
        'reservation_id' => $reservation_id,
        'page' => $page,
        'per_page' => $limit,
        'total' => $total,
        'total_pages' => $total > 0 ? (int) ceil($total / $limit) : 0,
        'data' => array_map(
            function ($row) use ($include_debug) {
                return tryzub_reservation_activity_public_item($row, $include_debug);
            },
            $rows ?: []
        ),
    ];
}

function tryzub_reservation_activity_build_summary_counts(array $rows) {
    $summary = [];

    foreach ($rows as $row) {
        $event_type = sanitize_text_field((string) ($row['event_type'] ?? ''));

        if ($event_type === '') {
            continue;
        }

        if (!isset($summary[$event_type])) {
            $summary[$event_type] = 0;
        }

        $summary[$event_type]++;
    }

    ksort($summary);

    return $summary;
}

function tryzub_reservation_activity_get_for_date($date, $limit = 50, $page = 1, $filters = []) {
    return tryzub_reservation_activity_query_feed(
        [
            'from' => $date,
            'to' => $date,
        ],
        $limit,
        $page,
        $filters
    );
}

function tryzub_reservation_activity_query_feed(array $range, $limit = 50, $page = 1, $filters = []) {
    global $wpdb;

    $limit = min(max(absint($limit), 1), 100);
    $page = max(absint($page), 1);
    $offset = ($page - 1) * $limit;
    $activity_table = tryzub_get_reservation_activity_table_name();
    $reservations_table = tryzub_get_reservations_table_name();
    $include_debug = !empty($filters['include_debug']);
    $reservation_id = !empty($filters['reservation_id']) ? absint($filters['reservation_id']) : 0;
    $event_type = !empty($filters['event_type']) ? sanitize_text_field((string) $filters['event_type']) : '';

    $from = !empty($range['from']) ? sanitize_text_field((string) $range['from']) : '';
    $to = !empty($range['to']) ? sanitize_text_field((string) $range['to']) : '';

    if ($from === '' || $to === '') {
        return new WP_Error(
            'tryzub_activity_invalid_range',
            'A valid from/to date range is required.',
            ['status' => 400]
        );
    }

    if (
        !tryzub_is_valid_managed_reservation_date($from) ||
        !tryzub_is_valid_managed_reservation_date($to) ||
        $from > $to
    ) {
        return new WP_Error(
            'tryzub_activity_invalid_range',
            'Date range must use valid YYYY-MM-DD values with from <= to.',
            ['status' => 400]
        );
    }

    $where = ['r.reservation_date BETWEEN %s AND %s'];
    $values = [$from, $to];

    if ($reservation_id > 0) {
        $where[] = 'a.reservation_id = %d';
        $values[] = $reservation_id;
    }

    if ($event_type !== '') {
        if (!in_array($event_type, tryzub_reservation_activity_event_types(), true)) {
            return new WP_Error(
                'tryzub_activity_invalid_event_type',
                'Invalid activity event_type filter.',
                ['status' => 400]
            );
        }

        $where[] = 'a.event_type = %s';
        $values[] = $event_type;
    }

    $where_sql = implode(' AND ', $where);

    $count_sql = "SELECT COUNT(*)
        FROM $activity_table a
        INNER JOIN $reservations_table r ON r.id = a.reservation_id
        WHERE $where_sql";

    $total = (int) $wpdb->get_var($wpdb->prepare($count_sql, $values));

    $rows_sql = "SELECT a.*
        FROM $activity_table a
        INNER JOIN $reservations_table r ON r.id = a.reservation_id
        WHERE $where_sql
        ORDER BY a.created_at DESC, a.id DESC
        LIMIT %d OFFSET %d";

    $query_values = array_merge($values, [$limit, $offset]);
    $rows = $wpdb->get_results($wpdb->prepare($rows_sql, $query_values), ARRAY_A);

    $summary_sql = "SELECT a.event_type, COUNT(*) AS event_count
        FROM $activity_table a
        INNER JOIN $reservations_table r ON r.id = a.reservation_id
        WHERE $where_sql
        GROUP BY a.event_type
        ORDER BY a.event_type ASC";

    $summary_rows = $wpdb->get_results($wpdb->prepare($summary_sql, $values), ARRAY_A);
    $summary = [];

    foreach ($summary_rows ?: [] as $summary_row) {
        $summary[sanitize_text_field((string) ($summary_row['event_type'] ?? ''))] = (int) ($summary_row['event_count'] ?? 0);
    }

    return [
        'range' => [
            'from' => $from,
            'to' => $to,
        ],
        'page' => $page,
        'per_page' => $limit,
        'total' => $total,
        'total_pages' => $total > 0 ? (int) ceil($total / $limit) : 0,
        'summary' => $summary,
        'data' => array_map(
            function ($row) use ($include_debug) {
                return tryzub_reservation_activity_public_item($row, $include_debug);
            },
            $rows ?: []
        ),
    ];
}

function tryzub_get_managed_reservation_activity(WP_REST_Request $request) {
    $reservation_id = absint($request->get_param('id'));
    $reservation = tryzub_get_managed_reservation_row_by_id($reservation_id);

    if (!$reservation) {
        return new WP_Error(
            'tryzub_reservation_not_found',
            'Managed reservation not found.',
            ['status' => 404]
        );
    }

    $page = max(1, absint($request->get_param('page') ?: 1));
    $per_page = min(max(absint($request->get_param('per_page') ?: 25), 1), 100);
    $include_debug = current_user_can('manage_options') && tryzub_rest_request_bool($request->get_param('include_debug'));
    $payload = tryzub_reservation_activity_get_for_reservation($reservation_id, $per_page, $page, $include_debug);

    return rest_ensure_response(array_merge(['success' => true], $payload));
}

function tryzub_get_reservation_activity_feed(WP_REST_Request $request) {
    $date = sanitize_text_field((string) ($request->get_param('date') ?? ''));
    $from = sanitize_text_field((string) ($request->get_param('from') ?? ''));
    $to = sanitize_text_field((string) ($request->get_param('to') ?? ''));

    if ($date !== '') {
        if (!tryzub_is_valid_managed_reservation_date($date)) {
            return new WP_Error(
                'tryzub_activity_invalid_date',
                'date must be a valid YYYY-MM-DD value.',
                ['status' => 400]
            );
        }

        $from = $date;
        $to = $date;
    }

    if ($from === '' && $to === '') {
        $today = current_time('Y-m-d');
        $from = $today;
        $to = $today;
    } elseif ($from === '' || $to === '') {
        return new WP_Error(
            'tryzub_activity_invalid_range',
            'Both from and to are required when date is not provided.',
            ['status' => 400]
        );
    }

    $page = max(1, absint($request->get_param('page') ?: 1));
    $per_page = min(max(absint($request->get_param('per_page') ?: 50), 1), 100);
    $include_debug = current_user_can('manage_options') && tryzub_rest_request_bool($request->get_param('include_debug'));
    $payload = tryzub_reservation_activity_query_feed(
        [
            'from' => $from,
            'to' => $to,
        ],
        $per_page,
        $page,
        [
            'reservation_id' => $request->get_param('reservation_id'),
            'event_type' => $request->get_param('event_type'),
            'include_debug' => $include_debug,
        ]
    );

    if (is_wp_error($payload)) {
        return $payload;
    }

    return rest_ensure_response(array_merge(['success' => true], $payload));
}

function tryzub_reservation_activity_manual_email_event($status) {
    $status = sanitize_text_field((string) $status);

    if ($status === 'draft_created') {
        return [
            'event_type' => 'email_draft_created',
            'summary' => 'Confirmation draft created.',
        ];
    }

    if ($status === 'manual_sent') {
        return [
            'event_type' => 'manual_email_sent',
            'summary' => 'Manual confirmation email marked sent.',
        ];
    }

    if ($status === 'manual_failed') {
        return [
            'event_type' => 'manual_email_failed',
            'summary' => 'Manual confirmation email marked failed.',
        ];
    }

    return null;
}
