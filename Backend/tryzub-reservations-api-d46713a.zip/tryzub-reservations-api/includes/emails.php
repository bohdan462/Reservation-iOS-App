<?php

function tryzub_confirm_managed_reservation(WP_REST_Request $request) {
    $id = absint($request->get_param('id'));
    $reservation = tryzub_get_managed_reservation_row_by_id($id);
    $request_body = tryzub_get_rest_request_body($request);

    if (!$reservation) {
        return new WP_Error(
            'tryzub_reservation_not_found',
            'Managed reservation not found.',
            ['status' => 404]
        );
    }

    if (in_array($reservation['status'], ['cancelled', 'no_show', 'completed'], true)) {
        return new WP_Error(
            'tryzub_invalid_status',
            'Cancelled, no-show, and completed reservations cannot be confirmed.',
            ['status' => 400]
        );
    }

    // Reject stale confirms when the client supplies the version it last saw.
    $confirm_lock_conflict = tryzub_check_reservation_optimistic_lock(
        $reservation,
        $request_body
    );

    if ($confirm_lock_conflict instanceof WP_REST_Response) {
        return $confirm_lock_conflict;
    }

    $result = tryzub_execute_managed_reservation_confirmation($id, [
        'source' => 'ios_confirm',
        'request_body' => $request_body,
        'activity_summary' => 'Reservation confirmed.',
        'activity_event_type' => 'confirmed',
    ]);

    if (is_wp_error($result)) {
        return $result;
    }

    return rest_ensure_response(
        tryzub_add_confirm_diagnostics_to_response(
            $result['response'],
            $request,
            $result['email_result'],
            $result['guest_manage_link_created'],
            $result['token_expires_at'],
            $result['activity_event_ids']
        )
    );
}

function tryzub_execute_managed_reservation_confirmation($reservation_id, array $context = []) {
    global $wpdb;

    $id = absint($reservation_id);
    $reservation = tryzub_get_managed_reservation_row_by_id($id);
    $request_body = is_array($context['request_body'] ?? null) ? $context['request_body'] : [];
    $activity_source = sanitize_text_field((string) ($context['source'] ?? 'backend_confirm'));
    $activity_event_type = sanitize_key((string) ($context['activity_event_type'] ?? 'confirmed'));
    $activity_summary = sanitize_text_field((string) ($context['activity_summary'] ?? 'Reservation confirmed.'));
    $activity_event_ids = [];
    $guest_manage_link_created = false;
    $token_expires_at = null;

    if (!$reservation) {
        return new WP_Error(
            'tryzub_reservation_not_found',
            'Managed reservation not found.',
            ['status' => 404]
        );
    }

    if (in_array($reservation['status'], ['cancelled', 'no_show', 'completed'], true)) {
        return new WP_Error(
            'tryzub_invalid_status',
            'Cancelled, no-show, and completed reservations cannot be confirmed.',
            ['status' => 400]
        );
    }

    if (
        $reservation['status'] === 'confirmed' &&
        (!empty($reservation['confirmation_email_sent_at']) || tryzub_reservation_email_already_sent($id, 'confirmation'))
    ) {
        $email_log_id = tryzub_log_reservation_email([
            'reservation_id' => $id,
            'email_type' => 'confirmation',
            'to_email' => sanitize_email((string) ($reservation['email'] ?? '')),
            'from_email' => tryzub_get_reservation_sender_email(),
            'reply_to_email' => tryzub_get_reservation_reply_to_email(),
            'subject' => tryzub_build_reservation_email_subject($reservation, 'confirmation'),
            'body_snapshot' => tryzub_build_reservation_email_body($reservation, 'confirmation'),
            'provider' => tryzub_get_reservation_email_provider(),
            'status' => 'already_sent',
            'error_message' => 'Confirmation email was already sent.',
        ]);

        $response = [
            'success' => true,
            'server_time' => current_time('mysql'),
            'email_status' => 'already_sent',
            'email_error' => null,
            'message' => 'already_confirmed',
            'data' => tryzub_format_managed_reservation_row($reservation)
        ];

        $email_result = tryzub_build_confirm_email_result([
            'status' => 'already_sent',
            'error_message' => null,
            'email_log_id' => is_wp_error($email_log_id) ? null : $email_log_id,
        ]);

        return [
            'response' => $response,
            'email_result' => $email_result,
            'guest_manage_link_created' => $guest_manage_link_created,
            'token_expires_at' => $token_expires_at,
            'activity_event_ids' => $activity_event_ids,
        ];
    }

    $before_status = sanitize_text_field((string) ($reservation['status'] ?? ''));
    $has_usable_email = tryzub_reservation_has_usable_guest_email($reservation);
    $email_result = [
        'status' => 'skipped',
        'error_message' => null,
    ];

    if ($has_usable_email) {
        $guest_manage_token = tryzub_create_guest_manage_token($id);

        if (is_wp_error($guest_manage_token)) {
            return $guest_manage_token;
        }

        $guest_manage_link_created = true;
        $token_expires_at = sanitize_text_field((string) ($guest_manage_token['expires_at'] ?? ''));
        $manage_url = tryzub_build_guest_manage_url($guest_manage_token['raw_token']);
        $link_activity_id = tryzub_reservation_activity_log(
            $id,
            'guest_manage_link_created',
            'Guest manage link created for confirmation email.',
            [
                'source' => tryzub_reservation_activity_request_context($request_body)['source'],
                'metadata' => [
                    'expires_at' => $token_expires_at,
                ],
            ]
        );

        if ($link_activity_id) {
            $activity_event_ids[] = (int) $link_activity_id;
        }

        $email_result = tryzub_send_reservation_email($reservation, 'confirmation', $manage_url);

        if ($email_result['status'] !== 'sent') {
            $response = [
                'success' => false,
                'server_time' => current_time('mysql'),
                'email_status' => 'failed',
                'email_error' => $email_result['error_message'],
                'fallback' => 'manual_mail',
                'data' => tryzub_format_managed_reservation_row($reservation),
            ];

            return [
                'response' => $response,
                'email_result' => $email_result,
                'guest_manage_link_created' => $guest_manage_link_created,
                'token_expires_at' => $token_expires_at,
                'activity_event_ids' => $activity_event_ids,
            ];
        }
    }

    $reservations_table_name = tryzub_get_reservations_table_name();
    $now = current_time('mysql');
    $updates = [
        'status' => 'confirmed',
        'updated_at' => $now,
    ];
    $formats = ['%s', '%s'];

    if (empty($reservation['confirmed_at'])) {
        $updates['confirmed_at'] = $now;
        $formats[] = '%s';
    }

    if ($has_usable_email) {
        $updates['confirmation_email_sent_at'] = $now;
        $formats[] = '%s';
    }

    $updated = $wpdb->update(
        $reservations_table_name,
        $updates,
        ['id' => $id],
        $formats,
        ['%d']
    );

    if ($updated === false) {
        error_log('Tryzub confirmation update failed for ID ' . $id . ': ' . $wpdb->last_error);

        return new WP_Error(
            'tryzub_database_error',
            'Failed to confirm reservation.',
            ['status' => 500]
        );
    }

    tryzub_guest_profiles_mark_dirty_for_reservation($id, 'confirmation_timestamp_changed');

    if (!$has_usable_email) {
        $email_result = tryzub_send_reservation_email($reservation, 'confirmation');
    }

    $logged_activity = [];

    if ($before_status !== 'confirmed') {
        $logged_activity = tryzub_reservation_activity_log_many(
            $id,
            [[
                'event_type' => $activity_event_type,
                'summary' => $activity_summary,
                'metadata' => [
                    'from_status' => $before_status,
                    'to_status' => 'confirmed',
                    'source' => $activity_source,
                ],
            ]],
            array_merge(tryzub_reservation_activity_request_context($request_body), [
                'source' => tryzub_reservation_activity_normalize_source($activity_source),
            ])
        );
    }

    foreach ($logged_activity as $activity_event) {
        if (!empty($activity_event['id'])) {
            $activity_event_ids[] = (int) $activity_event['id'];
        }
    }

    $response = tryzub_reservation_activity_attach_to_response([
            'success' => true,
            'server_time' => current_time('mysql'),
            'email_status' => $email_result['status'],
            'email_error' => $email_result['error_message'],
            'data' => tryzub_get_managed_reservation_by_id($id),
        ], $logged_activity);

    return [
        'response' => $response,
        'email_result' => $email_result,
        'guest_manage_link_created' => $guest_manage_link_created,
        'token_expires_at' => $token_expires_at,
        'activity_event_ids' => $activity_event_ids,
    ];
}

function tryzub_should_include_confirm_diagnostics(WP_REST_Request $request) {
    return current_user_can('manage_options')
        || (
            current_user_can('manage_tryzub_reservations')
            && $request->get_header('X-Tryzub-Developer-Mode') === '1'
        );
}

function tryzub_add_confirm_diagnostics_to_response(
    array $response,
    WP_REST_Request $request,
    array $email_result,
    $guest_manage_link_created,
    $token_expires_at,
    array $activity_event_ids
) {
    if (!tryzub_should_include_confirm_diagnostics($request)) {
        return $response;
    }

    $diagnostics = [
        'confirmation_order' => 'send_then_confirm',
        'provider' => sanitize_text_field((string) ($email_result['provider'] ?? tryzub_get_reservation_email_provider())),
        'email_usage' => is_array($email_result['email_usage'] ?? null)
            ? $email_result['email_usage']
            : tryzub_email_usage_summary(),
        'provider_message_id' => !empty($email_result['provider_message_id'])
            ? sanitize_text_field((string) $email_result['provider_message_id'])
            : null,
        'resend_http_status' => isset($email_result['resend_http_status'])
            ? absint($email_result['resend_http_status'])
            : null,
        'resend_response' => isset($email_result['resend_response']) && is_array($email_result['resend_response'])
            ? tryzub_sanitize_email_diagnostics_value($email_result['resend_response'])
            : [],
        'email_log_id' => !empty($email_result['email_log_id']) ? absint($email_result['email_log_id']) : null,
        'activity_event_ids' => array_values(array_map('absint', array_unique($activity_event_ids))),
        'guest_manage_link_created' => (bool) $guest_manage_link_created,
        'token_expires_at' => $token_expires_at ? sanitize_text_field((string) $token_expires_at) : null,
        'from_email' => sanitize_email((string) ($email_result['from_email'] ?? tryzub_get_reservation_sender_email())),
        'reply_to_email' => sanitize_email((string) ($email_result['reply_to_email'] ?? tryzub_get_reservation_reply_to_email())),
    ];

    $response['diagnostics'] = tryzub_sanitize_email_diagnostics_value($diagnostics);

    return $response;
}

function tryzub_sanitize_email_diagnostics_value($value) {
    if (is_array($value)) {
        $clean = [];
        $is_list = empty($value) || array_keys($value) === range(0, count($value) - 1);

        foreach ($value as $key => $item) {
            if ($is_list) {
                $clean[] = tryzub_sanitize_email_diagnostics_value($item);
                continue;
            }

            $clean_key = sanitize_key((string) $key);

            if (in_array($clean_key, tryzub_email_diagnostics_sensitive_keys(), true)) {
                $clean[$clean_key] = '[redacted]';
                continue;
            }

            $clean[$clean_key] = tryzub_sanitize_email_diagnostics_value($item);
        }

        return $clean;
    }

    if ($value === null || is_bool($value) || is_int($value)) {
        return $value;
    }

    $value = tryzub_scrub_guest_manage_tokens_from_text((string) $value);
    $value = sanitize_text_field($value);

    return substr($value, 0, 1000);
}

function tryzub_email_diagnostics_sensitive_keys() {
    return [
        'api_key',
        'authorization',
        'body',
        'body_html',
        'body_snapshot',
        'body_text',
        'html',
        'manage_url',
        'raw_token',
        'staff_notes',
        'text',
        'token',
    ];
}

function tryzub_build_confirm_email_result(array $overrides = []) {
    return array_merge([
        'status' => 'skipped',
        'code' => null,
        'error_message' => null,
        'provider' => tryzub_get_reservation_email_provider(),
        'provider_message_id' => null,
        'resend_http_status' => null,
        'resend_response' => [],
        'email_log_id' => null,
        'from_email' => tryzub_get_reservation_sender_email(),
        'reply_to_email' => tryzub_get_reservation_reply_to_email(),
        'email_usage' => null,
    ], $overrides);
}

function tryzub_log_manual_reservation_email(WP_REST_Request $request) {
    global $wpdb;

    $id = absint($request->get_param('id'));
    $reservation = tryzub_get_managed_reservation_row_by_id($id);

    if (!$reservation) {
        return new WP_Error(
            'tryzub_reservation_not_found',
            'Managed reservation not found.',
            ['status' => 404]
        );
    }

    $body = tryzub_get_rest_request_body($request);
    $allowed_fields = [
        'email_type',
        'status',
        'to_email',
        'subject',
        'body_snapshot',
        'provider',
        'provider_message_id',
        'error_message',
    ];
    $unknown_fields = array_diff(array_keys($body), $allowed_fields);

    if (!empty($unknown_fields)) {
        return new WP_Error(
            'tryzub_unknown_manual_email_log_field',
            'Unknown manual email log field: ' . implode(', ', array_values($unknown_fields)),
            ['status' => 400]
        );
    }

    $email_type = sanitize_text_field((string) ($body['email_type'] ?? ''));
    $allowed_email_types = ['confirmation', 'cancellation', 'reminder', 'custom'];

    if (!in_array($email_type, $allowed_email_types, true)) {
        return new WP_Error(
            'tryzub_invalid_manual_email_type',
            'Invalid manual email type.',
            ['status' => 400]
        );
    }

    $status = sanitize_text_field((string) ($body['status'] ?? ''));
    $allowed_statuses = ['draft_created', 'manual_sent', 'manual_failed', 'skipped'];

    if (!in_array($status, $allowed_statuses, true)) {
        return new WP_Error(
            'tryzub_invalid_manual_email_status',
            'Invalid manual email status.',
            ['status' => 400]
        );
    }

    $to_email = '';

    if (array_key_exists('to_email', $body) && trim((string) $body['to_email']) !== '') {
        $to_email = sanitize_email((string) $body['to_email']);

        if (!is_email($to_email)) {
            return new WP_Error(
                'tryzub_invalid_email',
                'to_email must be a valid email address.',
                ['status' => 400]
            );
        }
    } else {
        $reservation_email = sanitize_email((string) ($reservation['email'] ?? ''));
        $to_email = is_email($reservation_email) && !tryzub_is_call_in_placeholder_email($reservation_email)
            ? $reservation_email
            : '';
    }

    $provider = tryzub_prepare_manual_email_provider($body['provider'] ?? 'manual_gmail');

    if (is_wp_error($provider)) {
        return $provider;
    }

    $provider_message_id = tryzub_prepare_manual_email_short_text($body['provider_message_id'] ?? '', 190);
    $subject = tryzub_prepare_manual_email_subject($body['subject'] ?? '');
    $body_snapshot = tryzub_prepare_manual_email_body_snapshot($body['body_snapshot'] ?? '');
    $error_message = array_key_exists('error_message', $body)
        ? tryzub_prepare_manual_email_short_text($body['error_message'], 1000)
        : null;
    $now = current_time('mysql');
    $sent_at = $status === 'manual_sent' ? $now : null;

    $log_result = tryzub_log_reservation_email([
        'reservation_id' => $id,
        'email_type' => $email_type,
        'to_email' => $to_email,
        'from_email' => '',
        'reply_to_email' => '',
        'subject' => $subject,
        'body_snapshot' => $body_snapshot,
        'provider' => $provider,
        'provider_message_id' => $provider_message_id,
        'status' => $status,
        'error_message' => $error_message,
        'sent_at' => $sent_at,
    ]);

    if (is_wp_error($log_result)) {
        return $log_result;
    }

    $confirmation_email_sent_at = $reservation['confirmation_email_sent_at'] ?? null;

    if ($status === 'manual_sent' && $email_type === 'confirmation' && empty($confirmation_email_sent_at)) {
        $updated = $wpdb->update(
            tryzub_get_reservations_table_name(),
            [
                'confirmation_email_sent_at' => $sent_at,
                'updated_at' => $now,
            ],
            ['id' => $id],
            ['%s', '%s'],
            ['%d']
        );

        if ($updated === false) {
            error_log('Tryzub manual email timestamp update failed for ID ' . $id . ': ' . $wpdb->last_error);

            return new WP_Error(
                'tryzub_database_error',
                'Failed to update manual email timestamp.',
                ['status' => 500]
            );
        }

        tryzub_guest_profiles_mark_dirty_for_reservation($id, 'manual_email_timestamp_changed');
        $confirmation_email_sent_at = $sent_at;
    }

    $email_activity = tryzub_reservation_activity_manual_email_event($status);
    $logged_activity = [];

    if ($email_activity !== null) {
        $email_activity['metadata'] = [
            'email_type' => $email_type,
            'status' => $status,
        ];
        $logged_activity = tryzub_reservation_activity_log_many(
            $id,
            [$email_activity],
            tryzub_reservation_activity_request_context($body)
        );
    }

    return rest_ensure_response(
        tryzub_reservation_activity_attach_to_response([
            'success' => true,
            'data' => [
                'reservation_id' => $id,
                'email_type' => $email_type,
                'status' => $status,
                'provider' => $provider,
                'confirmation_email_sent_at' => $confirmation_email_sent_at,
            ],
        ], $logged_activity)
    );
}

function tryzub_prepare_manual_email_subject($value) {
    return tryzub_prepare_manual_email_short_text($value, 500);
}

function tryzub_prepare_manual_email_provider($value) {
    $provider = trim(sanitize_text_field((string) $value));

    if ($provider === '') {
        return 'manual_gmail';
    }

    $provider = preg_replace('/[^A-Za-z0-9_-]/', '', $provider);
    $provider = substr($provider ?: 'manual_gmail', 0, 50);

    if (strpos($provider, 'manual_') !== 0) {
        return new WP_Error(
            'tryzub_invalid_manual_email_provider',
            'Manual email provider must identify an external manual email flow.',
            ['status' => 400]
        );
    }

    return $provider;
}

function tryzub_prepare_manual_email_short_text($value, $max_length) {
    if ($value === null) {
        return '';
    }

    $value = tryzub_scrub_guest_manage_tokens_from_text((string) $value);
    $value = preg_replace('/\s+/', ' ', trim($value));
    $value = sanitize_text_field($value);

    return substr($value, 0, absint($max_length));
}

function tryzub_prepare_manual_email_body_snapshot($value) {
    if ($value === null) {
        return '';
    }

    $value = tryzub_scrub_guest_manage_tokens_from_text((string) $value);
    $value = sanitize_textarea_field($value);

    return substr($value, 0, 12000);
}

function tryzub_scrub_guest_manage_tokens_from_text($value) {
    if (!is_string($value) || $value === '') {
        return $value;
    }

    $value = preg_replace(
        '#https?://tryzubchicago\.com/manage-reservation/\?token=[A-Za-z0-9_\-\.~%]+#i',
        '[guest-manage-link]',
        $value
    );
    $value = preg_replace(
        '#https?://[^\s<>"\']*/manage-reservation/\?token=[A-Za-z0-9_\-\.~%]+#i',
        '[guest-manage-link]',
        $value
    );
    $value = preg_replace(
        '#token=[A-Za-z0-9_\-\.~%]+#i',
        'token=[guest-manage-token]',
        $value
    );
    $value = preg_replace(
        '/\b[a-f0-9]{64}\b/i',
        '[guest-manage-token]',
        $value
    );

    return $value;
}

function tryzub_send_due_reservation_reminders_rest(WP_REST_Request $request) {
    $date = sanitize_text_field((string) ($request->get_param('date') ?? ''));
    $result = tryzub_send_due_reservation_reminders([
        'date' => $date,
        'mode' => 'manual',
        'request' => $request,
    ]);

    if (is_wp_error($result)) {
        return $result;
    }

    return rest_ensure_response(array_merge(['success' => true], $result));
}

function tryzub_get_reservation_reminder_status_rest(WP_REST_Request $request) {
    $date = sanitize_text_field((string) ($request->get_param('date') ?? ''));
    $result = tryzub_get_reservation_reminder_status_for_date($date, $request);

    if (is_wp_error($result)) {
        return $result;
    }

    return rest_ensure_response(array_merge(['success' => true], $result));
}

function tryzub_send_due_reservation_reminders($args = []) {
    global $wpdb;

    if (!is_array($args)) {
        $args = [];
    }

    $request = $args['request'] ?? null;
    $now = tryzub_restaurant_now();
    $date = tryzub_prepare_reminder_service_date($args['date'] ?? $now->format('Y-m-d'));

    if (is_wp_error($date)) {
        return $date;
    }

    $mode = sanitize_text_field((string) ($args['mode'] ?? 'manual'));
    $settings = tryzub_get_reminder_automation_settings();
    $force = $request instanceof WP_REST_Request
        && current_user_can('manage_options')
        && in_array($request->get_param('force') ?: $request->get_param('cache_bust'), ['1', 'true', 1, true], true);
    $include_diagnostics = $request instanceof WP_REST_Request
        ? tryzub_should_include_confirm_diagnostics($request)
        : false;
    $target_time = tryzub_get_reminder_morning_target_time();
    $target_at = tryzub_restaurant_datetime_for_date_time($date, $target_time);
    $morning_batch = tryzub_get_reminder_batch_run($date, 'morning');

    if ($mode === 'auto' && empty($settings['automatic_reminders_enabled'])) {
        $result = tryzub_build_empty_reminder_batch_result(
            $date,
            'automatic_reminders_disabled',
            $target_time,
            $morning_batch,
            tryzub_get_reminder_batch_run($date, 'last'),
            $settings
        );

        if ($include_diagnostics) {
            $result['diagnostics'] = [
                'automatic_disabled_reason' => 'automatic_reminders_enabled_false',
                'settings_used' => $settings,
                'lead_hours_used' => $settings['reminder_lead_hours'],
                'effective_morning_time' => $settings['morning_reminder_time'],
            ];
        }

        return $result;
    }

    if ($mode === 'manual' && empty($settings['manual_batch_reminders_enabled']) && !$force) {
        $result = tryzub_build_empty_reminder_batch_result(
            $date,
            'manual_batch_reminders_disabled',
            $target_time,
            $morning_batch,
            tryzub_get_reminder_batch_run($date, 'last'),
            $settings
        );
        $result['success'] = false;
        $result['code'] = 'manual_batch_reminders_disabled';
        $result['message'] = 'Manual batch reminder sending is disabled.';

        if ($include_diagnostics) {
            $result['diagnostics'] = [
                'manual_disabled_reason' => 'manual_batch_reminders_enabled_false',
                'settings_used' => $settings,
                'lead_hours_used' => $settings['reminder_lead_hours'],
                'effective_morning_time' => $settings['morning_reminder_time'],
            ];
        }

        return $result;
    }

    if ($mode === 'auto' && $now < $target_at && empty($morning_batch)) {
        $result = tryzub_build_empty_reminder_batch_result(
            $date,
            'waiting_for_morning_target',
            $target_time,
            $morning_batch,
            tryzub_get_reminder_batch_run($date, 'last'),
            $settings
        );

        if ($include_diagnostics) {
            $result['diagnostics'] = tryzub_build_reminder_settings_diagnostics($settings);
        }

        return $result;
    }

    $effective_mode = $mode;
    $is_morning_batch = empty($morning_batch) && in_array($mode, ['auto', 'manual', 'morning'], true);
    $is_catch_up = !$is_morning_batch;
    $enforce_auto_confirm_cooldown = $mode === 'auto';

    if ($mode === 'auto') {
        $effective_mode = $is_morning_batch ? 'morning' : 'catch_up';
    } elseif ($mode === 'manual') {
        $effective_mode = $is_morning_batch ? 'manual_morning' : 'manual_catch_up';
    }

    $reservations = tryzub_fetch_reservations_for_reminder_date($date);

    if (is_wp_error($reservations)) {
        return $reservations;
    }

    $summary = [
        'sent' => 0,
        'failed' => 0,
        'skipped' => 0,
        'already_sent' => 0,
        'eligible' => 0,
        'total_checked' => count($reservations),
    ];
    $results = [];
    $batch_started_at = tryzub_mysql_from_restaurant_datetime($now);

    foreach ($reservations as $reservation) {
        $result = tryzub_process_reservation_day_reminder(
            $reservation,
            $date,
            $now,
            true,
            $include_diagnostics,
            $settings['reminder_lead_hours'],
            $enforce_auto_confirm_cooldown,
            $effective_mode
        );

        if (!empty($result['counts_as_eligible'])) {
            $summary['eligible']++;
        }

        $status = sanitize_text_field((string) ($result['status'] ?? 'skipped'));

        if (isset($summary[$status])) {
            $summary[$status]++;
        }

        unset($result['counts_as_eligible']);
        $results[] = $result;
    }

    $batch_completed_at = current_time('mysql');
    $batch_record = [
        'date' => $date,
        'mode' => $effective_mode,
        'target_time' => $target_time,
        'started_at' => $batch_started_at,
        'completed_at' => $batch_completed_at,
        'settings' => $settings,
        'summary' => $summary,
    ];

    tryzub_store_reminder_batch_run($date, 'last', $batch_record);

    if ($is_morning_batch) {
        tryzub_store_reminder_batch_run($date, 'morning', $batch_record);
        $morning_batch = $batch_record;
    }

    $response = [
        'date' => $date,
        'mode' => $effective_mode,
        'target_time' => $target_time,
        'settings' => $settings,
        'morning_batch_ran' => !empty($morning_batch),
        'morning_batch' => $morning_batch,
        'last_batch' => $batch_record,
        'summary' => $summary,
        'results' => $results,
    ];

    if ($include_diagnostics) {
        $response['diagnostics'] = tryzub_build_reminder_settings_diagnostics($settings);
    }

    $response['email_usage'] = tryzub_email_usage_summary();

    return $response;
}

function tryzub_run_scheduled_reservation_reminders() {
    $result = tryzub_send_due_reservation_reminders([
        'mode' => 'auto',
    ]);

    if (is_wp_error($result)) {
        error_log('Tryzub scheduled reminders failed: ' . $result->get_error_message());
    }
}

function tryzub_get_reservation_reminder_status_for_date($date, $request = null) {
    $now = tryzub_restaurant_now();
    $date = tryzub_prepare_reminder_service_date($date ?: $now->format('Y-m-d'));

    if (is_wp_error($date)) {
        return $date;
    }

    $reservations = tryzub_fetch_reservations_for_reminder_date($date);

    if (is_wp_error($reservations)) {
        return $reservations;
    }

    $summary = [
        'sent' => 0,
        'failed' => 0,
        'skipped' => 0,
        'already_sent' => 0,
        'eligible' => 0,
        'total_checked' => count($reservations),
    ];
    $results = [];
    $morning_batch = tryzub_get_reminder_batch_run($date, 'morning');
    $is_catch_up = !empty($morning_batch);
    $settings = tryzub_get_reminder_automation_settings();
    $include_diagnostics = $request instanceof WP_REST_Request
        ? tryzub_should_include_confirm_diagnostics($request)
        : false;
    $auto_policy = $request instanceof WP_REST_Request
        && sanitize_text_field((string) ($request->get_param('policy') ?? '')) === 'auto';

    foreach ($reservations as $reservation) {
        $result = tryzub_build_reservation_reminder_status(
            $reservation,
            $date,
            $now,
            true,
            $include_diagnostics,
            $settings['reminder_lead_hours'],
            $auto_policy,
            $auto_policy ? ($is_catch_up ? 'status_auto_catch_up' : 'status_auto_morning') : 'status'
        );

        if (!empty($result['counts_as_eligible'])) {
            $summary['eligible']++;
        }

        $status = sanitize_text_field((string) ($result['status'] ?? 'skipped'));

        if (isset($summary[$status])) {
            $summary[$status]++;
        }

        unset($result['counts_as_eligible']);
        $results[] = $result;
    }

    $response = [
        'date' => $date,
        'mode' => $auto_policy ? 'status_auto' : 'status',
        'target_time' => tryzub_get_reminder_morning_target_time(),
        'settings' => $settings,
        'morning_batch_ran' => !empty($morning_batch),
        'morning_batch' => $morning_batch,
        'last_batch' => tryzub_get_reminder_batch_run($date, 'last'),
        'summary' => $summary,
        'results' => $results,
    ];

    if ($include_diagnostics) {
        $response['diagnostics'] = tryzub_build_reminder_settings_diagnostics($settings);
    }

    $response['email_usage'] = tryzub_email_usage_summary();

    return $response;
}

function tryzub_process_reservation_day_reminder(array $reservation, $date, DateTimeImmutable $now, $enforce_lead_time, $include_diagnostics = false, $reminder_lead_hours = 3, $enforce_auto_confirm_cooldown = false, $mode = 'manual') {
    $status_result = tryzub_build_reservation_reminder_status(
        $reservation,
        $date,
        $now,
        $enforce_lead_time,
        $include_diagnostics,
        $reminder_lead_hours,
        $enforce_auto_confirm_cooldown,
        $mode
    );

    if (empty($status_result['counts_as_eligible'])) {
        if (in_array($status_result['reason'], ['no_email', 'inside_lead_window'], true)) {
            $email_result = tryzub_log_reservation_reminder_skip($reservation, $status_result['reason']);

            if ($include_diagnostics) {
                $status_result['diagnostics'] = tryzub_build_reminder_result_diagnostics($email_result);
            }
        }

        return $status_result;
    }

    $email_result = tryzub_send_reservation_email($reservation, 'reminder');

    if ($email_result['status'] === 'sent') {
        tryzub_mark_reservation_reminder_sent((int) $reservation['id']);
        $sent_at = current_time('mysql');

        return tryzub_add_reminder_diagnostics([
            'reservation_id' => (int) $reservation['id'],
            'reservation_time' => substr((string) ($reservation['reservation_time'] ?? ''), 0, 5),
            'status' => 'sent',
            'reason' => 'sent',
            'reminder_email_sent_at' => $sent_at,
            'display_message' => 'Reminder sent at ' . tryzub_format_reminder_display_time($sent_at),
            'counts_as_eligible' => true,
        ], $email_result, $include_diagnostics);
    }

    if ($email_result['status'] === 'skipped') {
        return tryzub_add_reminder_diagnostics([
            'reservation_id' => (int) $reservation['id'],
            'reservation_time' => substr((string) ($reservation['reservation_time'] ?? ''), 0, 5),
            'status' => 'skipped',
            'reason' => 'no_email',
            'reminder_email_sent_at' => null,
            'display_message' => 'Skipped: no email',
            'counts_as_eligible' => false,
        ], $email_result, $include_diagnostics);
    }

    $failed_message = in_array(($email_result['code'] ?? ''), ['email_daily_limit_reached', 'email_monthly_limit_reached'], true)
        ? 'Email limit reached. Use manual follow-up.'
        : 'Failed: use manual follow-up';

    return tryzub_add_reminder_diagnostics([
        'reservation_id' => (int) $reservation['id'],
        'reservation_time' => substr((string) ($reservation['reservation_time'] ?? ''), 0, 5),
        'status' => 'failed',
        'reason' => !empty($email_result['code']) ? sanitize_key((string) $email_result['code']) : 'provider_failed',
        'reminder_email_sent_at' => null,
        'display_message' => $failed_message,
        'counts_as_eligible' => true,
    ], $email_result, $include_diagnostics);
}

function tryzub_build_reservation_reminder_status(array $reservation, $date, DateTimeImmutable $now, $enforce_lead_time, $include_diagnostics = false, $reminder_lead_hours = 3, $enforce_auto_confirm_cooldown = false, $mode = 'status') {
    $reservation_id = (int) ($reservation['id'] ?? 0);
    $reservation_time = substr((string) ($reservation['reservation_time'] ?? ''), 0, 5);
    $reminder_lead_hours = max(1, min(24, absint($reminder_lead_hours)));
    $post_confirm_cooldown_seconds = tryzub_auto_reminder_post_confirm_cooldown_seconds();
    $base = [
        'reservation_id' => $reservation_id,
        'reservation_time' => $reservation_time,
        'status' => 'skipped',
        'reason' => 'not_eligible',
        'reminder_email_sent_at' => $reservation['reminder_email_sent_at'] ?? null,
        'display_message' => 'Skipped: not eligible',
        'counts_as_eligible' => false,
    ];

    if ((int) ($reservation['is_hidden'] ?? 0) === 1) {
        $base['reason'] = 'hidden';
        $base['display_message'] = 'Skipped: hidden';
        return $base;
    }

    if (($reservation['status'] ?? '') !== 'confirmed') {
        $base['reason'] = 'not_confirmed';
        $base['display_message'] = 'Skipped: not confirmed';
        return $base;
    }

    $sent_log = tryzub_get_reservation_email_sent_log($reservation_id, 'reminder');
    $sent_at = !empty($reservation['reminder_email_sent_at'])
        ? sanitize_text_field((string) $reservation['reminder_email_sent_at'])
        : ($sent_log['sent_at'] ?? null);

    if ($sent_at) {
        if (empty($reservation['reminder_email_sent_at'])) {
            tryzub_mark_reservation_reminder_sent($reservation_id, $sent_at);
        }

        return tryzub_add_reminder_diagnostics([
            'reservation_id' => $reservation_id,
            'reservation_time' => $reservation_time,
            'status' => 'already_sent',
            'reason' => 'already_sent',
            'reminder_email_sent_at' => $sent_at,
            'display_message' => 'Reminder sent at ' . tryzub_format_reminder_display_time($sent_at),
            'counts_as_eligible' => false,
        ], [
            'email_log_id' => $sent_log['id'] ?? null,
            'provider_message_id' => $sent_log['provider_message_id'] ?? null,
            'provider' => $sent_log['provider'] ?? tryzub_get_reservation_email_provider(),
        ], $include_diagnostics);
    }

    $latest_log = tryzub_get_latest_reservation_email_log($reservation_id, 'reminder');

    if (!tryzub_reservation_has_usable_guest_email($reservation)) {
        return tryzub_add_reminder_diagnostics(array_merge($base, [
            'reason' => 'no_email',
            'display_message' => 'Skipped: no email',
        ]), [
            'email_log_id' => $latest_log['id'] ?? null,
            'provider_message_id' => $latest_log['provider_message_id'] ?? null,
            'provider' => $latest_log['provider'] ?? tryzub_get_reservation_email_provider(),
        ], $include_diagnostics);
    }

    if ($enforce_auto_confirm_cooldown) {
        $cooldown = tryzub_reservation_auto_reminder_confirmation_cooldown($reservation, $now, $post_confirm_cooldown_seconds);
        if (!empty($cooldown['is_recent'])) {
            return tryzub_add_reminder_diagnostics(array_merge($base, [
                'reason' => 'recently_confirmed',
                'display_message' => 'Skipped: recently confirmed',
            ]), [
                'email_log_id' => $latest_log['id'] ?? null,
                'provider_message_id' => $latest_log['provider_message_id'] ?? null,
                'provider' => $latest_log['provider'] ?? tryzub_get_reservation_email_provider(),
                'mode' => $mode,
                'confirmed_reference_at' => $cooldown['reference_at'] ?? null,
                'confirmed_reference_source' => $cooldown['reference_source'] ?? null,
                'post_confirm_cooldown_minutes' => (int) ceil($post_confirm_cooldown_seconds / MINUTE_IN_SECONDS),
                'cooldown_remaining_seconds' => $cooldown['remaining_seconds'] ?? null,
            ], $include_diagnostics);
        }
    }

    if ($enforce_lead_time && !tryzub_reservation_time_is_at_least_hours_away($reservation, $now, $reminder_lead_hours)) {
        return tryzub_add_reminder_diagnostics(array_merge($base, [
            'reason' => 'inside_lead_window',
            'display_message' => 'Skipped: less than ' . $reminder_lead_hours . ' hours before reservation',
        ]), [
            'email_log_id' => $latest_log['id'] ?? null,
            'provider_message_id' => $latest_log['provider_message_id'] ?? null,
            'provider' => $latest_log['provider'] ?? tryzub_get_reservation_email_provider(),
            'lead_hours_used' => $reminder_lead_hours,
            'mode' => $mode,
        ], $include_diagnostics);
    }

    if (!empty($latest_log) && ($latest_log['status'] ?? '') === 'failed') {
        $base['status'] = 'failed';
        $error_code = sanitize_key((string) ($latest_log['error_message'] ?? ''));
        $base['reason'] = in_array($error_code, ['email_daily_limit_reached', 'email_monthly_limit_reached'], true)
            ? $error_code
            : 'provider_failed';
        $base['display_message'] = in_array($base['reason'], ['email_daily_limit_reached', 'email_monthly_limit_reached'], true)
            ? 'Email limit reached. Use manual follow-up.'
            : 'Failed: use manual follow-up';
    } else {
        $base['status'] = 'skipped';
        $base['reason'] = 'pending';
        $base['display_message'] = 'Not sent';
    }

    $base['counts_as_eligible'] = true;

    return tryzub_add_reminder_diagnostics($base, [
        'email_log_id' => $latest_log['id'] ?? null,
        'provider_message_id' => $latest_log['provider_message_id'] ?? null,
        'provider' => $latest_log['provider'] ?? tryzub_get_reservation_email_provider(),
    ], $include_diagnostics);
}

function tryzub_add_reminder_diagnostics(array $result, array $email_result, $include_diagnostics) {
    if (!$include_diagnostics) {
        return $result;
    }

    $result['diagnostics'] = tryzub_build_reminder_result_diagnostics($email_result);

    return $result;
}

function tryzub_build_reminder_result_diagnostics(array $email_result) {
    return tryzub_sanitize_email_diagnostics_value([
        'provider' => $email_result['provider'] ?? tryzub_get_reservation_email_provider(),
        'provider_message_id' => $email_result['provider_message_id'] ?? null,
        'resend_http_status' => $email_result['resend_http_status'] ?? null,
        'resend_response' => $email_result['resend_response'] ?? [],
        'email_log_id' => $email_result['email_log_id'] ?? null,
    ]);
}

function tryzub_log_reservation_reminder_skip(array $reservation, $reason) {
    $reason = sanitize_text_field((string) $reason);
    $message = $reason === 'inside_lead_window'
        ? 'inside_lead_window'
        : 'no_email';
    $latest_log = tryzub_get_latest_reservation_email_log((int) ($reservation['id'] ?? 0), 'reminder');

    if (
        !empty($latest_log) &&
        ($latest_log['status'] ?? '') === 'skipped' &&
        ($latest_log['error_message'] ?? '') === $message
    ) {
        return tryzub_build_confirm_email_result([
            'status' => 'skipped',
            'error_message' => $message,
            'provider' => $latest_log['provider'] ?? tryzub_get_reservation_email_provider(),
            'provider_message_id' => $latest_log['provider_message_id'] ?? null,
            'email_log_id' => $latest_log['id'] ?? null,
        ]);
    }

    $from_email = tryzub_get_reservation_sender_email();
    $reply_to_email = tryzub_get_reservation_reply_to_email();
    $provider = tryzub_get_reservation_email_provider();
    $email_log_id = tryzub_log_reservation_email([
        'reservation_id' => (int) $reservation['id'],
        'email_type' => 'reminder',
        'to_email' => sanitize_email((string) ($reservation['email'] ?? '')) ?: 'unknown',
        'from_email' => $from_email,
        'reply_to_email' => $reply_to_email,
        'subject' => tryzub_build_reservation_email_subject($reservation, 'reminder'),
        'body_snapshot' => tryzub_build_reservation_email_body($reservation, 'reminder'),
        'provider' => $provider,
        'status' => 'skipped',
        'error_message' => $message,
    ]);

    return tryzub_build_confirm_email_result([
        'status' => 'skipped',
        'error_message' => $message,
        'provider' => $provider,
        'email_log_id' => is_wp_error($email_log_id) ? null : $email_log_id,
        'from_email' => $from_email,
        'reply_to_email' => $reply_to_email,
    ]);
}

function tryzub_fetch_reservations_for_reminder_date($date) {
    global $wpdb;

    $table_name = tryzub_get_reservations_table_name();

    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT *
            FROM $table_name
            WHERE reservation_date = %s
            ORDER BY reservation_date ASC, reservation_time ASC, id ASC
            LIMIT 100",
            $date
        ),
        ARRAY_A
    );

    if (!is_array($rows)) {
        return new WP_Error(
            'tryzub_database_error',
            'Failed to fetch reservations for reminder date.',
            ['status' => 500]
        );
    }

    return $rows;
}

function tryzub_mark_reservation_reminder_sent($reservation_id, $sent_at = null) {
    global $wpdb;

    $sent_at = $sent_at ?: current_time('mysql');

    $updated = $wpdb->update(
        tryzub_get_reservations_table_name(),
        [
            'reminder_email_sent_at' => $sent_at,
            'updated_at' => current_time('mysql'),
        ],
        ['id' => absint($reservation_id)],
        ['%s', '%s'],
        ['%d']
    );

    if ($updated !== false) {
        tryzub_guest_profiles_mark_dirty_for_reservation($reservation_id, 'reminder_timestamp_changed');
    }

    return $updated;
}

function tryzub_get_reservation_email_sent_log($reservation_id, $email_type) {
    global $wpdb;

    $table_name = tryzub_get_reservation_emails_table_name();
    $row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT id, provider, provider_message_id, sent_at
            FROM $table_name
            WHERE reservation_id = %d
            AND email_type = %s
            AND status = %s
            ORDER BY sent_at DESC, id DESC
            LIMIT 1",
            absint($reservation_id),
            sanitize_text_field($email_type),
            'sent'
        ),
        ARRAY_A
    );

    return is_array($row) ? $row : null;
}

function tryzub_get_latest_reservation_email_log($reservation_id, $email_type) {
    global $wpdb;

    $table_name = tryzub_get_reservation_emails_table_name();
    $row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT id, provider, provider_message_id, status, error_message, sent_at, created_at
            FROM $table_name
            WHERE reservation_id = %d
            AND email_type = %s
            ORDER BY id DESC
            LIMIT 1",
            absint($reservation_id),
            sanitize_text_field($email_type)
        ),
        ARRAY_A
    );

    return is_array($row) ? $row : null;
}

function tryzub_reservation_time_is_at_least_hours_away(array $reservation, DateTimeImmutable $now, $hours) {
    $date = sanitize_text_field((string) ($reservation['reservation_date'] ?? ''));
    $time = sanitize_text_field((string) ($reservation['reservation_time'] ?? ''));

    if ($date === '' || $time === '') {
        return false;
    }

    $reservation_at = tryzub_restaurant_datetime_for_date_time($date, $time);

    return $reservation_at->getTimestamp() - $now->getTimestamp() >= (absint($hours) * HOUR_IN_SECONDS);
}

function tryzub_auto_reminder_post_confirm_cooldown_seconds() {
    $cooldown = (int) apply_filters('tryzub_auto_reminder_post_confirm_cooldown_seconds', 2 * HOUR_IN_SECONDS);
    return max(0, $cooldown);
}

function tryzub_reservation_auto_reminder_confirmation_cooldown(array $reservation, DateTimeImmutable $now, $cooldown_seconds) {
    $cooldown_seconds = max(0, absint($cooldown_seconds));
    if ($cooldown_seconds <= 0) {
        return ['is_recent' => false];
    }

    $reference = tryzub_reservation_auto_reminder_confirmation_reference($reservation);
    if (empty($reference['datetime'])) {
        return ['is_recent' => false];
    }

    $elapsed = $now->getTimestamp() - $reference['datetime']->getTimestamp();
    if ($elapsed < 0) {
        $elapsed = 0;
    }

    return [
        'is_recent' => $elapsed < $cooldown_seconds,
        'reference_at' => tryzub_mysql_from_restaurant_datetime($reference['datetime']),
        'reference_source' => $reference['source'] ?? null,
        'remaining_seconds' => max(0, $cooldown_seconds - $elapsed),
    ];
}

function tryzub_reservation_auto_reminder_confirmation_reference(array $reservation) {
    foreach (['confirmed_at', 'created_at'] as $field) {
        $value = sanitize_text_field((string) ($reservation[$field] ?? ''));
        if ($value === '') {
            continue;
        }

        try {
            return [
                'datetime' => new DateTimeImmutable($value, tryzub_get_restaurant_timezone()),
                'source' => $field,
            ];
        } catch (Exception $exception) {
            continue;
        }
    }

    return null;
}

function tryzub_prepare_reminder_service_date($date) {
    $date = sanitize_text_field((string) $date);

    if ($date === '') {
        $date = tryzub_restaurant_now()->format('Y-m-d');
    }

    if (!tryzub_is_valid_managed_reservation_date($date)) {
        return new WP_Error(
            'tryzub_invalid_reminder_date',
            'date must be a valid YYYY-MM-DD value.',
            ['status' => 400]
        );
    }

    return $date;
}

function tryzub_get_restaurant_timezone() {
    $settings = tryzub_get_restaurant_settings();
    $timezone = sanitize_text_field((string) ($settings['timezone'] ?? 'America/Chicago'));

    try {
        return new DateTimeZone($timezone ?: 'America/Chicago');
    } catch (Exception $exception) {
        return new DateTimeZone('America/Chicago');
    }
}

function tryzub_restaurant_now() {
    return new DateTimeImmutable('now', tryzub_get_restaurant_timezone());
}

function tryzub_restaurant_datetime_for_date_time($date, $time) {
    $time = substr(sanitize_text_field((string) $time), 0, 8);

    if (strlen($time) === 5) {
        $time .= ':00';
    }

    return new DateTimeImmutable($date . ' ' . $time, tryzub_get_restaurant_timezone());
}

function tryzub_mysql_from_restaurant_datetime(DateTimeImmutable $date_time) {
    return $date_time->setTimezone(tryzub_get_restaurant_timezone())->format('Y-m-d H:i:s');
}

function tryzub_get_reminder_morning_target_time() {
    $settings = tryzub_get_reminder_automation_settings();
    $target_time = defined('TRYZUB_REMINDER_BATCH_TIME')
        ? (string) TRYZUB_REMINDER_BATCH_TIME
        : (string) ($settings['morning_reminder_time'] ?? '09:00:00');
    $target_time = sanitize_text_field((string) apply_filters('tryzub_reminder_batch_time', $target_time));

    if (!preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $target_time)) {
        return '09:00:00';
    }

    return strlen($target_time) === 5 ? $target_time . ':00' : $target_time;
}

function tryzub_reminder_batch_option_key($date, $type) {
    return 'tryzub_reminder_' . sanitize_key($type) . '_batch_' . str_replace('-', '_', sanitize_text_field((string) $date));
}

function tryzub_get_reminder_batch_run($date, $type = 'last') {
    $value = get_option(tryzub_reminder_batch_option_key($date, $type), null);

    return is_array($value) ? $value : null;
}

function tryzub_store_reminder_batch_run($date, $type, array $value) {
    update_option(tryzub_reminder_batch_option_key($date, $type), $value, false);
}

function tryzub_build_empty_reminder_batch_result($date, $mode, $target_time, $morning_batch, $last_batch, $settings = null) {
    $settings = is_array($settings) ? $settings : tryzub_get_reminder_automation_settings();

    return [
        'date' => $date,
        'mode' => $mode,
        'target_time' => $target_time,
        'settings' => $settings,
        'morning_batch_ran' => !empty($morning_batch),
        'morning_batch' => $morning_batch,
        'last_batch' => $last_batch,
        'summary' => [
            'sent' => 0,
            'failed' => 0,
            'skipped' => 0,
            'already_sent' => 0,
            'eligible' => 0,
            'total_checked' => 0,
        ],
        'email_usage' => tryzub_email_usage_summary(),
        'results' => [],
    ];
}

function tryzub_get_reminder_automation_settings() {
    $settings = tryzub_get_restaurant_settings();
    $morning_time = function_exists('tryzub_normalize_restaurant_setup_time')
        ? tryzub_normalize_restaurant_setup_time($settings['morning_reminder_time'] ?? '09:00:00')
        : null;

    return [
        'automatic_reminders_enabled' => (bool) ($settings['automatic_reminders_enabled'] ?? true),
        'manual_batch_reminders_enabled' => (bool) ($settings['manual_batch_reminders_enabled'] ?? false),
        'reminder_lead_hours' => max(1, min(24, (int) ($settings['reminder_lead_hours'] ?? 3))),
        'morning_reminder_time' => $morning_time ?: '09:00:00',
        'post_confirm_cooldown_minutes' => (int) ceil(tryzub_auto_reminder_post_confirm_cooldown_seconds() / MINUTE_IN_SECONDS),
    ];
}

function tryzub_build_reminder_settings_diagnostics(array $settings) {
    return [
        'settings_used' => $settings,
        'lead_hours_used' => $settings['reminder_lead_hours'],
        'effective_morning_time' => $settings['morning_reminder_time'],
        'automatic_disabled_reason' => empty($settings['automatic_reminders_enabled'])
            ? 'automatic_reminders_enabled_false'
            : null,
        'manual_disabled_reason' => empty($settings['manual_batch_reminders_enabled'])
            ? 'manual_batch_reminders_enabled_false'
            : null,
    ];
}

function tryzub_format_reminder_display_time($mysql_datetime) {
    $timestamp = strtotime((string) $mysql_datetime);

    if (!$timestamp) {
        return '';
    }

    return date_i18n('g:i A', $timestamp);
}

function tryzub_email_usage_for_date($date) {
    global $wpdb;

    $date = sanitize_text_field((string) $date);

    if (!tryzub_is_valid_managed_reservation_date($date)) {
        $date = tryzub_restaurant_now()->format('Y-m-d');
    }

    $table_name = tryzub_get_reservation_emails_table_name();
    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT email_type, COUNT(*) AS sent_count
            FROM $table_name
            WHERE provider = %s
            AND status = %s
            AND sent_at IS NOT NULL
            AND DATE(sent_at) = %s
            GROUP BY email_type",
            'resend',
            'sent',
            $date
        ),
        ARRAY_A
    );

    return tryzub_format_email_usage_count_rows($rows);
}

function tryzub_email_usage_for_month($yyyy_mm) {
    global $wpdb;

    $yyyy_mm = sanitize_text_field((string) $yyyy_mm);

    if (!preg_match('/^\d{4}-\d{2}$/', $yyyy_mm)) {
        $yyyy_mm = tryzub_restaurant_now()->format('Y-m');
    }

    $table_name = tryzub_get_reservation_emails_table_name();
    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT email_type, COUNT(*) AS sent_count
            FROM $table_name
            WHERE provider = %s
            AND status = %s
            AND sent_at IS NOT NULL
            AND DATE_FORMAT(sent_at, '%%Y-%%m') = %s
            GROUP BY email_type",
            'resend',
            'sent',
            $yyyy_mm
        ),
        ARRAY_A
    );

    return tryzub_format_email_usage_count_rows($rows);
}

function tryzub_format_email_usage_count_rows($rows) {
    $by_type = [
        'confirmation' => 0,
        'reminder' => 0,
        'cancellation' => 0,
        'custom' => 0,
    ];
    $total = 0;

    foreach (is_array($rows) ? $rows : [] as $row) {
        $type = sanitize_key((string) ($row['email_type'] ?? 'custom'));
        $count = (int) ($row['sent_count'] ?? 0);

        if (!isset($by_type[$type])) {
            $by_type[$type] = 0;
        }

        $by_type[$type] += $count;
        $total += $count;
    }

    return [
        'sent' => $total,
        'by_type' => $by_type,
    ];
}

function tryzub_email_usage_summary() {
    $settings = tryzub_get_restaurant_settings();
    $now = tryzub_restaurant_now();
    $date = $now->format('Y-m-d');
    $month = $now->format('Y-m');
    $daily_limit = max(1, (int) ($settings['email_daily_limit'] ?? 100));
    $monthly_limit = max(1, (int) ($settings['email_monthly_limit'] ?? 3000));
    $daily = tryzub_email_usage_for_date($date);
    $monthly = tryzub_email_usage_for_month($month);

    return [
        'provider' => 'resend',
        'daily' => [
            'date' => $date,
            'sent' => $daily['sent'],
            'limit' => $daily_limit,
            'remaining' => max(0, $daily_limit - $daily['sent']),
            'by_type' => $daily['by_type'],
        ],
        'monthly' => [
            'month' => $month,
            'sent' => $monthly['sent'],
            'limit' => $monthly_limit,
            'remaining' => max(0, $monthly_limit - $monthly['sent']),
            'by_type' => $monthly['by_type'],
        ],
    ];
}

function tryzub_email_usage_can_send($email_type) {
    $summary = tryzub_email_usage_summary();

    if ((int) ($summary['daily']['remaining'] ?? 0) <= 0) {
        return [
            'allowed' => false,
            'code' => 'email_daily_limit_reached',
            'message' => 'Email daily limit reached.',
            'email_usage' => $summary,
        ];
    }

    if ((int) ($summary['monthly']['remaining'] ?? 0) <= 0) {
        return [
            'allowed' => false,
            'code' => 'email_monthly_limit_reached',
            'message' => 'Email monthly limit reached.',
            'email_usage' => $summary,
        ];
    }

    return [
        'allowed' => true,
        'code' => null,
        'message' => null,
        'email_usage' => $summary,
    ];
}

function tryzub_send_reservation_email(array $reservation, $email_type, $manage_url = '') {
    $email_type = sanitize_text_field((string) $email_type);
    $to_email = sanitize_email($reservation['email'] ?? '');
    $subject = tryzub_build_reservation_email_subject($reservation, $email_type);
    $text_body = tryzub_build_reservation_email_body($reservation, $email_type, $manage_url);
    $html_body = '';

    if ($email_type === 'confirmation') {
        $html_body = tryzub_build_reservation_confirmation_email_html($reservation, $manage_url);
    } elseif ($email_type === 'cancellation') {
        $html_body = tryzub_build_reservation_cancellation_email_html($reservation);
    } elseif ($email_type === 'reminder') {
        $html_body = tryzub_build_reservation_reminder_email_html($reservation);
    }
    $body_snapshot = tryzub_build_reservation_email_log_snapshot($text_body, $html_body);
    $from_email = tryzub_get_reservation_sender_email();
    $reply_to_email = tryzub_get_reservation_reply_to_email();
    $provider = tryzub_get_reservation_email_provider();

    if (!is_email($to_email) || tryzub_is_call_in_placeholder_email($to_email)) {
        $error_message = tryzub_is_call_in_placeholder_email($to_email)
            ? 'Reservation has no guest email.'
            : 'Reservation email is invalid.';
        $email_log_id = tryzub_log_reservation_email([
            'reservation_id' => (int) $reservation['id'],
            'email_type' => $email_type,
            'to_email' => $to_email ?: 'unknown',
            'from_email' => $from_email,
            'reply_to_email' => $reply_to_email,
            'subject' => $subject,
            'body_snapshot' => $body_snapshot,
            'provider' => $provider,
            'status' => 'skipped',
            'error_message' => $error_message,
        ]);

        return tryzub_build_confirm_email_result([
            'status' => 'skipped',
            'error_message' => $error_message,
            'provider' => $provider,
            'email_log_id' => is_wp_error($email_log_id) ? null : $email_log_id,
            'from_email' => $from_email,
            'reply_to_email' => $reply_to_email,
        ]);
    }

    if ($provider === 'resend') {
        $usage_gate = tryzub_email_usage_can_send($email_type);

        if (empty($usage_gate['allowed'])) {
            $email_log_id = tryzub_log_reservation_email([
                'reservation_id' => (int) $reservation['id'],
                'email_type' => $email_type,
                'to_email' => $to_email,
                'from_email' => $from_email,
                'reply_to_email' => $reply_to_email,
                'subject' => $subject,
                'body_snapshot' => $body_snapshot,
                'provider' => $provider,
                'status' => 'failed',
                'error_message' => $usage_gate['code'],
            ]);

            return tryzub_build_confirm_email_result([
                'status' => 'failed',
                'code' => $usage_gate['code'],
                'error_message' => $usage_gate['message'],
                'provider' => $provider,
                'email_log_id' => is_wp_error($email_log_id) ? null : $email_log_id,
                'from_email' => $from_email,
                'reply_to_email' => $reply_to_email,
                'email_usage' => $usage_gate['email_usage'],
            ]);
        }
    }

    if ($provider === 'resend') {
        $send_result = tryzub_send_reservation_email_via_resend(
            (int) $reservation['id'],
            $to_email,
            $from_email,
            $reply_to_email,
            $subject,
            $text_body,
            $html_body,
            $email_type
        );
    } elseif ($provider === 'postmark') {
        $send_result = tryzub_send_reservation_email_via_postmark($to_email, $from_email, $reply_to_email, $subject, $text_body, $html_body);
    } else {
        $send_result = tryzub_send_reservation_email_via_wp_mail($to_email, $from_email, $reply_to_email, $subject, $text_body, $html_body);
    }

    $email_log_id = tryzub_log_reservation_email([
        'reservation_id' => (int) $reservation['id'],
        'email_type' => $email_type,
        'to_email' => $to_email,
        'from_email' => $from_email,
        'reply_to_email' => $reply_to_email,
        'subject' => $subject,
        'body_snapshot' => $body_snapshot,
        'provider' => $provider,
        'provider_message_id' => $send_result['provider_message_id'] ?? null,
        'status' => $send_result['status'],
        'error_message' => $send_result['error_message'],
        'sent_at' => $send_result['status'] === 'sent' ? current_time('mysql') : null,
    ]);

    return tryzub_build_confirm_email_result([
        'status' => $send_result['status'],
        'error_message' => $send_result['error_message'],
        'provider_message_id' => $send_result['provider_message_id'] ?? null,
        'provider' => $provider,
        'resend_http_status' => $send_result['resend_http_status'] ?? null,
        'resend_response' => $send_result['resend_response'] ?? [],
        'email_log_id' => is_wp_error($email_log_id) ? null : $email_log_id,
        'from_email' => $from_email,
        'reply_to_email' => $reply_to_email,
        'email_usage' => tryzub_email_usage_summary(),
    ]);
}

function tryzub_reservation_has_usable_guest_email(array $reservation) {
    $to_email = sanitize_email($reservation['email'] ?? '');

    return is_email($to_email) && !tryzub_is_call_in_placeholder_email($to_email);
}

function tryzub_send_reservation_email_via_wp_mail($to_email, $from_email, $reply_to_email, $subject, $text_body, $html_body = '') {
    $body = $html_body !== '' ? $html_body : $text_body;
    $headers = [
        'Content-Type: ' . ($html_body !== '' ? 'text/html' : 'text/plain') . '; charset=UTF-8',
        'From: Tryzub Reservations <' . $from_email . '>',
        'Reply-To: ' . $reply_to_email,
    ];

    $sent = wp_mail($to_email, $subject, $body, $headers);

    return [
        'status' => $sent ? 'sent' : 'failed',
        'error_message' => $sent ? null : 'wp_mail failed',
        'provider_message_id' => null,
    ];
}

function tryzub_send_reservation_email_via_postmark($to_email, $from_email, $reply_to_email, $subject, $text_body, $html_body = '') {
    $token = tryzub_get_postmark_token();

    if (!$token) {
        return [
            'status' => 'failed',
            'error_message' => 'Postmark token is missing.',
            'provider_message_id' => null,
        ];
    }

    $payload = [
        'From' => 'Tryzub Reservations <' . $from_email . '>',
        'To' => $to_email,
        'ReplyTo' => $reply_to_email,
        'Subject' => $subject,
        'TextBody' => $text_body,
        'MessageStream' => 'outbound',
    ];

    if ($html_body !== '') {
        $payload['HtmlBody'] = $html_body;
    }

    $response = wp_remote_post(
        'https://api.postmarkapp.com/email',
        [
            'headers' => [
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
                'X-Postmark-Server-Token' => $token,
            ],
            'timeout' => 15,
            'body' => wp_json_encode($payload),
        ]
    );

    if (is_wp_error($response)) {
        return [
            'status' => 'failed',
            'error_message' => $response->get_error_message(),
            'provider_message_id' => null,
        ];
    }

    $status_code = (int) wp_remote_retrieve_response_code($response);
    $payload = json_decode((string) wp_remote_retrieve_body($response), true);

    if (!is_array($payload)) {
        $payload = [];
    }

    if ($status_code >= 200 && $status_code < 300 && (int) ($payload['ErrorCode'] ?? 0) === 0) {
        return [
            'status' => 'sent',
            'error_message' => null,
            'provider_message_id' => sanitize_text_field((string) ($payload['MessageID'] ?? '')),
        ];
    }

    return [
        'status' => 'failed',
        'error_message' => sanitize_text_field((string) ($payload['Message'] ?? 'Postmark send failed.')),
        'provider_message_id' => sanitize_text_field((string) ($payload['MessageID'] ?? '')),
    ];
}

function tryzub_send_reservation_email_via_resend($reservation_id, $to_email, $from_email, $reply_to_email, $subject, $text_body, $html_body, $email_type = 'confirmation') {
    $api_key = tryzub_get_resend_api_key();
    $reservation_id = absint($reservation_id);
    $email_type = sanitize_key((string) $email_type);

    if ($email_type === '') {
        $email_type = 'confirmation';
    }

    if (!$api_key) {
        return [
            'status' => 'failed',
            'error_message' => 'Resend API key is missing.',
            'provider_message_id' => null,
            'resend_http_status' => null,
            'resend_response' => [],
        ];
    }

    $payload = [
        'from' => 'Tryzub Reservations <' . $from_email . '>',
        'to' => [$to_email],
        'reply_to' => [$reply_to_email],
        'subject' => $subject,
        'text' => $text_body,
        'tags' => [
            [
                'name' => 'category',
                'value' => 'reservation_' . $email_type,
            ],
            [
                'name' => 'reservation_id',
                'value' => (string) $reservation_id,
            ],
        ],
    ];

    if ($html_body !== '') {
        $payload['html'] = $html_body;
    }

    $response = wp_remote_post(
        'https://api.resend.com/emails',
        [
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
                'User-Agent' => 'tryzub-reservations/1.0',
                'Idempotency-Key' => 'reservation-' . $email_type . '/' . $reservation_id,
            ],
            'timeout' => 15,
            'body' => wp_json_encode($payload),
        ]
    );

    if (is_wp_error($response)) {
        return [
            'status' => 'failed',
            'error_message' => tryzub_prepare_reservation_email_error_message($response->get_error_message(), 'Resend send failed.'),
            'provider_message_id' => null,
            'resend_http_status' => null,
            'resend_response' => [],
        ];
    }

    $status_code = (int) wp_remote_retrieve_response_code($response);
    $payload = json_decode((string) wp_remote_retrieve_body($response), true);

    if (!is_array($payload)) {
        $payload = [];
    }

    $provider_message_id = sanitize_text_field((string) ($payload['id'] ?? ''));

    if ($status_code >= 200 && $status_code < 300) {
        return [
            'status' => 'sent',
            'error_message' => null,
            'provider_message_id' => $provider_message_id ?: null,
            'resend_http_status' => $status_code,
            'resend_response' => tryzub_sanitize_email_diagnostics_value($payload),
        ];
    }

    $error_message = $payload['message'] ?? ($payload['error'] ?? 'Resend send failed.');

    return [
        'status' => 'failed',
        'error_message' => tryzub_prepare_reservation_email_error_message($error_message, 'Resend send failed.'),
        'provider_message_id' => $provider_message_id ?: null,
        'resend_http_status' => $status_code,
        'resend_response' => tryzub_sanitize_email_diagnostics_value($payload),
    ];
}

function tryzub_prepare_reservation_email_error_message($value, $fallback) {
    if (is_array($value)) {
        $value = wp_json_encode($value);
    }

    $value = tryzub_scrub_guest_manage_tokens_from_text((string) $value);
    $value = preg_replace('/\s+/', ' ', trim($value));
    $value = sanitize_text_field($value);

    return substr($value ?: $fallback, 0, 1000);
}

function tryzub_build_reservation_email_subject(array $reservation, $email_type) {
    if ($email_type === 'cancellation') {
        return 'Your Tryzub reservation has been cancelled';
    }

    if ($email_type === 'reminder') {
        return 'Reminder: Your Tryzub reservation';
    }

    return 'Your Tryzub reservation is confirmed';
}

function tryzub_build_reservation_email_body(array $reservation, $email_type, $manage_url = '') {
    if ($email_type === 'confirmation') {
        return tryzub_build_reservation_confirmation_email_text($reservation, $manage_url);
    }

    if ($email_type === 'cancellation') {
        return tryzub_build_reservation_cancellation_email_text($reservation);
    }

    if ($email_type === 'reminder') {
        $date_line = tryzub_reservation_email_date_line($reservation);
        $time_line = tryzub_reservation_email_time_line($reservation);
        $party_size = max(1, absint($reservation['party_size'] ?? 1));

        return implode("\n", [
            'Your reservation is coming up',
            '',
            'This is a reminder for your reservation at Tryzub Ukrainian Kitchen.',
            '',
            'Date: ' . $date_line,
            'Time: ' . $time_line,
            'Party size: ' . $party_size,
            '',
            'If you need to make a change, please call the restaurant.',
            '',
            'Tryzub Ukrainian Kitchen',
            '2201 W Chicago Ave, Chicago, IL 60622',
            'Phone: (773) 698-8624',
        ]);
    }

    return implode("\n", [
        'Your reservation is confirmed.',
        '',
        'Tryzub Ukrainian Kitchen',
    ]);
}

function tryzub_build_reservation_confirmation_email_text(array $reservation, $manage_url = '') {
    $guest_first_name = tryzub_reservation_email_guest_first_name($reservation);
    $date_line = tryzub_reservation_email_date_line($reservation);
    $time_line = tryzub_reservation_email_time_line($reservation);
    $party_size = max(1, absint($reservation['party_size'] ?? 1));
    $lines = [
        'Dear ' . $guest_first_name . ',',
        'Your reservation at Tryzub Ukrainian Kitchen is confirmed.',
        'Your reservation:',
        $date_line,
        $time_line,
        'Party of ' . $party_size,
    ];

    if (!empty($manage_url)) {
        $lines[] = 'Cancel your reservation:';
        $lines[] = $manage_url;
    }

    $lines[] = !empty($manage_url)
        ? 'To cancel, use the link above. For changes, reply to this email or call us.'
        : 'For changes or cancellation, reply to this email or call us.';

    $lines = array_merge($lines, [
        'Email info@tryzubchicago.com or call (773) 698-8624.',
        'Tryzub Ukrainian Kitchen',
        '2201 W Chicago Ave, Chicago, IL 60622',
        'https://tryzubchicago.com',
    ]);

    return implode("\n", $lines);
}

function tryzub_build_reservation_confirmation_email_html(array $reservation, $manage_url = '') {
    $restaurant_name = 'Tryzub Ukrainian Kitchen';
    $guest_first_name = tryzub_email_html_escape(tryzub_reservation_email_guest_first_name($reservation));
    $date_line = tryzub_email_html_escape(tryzub_reservation_email_date_line($reservation));
    $time_line = tryzub_email_html_escape(tryzub_reservation_email_time_line($reservation));
    $party_size = max(1, absint($reservation['party_size'] ?? 1));
    $manage_button = '';

    if (!empty($manage_url)) {
        $manage_href = esc_url($manage_url);
        $manage_button = '
        <td align="center" style="padding:0 4px 8px;">
            <a href="' . $manage_href . '" style="display:inline-block;min-width:170px;padding:12px 18px;background-color:#1f6b3a;color:#ffffff;text-decoration:none;border-radius:999px;font-size:14px;font-weight:700;">Cancel Reservation</a>
        </td>';
    }

    $book_url = esc_url('https://tryzubchicago.com/book-table/');
    $policies_url = esc_url('https://tryzubchicago.com/home-page/privacy-policy-terms-and-conditions/');
    $website_url = esc_url('https://tryzubchicago.com');
    $contact_email = 'info@tryzubchicago.com';
    $contact_email_html = tryzub_email_html_escape($contact_email);
    $phone = '(773) 698-8624';
    $address = '2201 W Chicago Ave, Chicago, IL 60622';
    $footer_copy = !empty($manage_url)
        ? 'To cancel, use the button above. For changes, reply to this email or call us.'
        : 'For changes or cancellation, reply to this email or call us.';

    return '<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin:0;padding:0;background-color:#f3efe6;font-family:Georgia,\'Times New Roman\',serif;">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color:#f3efe6;padding:18px 12px;">
<tr>
<td align="center">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:560px;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e4ddd1;">
<tr>
<td style="background:#1f3d2b;padding:22px 26px;text-align:center;">
<p style="margin:0;color:#d8c9a8;font-size:11px;letter-spacing:0.14em;text-transform:uppercase;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',sans-serif;">' . tryzub_email_html_escape($restaurant_name) . '</p>
<h1 style="margin:9px 0 0;color:#ffffff;font-size:23px;line-height:1.2;font-weight:650;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',sans-serif;">Reservation Confirmed</h1>
</td>
</tr>
<tr>
<td style="padding:24px 26px 20px;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',sans-serif;color:#222222;font-size:15px;line-height:1.5;">
<p style="margin:0 0 12px;">Dear ' . $guest_first_name . ',</p>
<p style="margin:0 0 16px;">Your reservation at <strong>' . tryzub_email_html_escape($restaurant_name) . '</strong> is confirmed. We look forward to welcoming you.</p>
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f8f5ef;border:1px solid #ece4d7;border-radius:10px;margin:0 0 18px;">
<tr>
<td style="padding:15px 16px 14px;">
<p style="margin:0 0 8px;font-size:11px;color:#7a7368;letter-spacing:0.1em;text-transform:uppercase;">Your reservation</p>
<p style="margin:0;font-size:18px;line-height:1.25;font-weight:700;color:#1f1f1f;">' . $date_line . '</p>
<p style="margin:5px 0 0;font-size:18px;line-height:1.25;font-weight:700;color:#1f1f1f;">' . $time_line . '</p>
<p style="margin:6px 0 0;font-size:14px;line-height:1.25;font-weight:650;color:#1f1f1f;">Party of ' . $party_size . '</p>
</td>
</tr>
</table>
<table role="presentation" cellspacing="0" cellpadding="0" align="center" style="margin:0 auto 18px;">
<tr>
' . $manage_button . '
<td align="center" style="padding:0 4px 8px;">
<a href="' . $book_url . '" style="display:inline-block;min-width:150px;padding:11px 16px;border:1px solid #1f6b3a;color:#1f6b3a;text-decoration:none;border-radius:999px;font-size:13px;font-weight:700;">Book another time</a>
</td>
</tr>
</table>
<p style="margin:4px 0 0;font-size:11px;line-height:1.45;color:#8a8378;text-align:center;">This is an automated reservation confirmation.</p>
<p style="margin:6px 0 0;font-size:11px;line-height:1.45;color:#766f65;text-align:center;">' . tryzub_email_html_escape($footer_copy) . ' Email <a href="mailto:' . tryzub_email_attr_escape($contact_email) . '" style="color:#1f6b3a;text-decoration:none;">' . $contact_email_html . '</a> or call us.</p>
<p style="margin:6px 0 0;font-size:11px;line-height:1.45;color:#8a8378;text-align:center;">
' . tryzub_email_html_escape($address) . ' &middot; ' . tryzub_email_html_escape($phone) . ' &middot; <a href="' . $website_url . '" style="color:#1f6b3a;text-decoration:none;">tryzubchicago.com</a>
</p>
</td>
</tr>
<tr>
<td style="padding:14px 26px 22px;border-top:1px solid #ece8e1;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',sans-serif;font-size:11px;line-height:1.45;color:#8a8378;text-align:center;">
<p style="margin:0;"><a href="' . $policies_url . '" style="color:#1f6b3a;text-decoration:underline;">Reservation policies</a></p>
</td>
</tr>
</table>
</td>
</tr>
</table>
</body>
</html>';
}

function tryzub_build_reservation_cancellation_email_text(array $reservation) {
    $date_line = tryzub_reservation_email_date_line($reservation);
    $time_line = tryzub_reservation_email_time_line($reservation);
    $party_size = max(1, absint($reservation['party_size'] ?? 1));

    return implode("\n", [
        'Your reservation has been cancelled.',
        '',
        'Reservation cancelled:',
        'Date: ' . $date_line,
        'Time: ' . $time_line,
        'Party size: ' . $party_size,
        '',
        'Tryzub Ukrainian Kitchen',
        'If you need another time, please book again at https://tryzubchicago.com/book-table/ or contact us.',
        'Email: info@tryzubchicago.com',
        'Phone: (773) 698-8624',
        '2201 W Chicago Ave, Chicago, IL 60622',
    ]);
}

function tryzub_build_reservation_cancellation_email_html(array $reservation) {
    $restaurant_name = 'Tryzub Ukrainian Kitchen';
    $date_line = tryzub_email_html_escape(tryzub_reservation_email_date_line($reservation));
    $time_line = tryzub_email_html_escape(tryzub_reservation_email_time_line($reservation));
    $party_size = max(1, absint($reservation['party_size'] ?? 1));
    $book_url = esc_url('https://tryzubchicago.com/book-table/');
    $website_url = esc_url('https://tryzubchicago.com');
    $contact_email = 'info@tryzubchicago.com';
    $contact_email_html = tryzub_email_html_escape($contact_email);
    $phone = '(773) 698-8624';
    $address = '2201 W Chicago Ave, Chicago, IL 60622';

    return '<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin:0;padding:0;background-color:#f3efe6;font-family:Georgia,\'Times New Roman\',serif;">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color:#f3efe6;padding:18px 12px;">
<tr>
<td align="center">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:560px;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e4ddd1;">
<tr>
<td style="background:#1f3d2b;padding:22px 26px;text-align:center;">
<p style="margin:0;color:#d8c9a8;font-size:11px;letter-spacing:0.14em;text-transform:uppercase;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',sans-serif;">' . tryzub_email_html_escape($restaurant_name) . '</p>
<h1 style="margin:9px 0 0;color:#ffffff;font-size:23px;line-height:1.2;font-weight:650;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',sans-serif;">Reservation Cancelled</h1>
</td>
</tr>
<tr>
<td style="padding:24px 26px 20px;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',sans-serif;color:#222222;font-size:15px;line-height:1.5;">
<p style="margin:0 0 16px;">Your reservation at <strong>' . tryzub_email_html_escape($restaurant_name) . '</strong> has been cancelled.</p>
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f8f5ef;border:1px solid #ece4d7;border-radius:10px;margin:0 0 18px;">
<tr>
<td style="padding:15px 16px 14px;">
<p style="margin:0 0 8px;font-size:11px;color:#7a7368;letter-spacing:0.1em;text-transform:uppercase;">Reservation cancelled</p>
<p style="margin:0;font-size:18px;line-height:1.25;font-weight:700;color:#1f1f1f;">' . $date_line . '</p>
<p style="margin:5px 0 0;font-size:18px;line-height:1.25;font-weight:700;color:#1f1f1f;">' . $time_line . '</p>
<p style="margin:6px 0 0;font-size:14px;line-height:1.25;font-weight:650;color:#1f1f1f;">Party of ' . $party_size . '</p>
</td>
</tr>
</table>
<p style="margin:4px 0 0;font-size:13px;line-height:1.45;color:#5f584f;text-align:center;">If you need another time, please book at <a href="' . $book_url . '" style="color:#1f6b3a;text-decoration:none;">tryzubchicago.com/book-table</a> or contact us.</p>
<p style="margin:12px 0 0;font-size:11px;line-height:1.45;color:#766f65;text-align:center;">Email <a href="mailto:' . tryzub_email_attr_escape($contact_email) . '" style="color:#1f6b3a;text-decoration:none;">' . $contact_email_html . '</a> or call ' . tryzub_email_html_escape($phone) . '.</p>
<p style="margin:6px 0 0;font-size:11px;line-height:1.45;color:#8a8378;text-align:center;">
' . tryzub_email_html_escape($address) . ' &middot; <a href="' . $website_url . '" style="color:#1f6b3a;text-decoration:none;">tryzubchicago.com</a>
</p>
</td>
</tr>
</table>
</td>
</tr>
</table>
</body>
</html>';
}

function tryzub_build_reservation_reminder_email_html(array $reservation) {
    $restaurant_name = 'Tryzub Ukrainian Kitchen';
    $date_line = tryzub_email_html_escape(tryzub_reservation_email_date_line($reservation));
    $time_line = tryzub_email_html_escape(tryzub_reservation_email_time_line($reservation));
    $party_size = max(1, absint($reservation['party_size'] ?? 1));
    $website_url = esc_url('https://tryzubchicago.com');
    $phone = '(773) 698-8624';
    $address = '2201 W Chicago Ave, Chicago, IL 60622';

    return '<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin:0;padding:0;background-color:#f3efe6;font-family:Georgia,\'Times New Roman\',serif;">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color:#f3efe6;padding:18px 12px;">
<tr>
<td align="center">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:560px;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e4ddd1;">
<tr>
<td style="background:#1f3d2b;padding:22px 26px;text-align:center;">
<p style="margin:0;color:#d8c9a8;font-size:11px;letter-spacing:0.14em;text-transform:uppercase;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',sans-serif;">' . tryzub_email_html_escape($restaurant_name) . '</p>
<h1 style="margin:9px 0 0;color:#ffffff;font-size:23px;line-height:1.2;font-weight:650;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',sans-serif;">Your reservation is coming up</h1>
</td>
</tr>
<tr>
<td style="padding:24px 26px 20px;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',sans-serif;color:#222222;font-size:15px;line-height:1.5;">
<p style="margin:0 0 16px;">This is a reminder for your reservation at <strong>' . tryzub_email_html_escape($restaurant_name) . '</strong>.</p>
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f8f5ef;border:1px solid #ece4d7;border-radius:10px;margin:0 0 18px;">
<tr>
<td style="padding:15px 16px 14px;">
<p style="margin:0 0 8px;font-size:11px;color:#7a7368;letter-spacing:0.1em;text-transform:uppercase;">Your reservation</p>
<p style="margin:0;font-size:18px;line-height:1.25;font-weight:700;color:#1f1f1f;">' . $date_line . '</p>
<p style="margin:5px 0 0;font-size:18px;line-height:1.25;font-weight:700;color:#1f1f1f;">' . $time_line . '</p>
<p style="margin:6px 0 0;font-size:14px;line-height:1.25;font-weight:650;color:#1f1f1f;">Party of ' . $party_size . '</p>
</td>
</tr>
</table>
<p style="margin:4px 0 0;font-size:13px;line-height:1.45;color:#5f584f;text-align:center;">If you need to make a change, please call the restaurant.</p>
<p style="margin:12px 0 0;font-size:11px;line-height:1.45;color:#8a8378;text-align:center;">
' . tryzub_email_html_escape($address) . ' &middot; ' . tryzub_email_html_escape($phone) . ' &middot; <a href="' . $website_url . '" style="color:#1f6b3a;text-decoration:none;">tryzubchicago.com</a>
</p>
</td>
</tr>
</table>
</td>
</tr>
</table>
</body>
</html>';
}

function tryzub_email_html_escape($value) {
    return esc_html((string) $value);
}

function tryzub_email_attr_escape($value) {
    return esc_attr((string) $value);
}

function tryzub_reservation_email_guest_first_name(array $reservation) {
    $guest_name = trim(sanitize_text_field((string) ($reservation['guest_name'] ?? '')));

    if ($guest_name === '') {
        return 'Guest';
    }

    $parts = preg_split('/\s+/', $guest_name);

    return !empty($parts[0]) ? $parts[0] : 'Guest';
}

function tryzub_reservation_email_date_line(array $reservation) {
    $date = sanitize_text_field((string) ($reservation['reservation_date'] ?? ''));

    if ($date === '') {
        return 'Date to be confirmed';
    }

    $timestamp = strtotime($date . ' 12:00:00');

    if (!$timestamp) {
        return $date;
    }

    return date_i18n('l, F j, Y', $timestamp);
}

function tryzub_reservation_email_time_line(array $reservation) {
    $time = sanitize_text_field((string) ($reservation['reservation_time'] ?? ''));

    if ($time === '') {
        return 'Time to be confirmed';
    }

    if (function_exists('tryzub_normalize_reservation_time')) {
        $normalized = tryzub_normalize_reservation_time($time);

        if ($normalized) {
            $time = $normalized;
        }
    }

    $timestamp = strtotime('2000-01-01 ' . $time);

    if (!$timestamp) {
        return substr($time, 0, 5);
    }

    return date_i18n('g:i A', $timestamp);
}

function tryzub_build_reservation_email_log_snapshot($text_body, $html_body = '') {
    $snapshot = (string) $text_body;

    if ($html_body !== '') {
        $snapshot .= "\n\n--- HTML ---\n" . (string) $html_body;
    }

    return tryzub_scrub_guest_manage_tokens_from_text($snapshot);
}

function tryzub_log_reservation_email(array $args) {
    global $wpdb;

    $table_name = tryzub_get_reservation_emails_table_name();
    $now = current_time('mysql');
    $status = sanitize_text_field((string) ($args['status'] ?? 'pending'));
    $reservation_id = isset($args['reservation_id']) ? absint($args['reservation_id']) : null;
    $body_snapshot = tryzub_scrub_guest_manage_tokens_from_text((string) ($args['body_snapshot'] ?? ''));
    $body_snapshot = sanitize_textarea_field($body_snapshot);
    $error_message = isset($args['error_message'])
        ? sanitize_text_field(tryzub_scrub_guest_manage_tokens_from_text((string) $args['error_message']))
        : null;
    $from_email = sanitize_email((string) ($args['from_email'] ?? ''));
    $reply_to_email = sanitize_email((string) ($args['reply_to_email'] ?? ''));
    $subject = sanitize_text_field(tryzub_scrub_guest_manage_tokens_from_text((string) ($args['subject'] ?? '')));
    $provider_message_id = sanitize_text_field((string) ($args['provider_message_id'] ?? ''));

    $inserted = $wpdb->insert(
        $table_name,
        [
            'reservation_id' => $reservation_id ?: null,
            'email_type' => sanitize_text_field((string) ($args['email_type'] ?? 'manual')),
            'to_email' => sanitize_email((string) ($args['to_email'] ?? '')),
            'from_email' => $from_email,
            'reply_to_email' => $reply_to_email,
            'subject' => $subject,
            'body_snapshot' => $body_snapshot,
            'provider' => sanitize_text_field((string) ($args['provider'] ?? 'wp_mail')),
            'provider_message_id' => $provider_message_id,
            'status' => $status,
            'error_message' => $error_message,
            'sent_at' => $args['sent_at'] ?? null,
            'created_at' => $now,
            'updated_at' => $now,
        ],
        [
            '%d',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
        ]
    );

    if ($inserted === false) {
        error_log('Tryzub reservation email log insert failed: ' . $wpdb->last_error);
        return new WP_Error(
            'tryzub_database_error',
            'Failed to record reservation email log.',
            ['status' => 500]
        );
    }

    tryzub_create_reservation_message([
        'reservation_id' => $reservation_id,
        'direction' => 'outbound',
        'channel' => 'email',
        'from_email' => $from_email,
        'to_email' => $args['to_email'] ?? null,
        'subject' => $subject,
        'body_text' => $body_snapshot,
        'provider_message_id' => $provider_message_id,
        'status' => $status,
    ]);

    return (int) $wpdb->insert_id;
}

function tryzub_create_reservation_message(array $args) {
    global $wpdb;

    $table_name = tryzub_get_reservation_messages_table_name();
    $inserted = $wpdb->insert(
        $table_name,
        [
            'reservation_id' => isset($args['reservation_id']) ? absint($args['reservation_id']) : null,
            'direction' => sanitize_text_field((string) ($args['direction'] ?? 'outbound')),
            'channel' => sanitize_text_field((string) ($args['channel'] ?? 'email')),
            'from_email' => isset($args['from_email']) ? sanitize_email((string) $args['from_email']) : null,
            'to_email' => isset($args['to_email']) ? sanitize_email((string) $args['to_email']) : null,
            'subject' => isset($args['subject']) ? sanitize_text_field((string) $args['subject']) : null,
            'body_text' => isset($args['body_text']) ? sanitize_textarea_field(tryzub_scrub_guest_manage_tokens_from_text((string) $args['body_text'])) : null,
            'body_html' => isset($args['body_html']) ? wp_kses_post(tryzub_scrub_guest_manage_tokens_from_text((string) $args['body_html'])) : null,
            'raw_payload_json' => isset($args['raw_payload']) ? tryzub_scrub_guest_manage_tokens_from_text(wp_json_encode($args['raw_payload'])) : null,
            'provider_message_id' => isset($args['provider_message_id']) ? sanitize_text_field((string) $args['provider_message_id']) : null,
            'in_reply_to' => isset($args['in_reply_to']) ? sanitize_text_field((string) $args['in_reply_to']) : null,
            'reply_token' => isset($args['reply_token']) ? sanitize_text_field((string) $args['reply_token']) : null,
            'status' => isset($args['status']) ? sanitize_text_field((string) $args['status']) : null,
            'created_at' => current_time('mysql'),
        ],
        [
            '%d',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
        ]
    );

    if ($inserted === false) {
        error_log('Tryzub reservation message insert failed: ' . $wpdb->last_error);
    }
}

function tryzub_reservation_email_already_sent($reservation_id, $email_type) {
    global $wpdb;

    $table_name = tryzub_get_reservation_emails_table_name();

    return (bool) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT id
            FROM $table_name
            WHERE reservation_id = %d
            AND email_type = %s
            AND status = %s
            LIMIT 1",
            absint($reservation_id),
            sanitize_text_field($email_type),
            'sent'
        )
    );
}

function tryzub_get_reservation_sender_email() {
    $settings = tryzub_get_restaurant_settings();
    $from_email = sanitize_email((string) ($settings['from_email'] ?? ''));

    if ($from_email === '' || $from_email === 'reservations@tryzubchicago.com') {
        $from_email = 'reservations@send.tryzubchicago.com';
    }

    return apply_filters('tryzub_reservation_sender_email', $from_email);
}

function tryzub_get_reservation_reply_to_email() {
    $settings = tryzub_get_restaurant_settings();
    $reply_to_email = sanitize_email((string) ($settings['reply_to_email'] ?? ''));

    if ($reply_to_email === '' || $reply_to_email === 'reservations@tryzubchicago.com') {
        $reply_to_email = 'info@tryzubchicago.com';
    }

    return apply_filters('tryzub_reservation_reply_to_email', $reply_to_email);
}

function tryzub_get_reservation_email_provider() {
    if (tryzub_get_resend_api_key()) {
        return 'resend';
    }

    return tryzub_get_postmark_token() ? 'postmark' : 'wp_mail';
}

function tryzub_get_resend_api_key() {
    $api_key = defined('TRYZUB_RESEND_API_KEY') ? (string) TRYZUB_RESEND_API_KEY : '';
    return trim((string) apply_filters('tryzub_resend_api_key', $api_key));
}

function tryzub_get_postmark_token() {
    $token = defined('TRYZUB_POSTMARK_TOKEN') ? (string) TRYZUB_POSTMARK_TOKEN : '';
    return trim((string) apply_filters('tryzub_postmark_token', $token));
}

add_action('tryzub_reservation_reminders_cron', 'tryzub_run_scheduled_reservation_reminders');
