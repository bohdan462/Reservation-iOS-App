<?php

function tryzub_get_intelligence_cache_table_name() {
    global $wpdb;

    return $wpdb->prefix . 'tryzub_intelligence_cache';
}

function tryzub_bi_cache_version() {
    $version = absint(get_option('tryzub_bi_cache_version', 1));

    return max(1, $version);
}

function tryzub_bump_intelligence_cache_version() {
    $next_version = tryzub_bi_cache_version() + 1;

    update_option('tryzub_bi_cache_version', $next_version, false);

    return $next_version;
}

function tryzub_bi_resolve_range_key($from, $to) {
    $from = sanitize_text_field((string) $from);
    $to = sanitize_text_field((string) $to);
    $today = current_time('Y-m-d');

    if ($to !== $today) {
        return 'custom';
    }

    $today_date = DateTimeImmutable::createFromFormat('!Y-m-d', $today, wp_timezone());

    if (!$today_date instanceof DateTimeImmutable) {
        return 'custom';
    }

    if ($from === $today_date->format('Y-m-01')) {
        return 'this_month';
    }

    if ($from === $today_date->modify('-29 days')->format('Y-m-d')) {
        return 'last_30_days';
    }

    $all_range = tryzub_bi_get_standard_ranges()['all'] ?? null;

    if (is_array($all_range) && $from === $all_range['from'] && $to === $all_range['to']) {
        return 'all';
    }

    return 'custom';
}

function tryzub_bi_cache_build_key($range_key, $from, $to, $generated_date, $cache_version) {
    return sprintf(
        'bi:%d:%s:%s:%s:%s',
        max(1, absint($cache_version)),
        sanitize_key((string) $range_key),
        sanitize_text_field((string) $from),
        sanitize_text_field((string) $to),
        sanitize_text_field((string) $generated_date)
    );
}

function tryzub_bi_cache_get($cache_key) {
    global $wpdb;

    $cache_key = sanitize_text_field((string) $cache_key);

    if ($cache_key === '') {
        return null;
    }

    $table_name = tryzub_get_intelligence_cache_table_name();
    $row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT *
            FROM $table_name
            WHERE cache_key = %s
            LIMIT 1",
            $cache_key
        ),
        ARRAY_A
    );

    return tryzub_bi_cache_format_row($row);
}

function tryzub_bi_cache_get_latest_for_range($range_key, $from, $to, $cache_version) {
    global $wpdb;

    $table_name = tryzub_get_intelligence_cache_table_name();
    $row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT *
            FROM $table_name
            WHERE cache_group = %s
            AND range_key = %s
            AND range_from = %s
            AND range_to = %s
            AND cache_version = %d
            ORDER BY generated_date DESC, updated_at DESC, id DESC
            LIMIT 1",
            'business_intelligence',
            sanitize_key((string) $range_key),
            sanitize_text_field((string) $from),
            sanitize_text_field((string) $to),
            max(1, absint($cache_version))
        ),
        ARRAY_A
    );

    return tryzub_bi_cache_format_row($row);
}

function tryzub_bi_cache_put($cache_key, $meta, $payload, $duration_ms) {
    global $wpdb;

    $cache_key = sanitize_text_field((string) $cache_key);
    $payload = tryzub_bi_scrub_cache_payload(is_array($payload) ? $payload : []);
    $payload_json = wp_json_encode($payload);

    if ($cache_key === '' || $payload_json === false) {
        return false;
    }

    $table_name = tryzub_get_intelligence_cache_table_name();
    $now = current_time('mysql');
    $data = [
        'cache_group' => sanitize_key((string) ($meta['cache_group'] ?? 'business_intelligence')),
        'cache_key' => $cache_key,
        'range_key' => sanitize_key((string) ($meta['range_key'] ?? 'custom')),
        'range_from' => sanitize_text_field((string) ($meta['range_from'] ?? '')),
        'range_to' => sanitize_text_field((string) ($meta['range_to'] ?? '')),
        'generated_date' => sanitize_text_field((string) ($meta['generated_date'] ?? current_time('Y-m-d'))),
        'cache_version' => max(1, absint($meta['cache_version'] ?? tryzub_bi_cache_version())),
        'payload_json' => $payload_json,
        'compute_duration_ms' => $duration_ms !== null ? max(0, absint($duration_ms)) : null,
        'created_at' => $now,
        'updated_at' => $now,
    ];
    $formats = ['%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%d', '%s', '%s'];

    $existing = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT id FROM $table_name WHERE cache_key = %s LIMIT 1",
            $cache_key
        )
    );

    if ($existing) {
        unset($data['created_at']);
        array_splice($formats, 9, 1);

        return $wpdb->update(
            $table_name,
            $data,
            ['cache_key' => $cache_key],
            $formats,
            ['%s']
        ) !== false;
    }

    return $wpdb->insert($table_name, $data, $formats) !== false;
}

function tryzub_bi_cache_prune_old_rows($keep_days = 14) {
    global $wpdb;

    $keep_days = max(1, absint($keep_days));
    $cutoff = current_datetime()->modify('-' . $keep_days . ' days')->format('Y-m-d');

    return $wpdb->query(
        $wpdb->prepare(
            "DELETE FROM " . tryzub_get_intelligence_cache_table_name() . "
            WHERE generated_date < %s",
            $cutoff
        )
    );
}

function tryzub_bi_earliest_reservation_date() {
    global $wpdb;

    $date = $wpdb->get_var(
        "SELECT MIN(reservation_date)
        FROM " . tryzub_get_reservations_table_name() . "
        WHERE reservation_date IS NOT NULL
        AND is_hidden = 0
        AND superseded_by_id IS NULL"
    );

    return $date ? sanitize_text_field((string) $date) : null;
}

function tryzub_bi_get_standard_ranges() {
    $today = current_time('Y-m-d');
    $today_date = DateTimeImmutable::createFromFormat('!Y-m-d', $today, wp_timezone());

    if (!$today_date instanceof DateTimeImmutable) {
        $today_date = new DateTimeImmutable('today', wp_timezone());
        $today = $today_date->format('Y-m-d');
    }

    $rolling_start = $today_date->modify('-365 days')->format('Y-m-d');
    $earliest = tryzub_bi_earliest_reservation_date();
    $all_from = $earliest && $earliest > $rolling_start ? $earliest : $rolling_start;

    return [
        'this_month' => [
            'from' => $today_date->format('Y-m-01'),
            'to' => $today,
        ],
        'last_30_days' => [
            'from' => $today_date->modify('-29 days')->format('Y-m-d'),
            'to' => $today,
        ],
        'all' => [
            'from' => $all_from,
            'to' => $today,
        ],
    ];
}

function tryzub_bi_precompute_and_store($range_key, $from, $to, $force = false) {
    $range_key = sanitize_key((string) $range_key);
    $range = tryzub_intelligence_validate_date_range($from, $to, 366);

    if (is_wp_error($range)) {
        return $range;
    }

    $generated_date = current_time('Y-m-d');
    $cache_version = tryzub_bi_cache_version();
    $cache_key = tryzub_bi_cache_build_key($range_key, $range['from'], $range['to'], $generated_date, $cache_version);

    if (!$force && tryzub_bi_cache_get($cache_key)) {
        return [
            'status' => 'cached',
            'cache_key' => $cache_key,
            'range_key' => $range_key,
        ];
    }

    $start = microtime(true);
    $payload = tryzub_business_intelligence_compute_payload($range);
    $duration_ms = (int) round((microtime(true) - $start) * 1000);
    $saved = tryzub_bi_cache_put(
        $cache_key,
        [
            'range_key' => $range_key,
            'range_from' => $range['from'],
            'range_to' => $range['to'],
            'generated_date' => $generated_date,
            'cache_version' => $cache_version,
        ],
        $payload,
        $duration_ms
    );

    if (!$saved) {
        return new WP_Error(
            'tryzub_bi_cache_write_failed',
            'Business intelligence cache write failed.'
        );
    }

    return [
        'status' => 'computed',
        'cache_key' => $cache_key,
        'range_key' => $range_key,
        'compute_duration_ms' => $duration_ms,
    ];
}

function tryzub_bi_run_daily_precompute() {
    foreach (tryzub_bi_get_standard_ranges() as $range_key => $range) {
        $result = tryzub_bi_precompute_and_store($range_key, $range['from'], $range['to'], true);

        if (is_wp_error($result)) {
            error_log('Tryzub BI daily precompute failed for ' . $range_key . ': ' . $result->get_error_message());
        }
    }

    tryzub_bi_cache_prune_old_rows(14);
}

function tryzub_bi_next_daily_precompute_timestamp() {
    $timezone = wp_timezone();
    $next = new DateTimeImmutable('tomorrow 06:00:00', $timezone);

    return $next->getTimestamp();
}

function tryzub_schedule_bi_daily_precompute() {
    if (!wp_next_scheduled('tryzub_bi_daily_precompute_cron')) {
        wp_schedule_event(tryzub_bi_next_daily_precompute_timestamp(), 'daily', 'tryzub_bi_daily_precompute_cron');
    }
}

function tryzub_bi_cache_format_row($row) {
    if (!is_array($row) || empty($row['payload_json'])) {
        return null;
    }

    $payload = json_decode((string) $row['payload_json'], true);

    if (!is_array($payload)) {
        return null;
    }

    return [
        'payload' => $payload,
        'meta' => [
            'range_key' => (string) ($row['range_key'] ?? 'custom'),
            'generated_at' => (string) ($row['updated_at'] ?? ''),
            'generated_date' => (string) ($row['generated_date'] ?? ''),
            'compute_duration_ms' => isset($row['compute_duration_ms']) ? (int) $row['compute_duration_ms'] : null,
            'cache_version' => isset($row['cache_version']) ? (int) $row['cache_version'] : tryzub_bi_cache_version(),
        ],
    ];
}

function tryzub_bi_scrub_cache_payload(array $payload) {
    $blocked_keys = [
        'email',
        'phone',
        'guest_name',
        'guest_notes',
        'staff_notes',
        'token',
        'raw_token',
        'token_hash',
        'api_key',
        'authorization',
        'password',
    ];

    foreach ($payload as $key => $value) {
        $normalized_key = strtolower((string) $key);

        if (in_array($normalized_key, $blocked_keys, true) || strpos($normalized_key, 'token') !== false || strpos($normalized_key, 'api_key') !== false) {
            unset($payload[$key]);
            continue;
        }

        if (is_array($value)) {
            $payload[$key] = tryzub_bi_scrub_cache_payload($value);
        }
    }

    return $payload;
}

add_action('tryzub_bi_daily_precompute_cron', 'tryzub_bi_run_daily_precompute');
