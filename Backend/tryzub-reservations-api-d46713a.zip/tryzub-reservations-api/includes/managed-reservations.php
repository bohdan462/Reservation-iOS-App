<?php

// TODO: Build this next.
// This should read rows from the managed reservations table and return app-ready reservation records.
// It should support filters like date, from, to, status, search, page, and per_page.
function tryzub_get_managed_reservations(WP_REST_Request $request) {
    global $wpdb;

    tryzub_complete_past_active_reservations();

    $table_name = tryzub_get_reservations_table_name();

    $per_page = min(max((int) $request->get_param('per_page'), 1), 100);
    $page = max((int) $request->get_param('page'), 1);
    $offset = ($page - 1) * $per_page;

    $date = $request->get_param('date');
    $from = $request->get_param('from');
    $to = $request->get_param('to');
    $status = $request->get_param('status');
    $search = $request->get_param('search');
    $updated_since = $request->get_param('updated_since');
    $include_hidden = tryzub_rest_request_bool($request->get_param('include_hidden'));

    $where = ['1=1'];
    $values = [];

    if (!$include_hidden) {
        $where[] = 'is_hidden = 0';
    }

    if ($date) {
        $date = tryzub_normalize_reservation_date($date);

        if (!$date) {
            return new WP_Error(
                'tryzub_invalid_date',
                'date must be a valid reservation date.',
                ['status' => 400]
            );
        }

        $where[] = 'reservation_date = %s';
        $values[] = $date;
    }

    if ($from) {
        $from = tryzub_normalize_reservation_date($from);

        if (!$from) {
            return new WP_Error(
                'tryzub_invalid_date',
                'from must be a valid reservation date.',
                ['status' => 400]
            );
        }

        $where[] = 'reservation_date >= %s';
        $values[] = $from;
    }

    if ($to) {
        $to = tryzub_normalize_reservation_date($to);

        if (!$to) {
            return new WP_Error(
                'tryzub_invalid_date',
                'to must be a valid reservation date.',
                ['status' => 400]
            );
        }

        $where[] = 'reservation_date <= %s';
        $values[] = $to;
    }

    if ($status) {
        $status = sanitize_text_field((string) $status);

        if (!in_array($status, tryzub_get_allowed_reservation_statuses(), true)) {
            return new WP_Error(
                'tryzub_invalid_status',
                'Invalid reservation status.',
                ['status' => 400]
            );
        }

        $where[] = 'status = %s';
        $values[] = $status;
    }

    if ($search) {
        $like = '%' . $wpdb->esc_like($search) . '%';
        $where[] = '(guest_name LIKE %s OR email LIKE %s OR phone LIKE %s)';
        $values[] = $like;
        $values[] = $like;
        $values[] = $like;
    }

    if ($updated_since) {
        $updated_since = tryzub_normalize_updated_since_value($updated_since);

        if (!$updated_since) {
            return new WP_Error(
                'tryzub_invalid_updated_since',
                'updated_since must be a valid YYYY-MM-DD HH:mm:ss or ISO8601 timestamp.',
                ['status' => 400]
            );
        }

        $where[] = '(updated_at >= %s OR created_at >= %s)';
        $values[] = $updated_since;
        $values[] = $updated_since;
    }

    $where_sql = implode(' AND ', $where);

    $count_sql = "SELECT COUNT(*) FROM $table_name WHERE $where_sql";

    if (!empty($values)) {
        $count_sql = $wpdb->prepare($count_sql, $values);
    }

    $total = (int) $wpdb->get_var($count_sql);
    $total_pages = (int) ceil($total / $per_page);

    $data_sql = "
        SELECT
            id,
            source_submission_id,
            source_type,
            created_by_user_id,
            created_by_device,
            guest_name,
            email,
            phone,
            reservation_date,
            reservation_time,
            party_size,
            guest_notes,
            staff_notes,
            status,
            table_name,
            created_at,
            updated_at,
            confirmed_at,
            seated_at,
            completed_at,
            confirmation_email_sent_at,
            reminder_email_sent_at,
            superseded_by_id,
            is_hidden,
            hidden_at,
            hidden_reason,
            hidden_by_user_id
        FROM $table_name
        WHERE $where_sql
        ORDER BY reservation_date ASC, reservation_time ASC, id ASC
        LIMIT %d OFFSET %d
    ";

    $data_values = array_merge($values, [$per_page, $offset]);
    $prepared_data_sql = $wpdb->prepare($data_sql, $data_values);

    $rows = $wpdb->get_results($prepared_data_sql, ARRAY_A);

    $reservations = array_map('tryzub_format_managed_reservation_row', $rows);

    return rest_ensure_response([
        'success' => true,
        'server_time' => current_time('mysql'),
        'page' => $page,
        'per_page' => $per_page,
        'total' => $total,
        'total_pages' => $total_pages,
        'data' => $reservations
    ]);
}

function tryzub_get_managed_reservation(WP_REST_Request $request) {
    tryzub_complete_past_active_reservations();

    $id = absint($request->get_param('id'));
    $reservation = tryzub_get_managed_reservation_by_id($id);

    if (!$reservation) {
        return new WP_Error(
            'tryzub_reservation_not_found',
            'Managed reservation not found.',
            ['status' => 404]
        );
    }

    return rest_ensure_response([
        'success' => true,
        'server_time' => current_time('mysql'),
        'data' => $reservation
    ]);
}

// Creates one managed reservation directly from the iOS app or staff tooling.
// If source_submission_id is provided, the new managed row is linked to that Flamingo submission and future imports will skip it.
function tryzub_create_managed_reservation(WP_REST_Request $request) {
    $body = tryzub_get_rest_request_body($request);
    $reservation = tryzub_prepare_manual_reservation_from_body($body);

    if (is_wp_error($reservation)) {
        return $reservation;
    }

    $insert_result = tryzub_insert_managed_reservation($reservation);

    if (is_wp_error($insert_result)) {
        return $insert_result;
    }

    if (!empty($reservation['id'])) {
        tryzub_mark_import_failure_resolved((int) $reservation['id'], 'Manual reservation created from failed import.');
    }

    $inserted_id = (int) $insert_result;
    $activity_context = tryzub_reservation_activity_request_context($body);
    $logged_activity = tryzub_reservation_activity_log_many(
        $inserted_id,
        [[
            'event_type' => 'created',
            'summary' => tryzub_reservation_activity_created_summary($reservation['source_type'] ?? ''),
            'metadata' => [
                'source_type' => sanitize_text_field((string) ($reservation['source_type'] ?? '')),
            ],
        ]],
        $activity_context
    );

    $response = rest_ensure_response(
        tryzub_reservation_activity_attach_to_response([
            'success' => true,
            'server_time' => current_time('mysql'),
            'data' => tryzub_get_managed_reservation_by_id($inserted_id),
        ], $logged_activity)
    );

    $response->set_status(201);

    return $response;
}

function tryzub_get_rest_request_body(WP_REST_Request $request) {
    $body = $request->get_json_params();

    if (!is_array($body)) {
        $body = $request->get_body_params();
    }

    return is_array($body) ? $body : [];
}

function tryzub_prepare_manual_reservation_from_body(array $body) {
    $source_submission_id = array_key_exists('source_submission_id', $body) ? absint($body['source_submission_id']) : null;
    $source_type = array_key_exists('source_type', $body)
        ? sanitize_text_field((string) $body['source_type'])
        : ($source_submission_id ? 'import_repair' : 'manual_call_in');

    if (!in_array($source_type, tryzub_get_allowed_reservation_source_types(), true)) {
        return new WP_Error(
            'tryzub_invalid_source_type',
            'Invalid reservation source type.',
            ['status' => 400]
        );
    }

    if ($source_submission_id && !in_array($source_type, ['form', 'import_repair'], true)) {
        return new WP_Error(
            'tryzub_invalid_source_type',
            'Reservations linked to Flamingo submissions must use form or import_repair source type.',
            ['status' => 400]
        );
    }

    if ($source_submission_id) {
        if (tryzub_managed_reservation_exists($source_submission_id)) {
            return new WP_Error(
                'tryzub_source_submission_already_imported',
                'This Flamingo submission already has a managed reservation.',
                ['status' => 409]
            );
        }

        $source_post = get_post($source_submission_id);

        if (!$source_post || $source_post->post_type !== 'flamingo_inbound') {
            return new WP_Error(
                'tryzub_invalid_source_submission',
                'source_submission_id must point to a Flamingo inbound message.',
                ['status' => 400]
            );
        }
    }

    $guest_name = sanitize_text_field((string) ($body['guest_name'] ?? ''));

    if ($guest_name === '') {
        return new WP_Error(
            'tryzub_invalid_guest_name',
            'Guest name is required.',
            ['status' => 400]
        );
    }

    $email = sanitize_email((string) ($body['email'] ?? ''));

    if ($email === '' && tryzub_reservation_source_allows_missing_email($source_type)) {
        $email = tryzub_get_call_in_placeholder_email();
    }

    if (!is_email($email)) {
        return new WP_Error(
            'tryzub_invalid_email',
            'Guest email is invalid.',
            ['status' => 400]
        );
    }

    $phone = tryzub_normalize_phone_digits($body['phone'] ?? '');

    if (strlen($phone) < 10) {
        return new WP_Error(
            'tryzub_invalid_phone',
            'Guest phone must contain at least 10 digits.',
            ['status' => 400]
        );
    }

    $reservation_date = tryzub_normalize_reservation_date($body['reservation_date'] ?? '');

    if (!$reservation_date) {
        return new WP_Error(
            'tryzub_invalid_date',
            'Reservation date is required and must be a valid date.',
            ['status' => 400]
        );
    }

    $reservation_time = tryzub_normalize_reservation_time($body['reservation_time'] ?? '');

    if (!$reservation_time) {
        return new WP_Error(
            'tryzub_invalid_time',
            'Reservation time is required and must be valid.',
            ['status' => 400]
        );
    }

    $party_size = absint($body['party_size'] ?? 0);

    if ($party_size < 1 || $party_size > tryzub_get_max_party_size()) {
        return new WP_Error(
            'tryzub_invalid_party_size',
            'Party size must be a positive number within the allowed limit.',
            ['status' => 400]
        );
    }

    $status = null;

    if (array_key_exists('status', $body)) {
        $status = sanitize_text_field((string) $body['status']);

        if (!in_array($status, tryzub_get_allowed_reservation_statuses(), true)) {
            return new WP_Error(
                'tryzub_invalid_status',
                'Invalid reservation status.',
                ['status' => 400]
            );
        }

        if ($source_type === 'manual_walk_in' && !in_array($status, ['confirmed', 'seated'], true)) {
            return new WP_Error(
                'tryzub_invalid_status',
                'Manual walk-ins may only be created as confirmed or seated.',
                ['status' => 400]
            );
        }
    } elseif (in_array($source_type, ['manual_call_in', 'manual_walk_in', 'known_guest_manual'], true)) {
        $status = 'confirmed';
    }

    return [
        'id' => $source_submission_id ?: null,
        'source_type' => $source_type,
        'created_by_user_id' => get_current_user_id() ?: null,
        'created_by_device' => array_key_exists('created_by_device', $body) ? sanitize_text_field((string) $body['created_by_device']) : null,
        'guest_name' => $guest_name,
        'email' => $email,
        'phone' => $phone,
        'reservation_date' => $reservation_date,
        'reservation_time' => $reservation_time,
        'party_size' => $party_size,
        'notes' => sanitize_textarea_field((string) ($body['guest_notes'] ?? '')),
        'staff_notes' => sanitize_textarea_field((string) ($body['staff_notes'] ?? '')),
        'status' => $status,
        'table_name' => array_key_exists('table_name', $body) ? sanitize_text_field((string) $body['table_name']) : null,
    ];
}

// Updates one managed reservation.
// This is the write endpoint the iOS app will use for staff actions like confirming, assigning a table, and adding notes.
function tryzub_update_managed_reservation(WP_REST_Request $request) {
    global $wpdb;

    $id = absint($request->get_param('id'));
    $reservations_table_name = tryzub_get_reservations_table_name();
    $existing = tryzub_get_managed_reservation_row_by_id($id);

    if (!$existing) {
        return new WP_Error(
            'tryzub_reservation_not_found',
            'Managed reservation not found.',
            ['status' => 404]
        );
    }

    $body = tryzub_get_rest_request_body($request);

    // Optimistic concurrency: when the client sends the version it last saw, reject stale writes
    // so two devices editing the same reservation cannot silently overwrite each other.
    $lock_conflict = tryzub_check_reservation_optimistic_lock($existing, $body);

    if ($lock_conflict instanceof WP_REST_Response) {
        return $lock_conflict;
    }

    unset($body['expected_updated_at']);
    $unknown_fields = array_diff(array_keys($body), tryzub_get_allowed_reservation_update_fields());

    if (!empty($unknown_fields)) {
        return new WP_Error(
            'tryzub_unknown_update_field',
            'Unknown update field: ' . implode(', ', array_values($unknown_fields)),
            ['status' => 400]
        );
    }

    $updates = [];
    $formats = [];

    if (array_key_exists('guest_name', $body)) {
        $guest_name = sanitize_text_field((string) $body['guest_name']);

        if ($guest_name === '') {
            return new WP_Error(
                'tryzub_invalid_guest_name',
                'Guest name cannot be empty.',
                ['status' => 400]
            );
        }

        $updates['guest_name'] = $guest_name;
        $formats[] = '%s';
    }

    if (array_key_exists('email', $body)) {
        $email = sanitize_email((string) $body['email']);

        if ($email === '' && tryzub_reservation_source_allows_missing_email($existing['source_type'] ?? 'form')) {
            $email = tryzub_get_call_in_placeholder_email();
        }

        if (!is_email($email)) {
            return new WP_Error(
                'tryzub_invalid_email',
                'Guest email is invalid.',
                ['status' => 400]
            );
        }

        $updates['email'] = $email;
        $formats[] = '%s';
    }

    if (array_key_exists('phone', $body)) {
        $phone = tryzub_normalize_phone_digits($body['phone']);

        if (strlen($phone) < 10) {
            return new WP_Error(
                'tryzub_invalid_phone',
                'Guest phone must contain at least 10 digits.',
                ['status' => 400]
            );
        }

        $updates['phone'] = $phone;
        $formats[] = '%s';
    }

    if (array_key_exists('reservation_date', $body)) {
        $date = tryzub_normalize_reservation_date($body['reservation_date']);

        if (!$date) {
            return new WP_Error(
                'tryzub_invalid_date',
                'Reservation date must be a valid date.',
                ['status' => 400]
            );
        }

        $updates['reservation_date'] = $date;
        $formats[] = '%s';
    }

    if (array_key_exists('reservation_time', $body)) {
        $time = tryzub_normalize_reservation_time($body['reservation_time']);

        if (!$time) {
            return new WP_Error(
                'tryzub_invalid_time',
                'Reservation time is invalid.',
                ['status' => 400]
            );
        }

        $updates['reservation_time'] = $time;
        $formats[] = '%s';
    }

    if (array_key_exists('party_size', $body)) {
        $party_size = absint($body['party_size']);

        if ($party_size < 1 || $party_size > tryzub_get_max_party_size()) {
            return new WP_Error(
                'tryzub_invalid_party_size',
                'Party size must be a positive number within the allowed limit.',
                ['status' => 400]
            );
        }

        $updates['party_size'] = $party_size;
        $formats[] = '%d';
    }

    if (array_key_exists('guest_notes', $body)) {
        $updates['guest_notes'] = sanitize_textarea_field((string) $body['guest_notes']);
        $formats[] = '%s';
    }

    if (array_key_exists('staff_notes', $body)) {
        $updates['staff_notes'] = sanitize_textarea_field((string) $body['staff_notes']);
        $formats[] = '%s';
    }

    if (array_key_exists('status', $body)) {
        $status = sanitize_text_field((string) $body['status']);

        if (!in_array($status, tryzub_get_allowed_reservation_statuses(), true)) {
            return new WP_Error(
                'tryzub_invalid_status',
                'Invalid reservation status.',
                ['status' => 400]
            );
        }

        $current_status = sanitize_text_field((string) ($existing['status'] ?? ''));

        if (!tryzub_managed_reservation_status_transition_allowed($current_status, $status)) {
            return new WP_Error(
                'tryzub_invalid_status_transition',
                'Status cannot move from ' . $current_status . ' to ' . $status . '.',
                [
                    'status' => 409,
                    'from' => $current_status,
                    'to' => $status,
                    'allowed_transitions' => tryzub_get_managed_reservation_status_transitions()[$current_status] ?? [],
                ]
            );
        }

        $updates['status'] = $status;
        $formats[] = '%s';

        $status_now = current_time('mysql');

        if ($status === 'confirmed' && empty($existing['confirmed_at'])) {
            $updates['confirmed_at'] = $status_now;
            $formats[] = '%s';
        }

        if ($status === 'seated' && empty($existing['seated_at'])) {
            $updates['seated_at'] = $status_now;
            $formats[] = '%s';
        }

        if ($status === 'completed' && empty($existing['completed_at'])) {
            $updates['completed_at'] = $status_now;
            $formats[] = '%s';
        }
    }

    if (array_key_exists('table_name', $body)) {
        $table_name_value = sanitize_text_field((string) $body['table_name']);
        $updates['table_name'] = $table_name_value !== '' ? $table_name_value : null;
        $formats[] = '%s';
    }

    if (array_key_exists('superseded_by_id', $body)) {
        $superseded_by_id = absint($body['superseded_by_id']);

        if ($superseded_by_id < 1) {
            return new WP_Error(
                'tryzub_invalid_superseded_by_id',
                'Superseded by must be a valid managed reservation ID.',
                ['status' => 400]
            );
        }

        if ($superseded_by_id === $id) {
            return new WP_Error(
                'tryzub_invalid_superseded_by_id',
                'A reservation cannot supersede itself.',
                ['status' => 400]
            );
        }

        if (!tryzub_get_managed_reservation_row_by_id($superseded_by_id)) {
            return new WP_Error(
                'tryzub_superseded_reservation_not_found',
                'Superseded reservation was not found.',
                ['status' => 400]
            );
        }

        $updates['superseded_by_id'] = $superseded_by_id;
        $formats[] = '%d';
    }

    if (array_key_exists('is_hidden', $body)) {
        $is_hidden = tryzub_normalize_boolean_value($body['is_hidden']);

        if ($is_hidden === null) {
            return new WP_Error(
                'tryzub_invalid_is_hidden',
                'is_hidden must be true or false.',
                ['status' => 400]
            );
        }

        if ($is_hidden) {
            $updates['is_hidden'] = 1;
            $formats[] = '%d';
            $updates['hidden_at'] = current_time('mysql');
            $formats[] = '%s';
            $updates['hidden_reason'] = array_key_exists('hidden_reason', $body)
                ? sanitize_textarea_field((string) $body['hidden_reason'])
                : sanitize_textarea_field((string) ($existing['hidden_reason'] ?? ''));
            $formats[] = '%s';
            $updates['hidden_by_user_id'] = get_current_user_id() ?: null;
            $formats[] = '%d';
        } else {
            $updates['is_hidden'] = 0;
            $formats[] = '%d';
            $updates['hidden_at'] = null;
            $formats[] = '%s';
            $updates['hidden_reason'] = null;
            $formats[] = '%s';
            $updates['hidden_by_user_id'] = null;
            $formats[] = '%d';
        }
    } elseif (array_key_exists('hidden_reason', $body)) {
        $updates['hidden_reason'] = sanitize_textarea_field((string) $body['hidden_reason']);
        $formats[] = '%s';
    }

    if (empty($updates)) {
        return new WP_Error(
            'tryzub_no_update_fields',
            'No valid fields were provided for update.',
            ['status' => 400]
        );
    }

    $updates['updated_at'] = current_time('mysql');
    $formats[] = '%s';

    $result = $wpdb->update(
        $reservations_table_name,
        $updates,
        ['id' => $id],
        $formats,
        ['%d']
    );

    if ($result === false) {
        error_log('Tryzub reservation update failed for ID ' . $id . ': ' . $wpdb->last_error);

        return new WP_Error(
            'tryzub_database_error',
            'Failed to update managed reservation.',
            ['status' => 500]
        );
    }

    tryzub_bump_intelligence_cache_version();

    $after = tryzub_get_managed_reservation_row_by_id($id);
    tryzub_guest_profiles_mark_dirty_for_reservation_rows($existing, $after ?: [], 'reservation_updated');
    $activity_context = tryzub_reservation_activity_request_context($body);
    $logged_activity = tryzub_reservation_activity_log_many(
        $id,
        tryzub_reservation_activity_summarize_update($existing, $after ?: []),
        $activity_context
    );

    return rest_ensure_response(
        tryzub_reservation_activity_attach_to_response([
            'success' => true,
            'server_time' => current_time('mysql'),
            'data' => tryzub_get_managed_reservation_by_id($id),
        ], $logged_activity)
    );
}

function tryzub_delete_managed_reservation(WP_REST_Request $request) {
    global $wpdb;

    $id = absint($request->get_param('id'));
    $existing = tryzub_get_managed_reservation_row_by_id($id);

    if (!$existing) {
        return new WP_Error(
            'tryzub_reservation_not_found',
            'Managed reservation not found.',
            ['status' => 404]
        );
    }

    $body = tryzub_get_rest_request_body($request);

    // Reject stale deletes when the client supplies the version it last saw.
    $lock_conflict = tryzub_check_reservation_optimistic_lock($existing, $body);

    if ($lock_conflict instanceof WP_REST_Response) {
        return $lock_conflict;
    }

    $force = tryzub_rest_request_bool($request->get_param('force'));
    $protected_statuses = ['confirmed', 'seated', 'completed', 'no_show'];

    if (in_array($existing['status'], $protected_statuses, true) && !$force) {
        return new WP_Error(
            'tryzub_delete_force_required',
            'Permanent deletion for this reservation status requires force=1.',
            ['status' => 409]
        );
    }

    $reason = array_key_exists('reason', $body)
        ? sanitize_textarea_field((string) $body['reason'])
        : sanitize_textarea_field((string) $request->get_param('reason'));

    $audit_result = tryzub_record_reservation_deletion_audit($existing, $reason);

    if (is_wp_error($audit_result)) {
        return $audit_result;
    }

    $activity_context = tryzub_reservation_activity_request_context($body);
    $logged_activity = tryzub_reservation_activity_log_many(
        $id,
        [[
            'event_type' => 'hard_deleted',
            'summary' => 'Reservation permanently deleted.',
            'metadata' => [
                'reason_present' => trim((string) $reason) !== '',
            ],
        ]],
        $activity_context
    );

    $deleted = $wpdb->delete(
        tryzub_get_reservations_table_name(),
        ['id' => $id],
        ['%d']
    );

    if ($deleted === false) {
        error_log('Tryzub reservation hard delete failed for ID ' . $id . ': ' . $wpdb->last_error);

        return new WP_Error(
            'tryzub_database_error',
            'Failed to permanently delete managed reservation.',
            ['status' => 500]
        );
    }

    tryzub_bump_intelligence_cache_version();
    tryzub_guest_profiles_mark_dirty_for_reservation_row($existing, 'reservation_deleted');

    return rest_ensure_response(
        tryzub_reservation_activity_attach_to_response([
            'success' => true,
            'server_time' => current_time('mysql'),
            'deleted_id' => $id,
            'message' => 'Reservation permanently deleted.',
        ], $logged_activity)
    );
}

function tryzub_record_reservation_deletion_audit(array $reservation_row, $reason = '') {
    global $wpdb;

    $inserted = $wpdb->insert(
        tryzub_get_reservation_deletion_audit_table_name(),
        [
            'reservation_id' => absint($reservation_row['id'] ?? 0),
            'source_submission_id' => isset($reservation_row['source_submission_id']) && $reservation_row['source_submission_id'] !== null
                ? absint($reservation_row['source_submission_id'])
                : null,
            'deleted_by_user_id' => get_current_user_id() ?: null,
            'deleted_at' => current_time('mysql'),
            'reason' => sanitize_textarea_field((string) $reason),
            'reservation_snapshot_json' => wp_json_encode($reservation_row),
        ],
        ['%d', '%d', '%d', '%s', '%s', '%s']
    );

    if ($inserted === false) {
        error_log('Tryzub deletion audit insert failed: ' . $wpdb->last_error);

        return new WP_Error(
            'tryzub_database_error',
            'Failed to write reservation deletion audit log.',
            ['status' => 500]
        );
    }

    return true;
}

function tryzub_get_managed_reservation_by_id($id) {
    $row = tryzub_get_managed_reservation_row_by_id($id);

    if (!$row) {
        return null;
    }

    return tryzub_format_managed_reservation_row($row);
}

function tryzub_get_managed_reservation_row_by_id($id) {
    global $wpdb;

    $table_name = tryzub_get_reservations_table_name();

    return $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM $table_name WHERE id = %d LIMIT 1",
            absint($id)
        ),
        ARRAY_A
    );
}

function tryzub_get_allowed_reservation_statuses() {
    return [
        'new',
        'needs_review',
        'confirmed',
        'seated',
        'completed',
        'cancelled',
        'no_show'
    ];
}

function tryzub_get_allowed_reservation_update_fields() {
    return [
        'guest_name',
        'email',
        'phone',
        'reservation_date',
        'reservation_time',
        'party_size',
        'guest_notes',
        'staff_notes',
        'status',
        'table_name',
        'superseded_by_id',
        'is_hidden',
        'hidden_reason',
    ];
}

function tryzub_get_max_party_size() {
    return 100;
}

// Returns the concurrency token for a reservation row. Clients echo this back as expected_updated_at.
// Uses updated_at when present, otherwise created_at for rows that have never been updated.
function tryzub_managed_reservation_row_version(array $row) {
    $updated_at = trim((string) ($row['updated_at'] ?? ''));

    if ($updated_at !== '' && $updated_at !== '0000-00-00 00:00:00') {
        return $updated_at;
    }

    return trim((string) ($row['created_at'] ?? ''));
}

// Optimistic concurrency guard. Returns null when the write may proceed, or a 409 WP_REST_Response when
// the client's expected_updated_at no longer matches the current row version (another device changed it).
// The check is opt-in: requests that omit expected_updated_at keep working for backward compatibility.
function tryzub_check_reservation_optimistic_lock(array $existing, array $body) {
    if (!is_array($body) || !array_key_exists('expected_updated_at', $body)) {
        return null;
    }

    $expected = trim(sanitize_text_field((string) $body['expected_updated_at']));

    if ($expected === '') {
        return null;
    }

    $current = tryzub_managed_reservation_row_version($existing);
    $expected_normalized = tryzub_normalize_updated_since_value($expected);
    $current_normalized = tryzub_normalize_updated_since_value($current);

    $matches = ($expected === $current)
        || ($expected_normalized !== null && $current_normalized !== null && $expected_normalized === $current_normalized);

    if ($matches) {
        return null;
    }

    return new WP_REST_Response([
        'success' => false,
        'code' => 'tryzub_reservation_conflict',
        'message' => 'This reservation was changed on another device. Reload the latest version before saving.',
        'expected_updated_at' => $expected,
        'current_version' => $current,
        'server_time' => current_time('mysql'),
        'data' => tryzub_format_managed_reservation_row($existing),
    ], 409);
}

// Allowed status transitions. Blocks nonsensical moves (e.g. completed -> cancelled, no_show -> completed)
// while still allowing realistic staff corrections (un-cancel, reopen a prematurely completed booking).
// A no-op transition (same status) is always allowed.
function tryzub_get_managed_reservation_status_transitions() {
    return [
        'new' => ['needs_review', 'confirmed', 'seated', 'completed', 'cancelled', 'no_show'],
        'needs_review' => ['new', 'confirmed', 'seated', 'completed', 'cancelled', 'no_show'],
        'confirmed' => ['new', 'needs_review', 'seated', 'completed', 'cancelled', 'no_show'],
        'seated' => ['confirmed', 'completed', 'cancelled', 'no_show'],
        'completed' => ['seated', 'confirmed'],
        'cancelled' => ['new', 'needs_review', 'confirmed'],
        'no_show' => ['new', 'needs_review', 'confirmed', 'seated'],
    ];
}

function tryzub_managed_reservation_status_transition_allowed($from, $to) {
    $from = sanitize_text_field((string) $from);
    $to = sanitize_text_field((string) $to);

    if ($from === $to) {
        return true;
    }

    $map = tryzub_get_managed_reservation_status_transitions();

    // Unknown/legacy current status: do not block so existing data stays editable.
    if (!isset($map[$from])) {
        return true;
    }

    return in_array($to, $map[$from], true);
}

// Keeps existing managed rows aligned with the operational rule:
// once a reservation date is in the past, active reservations should no longer appear as new/upcoming work.
//
// This is called from read endpoints so the rollover is reflected almost immediately, but it is throttled
// with a short-lived transient so concurrent multi-device reads do not each fire the same UPDATE and cause
// write contention. The hourly cron backstop (tryzub_run_past_active_reservation_completion) guarantees the
// sweep still runs even if no one reads the API.
function tryzub_complete_past_active_reservations() {
    if (get_transient('tryzub_past_completion_sweep_lock')) {
        return;
    }

    set_transient('tryzub_past_completion_sweep_lock', time(), MINUTE_IN_SECONDS);

    tryzub_run_past_active_reservation_completion();
}

function tryzub_run_past_active_reservation_completion() {
    global $wpdb;

    $table_name = tryzub_get_reservations_table_name();
    $today = current_time('Y-m-d');
    $now = current_time('mysql');
    $active_statuses = ['new', 'needs_review', 'confirmed', 'seated'];
    $status_placeholders = implode(', ', array_fill(0, count($active_statuses), '%s'));
    $select_values = array_merge([$today], $active_statuses);

    $rows_to_complete = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT id
            FROM $table_name
            WHERE reservation_date < %s
            AND status IN ($status_placeholders)",
            $select_values
        ),
        ARRAY_A
    );

    if (empty($rows_to_complete)) {
        return;
    }

    $wpdb->query(
        $wpdb->prepare(
            "UPDATE $table_name
            SET status = 'completed',
                completed_at = COALESCE(completed_at, %s),
                updated_at = %s
            WHERE reservation_date < %s
            AND status IN ($status_placeholders)",
            array_merge([$now, $now, $today], $active_statuses)
        )
    );

    foreach ($rows_to_complete as $row) {
        tryzub_reservation_activity_log(
            (int) ($row['id'] ?? 0),
            'auto_completed',
            'Reservation automatically marked completed after service date.',
            [
                'source' => 'backend',
                'metadata' => [
                    'trigger' => 'past_date_sweep',
                ],
            ]
        );
    }
}

// Hourly backstop so past-date active reservations are completed even on installs with little read traffic.
add_action('tryzub_reservation_reminders_cron', 'tryzub_run_past_active_reservation_completion');

function tryzub_is_valid_managed_reservation_date($date) {
    $date = sanitize_text_field($date);
    $parsed = DateTime::createFromFormat('Y-m-d', $date);

    return $parsed instanceof DateTime && $parsed->format('Y-m-d') === $date;
}

function tryzub_rest_request_bool($value) {
    $normalized = tryzub_normalize_boolean_value($value);
    return $normalized === true;
}

function tryzub_normalize_updated_since_value($value) {
    $value = trim(sanitize_text_field((string) $value));

    if ($value === '') {
        return null;
    }

    $formats = ['Y-m-d H:i:s', 'Y-m-d\TH:i:s', 'Y-m-d\TH:i:sP'];

    foreach ($formats as $format) {
        $date = DateTime::createFromFormat($format, $value);
        $errors = DateTime::getLastErrors();

        if (
            $date instanceof DateTime &&
            (
                $errors === false ||
                ((int) $errors['warning_count'] === 0 && (int) $errors['error_count'] === 0)
            )
        ) {
            return $date->format('Y-m-d H:i:s');
        }
    }

    try {
        $date = new DateTime($value);
        return $date->format('Y-m-d H:i:s');
    } catch (Exception $exception) {
        return null;
    }
}

function tryzub_normalize_boolean_value($value) {
    if (is_bool($value)) {
        return $value;
    }

    if (is_int($value)) {
        return $value === 1 ? true : ($value === 0 ? false : null);
    }

    $value = strtolower(trim((string) $value));

    if (in_array($value, ['1', 'true', 'yes', 'on'], true)) {
        return true;
    }

    if (in_array($value, ['0', 'false', 'no', 'off', ''], true)) {
        return false;
    }

    return null;
}

function tryzub_format_managed_reservation_row(array $row) {
    $source_type = sanitize_text_field((string) ($row['source_type'] ?? 'form'));
    $email = (string) ($row['email'] ?? '');

    if (tryzub_reservation_source_allows_missing_email($source_type) && tryzub_is_call_in_placeholder_email($email)) {
        $email = '';
    }

    return [
        'id' => (int) $row['id'],
        'source_submission_id' => $row['source_submission_id'] !== null ? (int) $row['source_submission_id'] : null,
        'source_type' => $source_type ?: 'form',
        'created_by_user_id' => isset($row['created_by_user_id']) && $row['created_by_user_id'] !== null ? (int) $row['created_by_user_id'] : null,
        'created_by_device' => $row['created_by_device'] ?? null,
        'guest_name' => $row['guest_name'],
        'email' => $email,
        'phone' => $row['phone'],
        'reservation_date' => $row['reservation_date'],
        'reservation_time' => $row['reservation_time'],
        'party_size' => (int) $row['party_size'],
        'guest_notes' => $row['guest_notes'],
        'staff_notes' => $row['staff_notes'],
        'status' => $row['status'],
        'table_name' => $row['table_name'],
        'created_at' => $row['created_at'],
        'updated_at' => $row['updated_at'],
        'confirmed_at' => $row['confirmed_at'],
        'seated_at' => $row['seated_at'] ?? null,
        'completed_at' => $row['completed_at'] ?? null,
        'confirmation_email_sent_at' => $row['confirmation_email_sent_at'],
        'reminder_email_sent_at' => $row['reminder_email_sent_at'],
        'superseded_by_id' => $row['superseded_by_id'] !== null ? (int) $row['superseded_by_id'] : null,
        'is_hidden' => (int) ($row['is_hidden'] ?? 0),
        'hidden_at' => $row['hidden_at'] ?? null,
        'hidden_reason' => $row['hidden_reason'] ?? null,
        'hidden_by_user_id' => isset($row['hidden_by_user_id']) && $row['hidden_by_user_id'] !== null ? (int) $row['hidden_by_user_id'] : null,
        // Concurrency token: the value the client must echo back as expected_updated_at to guard against
        // overwriting another device's change. Equals updated_at, or created_at for never-updated rows.
        'row_version' => tryzub_managed_reservation_row_version($row),
    ];
}

// Checks whether a specific Flamingo submission has already been imported.
// This is import idempotency: the import endpoint can run again without duplicating the same source post.
function tryzub_managed_reservation_exists($source_submission_id) {
    global $wpdb;

    $source_submission_id = absint($source_submission_id);

    if (!$source_submission_id) {
        return false;
    }

    $table_name = tryzub_get_reservations_table_name();

    $existing_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $table_name WHERE source_submission_id = %d LIMIT 1",
        $source_submission_id
    ));
    return !empty($existing_id);
}

// Inserts one managed reservation row.
// This is where raw formatted submission data becomes restaurant-operational data.
// The initial status may become needs_review if the submission looks suspicious, large, invalid, or related to another active reservation.
function tryzub_insert_managed_reservation(array $reservation) {
    global $wpdb;
    $table_name = tryzub_get_reservations_table_name();
    $requested_status = sanitize_text_field((string) ($reservation['status'] ?? ''));
    $review = tryzub_determine_initial_status($reservation, $requested_status ?: null);
    $source_submission_id = isset($reservation['id']) && $reservation['id'] !== null ? absint($reservation['id']) : null;
    $table_name_value = sanitize_text_field((string) ($reservation['table_name'] ?? ''));
    $provided_staff_notes = sanitize_textarea_field((string) ($reservation['staff_notes'] ?? ''));
    $review_notes = implode("\n", $review['reasons']);
    $staff_notes = trim($review_notes . ($review_notes && $provided_staff_notes ? "\n" : '') . $provided_staff_notes);
    $confirmed_at = $review['status'] === 'confirmed' ? current_time('mysql') : null;
    $seated_at = $review['status'] === 'seated' ? current_time('mysql') : null;
    $completed_at = $review['status'] === 'completed' ? current_time('mysql') : null;
    $client_request_id = tryzub_normalize_client_request_id($reservation['client_request_id'] ?? null);
    $submission_fingerprint = sanitize_text_field((string) ($reservation['submission_fingerprint'] ?? ''));
    $duplicate_of_reservation_id = !empty($reservation['duplicate_of_reservation_id'])
        ? absint($reservation['duplicate_of_reservation_id'])
        : null;
    $duplicate_reason = !empty($reservation['duplicate_reason'])
        ? sanitize_text_field((string) $reservation['duplicate_reason'])
        : null;

    $insert = $wpdb->insert(
        $table_name,
        [
            'source_submission_id' => $source_submission_id,
            'client_request_id' => $client_request_id,
            'submission_fingerprint' => $submission_fingerprint ?: null,
            'duplicate_of_reservation_id' => $duplicate_of_reservation_id,
            'duplicate_reason' => $duplicate_reason,
            'source_type' => sanitize_text_field((string) ($reservation['source_type'] ?? 'form')),
            'created_by_user_id' => isset($reservation['created_by_user_id']) ? absint($reservation['created_by_user_id']) : null,
            'created_by_device' => isset($reservation['created_by_device']) ? sanitize_text_field((string) $reservation['created_by_device']) : null,
            'guest_name' => sanitize_text_field($reservation['guest_name'] ?? ''),
            'email' => sanitize_email($reservation['email'] ?? ''),
            'phone' => tryzub_normalize_phone_digits($reservation['phone'] ?? ''),
            'reservation_date' => sanitize_text_field($reservation['reservation_date'] ?? ''),
            'reservation_time' => tryzub_normalize_reservation_time($reservation['reservation_time'] ?? ''),
            'party_size' => absint($reservation['party_size']),
            'guest_notes' => sanitize_textarea_field($reservation['notes'] ?? ''),
            'status' => $review['status'],
            'staff_notes' => $staff_notes,
            'table_name' => $table_name_value !== '' ? $table_name_value : null,
            'created_at' => current_time('mysql'),
            'confirmed_at' => $confirmed_at,
            'seated_at' => $seated_at,
            'completed_at' => $completed_at,
            // 'updated_at' => null,
            // 'confirmation_email_sent_at' => null,
            // 'reminder_email_sent_at' => null,
            // 'superseded_by_id' => null
        ],
        [
            '%d',
            '%s',
            '%s',
            '%d',
            '%s',
            '%s',
            '%d',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%d',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s'
        ]
    );
    if ($insert === false) {
        error_log('Tryzub reservation insert failed: ' . $wpdb->last_error);

        return new WP_Error(
            'tryzub_database_error',
            'Failed to insert managed reservation',
            ['status' => 500]
        );
    }

    $inserted_id = (int) $wpdb->insert_id;
    $related_reservation_id = $review['related_reservation_id'] ?? null;

    if ($related_reservation_id) {
        tryzub_mark_related_reservation_for_review($related_reservation_id, $inserted_id);
    }

    tryzub_bump_intelligence_cache_version();
    tryzub_guest_profiles_mark_dirty_for_reservation($inserted_id, 'reservation_created');

    return $inserted_id;
}

// When a new submission looks like a correction or duplicate, flag the older active row too.
// Staff can then compare both records and decide which one to keep.
function tryzub_mark_related_reservation_for_review($related_reservation_id, $new_reservation_id) {
    global $wpdb;

    $table_name = tryzub_get_reservations_table_name();

    $related = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT id, status, staff_notes FROM $table_name WHERE id = %d LIMIT 1",
            absint($related_reservation_id)
        ),
        ARRAY_A
    );

    if (!$related) {
        return;
    }

    if (!in_array($related['status'], ['new', 'needs_review', 'confirmed'], true)) {
        return;
    }

    $note = 'Possible duplicate or correction: new reservation ID ' . absint($new_reservation_id) . ' was imported with the same date/contact.';
    $existing_notes = trim((string) ($related['staff_notes'] ?? ''));
    $updated_notes = $existing_notes;

    if (strpos($existing_notes, $note) === false) {
        $updated_notes = $existing_notes !== '' ? $existing_notes . "\n" . $note : $note;
    }

    $wpdb->update(
        $table_name,
        [
            'status' => 'needs_review',
            'staff_notes' => $updated_notes,
            'updated_at' => current_time('mysql')
        ],
        ['id' => absint($related_reservation_id)],
        ['%s', '%s', '%s'],
        ['%d']
    );
}
