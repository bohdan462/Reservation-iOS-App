<?php

function tryzub_guest_profiles_table_exists() {
    global $wpdb;

    $table_name = tryzub_get_guest_profiles_table_name();

    return $wpdb->get_var(
        $wpdb->prepare("SHOW TABLES LIKE %s", $table_name)
    ) === $table_name;
}

function tryzub_guest_profiles_guest_key_for_reservation_row($row) {
    $identity = tryzub_intelligence_identity_from_row($row);

    return $identity['guest_key'] ?? null;
}

function tryzub_guest_profiles_mark_dirty_for_reservation($reservation_id, $reason = 'reservation_changed') {
    $row = tryzub_get_managed_reservation_row_by_id(absint($reservation_id));

    if (!$row) {
        return false;
    }

    return tryzub_guest_profiles_mark_dirty_for_reservation_row($row, $reason);
}

function tryzub_guest_profiles_mark_dirty_for_reservation_row(array $row, $reason = 'reservation_changed') {
    $identity = tryzub_intelligence_identity_from_row($row);
    $guest_key = $identity['guest_key'] ?? null;

    if (!$guest_key) {
        return false;
    }

    return tryzub_guest_profiles_mark_dirty_for_guest_key($guest_key, $reason, [
        'primary_name' => sanitize_text_field((string) ($row['guest_name'] ?? '')),
        'primary_email' => $identity['normalized_email'] ?: tryzub_intelligence_normalize_email($row['email'] ?? ''),
        'primary_phone' => sanitize_text_field((string) ($row['phone'] ?? '')),
        'normalized_phone' => $identity['normalized_phone'] ?? '',
        'identity_confidence' => sanitize_text_field((string) ($identity['confidence'] ?? 'derived')),
    ]);
}

function tryzub_guest_profiles_mark_dirty_for_reservation_rows($before, $after, $reason = 'reservation_changed') {
    $marked = false;
    $seen = [];

    foreach ([$before, $after] as $row) {
        if (!is_array($row) || empty($row)) {
            continue;
        }

        $guest_key = tryzub_guest_profiles_guest_key_for_reservation_row($row);

        if (!$guest_key || isset($seen[$guest_key])) {
            continue;
        }

        $seen[$guest_key] = true;
        $marked = tryzub_guest_profiles_mark_dirty_for_reservation_row($row, $reason) || $marked;
    }

    return $marked;
}

function tryzub_guest_profiles_mark_dirty_for_guest_key($guest_key, $reason = 'manual', array $identity_hint = []) {
    global $wpdb;

    if (!tryzub_guest_profiles_table_exists()) {
        return false;
    }

    $guest_key = sanitize_text_field((string) $guest_key);

    if ($guest_key === '') {
        return false;
    }

    $table_name = tryzub_get_guest_profiles_table_name();
    $now = current_time('mysql');
    $now_gmt = current_time('mysql', true);
    $existing_id = $wpdb->get_var(
        $wpdb->prepare("SELECT id FROM $table_name WHERE guest_key = %s LIMIT 1", $guest_key)
    );
    $data = [
        'dirty_at' => $now,
        'dirty_reason' => sanitize_text_field((string) $reason),
        'updated_at' => $now,
        'updated_at_gmt' => $now_gmt,
    ];
    $formats = ['%s', '%s', '%s', '%s'];

    foreach (['primary_name', 'primary_email', 'primary_phone', 'normalized_phone', 'identity_confidence'] as $field) {
        if (array_key_exists($field, $identity_hint) && (string) $identity_hint[$field] !== '') {
            $data[$field] = sanitize_text_field((string) $identity_hint[$field]);
            $formats[] = '%s';
        }
    }

    if ($existing_id) {
        $updated = $wpdb->update(
            $table_name,
            $data,
            ['guest_key' => $guest_key],
            $formats,
            ['%s']
        );

        return $updated !== false;
    }

    $data = array_merge([
        'guest_key' => $guest_key,
        'identity_confidence' => sanitize_text_field((string) ($identity_hint['identity_confidence'] ?? 'derived')),
        'identity_source' => 'reservation_history',
        'created_at' => $now,
        'created_at_gmt' => $now_gmt,
    ], $data);

    $inserted = $wpdb->insert(
        $table_name,
        $data,
        array_merge(['%s', '%s', '%s', '%s', '%s'], $formats)
    );

    return $inserted !== false;
}

function tryzub_guest_profiles_fetch_profile($guest_key) {
    global $wpdb;

    if (!tryzub_guest_profiles_table_exists()) {
        return null;
    }

    $table_name = tryzub_get_guest_profiles_table_name();
    $row = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM $table_name WHERE guest_key = %s LIMIT 1", sanitize_text_field((string) $guest_key)),
        ARRAY_A
    );

    return $row ?: null;
}

function tryzub_guest_profiles_fetch_profile_for_reservation($reservation_id) {
    $row = tryzub_get_managed_reservation_row_by_id(absint($reservation_id));

    if (!$row) {
        return null;
    }

    $guest_key = tryzub_guest_profiles_guest_key_for_reservation_row($row);

    if (!$guest_key) {
        return null;
    }

    return tryzub_guest_profiles_fetch_profile($guest_key);
}

function tryzub_guest_profiles_recalculate_for_reservation($reservation_id, $reason = 'reservation_changed') {
    $row = tryzub_get_managed_reservation_row_by_id(absint($reservation_id));

    if (!$row) {
        return new WP_Error('tryzub_reservation_not_found', 'Managed reservation not found.', ['status' => 404]);
    }

    $guest_key = tryzub_guest_profiles_guest_key_for_reservation_row($row);

    if (!$guest_key) {
        return new WP_Error('tryzub_guest_profile_no_identity', 'Reservation does not have a usable guest identity.', ['status' => 400]);
    }

    return tryzub_guest_profiles_recalculate_guest_key($guest_key, $reason, $row);
}

function tryzub_guest_profiles_recalculate_guest_key($guest_key, $reason = 'manual', $seed_row = null) {
    global $wpdb;

    if (!tryzub_guest_profiles_table_exists()) {
        return new WP_Error('tryzub_guest_profiles_unavailable', 'Guest profile table is not available.', ['status' => 500]);
    }

    $guest_key = sanitize_text_field((string) $guest_key);
    $profile = tryzub_guest_profiles_fetch_profile($guest_key);

    if (!is_array($seed_row)) {
        $seed_row = tryzub_guest_profiles_find_seed_row($guest_key, $profile);
    }

    if (!is_array($seed_row) || empty($seed_row)) {
        tryzub_guest_profiles_mark_dirty_for_guest_key($guest_key, 'missing_seed_' . sanitize_key($reason));

        return new WP_Error('tryzub_guest_profile_missing_seed', 'No reservation row could be found for this guest profile.', ['status' => 404]);
    }

    $identity = tryzub_intelligence_identity_from_row($seed_row);
    $history_rows = tryzub_guest_profiles_fetch_history_rows_for_identity($identity, $seed_row);

    if (empty($history_rows)) {
        $history_rows = [$seed_row];
    }

    $context = tryzub_guest_profiles_build_context($history_rows, $seed_row);
    $context_row = $context['context_row'];
    $prior_matches = tryzub_guest_intelligence_prior_matches($context_row, $identity, $history_rows);
    $clean_matches = array_values(array_filter($history_rows, function ($history_row) use ($context) {
        return tryzub_guest_history_is_clean_past_visit($history_row, $context);
    }));
    $item = tryzub_guest_intelligence_build_item($context_row, $history_rows, [$context_row], true);
    $profile_pack = tryzub_guest_intelligence_build_profile_pack(
        $context_row,
        $identity,
        $prior_matches,
        $clean_matches,
        $item,
        $history_rows,
        $context
    );
    $labels = tryzub_guest_profiles_build_labels($profile_pack, $history_rows, $context);
    $evidence = tryzub_guest_profiles_build_evidence($profile_pack, $history_rows, $context);
    $summary = tryzub_guest_profiles_build_summary($profile_pack, $labels, $context);
    $source_coverage = tryzub_guest_profiles_source_coverage(false);
    $aggregate = tryzub_guest_profiles_build_aggregate_values($guest_key, $identity, $history_rows, $context);
    $now = current_time('mysql');
    $now_gmt = current_time('mysql', true);
    $table_name = tryzub_get_guest_profiles_table_name();
    $data = array_merge($aggregate, [
        'labels_json' => wp_json_encode($labels),
        'evidence_json' => wp_json_encode($evidence),
        'summary_json' => wp_json_encode($summary),
        'source_coverage_json' => wp_json_encode($source_coverage),
        'profile_pack_json' => wp_json_encode($profile_pack),
        'last_calculated_at' => $now,
        'last_calculated_at_gmt' => $now_gmt,
        'dirty_at' => null,
        'dirty_reason' => null,
        'updated_at' => $now,
        'updated_at_gmt' => $now_gmt,
    ]);
    $formats = tryzub_guest_profiles_profile_formats($data);
    $existing_id = $wpdb->get_var(
        $wpdb->prepare("SELECT id FROM $table_name WHERE guest_key = %s LIMIT 1", $guest_key)
    );

    if ($existing_id) {
        $updated = $wpdb->update($table_name, $data, ['guest_key' => $guest_key], $formats, ['%s']);

        if ($updated === false) {
            return new WP_Error('tryzub_guest_profile_update_failed', 'Failed to update guest profile aggregate.', ['status' => 500]);
        }
    } else {
        $data['created_at'] = $now;
        $data['created_at_gmt'] = $now_gmt;
        $inserted = $wpdb->insert($table_name, $data, tryzub_guest_profiles_profile_formats($data));

        if ($inserted === false) {
            return new WP_Error('tryzub_guest_profile_insert_failed', 'Failed to insert guest profile aggregate.', ['status' => 500]);
        }
    }

    return tryzub_guest_profiles_fetch_profile($guest_key);
}

function tryzub_guest_profiles_find_seed_row($guest_key, $profile = null) {
    global $wpdb;

    $profile = is_array($profile) ? $profile : [];
    $table_name = tryzub_get_reservations_table_name();
    $conditions = [];
    $values = [];

    if (!empty($profile['primary_email'])) {
        $conditions[] = 'LOWER(email) = %s';
        $values[] = strtolower((string) $profile['primary_email']);
    } elseif (!empty($profile['normalized_phone'])) {
        $conditions[] = 'phone = %s';
        $values[] = (string) $profile['normalized_phone'];
    } elseif (!empty($profile['primary_name'])) {
        $conditions[] = 'LOWER(guest_name) = %s';
        $values[] = strtolower((string) $profile['primary_name']);
    } else {
        return null;
    }

    $sql = "SELECT * FROM $table_name WHERE " . implode(' AND ', $conditions) . " ORDER BY reservation_date DESC, reservation_time DESC, id DESC LIMIT 1";

    return $wpdb->get_row($wpdb->prepare($sql, $values), ARRAY_A);
}

function tryzub_guest_profiles_fetch_history_rows_for_identity(array $identity, array $seed_row) {
    global $wpdb;

    $table_name = tryzub_get_reservations_table_name();
    // is_hidden = 0: staff-deleted rows are excluded by design — they represent
    // spam/test entries that the team deliberately removed from view and should not
    // appear in the guest profile or distort counts.
    // superseded_by_id is intentionally NOT filtered here so that corrected/superseded
    // bookings appear in booking_history with outcome_category = superseded, giving the
    // host full correction context. The classifier handles them correctly.
    $conditions = ['is_hidden = 0'];
    $values = [];
    $identity_conditions = [];

    if (!empty($identity['normalized_email'])) {
        $identity_conditions[] = 'LOWER(email) = %s';
        $values[] = strtolower((string) $identity['normalized_email']);
    }

    if (!empty($identity['normalized_phone'])) {
        $identity_conditions[] = 'phone = %s';
        $values[] = (string) $identity['normalized_phone'];
    }

    if (empty($identity_conditions) && !empty($identity['normalized_name'])) {
        $identity_conditions[] = 'LOWER(guest_name) = %s';
        $values[] = strtolower((string) $seed_row['guest_name']);
    }

    if (empty($identity_conditions)) {
        return [];
    }

    $conditions[] = '(' . implode(' OR ', $identity_conditions) . ')';
    $sql = "SELECT *
        FROM $table_name
        WHERE " . implode(' AND ', $conditions) . "
        ORDER BY reservation_date ASC, reservation_time ASC, id ASC";

    return $wpdb->get_results($wpdb->prepare($sql, $values), ARRAY_A) ?: [];
}

function tryzub_guest_profiles_build_context(array $history_rows, array $seed_row) {
    $today = current_time('Y-m-d');
    $active_statuses = tryzub_intelligence_active_statuses();
    $next = null;

    foreach ($history_rows as $row) {
        // Superseded rows should never drive the context or next-reservation reference —
        // they have been replaced by a newer booking and are only present for history display.
        if (!empty($row['superseded_by_id'])) {
            continue;
        }

        $date = (string) ($row['reservation_date'] ?? '');
        $status = sanitize_text_field((string) ($row['status'] ?? ''));

        if ($date < $today || !in_array($status, $active_statuses, true)) {
            continue;
        }

        if (!$next || ($date . ' ' . ($row['reservation_time'] ?? '')) < (($next['reservation_date'] ?? '') . ' ' . ($next['reservation_time'] ?? ''))) {
            $next = $row;
        }
    }

    // Also exclude superseded rows from fallback context_row selection.
    $non_superseded = array_values(array_filter($history_rows, function ($r) {
        return empty($r['superseded_by_id']);
    }));
    $context_row = $next ?: end($non_superseded);

    if (!is_array($context_row)) {
        $context_row = $seed_row;
    }

    $large_party_threshold = 7;

    if (function_exists('tryzub_get_restaurant_settings')) {
        $settings = tryzub_get_restaurant_settings();
        $large_party_threshold = max(1, (int) ($settings['large_party_review_threshold'] ?? 7));
    }

    return [
        'today' => $today,
        'context_row' => $context_row,
        'next_reservation' => $next,
        'reference_service_datetime' => $next
            ? tryzub_guest_history_service_key($next)
            : current_time('mysql'),
        'large_party_review_threshold' => $large_party_threshold,
    ];
}

function tryzub_guest_profiles_build_aggregate_values($guest_key, array $identity, array $history_rows, array $context) {
    $today = (string) ($context['today'] ?? current_time('Y-m-d'));
    $history_payload = tryzub_guest_history_build_payload($history_rows, $identity, $context);
    $clean_past_rows = [];
    $counts = [
        'completed_count' => 0,
        'confirmed_count' => 0,
        'cancelled_count' => 0,
        'no_show_count' => 0,
        'needs_review_count' => 0,
        'upcoming_count' => 0,
        'website_count' => 0,
        'call_in_count' => 0,
        'manual_count' => 0,
        'unknown_source_count' => 0,
        'guest_notes_count' => 0,
        'staff_notes_count' => 0,
        'notes_count' => 0,
    ];
    $party_sizes = [];
    $hours = [];
    $weekdays = [];
    $last_booked_at = null;
    $largest_party_size = null;
    $primary = end($history_rows);

    if (!is_array($primary)) {
        $primary = [];
    }

    foreach ($history_rows as $row) {
        $status = sanitize_text_field((string) ($row['status'] ?? ''));
        $date = (string) ($row['reservation_date'] ?? '');
        $party_size = (int) ($row['party_size'] ?? 0);
        $created_at = (string) ($row['created_at'] ?? '');
        $guest_notes = trim((string) ($row['guest_notes'] ?? ''));
        $staff_notes = trim((string) ($row['staff_notes'] ?? ''));
        $bucket = tryzub_intelligence_source_bucket($row['source_type'] ?? '');
        $outcome = tryzub_guest_history_classify_row($row, $context);

        if ($outcome === 'clean_visit' && $status === 'completed') {
            $counts['completed_count']++;
        } elseif ($outcome === 'clean_visit' && $status === 'confirmed') {
            $counts['confirmed_count']++;
        } elseif ($outcome === 'cancelled') {
            $counts['cancelled_count']++;
        } elseif ($outcome === 'no_show') {
            $counts['no_show_count']++;
        } elseif ($status === 'needs_review') {
            $counts['needs_review_count']++;
        }

        if ($outcome === 'upcoming') {
            $counts['upcoming_count']++;
        }

        if ($bucket === 'online') {
            $counts['website_count']++;
        } elseif ($bucket === 'call_in') {
            $counts['call_in_count']++;
        } elseif ($bucket === 'manual') {
            $counts['manual_count']++;
        } else {
            $counts['unknown_source_count']++;
        }

        if ($guest_notes !== '') {
            $counts['guest_notes_count']++;
        }

        if ($staff_notes !== '') {
            $counts['staff_notes_count']++;
        }

        if ($guest_notes !== '' || $staff_notes !== '') {
            $counts['notes_count']++;
        }

        if ($created_at !== '' && (!$last_booked_at || $created_at > $last_booked_at)) {
            $last_booked_at = $created_at;
        }

        if ($outcome === 'clean_visit') {
            $clean_past_rows[] = $row;
            if ($party_size > 0) {
                $party_sizes[] = $party_size;
                $largest_party_size = $largest_party_size === null ? $party_size : max($largest_party_size, $party_size);
            }
            $hour = (int) substr((string) ($row['reservation_time'] ?? '00:00:00'), 0, 2);

            if ($hour >= 0 && $hour <= 23) {
                $hours[] = $hour;
            }

            $weekday = tryzub_guest_intelligence_mysql_weekday($date);

            if ($weekday !== null) {
                $weekdays[] = $weekday;
            }
        }
    }

    $next = $context['next_reservation'] ?? null;
    $note_flags = tryzub_guest_profiles_note_flags($history_rows);

    return array_merge($counts, [
        'guest_key' => sanitize_text_field((string) $guest_key),
        'primary_name' => sanitize_text_field((string) ($primary['guest_name'] ?? '')),
        'primary_email' => $identity['normalized_email'] ?: tryzub_intelligence_normalize_email($primary['email'] ?? ''),
        'primary_phone' => sanitize_text_field((string) ($primary['phone'] ?? '')),
        'normalized_phone' => sanitize_text_field((string) ($identity['normalized_phone'] ?? '')),
        'identity_confidence' => sanitize_text_field((string) ($identity['confidence'] ?? 'derived')),
        'identity_source' => 'reservation_history',
        'first_seen_date' => $history_payload['first_seen_date'],
        'last_seen_date' => tryzub_guest_profiles_max_date($clean_past_rows),
        'last_booked_at' => $last_booked_at,
        'total_reservations' => $history_payload['total_booking_count'],
        'clean_visit_count' => $history_payload['clean_past_visit_count'],
        'next_reservation_id' => $next ? (int) ($next['id'] ?? 0) : null,
        'next_reservation_date' => $next ? (string) ($next['reservation_date'] ?? '') : null,
        'next_reservation_time' => $next ? (string) ($next['reservation_time'] ?? '') : null,
        'next_reservation_status' => $next ? sanitize_text_field((string) ($next['status'] ?? '')) : null,
        'next_party_size' => $next ? (int) ($next['party_size'] ?? 0) : null,
        'next_table_name' => $next ? sanitize_text_field((string) ($next['table_name'] ?? '')) : null,
        'usual_party_size' => tryzub_guest_profiles_mode($party_sizes),
        'average_party_size' => empty($party_sizes) ? null : round(array_sum($party_sizes) / count($party_sizes), 2),
        'largest_party_size' => $largest_party_size,
        'usual_hour' => tryzub_guest_profiles_mode($hours),
        'usual_weekday' => tryzub_guest_profiles_mode($weekdays),
        'has_birthday_note' => $note_flags['birthday'] ? 1 : 0,
        'has_occasion_note' => $note_flags['occasion'] ? 1 : 0,
        'has_reply_needed_note' => $note_flags['reply_needed'] ? 1 : 0,
        'has_group_note' => $note_flags['group'] ? 1 : 0,
        'has_dietary_note' => $note_flags['dietary'] ? 1 : 0,
        'has_large_party_history' => ($largest_party_size !== null && $largest_party_size >= (int) ($context['large_party_review_threshold'] ?? 7)) ? 1 : 0,
    ]);
}

function tryzub_guest_profiles_build_labels(array $profile_pack, array $history_rows, array $context) {
    $aggregate = tryzub_guest_profiles_build_aggregate_values(
        tryzub_guest_profiles_guest_key_for_reservation_row($context['context_row'] ?? []),
        tryzub_intelligence_identity_from_row($context['context_row'] ?? []),
        $history_rows,
        $context
    );
    $labels = [];
    $add = function ($id, $category, $title, $detail, $evidence, $confidence, $priority) use (&$labels) {
        $labels[] = [
            'id' => $id,
            'category' => $category,
            'title' => $title,
            'detail' => $detail,
            'evidence' => $evidence,
            'confidence' => $confidence,
            'priority' => $priority,
            'source' => 'guest_history',
            'visibility' => 'staff',
        ];
    };
    $clean_visits = (int) ($aggregate['clean_visit_count'] ?? 0);

    if ($clean_visits <= 0) {
        $add('first_time_guest', 'regularity', 'First-time guest', 'No prior clean visits found', 'No prior clean visits in managed reservations', 0.86, 80);
    } elseif ($clean_visits === 1) {
        $add('seen_before', 'regularity', 'Seen before', '1 clean visit', 'Seen once before in managed reservations', 0.9, 90);
    } elseif ($clean_visits < 5) {
        $add('returning_guest', 'regularity', 'Returning guest', $clean_visits . ' clean visits', 'Seen ' . $clean_visits . ' times since ' . ($aggregate['first_seen_date'] ?? 'first recorded visit'), 0.93, 95);
    } else {
        $add('regular_guest', 'regularity', 'Regular guest', $clean_visits . ' clean visits', 'Seen ' . $clean_visits . ' times since ' . ($aggregate['first_seen_date'] ?? 'first recorded visit'), 0.95, 100);
    }

    if (!empty($aggregate['usual_hour'])) {
        $add('usual_hour', 'timing', 'Usually books around ' . tryzub_guest_intelligence_format_time_friendly(sprintf('%02d:00:00', (int) $aggregate['usual_hour'])), 'Common booking time', 'Most common reservation hour from managed history', 0.82, 60);
    }

    if ($aggregate['usual_weekday'] !== null) {
        $weekday = (int) $aggregate['usual_weekday'];
        $names = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        $label = $names[$weekday] ?? 'weekday';
        $add('usual_weekday', 'timing', 'Often books on ' . $label, 'Common visit day', 'Most common reservation weekday from managed history', 0.8, 58);

        if ($weekday >= 5) {
            $add('weekend_guest', 'timing', 'Weekend guest', 'Often books weekends', 'Common reservation day falls on the weekend', 0.78, 50);
        } else {
            $add('weekday_guest', 'timing', 'Weekday guest', 'Often books weekdays', 'Common reservation day falls on a weekday', 0.78, 50);
        }
    }

    if (!empty($aggregate['usual_party_size'])) {
        $add('usual_party_size', 'party', 'Usually books for ' . (int) $aggregate['usual_party_size'], 'Typical party size', 'Most common party size in managed history', 0.84, 62);
    }

    if (!empty($aggregate['has_large_party_history'])) {
        $add('large_party_history', 'party', 'Large-party history', 'Has booked a large party before', 'Largest recorded party size is ' . (int) ($aggregate['largest_party_size'] ?? 0), 0.88, 72);
    }

    $next_party_size = (int) ($aggregate['next_party_size'] ?? 0);
    $large_threshold = (int) ($context['large_party_review_threshold'] ?? 7);

    if ($next_party_size >= $large_threshold) {
        $add('upcoming_large_party', 'party', 'Upcoming large party', $next_party_size . ' guests', 'Next reservation meets the restaurant large-party threshold', 0.92, 93);
    }

    if (!empty($aggregate['has_birthday_note'])) {
        $add('birthday_note', 'notes', 'Birthday note', 'Birthday mentioned in notes', 'Managed reservation notes mention a birthday', 0.86, 70);
    }
    if (!empty($aggregate['has_occasion_note'])) {
        $add('occasion_note', 'notes', 'Occasion note', 'Occasion mentioned in notes', 'Managed reservation notes mention an occasion', 0.84, 68);
    }
    if (!empty($aggregate['has_group_note'])) {
        $add('group_details', 'notes', 'Group details', 'Group or event details found', 'Managed reservation notes mention group details', 0.84, 68);
    }
    if (!empty($aggregate['has_dietary_note'])) {
        $add('dietary_note', 'notes', 'Dietary note', 'Dietary details found', 'Managed reservation notes mention dietary details', 0.84, 68);
    }
    if (!empty($aggregate['has_reply_needed_note'])) {
        $add('reply_needed', 'notes', 'May expect a reply', 'Question or reply cue found', 'Managed reservation notes include a question or reply cue', 0.78, 76);
    }
    if ((int) ($aggregate['notes_count'] ?? 0) >= 3) {
        $add('often_leaves_notes', 'notes', 'Often leaves notes', (int) $aggregate['notes_count'] . ' reservations with notes', 'Multiple reservations include guest or staff notes', 0.8, 55);
    }
    if ((int) ($aggregate['staff_notes_count'] ?? 0) > 0) {
        $add('staff_notes_found', 'notes', 'Staff notes found', (int) $aggregate['staff_notes_count'] . ' staff notes', 'Staff notes exist in managed reservation history', 0.9, 65);
    }

    if ((int) ($aggregate['upcoming_count'] ?? 0) > 0) {
        $add('confirmed_upcoming_visit', 'operational', 'Confirmed upcoming visit', 'Future active reservation found', 'Guest has an upcoming active reservation', 0.9, 86);
    }
    if (($aggregate['next_reservation_status'] ?? '') === 'needs_review') {
        $add('upcoming_needs_review', 'operational', 'Upcoming reservation needs review', 'Review before service', 'Next reservation is marked needs_review', 0.95, 98);
    }
    if (!empty($aggregate['next_reservation_id']) && empty($aggregate['next_table_name'])) {
        $add('needs_table_plan', 'operational', 'Needs table plan', 'No table assigned yet', 'Next reservation has no table assignment', 0.92, 94);
    }

    $next_row = is_array($context['next_reservation'] ?? null) ? $context['next_reservation'] : null;

    if ($next_row && empty($next_row['reminder_email_sent_at'])) {
        $add('reminder_not_sent', 'operational', 'Reminder not sent', 'Guest reminder has not been recorded', 'Next reservation has no reminder sent timestamp', 0.86, 74);
    }

    if ($next_row && empty($next_row['confirmation_email_sent_at'])) {
        $add('confirmation_not_sent', 'operational', 'Confirmation not sent', 'Confirmation email has not been recorded', 'Next reservation has no confirmation sent timestamp', 0.86, 73);
    }

    if ((int) ($aggregate['cancelled_count'] ?? 0) > 0) {
        $add('cancellation_history', 'reliability', 'Cancellation history', (int) $aggregate['cancelled_count'] . ' cancelled', 'Managed history includes cancellations', 0.86, 45);
    }
    if ((int) ($aggregate['no_show_count'] ?? 0) > 0) {
        $add('no_show_history', 'reliability', 'No-show history', (int) $aggregate['no_show_count'] . ' no-show', 'Managed history includes no-show status', 0.86, 46);
    }

    $online = (int) ($aggregate['website_count'] ?? 0);
    $call_in = (int) ($aggregate['call_in_count'] ?? 0);
    $manual = (int) ($aggregate['manual_count'] ?? 0);
    $sources_used = count(array_filter([$online, $call_in, $manual]));

    if ($sources_used > 1) {
        $add('mixed_booking_source', 'source', 'Mixed booking source', 'Uses more than one booking path', 'Managed history includes multiple booking sources', 0.78, 35);
    } elseif ($online > 0) {
        $add('usually_books_online', 'source', 'Usually books online', $online . ' online bookings', 'Managed source history is mostly online', 0.78, 34);
    } elseif ($call_in > 0) {
        $add('call_in_guest', 'source', 'Call-in guest', $call_in . ' call-in bookings', 'Managed source history is mostly call-in', 0.78, 34);
    }

    usort($labels, function ($a, $b) {
        return (int) ($b['priority'] ?? 0) <=> (int) ($a['priority'] ?? 0);
    });

    return $labels;
}

function tryzub_guest_profiles_build_evidence(array $profile_pack, array $history_rows, array $context) {
    $recent = array_slice(array_reverse($history_rows), 0, 5);
    $items = [];

    foreach ($recent as $row) {
        $items[] = [
            'reservation_id' => (int) ($row['id'] ?? 0),
            'date' => (string) ($row['reservation_date'] ?? ''),
            'time' => (string) ($row['reservation_time'] ?? ''),
            'status' => sanitize_text_field((string) ($row['status'] ?? '')),
            'party_size' => (int) ($row['party_size'] ?? 0),
            'source' => tryzub_guest_intelligence_map_source_label($row['source_type'] ?? ''),
            'guest_note_preview' => tryzub_guest_intelligence_trim_note_preview($row['guest_notes'] ?? '', 90),
            'staff_note_preview' => tryzub_guest_intelligence_trim_note_preview($row['staff_notes'] ?? '', 90),
        ];
    }

    return [
        'recent_reservations' => $items,
        'history_row_count' => count($history_rows),
        'large_party_review_threshold' => (int) ($context['large_party_review_threshold'] ?? 7),
    ];
}

function tryzub_guest_profiles_build_summary(array $profile_pack, array $labels, array $context) {
    $summary = $profile_pack['profile_summary'] ?? [];

    return [
        'summary_text' => $summary['summary_text'] ?? null,
        'management_notes' => $summary['management_notes'] ?? [],
        'top_labels' => array_slice($labels, 0, 5),
        'updated_at' => current_time('mysql'),
    ];
}

function tryzub_guest_profiles_note_flags(array $history_rows) {
    $flags = [
        'birthday' => false,
        'occasion' => false,
        'reply_needed' => false,
        'group' => false,
        'dietary' => false,
    ];

    foreach ($history_rows as $row) {
        $text = strtolower((string) ($row['guest_notes'] ?? '') . ' ' . (string) ($row['staff_notes'] ?? ''));

        if (preg_match('/\b(birthday|bday)\b/', $text)) {
            $flags['birthday'] = true;
        }
        if (preg_match('/\b(birthday|bday|anniversary|graduation|celebration|celebrate)\b/', $text)) {
            $flags['occasion'] = true;
        }
        if (strpos($text, '?') !== false || preg_match('/\b(please let us know|can you|do you|why did|would like to know)\b/', $text)) {
            $flags['reply_needed'] = true;
        }
        if (preg_match('/\b(banquet|group|event|party|pre-order|preorder|deposit)\b/', $text)) {
            $flags['group'] = true;
        }
        if (preg_match('/\b(allergy|allergic|gluten|vegan|vegetarian|dairy|nut|shellfish)\b/', $text)) {
            $flags['dietary'] = true;
        }
    }

    return $flags;
}

function tryzub_guest_profiles_mode(array $values) {
    $counts = [];

    foreach ($values as $value) {
        if ($value === null || $value === '') {
            continue;
        }

        $key = (string) $value;
        $counts[$key] = ($counts[$key] ?? 0) + 1;
    }

    if (empty($counts)) {
        return null;
    }

    arsort($counts);

    return (int) array_key_first($counts);
}

function tryzub_guest_profiles_min_date(array $rows) {
    $dates = array_values(array_filter(array_map(function ($row) {
        return (string) ($row['reservation_date'] ?? '');
    }, $rows)));

    return empty($dates) ? null : min($dates);
}

function tryzub_guest_profiles_max_date(array $rows) {
    $dates = array_values(array_filter(array_map(function ($row) {
        return (string) ($row['reservation_date'] ?? '');
    }, $rows)));

    return empty($dates) ? null : max($dates);
}

function tryzub_guest_profiles_source_coverage($stale) {
    return [
        'backend_profile' => true,
        'backend_precomputed' => true,
        'local_cache_supplement' => false,
        'pos_connected' => false,
        'stale' => (bool) $stale,
    ];
}

function tryzub_guest_profiles_profile_formats(array $data) {
    $ints = [
        'total_reservations', 'clean_visit_count', 'completed_count', 'confirmed_count', 'cancelled_count',
        'no_show_count', 'needs_review_count', 'upcoming_count', 'next_reservation_id', 'next_party_size',
        'usual_party_size', 'largest_party_size', 'usual_hour', 'usual_weekday', 'website_count',
        'call_in_count', 'manual_count', 'unknown_source_count', 'guest_notes_count', 'staff_notes_count',
        'notes_count', 'has_birthday_note', 'has_occasion_note', 'has_reply_needed_note', 'has_group_note',
        'has_dietary_note', 'has_large_party_history',
    ];
    $floats = ['average_party_size'];

    return array_map(function ($key) use ($data, $ints, $floats) {
        if (!isset($data[$key])) {
            return '%s';
        }

        if (in_array($key, $ints, true)) {
            return '%d';
        }

        if (in_array($key, $floats, true)) {
            return '%f';
        }

        return '%s';
    }, array_keys($data));
}

function tryzub_guest_profiles_decode_json($value, $fallback = []) {
    if (!is_string($value) || trim($value) === '') {
        return $fallback;
    }

    $decoded = json_decode($value, true);

    return is_array($decoded) ? $decoded : $fallback;
}

function tryzub_guest_profiles_format_profile(array $row, $include_detail = false) {
    $stale = !empty($row['dirty_at']);
    $source_coverage = tryzub_guest_profiles_decode_json($row['source_coverage_json'] ?? '', tryzub_guest_profiles_source_coverage($stale));
    $source_coverage['stale'] = $stale;
    $profile = [
        'id' => (int) ($row['id'] ?? 0),
        'guest_key' => (string) ($row['guest_key'] ?? ''),
        'primary_name' => $row['primary_name'] ?? null,
        'primary_email' => $row['primary_email'] ?? null,
        'primary_phone' => $row['primary_phone'] ?? null,
        'identity_confidence' => $row['identity_confidence'] ?? 'derived',
        'identity_source' => $row['identity_source'] ?? 'reservation_history',
        'first_seen_date' => $row['first_seen_date'] ?? null,
        'last_seen_date' => $row['last_seen_date'] ?? null,
        'last_booked_at' => $row['last_booked_at'] ?? null,
        'total_reservations' => (int) ($row['total_reservations'] ?? 0),
        'clean_visit_count' => (int) ($row['clean_visit_count'] ?? 0),
        'upcoming_count' => (int) ($row['upcoming_count'] ?? 0),
        'next_reservation' => [
            'id' => isset($row['next_reservation_id']) ? (int) $row['next_reservation_id'] : null,
            'date' => $row['next_reservation_date'] ?? null,
            'time' => $row['next_reservation_time'] ?? null,
            'status' => $row['next_reservation_status'] ?? null,
            'party_size' => isset($row['next_party_size']) ? (int) $row['next_party_size'] : null,
            'table_name' => $row['next_table_name'] ?? null,
        ],
        'labels' => tryzub_guest_profiles_decode_json($row['labels_json'] ?? '', []),
        'summary' => tryzub_guest_profiles_decode_json($row['summary_json'] ?? '', []),
        'source_coverage' => $source_coverage,
        'stale' => $stale,
        'dirty_reason' => $row['dirty_reason'] ?? null,
        'last_calculated_at' => $row['last_calculated_at'] ?? null,
        'updated_at' => $row['updated_at'] ?? null,
    ];

    if ($include_detail) {
        $profile_pack = tryzub_guest_profiles_decode_json($row['profile_pack_json'] ?? '', []);
        $history_counts = is_array($profile_pack['history_counts'] ?? null) ? $profile_pack['history_counts'] : [];
        $booking_history = is_array($profile_pack['booking_history'] ?? null) ? $profile_pack['booking_history'] : [];
        $notes_history = is_array($profile_pack['notes_history'] ?? null) ? $profile_pack['notes_history'] : [];
        $profile['clean_past_visit_count'] = (int) ($history_counts['clean_past_visit_count'] ?? $row['clean_visit_count'] ?? 0);
        $profile['total_booking_count'] = (int) ($history_counts['total_booking_count'] ?? $row['total_reservations'] ?? 0);
        $profile['upcoming_count'] = (int) ($history_counts['upcoming_count'] ?? $row['upcoming_count'] ?? 0);
        $profile['cancelled_count'] = (int) ($history_counts['cancelled_count'] ?? $row['cancelled_count'] ?? 0);
        $profile['no_show_count'] = (int) ($history_counts['no_show_count'] ?? $row['no_show_count'] ?? 0);
        $profile['duplicate_or_correction_count'] = (int) ($history_counts['duplicate_or_correction_count'] ?? 0);
        $profile['last_clean_visit_date'] = $history_counts['last_clean_visit_date'] ?? $row['last_seen_date'] ?? null;
        $profile['last_clean_visit_id'] = isset($history_counts['last_clean_visit_id'])
            ? (int) $history_counts['last_clean_visit_id']
            : null;
        $profile['guest_notes_count'] = (int) ($history_counts['guest_notes_count'] ?? $row['guest_notes_count'] ?? 0);
        $profile['staff_notes_count'] = (int) ($history_counts['staff_notes_count'] ?? $row['staff_notes_count'] ?? 0);
        $profile['booking_history'] = $booking_history;
        $profile['notes_history'] = $notes_history;
        $profile['counts'] = [
            'completed' => (int) ($row['completed_count'] ?? 0),
            'confirmed' => (int) ($row['confirmed_count'] ?? 0),
            'cancelled' => (int) ($row['cancelled_count'] ?? 0),
            'no_show' => (int) ($row['no_show_count'] ?? 0),
            'needs_review' => (int) ($row['needs_review_count'] ?? 0),
            'guest_notes' => (int) ($row['guest_notes_count'] ?? 0),
            'staff_notes' => (int) ($row['staff_notes_count'] ?? 0),
        ];
        $profile['preferences'] = [
            'usual_party_size' => isset($row['usual_party_size']) ? (int) $row['usual_party_size'] : null,
            'average_party_size' => isset($row['average_party_size']) ? (float) $row['average_party_size'] : null,
            'largest_party_size' => isset($row['largest_party_size']) ? (int) $row['largest_party_size'] : null,
            'usual_hour' => isset($row['usual_hour']) ? (int) $row['usual_hour'] : null,
            'usual_weekday' => isset($row['usual_weekday']) ? (int) $row['usual_weekday'] : null,
        ];
        $profile['evidence'] = tryzub_guest_profiles_decode_json($row['evidence_json'] ?? '', []);
        $profile['profile_pack'] = $profile_pack;
    }

    return $profile;
}

function tryzub_guest_profiles_list_profiles($args = []) {
    global $wpdb;

    $table_name = tryzub_get_guest_profiles_table_name();
    $page = max(1, absint($args['page'] ?? 1));
    $per_page = min(100, max(1, absint($args['per_page'] ?? 25)));
    $offset = ($page - 1) * $per_page;
    $where = ['1=1'];
    $values = [];
    $q = trim((string) ($args['q'] ?? ''));
    $filter = sanitize_key((string) ($args['filter'] ?? ''));
    $sort = sanitize_key((string) ($args['sort'] ?? 'last_seen'));

    if ($q !== '') {
        $like = '%' . $wpdb->esc_like($q) . '%';
        $phone_like = '%' . $wpdb->esc_like(preg_replace('/\D+/', '', $q)) . '%';
        $where[] = '(primary_name LIKE %s OR primary_email LIKE %s OR normalized_phone LIKE %s)';
        $values[] = $like;
        $values[] = $like;
        $values[] = $phone_like;
    }

    if (!empty($args['updated_since'])) {
        $where[] = 'updated_at_gmt >= %s';
        $values[] = sanitize_text_field((string) $args['updated_since']);
    }

    $label_filters = [
        'regular' => 'regular_guest',
        'seen_before' => 'seen_before',
        'needs_table' => 'needs_table_plan',
        'reply_needed' => 'reply_needed',
        'occasion' => 'occasion_note',
        'large_party' => 'large_party_history',
        'notes' => 'often_leaves_notes',
        'cancel_history' => 'cancellation_history',
        'no_show_history' => 'no_show_history',
    ];

    if ($filter === 'upcoming') {
        $where[] = 'upcoming_count > 0';
    } elseif (isset($label_filters[$filter])) {
        $where[] = 'labels_json LIKE %s';
        $values[] = '%"id":"' . $wpdb->esc_like($label_filters[$filter]) . '"%';
    }

    $order_by = 'last_seen_date DESC, last_booked_at DESC';

    if ($sort === 'upcoming') {
        $order_by = 'next_reservation_date IS NULL ASC, next_reservation_date ASC, next_reservation_time ASC';
    } elseif ($sort === 'regularity' || $sort === 'most_reservations') {
        $order_by = 'clean_visit_count DESC, total_reservations DESC';
    } elseif ($sort === 'notes') {
        $order_by = 'notes_count DESC, last_seen_date DESC';
    } elseif ($sort === 'needs_attention') {
        $order_by = 'needs_review_count DESC, has_reply_needed_note DESC, next_reservation_date ASC';
    }

    $where_sql = implode(' AND ', $where);
    $count_sql = "SELECT COUNT(*) FROM $table_name WHERE $where_sql";
    $total = empty($values)
        ? (int) $wpdb->get_var($count_sql)
        : (int) $wpdb->get_var($wpdb->prepare($count_sql, $values));
    $query_values = array_merge($values, [$per_page, $offset]);
    $rows_sql = "SELECT * FROM $table_name WHERE $where_sql ORDER BY $order_by LIMIT %d OFFSET %d";
    $rows = $wpdb->get_results($wpdb->prepare($rows_sql, $query_values), ARRAY_A) ?: [];

    return [
        'profiles' => array_map(function ($row) {
            return tryzub_guest_profiles_format_profile($row, false);
        }, $rows),
        'page' => $page,
        'per_page' => $per_page,
        'total' => $total,
        'total_pages' => $per_page > 0 ? (int) ceil($total / $per_page) : 0,
    ];
}

function tryzub_get_guest_profiles(WP_REST_Request $request) {
    if (!tryzub_guest_profiles_table_exists()) {
        return new WP_Error('tryzub_guest_profiles_unavailable', 'Guest profile table is not available.', ['status' => 500]);
    }

    $result = tryzub_guest_profiles_list_profiles([
        'q' => $request->get_param('q'),
        'filter' => $request->get_param('filter'),
        'sort' => $request->get_param('sort'),
        'page' => $request->get_param('page'),
        'per_page' => $request->get_param('per_page'),
        'updated_since' => $request->get_param('updated_since'),
    ]);

    return rest_ensure_response(array_merge(['success' => true], $result));
}

function tryzub_get_guest_profile(WP_REST_Request $request) {
    $guest_key = sanitize_text_field((string) ($request->get_param('guest_key') ?: $request->get_param('guest_key_path')));
    $profile = tryzub_guest_profiles_fetch_profile($guest_key);

    if (!$profile) {
        tryzub_guest_profiles_mark_dirty_for_guest_key($guest_key, 'detail_missing');
        tryzub_guest_profiles_schedule_dirty_rebuild();

        return new WP_Error('tryzub_guest_profile_not_found', 'Guest profile was not found.', ['status' => 404]);
    }

    if (!empty($profile['dirty_at'])) {
        tryzub_guest_profiles_schedule_dirty_rebuild();
    }

    return rest_ensure_response([
        'success' => true,
        'data' => tryzub_guest_profiles_format_profile($profile, true),
    ]);
}

function tryzub_get_guest_profile_by_reservation(WP_REST_Request $request) {
    $reservation_id = absint($request->get_param('id'));
    $row = tryzub_get_managed_reservation_row_by_id($reservation_id);

    if (!$row) {
        return new WP_Error('tryzub_reservation_not_found', 'Managed reservation not found.', ['status' => 404]);
    }

    $guest_key = tryzub_guest_profiles_guest_key_for_reservation_row($row);

    if (!$guest_key) {
        return new WP_Error('tryzub_guest_profile_no_identity', 'Reservation does not have a usable guest identity.', ['status' => 400]);
    }

    $profile = tryzub_guest_profiles_fetch_profile($guest_key);

    if (!$profile) {
        tryzub_guest_profiles_mark_dirty_for_reservation_row($row, 'by_reservation_missing');
        tryzub_guest_profiles_schedule_dirty_rebuild();
        $identity = tryzub_intelligence_identity_from_row($row);
        $history_rows = tryzub_guest_profiles_fetch_history_rows_for_identity($identity, $row);
        $history_payload = tryzub_guest_history_build_payload($history_rows, $identity, ['context_row' => $row]);

        return rest_ensure_response([
            'success' => true,
            'stale' => true,
            'data' => [
                'guest_key' => $guest_key,
                'source_coverage' => tryzub_guest_profiles_source_coverage(true),
                'clean_visit_count' => $history_payload['clean_past_visit_count'],
                'clean_past_visit_count' => $history_payload['clean_past_visit_count'],
                'total_reservations' => $history_payload['total_booking_count'],
                'total_booking_count' => $history_payload['total_booking_count'],
                'upcoming_count' => $history_payload['upcoming_count'],
                'cancelled_count' => $history_payload['cancelled_count'],
                'no_show_count' => $history_payload['no_show_count'],
                'duplicate_or_correction_count' => $history_payload['duplicate_or_correction_count'],
                'last_clean_visit_date' => $history_payload['last_clean_visit_date'],
                'last_clean_visit_id' => $history_payload['last_clean_visit_id'],
                'first_seen_date' => $history_payload['first_seen_date'],
                'guest_notes_count' => $history_payload['guest_notes_count'],
                'staff_notes_count' => $history_payload['staff_notes_count'],
                'booking_history' => $history_payload['booking_history'],
                'notes_history' => $history_payload['notes_history'],
            ],
        ]);
    }

    if (!empty($profile['dirty_at'])) {
        tryzub_guest_profiles_schedule_dirty_rebuild();
    }

    return rest_ensure_response([
        'success' => true,
        'data' => tryzub_guest_profiles_format_profile($profile, true),
    ]);
}

function tryzub_rebuild_guest_profiles(WP_REST_Request $request) {
    $body = tryzub_get_rest_request_body($request);
    $limit = min(100, max(1, absint($body['limit'] ?? $request->get_param('limit') ?? 50)));

    if (!empty($body['reservation_id'])) {
        $result = tryzub_guest_profiles_recalculate_for_reservation(absint($body['reservation_id']), 'manual_reservation');

        if (is_wp_error($result)) {
            return $result;
        }

        return rest_ensure_response([
            'success' => true,
            'processed' => 1,
            'remaining' => tryzub_guest_profiles_dirty_count(),
            'next_cursor' => null,
            'done' => tryzub_guest_profiles_dirty_count() === 0,
        ]);
    }

    if (!empty($body['guest_key'])) {
        $result = tryzub_guest_profiles_recalculate_guest_key(sanitize_text_field((string) $body['guest_key']), 'manual_guest_key');

        if (is_wp_error($result)) {
            return $result;
        }

        return rest_ensure_response([
            'success' => true,
            'processed' => 1,
            'remaining' => tryzub_guest_profiles_dirty_count(),
            'next_cursor' => null,
            'done' => tryzub_guest_profiles_dirty_count() === 0,
        ]);
    }

    if (!empty($body['all'])) {
        $cursor = absint($body['cursor'] ?? $request->get_param('cursor') ?? 0);
        $result = tryzub_guest_profiles_rebuild_all_batch($cursor, $limit);

        return rest_ensure_response(array_merge(['success' => true], $result));
    }

    $result = tryzub_guest_profiles_rebuild_dirty_batch($limit);

    return rest_ensure_response(array_merge(['success' => true], $result));
}

function tryzub_guest_profiles_dirty_count() {
    global $wpdb;

    if (!tryzub_guest_profiles_table_exists()) {
        return 0;
    }

    $table_name = tryzub_get_guest_profiles_table_name();

    return (int) $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE dirty_at IS NOT NULL");
}

function tryzub_guest_profiles_rebuild_all_batch($cursor = 0, $limit = 50) {
    global $wpdb;

    if (!tryzub_guest_profiles_table_exists()) {
        return [
            'processed' => 0,
            'remaining' => 0,
            'next_cursor' => null,
            'done' => true,
        ];
    }

    $reservations_table = tryzub_get_reservations_table_name();
    $cursor = absint($cursor);
    $limit = min(100, max(1, absint($limit)));
    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT id FROM $reservations_table WHERE id > %d AND is_hidden = 0 AND superseded_by_id IS NULL ORDER BY id ASC LIMIT %d",
            $cursor,
            $limit
        ),
        ARRAY_A
    ) ?: [];
    $processed = 0;
    $last_id = $cursor;

    foreach ($rows as $row) {
        $reservation_id = absint($row['id'] ?? 0);

        if ($reservation_id < 1) {
            continue;
        }

        $last_id = $reservation_id;
        tryzub_guest_profiles_recalculate_for_reservation($reservation_id, 'manual_all_rebuild');
        $processed++;
    }

    $remaining = (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM $reservations_table WHERE id > %d AND is_hidden = 0 AND superseded_by_id IS NULL",
            $last_id
        )
    );

    return [
        'processed' => $processed,
        'remaining' => $remaining,
        'next_cursor' => $remaining > 0 ? (string) $last_id : null,
        'done' => $remaining === 0,
    ];
}

function tryzub_guest_profiles_rebuild_dirty_batch($limit = 25) {
    global $wpdb;

    if (!tryzub_guest_profiles_table_exists()) {
        return [
            'processed' => 0,
            'remaining' => 0,
            'next_cursor' => null,
            'done' => true,
        ];
    }

    $table_name = tryzub_get_guest_profiles_table_name();
    $limit = min(100, max(1, absint($limit)));
    $rows = $wpdb->get_results(
        $wpdb->prepare("SELECT guest_key, dirty_reason FROM $table_name WHERE dirty_at IS NOT NULL ORDER BY dirty_at ASC LIMIT %d", $limit),
        ARRAY_A
    ) ?: [];
    $processed = 0;

    foreach ($rows as $row) {
        $result = tryzub_guest_profiles_recalculate_guest_key($row['guest_key'], $row['dirty_reason'] ?: 'dirty_batch');

        if (!is_wp_error($result)) {
            $processed++;
        }
    }

    $remaining = tryzub_guest_profiles_dirty_count();
    $next_cursor = $remaining > 0 ? 'dirty:' . current_time('timestamp') : null;

    return [
        'processed' => $processed,
        'remaining' => $remaining,
        'next_cursor' => $next_cursor,
        'done' => $remaining === 0,
    ];
}

function tryzub_guest_profiles_schedule_dirty_rebuild() {
    if (!wp_next_scheduled('tryzub_guest_profiles_rebuild_dirty_cron')) {
        wp_schedule_single_event(time() + 60, 'tryzub_guest_profiles_rebuild_dirty_cron');
    }
}

function tryzub_guest_profiles_build_compatible_reservation_payload(array $row, array $profile) {
    $profile_pack = tryzub_guest_profiles_decode_json($profile['profile_pack_json'] ?? '', []);
    $identity = tryzub_intelligence_identity_from_row($row);
    $history_rows = tryzub_guest_profiles_fetch_history_rows_for_identity($identity, $row);
    $history_payload = tryzub_guest_history_build_payload($history_rows, $identity, ['context_row' => $row]);
    $profile_pack['booking_history'] = $history_payload['booking_history'];
    $profile_pack['notes_history'] = $history_payload['notes_history'];
    $profile_pack['history_counts'] = array_diff_key($history_payload, array_flip(['booking_history', 'notes_history']));
    $profile_pack['history'] = array_merge($profile_pack['history'] ?? [], [
        'booking_history' => $history_payload['booking_history'],
        'notes_history' => $history_payload['notes_history'],
        'clean_past_visit_count' => $history_payload['clean_past_visit_count'],
        'total_booking_count' => $history_payload['total_booking_count'],
        'upcoming_count' => $history_payload['upcoming_count'],
        'cancelled_count' => $history_payload['cancelled_count'],
        'no_show_count' => $history_payload['no_show_count'],
        'duplicate_or_correction_count' => $history_payload['duplicate_or_correction_count'],
        'last_clean_visit_date' => $history_payload['last_clean_visit_date'],
        'last_clean_visit_id' => $history_payload['last_clean_visit_id'],
    ]);
    $item = tryzub_guest_intelligence_build_item($row, [], [$row], true);
    $payload = tryzub_guest_intelligence_build_reservation_payload($row, $item, $profile_pack);
    $payload['source_coverage'] = tryzub_guest_profiles_source_coverage(!empty($profile['dirty_at']));
    $payload['stale'] = !empty($profile['dirty_at']);

    return $payload;
}

add_action('tryzub_guest_profiles_rebuild_dirty_cron', function () {
    tryzub_guest_profiles_rebuild_dirty_batch(25);
});
