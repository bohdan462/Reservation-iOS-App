<?php

function tryzub_get_reservation_pipeline_diagnostics(WP_REST_Request $request) {
    $range = tryzub_intelligence_validate_date_range(
        $request->get_param('from'),
        $request->get_param('to'),
        366
    );

    if (is_wp_error($range)) {
        return $range;
    }

    $include_items = tryzub_pipeline_parse_include_items_param($request->get_param('include_items'));
    $classification_filter = tryzub_pipeline_parse_classification_filter($request->get_param('classification'));

    if (is_wp_error($classification_filter)) {
        return $classification_filter;
    }

    $page = max(1, absint($request->get_param('page')));
    $per_page = min(max(absint($request->get_param('per_page')), 1), 500);

    if (!$request->get_param('per_page')) {
        $per_page = 100;
    }

    $payload = tryzub_collect_reservation_pipeline_diagnostics(
        $range['from'],
        $range['to'],
        [
            'include_items' => $include_items,
            'classification' => $classification_filter,
            'page' => $page,
            'per_page' => $per_page,
        ]
    );

    $summary = $payload['summary'] ?? [];

    return tryzub_intelligence_response(
        array_merge(
            [
                'contract_version' => '1.1',
                'scope' => 'reservation_pipeline_diagnostics',
                'generated_at' => tryzub_intelligence_generated_at_iso(),
                'manager_message' => tryzub_pipeline_diagnostics_manager_message($summary),
                'developer_message' => tryzub_pipeline_diagnostics_developer_message($summary),
            ],
            $payload
        )
    );
}

function tryzub_pipeline_parse_include_items_param($value) {
    if ($value === null || $value === '') {
        return true;
    }

    $normalized = tryzub_normalize_boolean_value($value);

    return $normalized === null ? true : $normalized;
}

function tryzub_pipeline_parse_classification_filter($value) {
    $value = sanitize_text_field((string) $value);

    if ($value === '') {
        return null;
    }

    $allowed = tryzub_pipeline_allowed_classifications();

    if (!in_array($value, $allowed, true)) {
        return new WP_Error(
            'tryzub_invalid_pipeline_classification',
            'classification must be one of: ' . implode(', ', $allowed),
            ['status' => 400]
        );
    }

    return $value;
}

function tryzub_pipeline_allowed_classifications() {
    return [
        'managed_active',
        'managed_hidden',
        'managed_terminal',
        'failed_import',
        'duplicate_import',
        'hard_deleted_test_row',
        'spam_or_rejected',
        'non_reservation_form',
        'form_source_unknown',
        'unexplained_missing',
    ];
}

function tryzub_collect_reservation_pipeline_diagnostics($from, $to, array $options = []) {
    $include_items = !array_key_exists('include_items', $options) || !empty($options['include_items']);
    $classification_filter = $options['classification'] ?? null;
    $page = max(1, absint($options['page'] ?? 1));
    $per_page = min(max(absint($options['per_page'] ?? 100), 1), 500);

    $flamingo_rows = tryzub_pipeline_fetch_flamingo_submissions_in_range($from, $to);
    $source_ids = array_map('intval', array_column($flamingo_rows, 'source_submission_id'));
    $field_keys_by_source = tryzub_pipeline_fetch_submission_field_keys_by_post_ids($source_ids);
    $form_meta_by_source = tryzub_pipeline_fetch_form_meta_by_post_ids($source_ids);

    $managed_by_source = tryzub_pipeline_fetch_managed_rows_by_source_ids($source_ids);
    $failures_by_source = tryzub_pipeline_fetch_import_failures_by_source_ids($source_ids);
    $duplicates_by_source = tryzub_pipeline_fetch_duplicate_imports_by_source_ids($source_ids);
    $deletions_by_source = tryzub_pipeline_fetch_deletion_audits_by_source_ids($source_ids);

    $summary = tryzub_pipeline_empty_summary($from, $to);
    $matched_items = [];

    foreach ($flamingo_rows as $flamingo_row) {
        $source_id = (int) ($flamingo_row['source_submission_id'] ?? 0);
        $form_source = tryzub_pipeline_build_form_source(
            $source_id,
            $field_keys_by_source[$source_id] ?? [],
            $form_meta_by_source[$source_id] ?? []
        );
        $classification = tryzub_pipeline_classify_flamingo_submission(
            $flamingo_row,
            $form_source,
            $managed_by_source[$source_id] ?? null,
            $failures_by_source[$source_id] ?? null,
            $duplicates_by_source[$source_id] ?? null,
            $deletions_by_source[$source_id] ?? null
        );

        tryzub_pipeline_increment_summary($summary, $classification, $form_source);

        if ($classification_filter !== null && $classification['classification'] !== $classification_filter) {
            continue;
        }

        $matched_items[] = tryzub_pipeline_format_diagnostic_item($flamingo_row, $classification, $form_source);
    }

    $summary = tryzub_pipeline_finalize_summary($summary);
    $items_total = count($matched_items);
    $items = [];

    if ($include_items) {
        $offset = ($page - 1) * $per_page;
        $items = array_slice($matched_items, $offset, $per_page);
    }

    return [
        'range' => [
            'from' => $from,
            'to' => $to,
        ],
        'summary' => $summary,
        'warnings' => tryzub_pipeline_diagnostics_build_warnings($summary),
        'items' => $items,
        'items_meta' => [
            'include_items' => $include_items,
            'classification_filter' => $classification_filter,
            'items_total' => $items_total,
            'items_returned' => count($items),
            'page' => $page,
            'per_page' => $per_page,
            'has_more' => $include_items && ($page * $per_page) < $items_total,
        ],
    ];
}

function tryzub_pipeline_empty_summary($from, $to) {
    return [
        'flamingo_inbound_total' => 0,
        'flamingo_non_spam_total' => 0,
        'reservation_intake_total' => 0,
        'reservation_intake_non_spam_total' => 0,
        'managed_active_with_source' => 0,
        'managed_hidden_with_source' => 0,
        'managed_terminal_with_source' => 0,
        'failed_imports' => 0,
        'duplicate_imports' => 0,
        'hard_deleted' => 0,
        'unexplained_missing' => 0,
        'spam_or_rejected' => 0,
        'non_reservation_form' => 0,
        'form_source_unknown' => 0,
        'manual_rows_without_flamingo_source' => tryzub_pipeline_count_manual_rows_without_source($from, $to),
        'non_spam_reservation_intake_without_active_managed_row' => 0,
        'explained_missing_submissions' => 0,
        'unexplained_missing_submissions' => 0,
    ];
}

function tryzub_pipeline_finalize_summary(array $summary) {
    $summary['manual_rows_without_flamingo_source'] = (int) ($summary['manual_rows_without_flamingo_source'] ?? 0);
    $summary['manual_without_source'] = $summary['manual_rows_without_flamingo_source'];

    return $summary;
}

function tryzub_pipeline_fetch_flamingo_submissions_in_range($from, $to) {
    global $wpdb;

    $posts_table = $wpdb->posts;
    $postmeta_table = $wpdb->postmeta;
    $submission_status_sql = tryzub_get_reservation_analytics_submission_status_join_sql($postmeta_table);

    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT
                p.ID AS source_submission_id,
                p.post_date AS submitted_at,
                COALESCE(submission_status.meta_value, '') AS submission_status
            FROM $posts_table p
            $submission_status_sql
            WHERE p.post_type = 'flamingo_inbound'
            AND DATE(p.post_date) BETWEEN %s AND %s
            ORDER BY p.post_date ASC, p.ID ASC",
            $from,
            $to
        ),
        ARRAY_A
    ) ?: [];

    return $rows;
}

function tryzub_pipeline_fetch_submission_field_keys_by_post_ids(array $post_ids) {
    global $wpdb;

    $post_ids = array_values(array_filter(array_map('absint', $post_ids)));

    if (empty($post_ids)) {
        return [];
    }

    $postmeta_table = $wpdb->postmeta;
    $placeholders = implode(', ', array_fill(0, count($post_ids), '%d'));
    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT post_id, meta_key
            FROM $postmeta_table
            WHERE post_id IN ($placeholders)
            AND meta_key LIKE %s",
            array_merge($post_ids, [$wpdb->esc_like('_field_') . '%'])
        ),
        ARRAY_A
    ) ?: [];
    $indexed = [];

    foreach ($rows as $row) {
        $post_id = (int) ($row['post_id'] ?? 0);
        $meta_key = (string) ($row['meta_key'] ?? '');

        if ($post_id < 1 || strpos($meta_key, '_field_') !== 0) {
            continue;
        }

        if (!isset($indexed[$post_id])) {
            $indexed[$post_id] = [];
        }

        $indexed[$post_id][] = substr($meta_key, strlen('_field_'));
    }

    return $indexed;
}

function tryzub_pipeline_fetch_form_meta_by_post_ids(array $post_ids) {
    global $wpdb;

    $post_ids = array_values(array_filter(array_map('absint', $post_ids)));

    if (empty($post_ids)) {
        return [];
    }

    $postmeta_table = $wpdb->postmeta;
    $placeholders = implode(', ', array_fill(0, count($post_ids), '%d'));
    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT post_id, meta_value
            FROM $postmeta_table
            WHERE post_id IN ($placeholders)
            AND meta_key = %s",
            array_merge($post_ids, ['_wpcf7_contact_form'])
        ),
        ARRAY_A
    ) ?: [];
    $indexed = [];

    foreach ($rows as $row) {
        $post_id = (int) ($row['post_id'] ?? 0);
        $form_id = absint($row['meta_value'] ?? 0);

        if ($post_id < 1) {
            continue;
        }

        $indexed[$post_id] = [
            'form_id' => $form_id > 0 ? $form_id : null,
            'form_title' => null,
        ];

        if ($form_id > 0) {
            $form_post = get_post($form_id);

            if ($form_post instanceof WP_Post) {
                $indexed[$post_id]['form_title'] = sanitize_text_field((string) $form_post->post_title) ?: null;
            }
        }
    }

    return $indexed;
}

function tryzub_pipeline_build_form_source($post_id, array $field_keys, array $form_meta) {
    $detected = tryzub_detect_submission_form_source($post_id, $field_keys);

    if (!empty($form_meta['form_id'])) {
        $detected['form_id'] = (int) $form_meta['form_id'];
    }

    if (!empty($form_meta['form_title'])) {
        $detected['form_title'] = $form_meta['form_title'];
    }

    return $detected;
}

function tryzub_pipeline_fetch_managed_rows_by_source_ids(array $source_ids) {
    global $wpdb;

    $source_ids = array_values(array_filter(array_map('absint', $source_ids)));

    if (empty($source_ids)) {
        return [];
    }

    $table_name = tryzub_get_reservations_table_name();
    $placeholders = implode(', ', array_fill(0, count($source_ids), '%d'));
    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT
                id,
                source_submission_id,
                status,
                is_hidden,
                duplicate_reason
            FROM $table_name
            WHERE source_submission_id IN ($placeholders)",
            $source_ids
        ),
        ARRAY_A
    ) ?: [];
    $indexed = [];

    foreach ($rows as $row) {
        $source_id = (int) ($row['source_submission_id'] ?? 0);

        if ($source_id > 0) {
            $indexed[$source_id] = $row;
        }
    }

    return $indexed;
}

function tryzub_pipeline_fetch_import_failures_by_source_ids(array $source_ids) {
    return tryzub_pipeline_fetch_rows_indexed_by_source_id(
        tryzub_get_import_failures_table_name(),
        $source_ids,
        'source_submission_id, error_code, status'
    );
}

function tryzub_pipeline_fetch_duplicate_imports_by_source_ids(array $source_ids) {
    return tryzub_pipeline_fetch_rows_indexed_by_source_id(
        tryzub_get_reservation_duplicate_imports_table_name(),
        $source_ids,
        'source_submission_id, duplicate_reason, existing_reservation_id'
    );
}

function tryzub_pipeline_fetch_deletion_audits_by_source_ids(array $source_ids) {
    return tryzub_pipeline_fetch_rows_indexed_by_source_id(
        tryzub_get_reservation_deletion_audit_table_name(),
        $source_ids,
        'id, source_submission_id, reservation_id, deleted_at'
    );
}

function tryzub_pipeline_fetch_rows_indexed_by_source_id($table_name, array $source_ids, $select_columns) {
    global $wpdb;

    $source_ids = array_values(array_filter(array_map('absint', $source_ids)));

    if (empty($source_ids)) {
        return [];
    }

    $placeholders = implode(', ', array_fill(0, count($source_ids), '%d'));
    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT $select_columns
            FROM $table_name
            WHERE source_submission_id IN ($placeholders)",
            $source_ids
        ),
        ARRAY_A
    ) ?: [];
    $indexed = [];

    foreach ($rows as $row) {
        $source_id = (int) ($row['source_submission_id'] ?? 0);

        if ($source_id > 0) {
            $indexed[$source_id] = $row;
        }
    }

    return $indexed;
}

function tryzub_pipeline_count_manual_rows_without_source($from, $to) {
    global $wpdb;

    $table_name = tryzub_get_reservations_table_name();

    return (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*)
            FROM $table_name
            WHERE source_submission_id IS NULL
            AND reservation_date BETWEEN %s AND %s",
            $from,
            $to
        )
    );
}

function tryzub_pipeline_is_spam_or_rejected_submission_status($submission_status) {
    $submission_status = strtoupper(trim(sanitize_text_field((string) $submission_status)));

    return in_array($submission_status, ['SPAM', 'REJECTED'], true);
}

function tryzub_pipeline_is_terminal_managed_status($status) {
    return in_array(sanitize_text_field((string) $status), ['cancelled', 'completed', 'no_show'], true);
}

function tryzub_pipeline_counts_toward_reconciliation(array $form_source, array $classification) {
    if (!empty($classification['is_spam_or_rejected'])) {
        return false;
    }

    if ($classification['classification'] === 'non_reservation_form') {
        return false;
    }

    if (
        $classification['classification'] === 'form_source_unknown' &&
        empty($form_source['matches_reservation_field_set'])
    ) {
        return false;
    }

    return !empty($form_source['is_reservation_form']) || !empty($form_source['matches_reservation_field_set']);
}

function tryzub_pipeline_classify_flamingo_submission(
    array $flamingo_row,
    array $form_source,
    $managed_row,
    $failure_row,
    $duplicate_row,
    $deletion_row
) {
    $submission_status = (string) ($flamingo_row['submission_status'] ?? '');
    $is_spam_or_rejected = tryzub_pipeline_is_spam_or_rejected_submission_status($submission_status);

    if ($is_spam_or_rejected) {
        return tryzub_pipeline_make_classification_result('spam_or_rejected', true);
    }

    if (is_array($managed_row)) {
        $managed_reservation_id = (int) ($managed_row['id'] ?? 0);
        $managed_status = sanitize_text_field((string) ($managed_row['status'] ?? ''));
        $is_hidden = !empty($managed_row['is_hidden']);
        $duplicate_reason = trim((string) ($managed_row['duplicate_reason'] ?? ''));
        $duplicate_reason = $duplicate_reason !== '' ? $duplicate_reason : null;

        if ($is_hidden) {
            return tryzub_pipeline_make_classification_result(
                'managed_hidden',
                false,
                $managed_reservation_id,
                $managed_status,
                true,
                $duplicate_reason
            );
        }

        if (tryzub_pipeline_is_terminal_managed_status($managed_status)) {
            return tryzub_pipeline_make_classification_result(
                'managed_terminal',
                false,
                $managed_reservation_id,
                $managed_status,
                false,
                $duplicate_reason
            );
        }

        return tryzub_pipeline_make_classification_result(
            'managed_active',
            false,
            $managed_reservation_id,
            $managed_status,
            false,
            $duplicate_reason
        );
    }

    if (is_array($deletion_row)) {
        return tryzub_pipeline_make_classification_result(
            'hard_deleted_test_row',
            false,
            isset($deletion_row['reservation_id']) ? (int) $deletion_row['reservation_id'] : null,
            null,
            false,
            null,
            null,
            (int) ($deletion_row['id'] ?? 0)
        );
    }

    if (is_array($failure_row)) {
        return tryzub_pipeline_make_classification_result(
            'failed_import',
            false,
            null,
            null,
            false,
            null,
            sanitize_text_field((string) ($failure_row['error_code'] ?? '')) ?: null
        );
    }

    if (is_array($duplicate_row)) {
        return tryzub_pipeline_make_classification_result(
            'duplicate_import',
            false,
            isset($duplicate_row['existing_reservation_id']) ? (int) $duplicate_row['existing_reservation_id'] : null,
            null,
            false,
            sanitize_text_field((string) ($duplicate_row['duplicate_reason'] ?? '')) ?: null
        );
    }

    if (($form_source['form_source_kind'] ?? '') === 'non_reservation_form') {
        return tryzub_pipeline_make_classification_result('non_reservation_form', false);
    }

    if (($form_source['form_source_kind'] ?? '') === 'form_source_unknown') {
        return tryzub_pipeline_make_classification_result('form_source_unknown', false);
    }

    return tryzub_pipeline_make_classification_result('unexplained_missing', false);
}

function tryzub_pipeline_make_classification_result(
    $classification,
    $is_spam_or_rejected,
    $managed_reservation_id = null,
    $managed_status = null,
    $is_hidden = false,
    $duplicate_reason = null,
    $failure_code = null,
    $deletion_audit_id = null
) {
    return [
        'classification' => $classification,
        'is_spam_or_rejected' => $is_spam_or_rejected,
        'managed_reservation_id' => $managed_reservation_id,
        'managed_status' => $managed_status,
        'is_hidden' => (bool) $is_hidden,
        'duplicate_reason' => $duplicate_reason,
        'failure_code' => $failure_code,
        'deletion_audit_id' => $deletion_audit_id ?: null,
    ];
}

function tryzub_pipeline_increment_summary(array &$summary, array $classification, array $form_source) {
    $summary['flamingo_inbound_total']++;

    if (empty($classification['is_spam_or_rejected'])) {
        $summary['flamingo_non_spam_total']++;
    }

    if (!empty($form_source['is_reservation_form'])) {
        $summary['reservation_intake_total']++;

        if (empty($classification['is_spam_or_rejected'])) {
            $summary['reservation_intake_non_spam_total']++;
        }
    }

    $map = [
        'managed_active' => 'managed_active_with_source',
        'managed_hidden' => 'managed_hidden_with_source',
        'managed_terminal' => 'managed_terminal_with_source',
        'failed_import' => 'failed_imports',
        'duplicate_import' => 'duplicate_imports',
        'hard_deleted_test_row' => 'hard_deleted',
        'unexplained_missing' => 'unexplained_missing',
        'spam_or_rejected' => 'spam_or_rejected',
        'non_reservation_form' => 'non_reservation_form',
        'form_source_unknown' => 'form_source_unknown',
    ];

    $classification_key = $classification['classification'] ?? '';

    if (isset($map[$classification_key])) {
        $summary[$map[$classification_key]]++;
    }

    if (!tryzub_pipeline_counts_toward_reconciliation($form_source, $classification)) {
        return;
    }

    if ($classification_key !== 'managed_active') {
        $summary['non_spam_reservation_intake_without_active_managed_row']++;
    }

    if (in_array($classification_key, ['managed_hidden', 'managed_terminal', 'failed_import', 'duplicate_import', 'hard_deleted_test_row'], true)) {
        $summary['explained_missing_submissions']++;
    }

    if ($classification_key === 'unexplained_missing') {
        $summary['unexplained_missing_submissions']++;
    }
}

function tryzub_pipeline_format_diagnostic_item(array $flamingo_row, array $classification, array $form_source) {
    return [
        'source_submission_id' => (int) ($flamingo_row['source_submission_id'] ?? 0),
        'submitted_at' => (string) ($flamingo_row['submitted_at'] ?? ''),
        'submission_status' => sanitize_text_field((string) ($flamingo_row['submission_status'] ?? '')) ?: null,
        'form_id' => $form_source['form_id'] ?? null,
        'form_title' => $form_source['form_title'] ?? null,
        'is_reservation_form' => (bool) ($form_source['is_reservation_form'] ?? false),
        'classification' => $classification['classification'],
        'managed_reservation_id' => $classification['managed_reservation_id'],
        'managed_status' => $classification['managed_status'],
        'is_hidden' => (bool) $classification['is_hidden'],
        'duplicate_reason' => $classification['duplicate_reason'],
        'failure_code' => $classification['failure_code'],
        'deletion_audit_id' => $classification['deletion_audit_id'] ?: null,
        'explanation' => tryzub_pipeline_diagnostics_build_explanation($classification, $form_source),
    ];
}

function tryzub_pipeline_diagnostics_build_explanation(array $classification, array $form_source) {
    switch ($classification['classification']) {
        case 'managed_active':
            return 'Managed reservation exists and is active for this Flamingo source.';
        case 'managed_hidden':
            return 'Managed reservation exists for this source but is hidden from normal staff views.';
        case 'managed_terminal':
            return 'Managed reservation exists for this source with a terminal status (cancelled, completed, or no-show).';
        case 'hard_deleted_test_row':
            return 'This source had a managed reservation, but it was hard-deleted and has a deletion audit row.';
        case 'failed_import':
            $code = $classification['failure_code'] ?: 'unknown_import_error';

            return 'Flamingo reservation-intake submission failed import (' . $code . ').';
        case 'duplicate_import':
            $reason = $classification['duplicate_reason'] ?: 'duplicate_detected';

            return 'Flamingo reservation-intake submission was skipped as a duplicate import (' . $reason . ').';
        case 'spam_or_rejected':
            return 'Flamingo submission is marked spam or rejected and is not expected to have an active managed row.';
        case 'non_reservation_form':
            return 'Flamingo submission appears to be from a non-reservation form and is not expected to create a managed reservation row.';
        case 'form_source_unknown':
            return 'Flamingo submission form source is unknown and does not match the reservation field set strongly enough to treat as a missing managed reservation.';
        case 'unexplained_missing':
        default:
            return 'Reservation-intake Flamingo submission has no managed row and no known import, duplicate, or deletion audit explanation.';
    }
}

function tryzub_pipeline_diagnostics_build_warnings(array $summary) {
    $warnings = [
        'pipeline_diagnostics_are_developer_facing_v1',
        'not_every_missing_row_is_an_operational_problem',
        'non_reservation_flamingo_forms_are_excluded_from_unexplained_missing',
    ];

    if ($summary['unexplained_missing_submissions'] > 0) {
        $warnings[] = 'unexplained_reservation_intake_submissions_present';
    }

    if ($summary['explained_missing_submissions'] > 0) {
        $warnings[] = 'some_reservation_intake_submissions_are_not_active_managed_reservations';
    }

    return array_values(array_unique($warnings));
}

function tryzub_pipeline_diagnostics_manager_message(array $summary) {
    $summary = tryzub_pipeline_finalize_summary($summary);
    $gap_count = (int) ($summary['non_spam_reservation_intake_without_active_managed_row'] ?? 0);

    if ($gap_count < 1) {
        return 'All reservation-intake form submissions in this intake range have an active managed reservation row.';
    }

    return 'Some reservation-intake form submissions are not active managed reservations. Most are explained by failed imports, duplicates, hidden rows, terminal statuses, deleted test rows, or non-reservation forms. Review developer diagnostics for details.';
}

function tryzub_pipeline_diagnostics_developer_message(array $summary) {
    $summary = tryzub_pipeline_finalize_summary($summary);
    $unexplained = (int) ($summary['unexplained_missing_submissions'] ?? 0);

    if ($unexplained < 1) {
        return 'No unexplained reservation-intake Flamingo submissions were found without an active managed reservation row in this intake range.';
    }

    return 'There are ' . $unexplained . ' unexplained reservation-intake Flamingo submissions without an active managed reservation row.';
}
